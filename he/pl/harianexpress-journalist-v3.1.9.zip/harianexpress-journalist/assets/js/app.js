// Initialize Icons
        if (window.lucide) lucide.createIcons();

                let lastArticleData = null;
        let lastSourceImages = [];

        // ---------- Definisi Prompt Dasar ----------
        const promptDefault = `{
  "role": "Asisten Jurnalistik Profesional HarianExpress.com",
  "task": "Menulis ulang artikel berita secara SANGAT AKURAT berdasarkan sumber (link atau teks) yang diberikan pengguna.",
  "input": { "source": "[Diberikan pengguna: URL, teks, atau transkrip video]" },
  "strict_accuracy_rules": { 
    "rule_1": "Bila berupa URL, WAJIB gunakan alat pencari untuk MEMBACA ISI TAUTAN tersebut secara langsung.", 
    "rule_2": "DILARANG KERAS berhalusinasi, menambahkan opini, cerita, nama tokoh, atau kejadian yang tidak terdapat dalam sumber asli. Fokus pada parafrase fakta.", 
    "rule_3": "Tulis ulang HANYA berdasarkan data mutlak dari input." 
  },
  "writing_goals": {
    "language": "Bahasa Indonesia",
    "style": "Jurnalistik profesional, lugas, jelas, dan to the point",
    "tone": "Netral, profesional, tanpa clickbait atau sensasionalisme",
    "uniqueness": "Parafrase dengan gaya sendiri HANYA menggunakan informasi dari referensi, 100% bebas halusinasi",
    "voice": "Aktif; hindari kalimat pasif",
    "length_rule": "Ikuti panjang artikel sumber, jangan dipotong"
  },
  "article_structure": {
    "headline": { "max_length": 60, "requirement": "SEO-friendly, informatif, sangat relevan dengan inti sumber" },
    "leads": {
      "max_words": 35,
      "format": "<strong>HARIANEXPRESS, [KOTA ASAL KEJADIAN DARI SUMBER]</strong> - [kalimat SPOK]. <strong>(DD/MM/YYYY)</strong>",
      "note": "KOTA dan TANGGAL wajib diambil tepat seperti dari sumber, dilarang menebak-nebak."
    },
    "body": {
      "use_headings": "Gunakan heading (H2, H3) jika sesuai untuk memecah teks",	  
	  "quotes": {
        "format": "<blockquote>\\"[KUTIPAN AKURAT SAMA PERSIS DENGAN SUMBER MENTAH]\\\" ujar [NAMA LENGKAP] ([JABATAN]) di [LOKASI], [HARI/TANGGAL].</blockquote>"
      },
      "dates_times": "Pertahankan waktu dan tanggal persis seperti di sumber, JANGAN MENGARANG."
    },
    "footer": { "references": "Sertakan link sumber referensi asli" }
  },
  "seo_requirements": {
    "slug": "Buat 3 opsi slug SEO-friendly singkat",
    "meta_description": "Buat 3-5 opsi meta deskripsi (maks 160 karakter)",
    "tags": "Minimal 10 tag relevan (tanpa tanda #) huruf kecil semua",
    "category": "Tentukan kategori / label yang relevan"
  }
}`; 
        const promptStraightNews = `{
  "role": "Professional Journalist & SEO Content Writer",
  "task": "Tulis ulang artikel berita menjadi Straight News yang SANGAT AKURAT berdasarkan tautan/sumber.",
  "strict_accuracy_rules": { 
    "rule_1": "DILARANG KERAS menambahkan fakta, cerita, tokoh, atau spekulasi baru. Hanya gunakan informasi murni yang ada di dalam referensi.",
    "rule_2": "Gunakan alat pencarian HANYA untuk mengekstrak isi teks sebenarnya dari URL yang diberikan pengguna."
  },
  "writing_goals": {
    "language_style": "Jurnalistik + Santai",
    "tone": "Netral, Objektif, Seimbang",
    "plagiarism": "100% unik dengan parafrase, tetapi TANPA mengubah esensi fakta",
    "fact_policy": "Fakta 100% WAJIB HANYA berasal dari sumber."
  },
  "journalistic_standards": {
    "mandatory_elements_lead": "lead [3W+1H maks 160 word]",
    "mandatory_elements_content": "content [5W+1H]",
    "structure": "Piramida Terbalik",
    "accuracy": "Semua fakta harus sesuai dengan sumbernya."
  },
  "article_structure": {
    "title": { "rules": ["Menarik dan informatif", "Mencerminkan isi nyata berita"] },
    "meta_description": { "max_length": 160, "rules": ["Standar jurnalistik", "Berisi intisari berita"] },
    "content": {
      "min_word_count": 350,
      "sections": ["Lead (ringkasan inti berita standar jurnalistik)", "Detail peristiwa murni dari sumber", "Kronologi peristiwa jika ada di sumber", "Dampak pihak terkait", "Gunakan <h2>/<h3> untuk subtopik penting", "Gunakan <ul><li> jika ada poin penting", "Gunakan <blockquote> untuk kutipan", "<strong> untuk kata penting"],
      "writing_style_rules": ["Gunakan bahasa santai namun profesional.", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan", "Transisi halus"]
    }
  },
  "output_format": [
    "TITLE:", 
    "SLUG: Buat 3 opsi slug",
    "META DESCRIPTION: Buat 3-5 opsi meta",
    "ARTICLE CONTENT:",
    "BUAT 10 TAG SESUAI DENGAN ARTIKEL (koma, tanpa #, huruf kecil)",
    "category: Tentukan kategori"
  ]
}`;
        const promptJurnalisHeading = `{ "role": "Jurnalis Profesional & SEO Content Writer", "task": "Menulis ulang artikel berita dengan SANGAT AKURAT sesuai link sumber yang diberikan", "strict_accuracy_rules": { "rule_1": "Bila berupa URL, gunakan tool untuk ekstraksi teks halaman tersebut", "rule_2": "JANGAN PERNAH menyertakan data, kejadian, opini, atau waktu yang tidak tercantum di dalam teks sumber" }, "writing_goals": { "language_style": "Santai", "tone": "Netral, Objektif", "fact_policy": "100% FAKTA DARI SUMBER ASLI, DILARANG MENGARANG" }, "journalistic_standards": { "mandatory_elements_lead": "lead [3W+1H maks 160 word]", "mandatory_elements_content": "content [5W+1H]", "structure": "Piramida Terbalik", "accuracy": "Semua fakta wajib sama persis dengan sumber" }, "article_structure": { "title": { "rules": ["Menarik", "Tidak clickbait", "Sesuai sumber"] }, "meta_description": { "max_length": 160, "rules": ["Intisari berita"] }, "content": { "min_word_count": 800, "sections": ["H2: Topik utama", "H3: Penjelasan detail", "Lead", "Detail peristiwa", "Kronologi (jika ada di sumber)", "Buat blockquote Pernyataan narasumber", "Bold keyword", "Bullet list bila relevan"], "writing_style_rules": ["Bahasa santai profesional", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan"] } } }`;
        const promptSeoArtikel = `{ "role": "SEO Content Writer Professional", "goal": "Membuat artikel SEO SANGAT AKURAT dari referensi pengguna", "strict_accuracy_rules": { "rule_1": "Wajib mendasarkan seluruh konten murni pada fakta di teks/URL referensi", "rule_2": "Dilarang keras berhalusinasi atau menambahkan konteks luar" }, "general_criteria": { "minimum_word_count": 1000, "language": "Bahasa Indonesia", "writing_style": "Casual / Santai", "tone": "Informatif + Solutif", "readability": "Mudah dipahami", "seo_requirements": ["SEO-friendly", "Gunakan active voice"] }, "article_structure": { "title": { "format": "H1", "requirements": ["Mengandung keyword", "SEO optimized"] }, "meta_description": { "max_length": 160, "requirements": ["Mengandung keyword", "Relevan"] }, "introduction": { "paragraphs": "2-3 paragraphs", "requirements": ["Gaya santai", "Menarik"] }, "main_content": { "heading_structure": { "H2": "Topik utama", "H3": "Penjelasan detail" }, "mandatory_elements": ["Penjelasan mendalam murni dari sumber", "Gunakan heading H2/H3", "Gunakan bullet point", "Gunakan bold/blockquote bila relevan", "Bahas sesuai fakta referensi semata"] }, "faq_section": { "minimum_questions": 5, "format": "Tanya jawab", "requirements": ["Pertanyaan relevan dengan konten", "Jawaban akurat"] }, "conclusion": { "requirements": ["Ringkas isi artikel"] } } }`;

        const promptMap = { "default": promptDefault, "straight_news": promptStraightNews, "jurnalis_heading": promptJurnalisHeading, "seo_artikel": promptSeoArtikel };

        // ---------- Skema JSON ----------
        const responseSchema = {
            type: "OBJECT",
            properties: {
                titleOptions: { type: "ARRAY", items: { type: "STRING" } },
                slugOptions: { type: "ARRAY", items: { type: "STRING" } },
                metaDescriptions: { type: "ARRAY", items: { type: "STRING" } },
                category: { type: "STRING" },
                tags: { type: "ARRAY", items: { type: "STRING" } },
                articleBody: { type: "STRING" },
                references: { type: "ARRAY", items: { type: "STRING" } }
            },
            required: ["titleOptions", "slugOptions", "metaDescriptions", "category", "tags", "articleBody", "references"]
        };

        const sosmedSchema = {
            type: "OBJECT",
            properties: {
                twitterThread: { type: "ARRAY", items: { type: "STRING" } },
                igFbCaption: { type: "STRING", description: "Caption gabungan untuk IG/FB dengan emoji dan CTA." }
            },
            required: ["twitterThread", "igFbCaption"]
        };

        const ringkasanSchema = {
            type: "OBJECT",
            properties: {
                takeaways: { type: "ARRAY", items: { type: "STRING" }, description: "3-5 poin ringkasan utama dan paling penting dari artikel" }
            },
            required: ["takeaways"]
        };

        const videoScriptSchema = {
            type: "OBJECT",
            properties: {
                visualCues: { type: "STRING", description: "Ide visual B-Roll untuk editor video" },
                hook: { type: "STRING", description: "Kalimat pembuka yang memancing perhatian (2-3 detik)" },
                body: { type: "ARRAY", items: { type: "STRING" }, description: "Isi skrip video narasi yang padat dan menarik" },
                cta: { type: "STRING", description: "Call to action di akhir video (misal: Follow HarianExpress)" }
            },
            required: ["visualCues", "hook", "body", "cta"]
        };

        // ---------- UI State Management ----------
        function setUIState(state) {
            const empty = document.getElementById('emptyState');
            const load = document.getElementById('loadingState');
            const result = document.getElementById('outputContainer');
            
            empty.classList.add('hidden'); empty.classList.remove('flex');
            load.classList.add('hidden'); load.classList.remove('flex');
            result.classList.add('hidden'); result.classList.remove('flex');

            if (state === 'empty') { empty.classList.remove('hidden'); empty.classList.add('flex'); }
            else if (state === 'loading') { load.classList.remove('hidden'); load.classList.add('flex'); }
            else if (state === 'result') { result.classList.remove('hidden'); result.classList.add('flex'); }
        }

        // ---------- Toast & Copy Utility ----------
        async function copyToClipboard(text) {
            try { await navigator.clipboard.writeText(text); return true; } 
            catch {
                const textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                try { document.execCommand('copy'); document.body.removeChild(textarea); return true; } 
                catch { document.body.removeChild(textarea); return false; }
            }
        }

        function showToast(message, isError = false) {
            const toast = document.getElementById('toast');
            const icon = document.getElementById('toastIcon');
            document.getElementById('toastMessage').textContent = message;

            if (isError) {
                toast.classList.replace('bg-slate-800', 'bg-red-600');
                icon.setAttribute('data-lucide', 'alert-circle');
            } else {
                toast.classList.replace('bg-red-600', 'bg-slate-800');
                icon.setAttribute('data-lucide', 'check-circle-2');
            }
            if (window.lucide) lucide.createIcons();
            toast.classList.remove('translate-y-24', 'opacity-0');
            setTimeout(() => toast.classList.add('translate-y-24', 'opacity-0'), 3000);
        }

        function copyTextToClipboard(text, btnElement = null) {
            copyToClipboard(text).then(success => {
                if (success) {
                    showToast("Disalin ke clipboard!");
                    if (btnElement) {
                        const originalHTML = btnElement.innerHTML;
                        btnElement.innerHTML = '<i data-lucide="check" class="w-3 h-3 text-emerald-500"></i>';
                        if (window.lucide) lucide.createIcons();
                        setTimeout(() => { btnElement.innerHTML = originalHTML; if (window.lucide) lucide.createIcons(); }, 1500);
                    }
                } else showToast("Gagal menyalin.", true);
            });
        }

        function createSelectableItem(text, container, groupName, index, isCode = false) {
            const label = document.createElement('label');
            label.className = "flex items-start gap-3 bg-white p-3 border border-slate-200 rounded-lg cursor-pointer hover:border-indigo-300 transition-colors";
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.name = groupName;
            radio.value = String(index);
            radio.className = "mt-0.5 w-4 h-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 shrink-0";
            radio.checked = index === 0;
            radio.addEventListener('change', syncSelectedSeoFields);

            const span = document.createElement(isCode ? 'code' : 'span');
            span.className = isCode ? "text-red-600 text-xs font-mono flex-1 break-all mt-0.5 bg-red-50 px-1.5 rounded" : "text-slate-700 text-xs flex-1 leading-relaxed";
            span.textContent = text;

            label.appendChild(radio);
            label.appendChild(span);
            container.appendChild(label);
        }

        function getSelectedSEOValue(type) {
            if (!lastArticleData) return '';
            const map = {
                title: ['heaj_title_option', 'titleOptions'],
                slug: ['heaj_slug_option', 'slugOptions'],
                meta: ['heaj_meta_option', 'metaDescriptions']
            };
            const config = map[type];
            if (!config) return '';
            const checked = document.querySelector(`input[name="${config[0]}"]:checked`);
            const index = checked ? parseInt(checked.value, 10) : 0;
            const values = Array.isArray(lastArticleData[config[1]]) ? lastArticleData[config[1]] : [];
            return values[index] || values[0] || '';
        }

        function syncSelectedSeoFields() {
            const selectedTitle = getSelectedSEOValue('title');
            if (selectedTitle) {
                document.getElementById('articleH1').textContent = selectedTitle;
            }
        }

        // ---------- API Caller Helper ----------
        async function fetchGeminiJSON(systemPrompt, userText, schema, useSearch = false) {
            const formData = new FormData();
            formData.append('action', 'heaj_generate_content');
            formData.append('nonce', HEAJ.nonce);
            formData.append('systemPrompt', systemPrompt);
            formData.append('userText', userText);
            formData.append('schema', JSON.stringify(schema));
            formData.append('useSearch', useSearch ? '1' : '0');
            formData.append('aiProvider', document.getElementById('aiProviderSelect')?.value || 'gemini');

            const res = await fetch(HEAJ.ajax_url, {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            });

            const payload = await res.json().catch(() => null);
            if (!res.ok || !payload || !payload.success) {
                if (payload?.data?.redirect_url) { window.location.href = payload.data.redirect_url; return; }
                const msg = payload?.data?.message || `HTTP ${res.status}`;
                throw new Error(msg);
            }
            if (payload?.data?.fallback_from && typeof showToast === 'function') {
                showToast(`Provider ${payload.data.fallback_from.toUpperCase()} gagal, otomatis fallback ke Gemini.`, false);
            }
            return payload.data.result;
        }

        // ---------- Fitur Utama: Proses Artikel ----------
        async function processArticle() {
            const sourceInput = document.getElementById('sourceInput').value.trim();
            if (!sourceInput) return showToast("Mohon masukkan tautan atau teks sumber.", true);

            const btn = document.getElementById('generateBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="loader" style="width:16px;height:16px;border-width:2px;border-top-color:white;"></div> <span class="ml-2">Memproses...</span>';
            btn.classList.replace('bg-red-600','bg-red-400');

            setUIState('loading');
            closeFeature('sosmedContainer');
            closeFeature('ringkasanContainer');
            closeFeature('videoScriptContainer');

            try {
                const selectedPromptKey = document.getElementById('promptSelect').value;
                const selectedWordCount = document.getElementById('wordCountSelect').value;
                const selectedLanguage = document.getElementById('languageSelect')?.value || 'id';
                let finalSystemPrompt = promptMap[selectedPromptKey];
                
                if (selectedWordCount) finalSystemPrompt += `\n\nINSTRUKSI TAMBAHAN: Panjang artikel wajib ${selectedWordCount}.`;
                if (selectedLanguage === 'en') {
                    finalSystemPrompt += `\n\nLANGUAGE OVERRIDE: Write ALL generated output in English, including titleOptions, slugOptions, metaDescriptions, category, tags, articleBody, takeaways, captions, and video scripts. Keep proper nouns and original quotes accurate. Use English journalistic style.`;
                } else {
                    finalSystemPrompt += `\n\nBAHASA OUTPUT: Gunakan Bahasa Indonesia untuk seluruh output.`;
                }
                if (['straight_news', 'jurnalis_heading', 'seo_artikel'].includes(selectedPromptKey)) {
                    finalSystemPrompt += `\n\nFORMAT MARKUP ARTIKEL: Untuk articleBody, gunakan markup artikel yang kaya dan rapi: <h2>, <h3>, <p>, <strong>, <blockquote>, dan <ul><li> bila relevan. Jangan mengembalikan teks polos.`;
                }
                finalSystemPrompt += `\n\nATURAN KETAT AKURASI, PARAGRAF & TANGGAL:
                1. SANGAT PENTING: DILARANG KERAS berhalusinasi. Anda HANYA BOLEH memparafrase fakta, tokoh, lokasi, dan kejadian yang BENAR-BENAR TERCANTUM di dalam sumber. Jangan mengambil info eksternal.
                2. Hasil harus format JSON dengan schema yang ditentukan.
                3. Untuk 'articleBody', WAJIB menggunakan tag <p> untuk setiap paragraf.
                4. Setiap paragraf (kecuali leads/pengantar dan blockquote/kutipan) HARUS maksimal 2 kalimat saja.
                5. Jangan gunakan <br> sebagai pemisah paragraf.
                6. PENTING UNTUK TANGGAL: Analisis dan ekstrak TANGGAL KEJADIAN secara akurat murni dari sumber teks/link. DILARANG KERAS menggunakan tanggal acak (seperti 12/05/2024 dll). Gunakan format tanggal dari sumber asli (DD/MM/YYYY).`;

                const userPrompt = `TUGAS: Tulis ulang referensi berita di bawah ini dengan akurasi fakta 100%. SANGAT DILARANG menambahkan narasi, tokoh, atau waktu fiktif yang tidak ada di sumber.\n\nSumber Referensi Utama:\n\n${sourceInput}`;

                lastArticleData = await fetchGeminiJSON(finalSystemPrompt, userPrompt, responseSchema, true);
                lastSourceImages = await fetchSourceImages(sourceInput);
                lastArticleData.sourceImages = lastSourceImages;
                
                // Injeksi Byline Penulis & Editor
                const author = document.getElementById('authorSelect').value;
                const editor = document.getElementById('editorSelect').value;
                if (author || editor) {
                    let authorPart = author ? `<b>${author}</b> <span style="font-size: x-small;">Penulis</span>` : '';
                    let editorPart = editor ? `<b>${editor}</b> <span style="font-size: x-small;">Editor</span>` : '';
                    let separator = (author && editor) ? ' | ' : '';
                    let bylineHTML = `<p class="lh-normal">${authorPart}${separator}${editorPart}</p>\n`;
                    lastArticleData.articleBody = bylineHTML + lastArticleData.articleBody;
                }
                
                renderResults(lastArticleData);
                setUIState('result');
                showToast("Artikel berhasil dibuat!");
            } catch (e) {
                console.error(e);
                setUIState('empty');
                showToast(e?.message || "Gagal memproses artikel. Coba lagi.", true);
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i data-lucide="sparkles" class="w-4 h-4"></i> Buat Artikel';
                btn.classList.replace('bg-red-400','bg-red-600');
                if (window.lucide) lucide.createIcons();
            }
        }

        // ---------- Fitur Tambahan (Ringkasan, Sosmed, Video) ----------
        function getLanguageInstruction() {
            return (document.getElementById('languageSelect')?.value === 'en')
                ? 'Write the output in English.'
                : 'Tulis output dalam Bahasa Indonesia.';
        }

        function getCleanArticleText() {
            if (!lastArticleData || !lastArticleData.articleBody) return "";
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = lastArticleData.articleBody;
            return tempDiv.textContent || tempDiv.innerText || "";
        }

        async function generateRingkasan() {
            const cleanText = getCleanArticleText();
            if (!cleanText) return showToast("Silakan buat artikel terlebih dahulu.", true);

            const btn = document.getElementById('btnRingkasan');
            const container = document.getElementById('ringkasanContainer');
            const loader = document.getElementById('ringkasanLoading');
            const content = document.getElementById('outRingkasan');

            btn.disabled = true; btn.classList.add('opacity-70');
            container.classList.remove('hidden');
            loader.classList.remove('hidden'); loader.classList.add('flex');
            content.classList.add('hidden');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });

            const sysPrompt = "Buat 3-5 poin ringkasan utama (Key Takeaways) dari artikel berita berikut. Tulis singkat, padat, dan representatif. " + getLanguageInstruction();
            
            try {
                const result = await fetchGeminiJSON(sysPrompt, `Artikel:\n${cleanText}`, ringkasanSchema);
                const ul = document.getElementById('ringkasanList');
                ul.innerHTML = '';
                result.takeaways.forEach(poin => {
                    const li = document.createElement('li');
                    li.textContent = poin;
                    ul.appendChild(li);
                });
                loader.classList.add('hidden'); loader.classList.remove('flex');
                content.classList.remove('hidden');
                showToast("Ringkasan berhasil dibuat!");
            } catch (e) {
                container.classList.add('hidden');
                showToast("Gagal menyusun ringkasan.", true);
            } finally {
                btn.disabled = false; btn.classList.remove('opacity-70');
            }
        }

        async function generateSosmed() {
            const cleanText = getCleanArticleText();
            if (!cleanText) return showToast("Silakan buat artikel terlebih dahulu.", true);

            const btn = document.getElementById('btnSosmed');
            const container = document.getElementById('sosmedContainer');
            const loader = document.getElementById('sosmedLoading');
            const content = document.getElementById('sosmedContent');

            btn.disabled = true; btn.classList.add('opacity-70');
            container.classList.remove('hidden');
            loader.classList.remove('hidden'); loader.classList.add('flex');
            content.classList.add('hidden'); content.classList.remove('grid');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });

            const sysPrompt = `Berdasarkan isi artikel berita yang diberikan, buatkan draft postingan sosial media yang menarik, interaktif, dan sesuai dengan gaya bahasa jurnalistik santai khas HarianExpress.
            1. twitterThread: Buat utas (thread) Twitter/X singkat yang terdiri dari 3-4 tweet bersambung.
            2. igFbCaption: Buat caption gabungan yang dioptimalkan untuk Instagram dan Facebook sekaligus. Sertakan emoji, berikan pertanyaan untuk diskusi audiens, dan hashtags relevan.
            ${getLanguageInstruction()}`;

            try {
                const sosmedData = await fetchGeminiJSON(sysPrompt, `Artikel:\n${cleanText}`, sosmedSchema);

                const twContainer = document.getElementById('outTwitter');
                twContainer.innerHTML = '';
                sosmedData.twitterThread.forEach((tweet, index) => {
                    const p = document.createElement('p');
                    p.className = "pb-2 mb-2 border-b border-indigo-50 last:border-0 last:mb-0 last:pb-0";
                    p.innerHTML = `<strong>${index + 1}/</strong> ${tweet}`;
                    twContainer.appendChild(p);
                });

                document.getElementById('outIgFb').innerText = sosmedData.igFbCaption;

                loader.classList.add('hidden'); loader.classList.remove('flex');
                content.classList.remove('hidden'); content.classList.add('grid');
                showToast("Draft sosial media berhasil dibuat!");
            } catch (error) {
                container.classList.add('hidden');
                showToast("Gagal membuat draft sosmed.", true);
            } finally {
                btn.disabled = false; btn.classList.remove('opacity-70');
            }
        }

        async function generateVideoScript() {
            const cleanText = getCleanArticleText();
            if (!cleanText) return showToast("Silakan buat artikel terlebih dahulu.", true);

            const btn = document.getElementById('btnVideoScript');
            const container = document.getElementById('videoScriptContainer');
            const loader = document.getElementById('videoScriptLoading');
            const content = document.getElementById('outVideoScript');

            btn.disabled = true; btn.classList.add('opacity-70');
            container.classList.remove('hidden');
            loader.classList.remove('hidden'); loader.classList.add('flex');
            content.classList.add('hidden');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });

            const sysPrompt = `Konversi artikel berita ini menjadi skrip video vertikal singkat (TikTok/Instagram Reels/Shorts) berdurasi 30-60 detik. 
            Gunakan gaya bahasa yang LUGAS, TEGAS, dan KHAS JURNALISTIK PROFESIONAL (Straight News). Sampaikan fakta secara langsung, to the point, namun tetap ringkas untuk format video pendek. Pisahkan ke dalam JSON: 
            - visualCues: Arahan visual/B-roll untuk editor.
            - hook: Kalimat pembuka yang tegas dan langsung membidik inti berita (0-3 detik).
            - body: Array isi cerita (voiceover) yang padat fakta (5W+1H) tanpa basa-basi.
            - cta: Ajak penonton memberikan tanggapan atau follow HarianExpress.
            ${getLanguageInstruction()}`;

            try {
                const scriptData = await fetchGeminiJSON(sysPrompt, `Artikel:\n${cleanText}`, videoScriptSchema);

                document.getElementById('outVideoVisuals').innerText = scriptData.visualCues;
                document.getElementById('outVideoHook').innerText = `"${scriptData.hook}"`;
                
                const bodyContainer = document.getElementById('outVideoBody');
                bodyContainer.innerHTML = '';
                scriptData.body.forEach(paragraf => {
                    const p = document.createElement('p');
                    p.className = "mb-1";
                    p.textContent = paragraf;
                    bodyContainer.appendChild(p);
                });
                
                document.getElementById('outVideoCta').innerText = scriptData.cta;

                loader.classList.add('hidden'); loader.classList.remove('flex');
                content.classList.remove('hidden');
                showToast("Skrip video berhasil dibuat!");
            } catch (e) {
                container.classList.add('hidden');
                showToast("Gagal menyusun skrip video.", true);
            } finally {
                btn.disabled = false; btn.classList.remove('opacity-70');
            }
        }

        function closeFeature(containerId) {
            document.getElementById(containerId).classList.add('hidden');
        }



        async function fetchSourceImages(sourceInput) {
            const hasUrl = /https?:\/\//i.test(sourceInput || '');
            if (!hasUrl) return [];
            const formData = new FormData();
            formData.append('action', 'heaj_fetch_source_images');
            formData.append('nonce', HEAJ.nonce);
            formData.append('source', sourceInput);
            try {
                const res = await fetch(HEAJ.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                const payload = await res.json().catch(() => null);
                if (!res.ok || !payload || !payload.success) return [];
                return Array.isArray(payload.data?.images) ? payload.data.images : [];
            } catch (e) {
                console.warn('Gagal mengambil gambar sumber', e);
                return [];
            }
        }

        function renderSourceImages(images = []) {
            const section = document.getElementById('sourceImagesSection');
            const grid = document.getElementById('sourceImagesGrid');
            const count = document.getElementById('sourceImagesCount');
            if (!section || !grid) return;
            grid.innerHTML = '';
            const cleanImages = Array.isArray(images) ? images.filter(item => item && item.url) : [];
            if (count) count.textContent = `${cleanImages.length} gambar`;
            if (!cleanImages.length) {
                section.classList.add('hidden');
                return;
            }
            cleanImages.forEach((item, index) => {
                const card = document.createElement('div');
                card.className = 'border border-slate-200 rounded-xl overflow-hidden bg-slate-50 shadow-sm';
                const image = document.createElement('img');
                image.src = item.url;
                image.alt = `Gambar sumber ${index + 1}`;
                image.loading = 'lazy';
                image.className = 'w-full h-36 object-cover bg-slate-100';
                const body = document.createElement('div');
                body.className = 'p-3 space-y-2';
                const source = document.createElement('p');
                source.className = 'text-[10px] text-slate-500 truncate';
                source.textContent = item.source || item.url;
                const actions = document.createElement('div');
                actions.className = 'flex items-center gap-2';
                const copyBtn = document.createElement('button');
                copyBtn.type = 'button';
                copyBtn.className = 'flex-1 inline-flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-semibold px-3 py-2 rounded-lg transition';
                copyBtn.innerHTML = '<i data-lucide="copy" class="w-3 h-3"></i> Copy Link';
                copyBtn.onclick = () => copyTextToClipboard(item.url, copyBtn);
                const download = document.createElement('a');
                download.href = item.url;
                download.target = '_blank';
                download.rel = 'noopener noreferrer';
                download.download = '';
                download.className = 'inline-flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-semibold px-3 py-2 rounded-lg transition';
                download.innerHTML = '<i data-lucide="download" class="w-3 h-3"></i> Download';
                actions.appendChild(copyBtn);
                actions.appendChild(download);
                body.appendChild(source);
                body.appendChild(actions);
                card.appendChild(image);
                card.appendChild(body);
                grid.appendChild(card);
            });
            section.classList.remove('hidden');
            if (window.lucide) lucide.createIcons();
        }

        // ---------- Render UI ----------
        function renderResults(data) {
            document.getElementById('badgeCategory').textContent = data.category;
            const pName = document.getElementById('promptSelect').options[document.getElementById('promptSelect').selectedIndex].text;
            const wCount = document.getElementById('wordCountSelect').value;
            const lang = document.getElementById('languageSelect')?.value === 'en' ? 'English' : 'Indonesia';
            document.getElementById('promptLabel').textContent = `Format: ${pName}${wCount ? ' (' + wCount + ')' : ''} • ${lang}`;

            const containers = {
                title: document.getElementById('outTitleOptions'),
                slug: document.getElementById('outSlugs'),
                meta: document.getElementById('outMeta')
            };
            
            containers.title.innerHTML = '';
            data.titleOptions.forEach((t, index) => createSelectableItem(t, containers.title, 'heaj_title_option', index, false));
            document.getElementById('articleH1').textContent = data.titleOptions[0] || "Judul Artikel";

            containers.slug.innerHTML = '';
            data.slugOptions.forEach((slug, index) => createSelectableItem(slug, containers.slug, 'heaj_slug_option', index, true));

            containers.meta.innerHTML = '';
            data.metaDescriptions.forEach((meta, index) => createSelectableItem(meta, containers.meta, 'heaj_meta_option', index, false));

            const tagsContainer = document.getElementById('outTags');
            tagsContainer.innerHTML = '';
            const cleanedTags = data.tags.map(t => t.replace(/^#+/, '').trim());
            cleanedTags.forEach(tag => {
                const chip = document.createElement('span');
                chip.className = "bg-indigo-50 text-indigo-700 border border-indigo-100 px-3 py-1 rounded-full text-xs shadow-sm";
                chip.textContent = tag;
                tagsContainer.appendChild(chip);
            });

            document.getElementById('articleContent').innerHTML = data.articleBody || "<p>Data isi artikel kosong.</p>";
            const wordCount = document.getElementById('articleContent').innerText.trim().split(/\s+/).length;
            document.getElementById('wordCountDisplay').innerHTML = `<i data-lucide="bar-chart-2" class="w-3 h-3 inline mr-1"></i> ${wordCount} kata`;

            const refList = document.getElementById('outReferences');
            if (refList) {
                refList.innerHTML = '';
                if (Array.isArray(data.references)) {
                    data.references.forEach(ref => {
                        const li = document.createElement('li');
                        li.className = "truncate flex items-center gap-2";
                        const refText = String(ref || '').trim();
                        if (/^https?:\/\//i.test(refText)) {
                            const a = document.createElement('a');
                            a.href = refText;
                            a.target = '_blank';
                            a.rel = 'noopener noreferrer';
                            a.className = 'hover:underline hover:text-blue-800 transition-colors';
                            a.textContent = refText;
                            const icon = document.createElement('span');
                            icon.innerHTML = '<i data-lucide="link" class="w-3 h-3 text-blue-400 shrink-0"></i>';
                            li.appendChild(icon);
                            li.appendChild(a);
                        } else if (refText) {
                            li.textContent = refText;
                        }
                        if (refText) refList.appendChild(li);
                    });
                }
            }
            toggleReferencesVisibility();
            renderSourceImages(data.sourceImages || lastSourceImages || []);

            if (window.lucide) lucide.createIcons();
            localStorage.setItem('heaj_last_article', JSON.stringify(data));
        }

        function toggleReferencesVisibility() {
            const refSection = document.getElementById('referencesSection');
            if (!refSection) return;
            const checked = document.querySelector('input[name="showSource"]:checked');
            const showRef = !checked || checked.value === 'yes';
            const hasRefs = lastArticleData && Array.isArray(lastArticleData.references) && lastArticleData.references.length > 0;
            if (showRef && hasRefs) refSection.classList.remove('hidden');
            else refSection.classList.add('hidden');
        }

        function copyArticleHTML(btnElement = null) {
            if (!lastArticleData || !lastArticleData.articleBody) {
                showToast('Silakan buat artikel terlebih dahulu.', true);
                return;
            }
            const title = getSelectedSEOValue('title') || (document.getElementById('articleH1')?.textContent || 'Artikel HarianExpress');
            const content = document.getElementById('articleContent')?.innerHTML || lastArticleData.articleBody || '';
            const html = `<h1>${escapeHTML(title)}</h1>
${content}`;
            copyTextToClipboard(html, btnElement);
        }

        function escapeHTML(value) {
            return String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function copyAllSEOData() {
            if (!lastArticleData) return showToast("Tidak ada data untuk disalin.", true);
            const bundle = `Judul:\n${getSelectedSEOValue('title')}\n\nSlug:\n${getSelectedSEOValue('slug')}\n\nMeta Deskripsi:\n${getSelectedSEOValue('meta')}\n\nTags:\n${lastArticleData.tags.map(t=>t.replace(/^#+/,'').trim()).join(', ')}`;
            copyTextToClipboard(bundle, document.getElementById('btnCopyAllSEO'));
        }

        function copyElementText(elementId, btnElement) {
            const el = document.getElementById(elementId);
            const range = document.createRange();
            range.selectNodeContents(el);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            try {
                document.execCommand('copy');
                sel.removeAllRanges();
                showToast("Berhasil disalin!");
                if(btnElement) {
                    const orig = btnElement.innerHTML;
                    btnElement.innerHTML = '<i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i> Disalin!';
                    if (window.lucide) lucide.createIcons();
                    setTimeout(()=> { btnElement.innerHTML = orig; if (window.lucide) lucide.createIcons(); }, 2000);
                }
            } catch { showToast("Gagal menyalin.", true); }
        }



        // ---------- Kirim ke Draft WordPress ----------
        function setDraftStatus(message, isError = false, editUrl = '') {
            const status = document.getElementById('draftStatus');
            if (!status) return;
            status.classList.remove('hidden', 'bg-emerald-50', 'border-emerald-200', 'text-emerald-700', 'bg-red-50', 'border-red-200', 'text-red-700');
            status.classList.add(isError ? 'bg-red-50' : 'bg-emerald-50', isError ? 'border-red-200' : 'border-emerald-200', isError ? 'text-red-700' : 'text-emerald-700');
            status.innerHTML = editUrl ? `${message} <a class="underline font-bold" href="${editUrl}" target="_blank" rel="noopener">Edit draft</a>` : message;
        }

        async function sendToWordPressDraft() {
            if (!lastArticleData || !lastArticleData.articleBody) {
                showToast('Silakan buat artikel terlebih dahulu.', true);
                return;
            }
            const btn = document.getElementById('btnAddDraft');
            if (!btn) return;
            const original = btn.innerHTML;
            btn.disabled = true;
            btn.classList.add('opacity-70');
            btn.innerHTML = '<div class="loader" style="width:16px;height:16px;border-width:2px;border-top-color:white;"></div> <span class="ml-2">Mengirim ke Draft...</span>';

            const title = getSelectedSEOValue('title') || (document.getElementById('articleH1')?.textContent || 'Artikel HarianExpress');
            const slug = getSelectedSEOValue('slug');
            const meta = getSelectedSEOValue('meta');
            const tags = (lastArticleData.tags || []).map(t => String(t).replace(/^#+/, '').trim()).filter(Boolean).join(', ');

            const formData = new FormData();
            formData.append('action', 'he_create_draft');
            formData.append('nonce', HEAJ.nonce);
            formData.append('title', title);
            formData.append('slug', slug);
            formData.append('meta', meta);
            formData.append('content', lastArticleData.articleBody);
            formData.append('category', lastArticleData.category || '');
            formData.append('tags', tags);

            try {
                const res = await fetch(HEAJ.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                const payload = await res.json().catch(() => null);
                if (!res.ok || !payload || !payload.success) {
                    if (payload?.data?.redirect_url) { window.location.href = payload.data.redirect_url; return; }
                    throw new Error(payload?.data?.message || `HTTP ${res.status}`);
                }
                showToast('Draft WordPress berhasil dibuat!');
                setDraftStatus('Draft berhasil dibuat.', false, payload.data?.edit_url || '');
            } catch (e) {
                showToast(e?.message || 'Gagal membuat draft.', true);
                setDraftStatus(e?.message || 'Gagal membuat draft.', true);
            } finally {
                btn.disabled = false;
                btn.classList.remove('opacity-70');
                btn.innerHTML = original;
                if (window.lucide) lucide.createIcons();
            }
        }

        function resetAll() {
            document.getElementById('sourceInput').value = '';
            setUIState('empty');
            closeFeature('sosmedContainer');
            closeFeature('ringkasanContainer');
            closeFeature('videoScriptContainer');
            renderSourceImages([]);
            localStorage.removeItem('heaj_last_article');
            lastArticleData = null;
            showToast("Ruang kerja dibersihkan.");
        }

        function initAiProviderSelect() {
            const select = document.getElementById('aiProviderSelect');
            const help = document.getElementById('aiProviderHelp');
            if (!select) return;
            const providers = (window.HEAJ && HEAJ.providers) ? HEAJ.providers : { gemini: 1, grok: 0, zai: 0 };
            Array.from(select.options).forEach(option => {
                const key = option.value;
                const count = parseInt(providers[key] || 0, 10);
                option.disabled = count <= 0;
                if (count <= 0) option.textContent = option.textContent.replace(/ \(belum ada API\)$/,'') + ' (belum ada API)';
            });
            if (select.selectedOptions[0]?.disabled) {
                const firstEnabled = Array.from(select.options).find(o => !o.disabled);
                if (firstEnabled) select.value = firstEnabled.value;
            }
            const updateHelp = () => {
                const label = select.options[select.selectedIndex]?.textContent || 'AI';
                const count = parseInt(providers[select.value] || 0, 10);
                if (help) help.textContent = `${label.replace(' (belum ada API)','')} aktif dengan ${count} API key.`;
            };
            select.addEventListener('change', updateHelp);
            updateHelp();
        }

        // Restore state on load
        window.addEventListener('load', () => {
            initAiProviderSelect();
            const saved = localStorage.getItem('heaj_last_article');
            if (saved) {
                try {
                    lastArticleData = JSON.parse(saved);
                    renderResults(lastArticleData);
                    setUIState('result');
                } catch { localStorage.removeItem('heaj_last_article'); }
            }
        });
        

        const draftBtn = document.getElementById('btnAddDraft');
        if (draftBtn) draftBtn.addEventListener('click', sendToWordPressDraft);

        document.querySelectorAll('input[name="showSource"]').forEach(radio => radio.addEventListener('change', toggleReferencesVisibility));

        document.getElementById('btnCopyCategory').onclick = function() {
            if (lastArticleData) copyTextToClipboard(lastArticleData.category, this.querySelector('i'));
        }
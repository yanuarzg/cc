<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$settings = is_array( $settings ?? null ) ? $settings : HE_Journalist_Pro_Tools::default_auto_news_settings();
$next_run = wp_next_scheduled( HE_Journalist_Pro_Tools::AUTO_NEWS_CRON_HOOK );
$last_run = absint( $last_run ?? 0 );
$last_result = is_array( $last_result ?? null ) ? $last_result : [];
$custom_settings = $this->get_custom_settings();
$langs = is_array( $custom_settings['languages'] ?? null ) ? $custom_settings['languages'] : [ [ 'code' => 'id', 'label' => 'Bahasa Indonesia' ], [ 'code' => 'en', 'label' => 'English' ] ];
$author_id = absint( $settings['author_user_id'] ?? 0 );
$author = $author_id ? get_userdata( $author_id ) : null;
$auto_news_author_users = is_array( $auto_news_author_users ?? null ) ? $auto_news_author_users : [];
$selected_author_id = $author_id ?: get_current_user_id();
$auto_news_license_valid = ! empty( $auto_news_license_valid );
$keyword_status_rows = is_array( $keyword_status_rows ?? null ) ? $keyword_status_rows : [];
$queue = is_array( $queue ?? null ) ? $queue : [];
$queue_counts = [ 'queued' => 0, 'retry' => 0, 'processing' => 0, 'published' => 0, 'drafted' => 0, 'skipped_no_image' => 0, 'failed' => 0 ];
foreach ( $queue as $job ) {
    $st = sanitize_key( $job['status'] ?? '' );
    if ( isset( $queue_counts[ $st ] ) ) { $queue_counts[ $st ]++; }
}
$keyword_done_count = 0;
foreach ( $keyword_status_rows as $row ) {
    if ( ! empty( $row['done'] ) ) { $keyword_done_count++; }
}
$keyword_total_count = count( $keyword_status_rows );
?>
<div class="wrap heaj-admin-wrap">
    <h1 class="wp-heading-inline">Auto Artikel</h1>
    <p class="description">Auto Artikel memiliki tiga metode utama: Google Trends, Global Trends, dan Manual Keyword.</p>

    <?php if ( ! $auto_news_license_valid ) : ?>
        <div class="notice notice-error"><p><strong>Lisensi belum valid.</strong> Fitur Auto Artikel dikunci sampai lisensi aktif pada domain ini.</p></div>
    <?php endif; ?>

    <?php if ( isset( $_GET['saved'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p>Pengaturan Auto Artikel disimpan.</p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['kwreset'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p>Status keyword manual berhasil direset.</p></div>
    <?php endif; ?>

    <div class="heaj-card" style="max-width:980px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:22px;margin-top:16px;">
        <h2 style="margin-top:0;">Pilih Fungsi Auto Artikel</h2>
        <form id="heajAutoArticleForm" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'heaj_save_auto_news' ); ?>
            <input type="hidden" name="action" value="heaj_save_auto_news">
            <input type="hidden" name="auto_news[enabled]" value="1">
            <input type="hidden" name="auto_news[keyword_pick_mode]" value="sequential">
            <input type="hidden" name="auto_news[keywords_per_run]" value="1">
            <input type="hidden" name="auto_news[keyword_cycle_reset]" value="0">

            <fieldset <?php disabled( ! $auto_news_license_valid ); ?> style="border:0;margin:0;padding:0;">
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;margin:18px 0;">
                    <label style="display:block;border:1px solid #dcdcde;border-radius:12px;padding:16px;background:#f8fafc;cursor:pointer;">
                        <input type="radio" name="auto_news[feed_mode]" value="google_trends" <?php checked( $settings['feed_mode'] ?? 'google_trends', 'google_trends' ); ?>>
                        <strong style="display:block;margin-top:6px;font-size:15px;">Feeds Google Trends</strong>
                        <span class="description" style="display:block;margin-top:6px;">Menggunakan prompt model <strong>Rewrite Default Jurnalis</strong>. Sumber wajib bisa diakses dan wajib punya image valid.</span>
                    </label>

                    <label style="display:block;border:1px solid #dcdcde;border-radius:12px;padding:16px;background:#f8fafc;cursor:pointer;">
                        <input type="radio" name="auto_news[feed_mode]" value="global_trends" <?php checked( $settings['feed_mode'] ?? 'google_trends', 'global_trends' ); ?>>
                        <strong style="display:block;margin-top:6px;font-size:15px;">Global Trends</strong>
                        <span class="description" style="display:block;margin-top:6px;">Mengambil feed dari <code>trendhunter.com/rss</code>. Sumber wajib bisa diakses dan wajib punya image valid.</span>
                    </label>

                    <label style="display:block;border:1px solid #dcdcde;border-radius:12px;padding:16px;background:#f8fafc;cursor:pointer;">
                        <input type="radio" name="auto_news[feed_mode]" value="manual_keywords" <?php checked( $settings['feed_mode'] ?? 'google_trends', 'manual_keywords' ); ?>>
                        <strong style="display:block;margin-top:6px;font-size:15px;">Keyword Manual</strong>
                        <span class="description" style="display:block;margin-top:6px;">Menggunakan prompt model <strong>Target SEO Page 1</strong>. Gambar diambil dari Pexels API, satu keyword per siklus.</span>
                    </label>
                </div>

                <div id="heajAutoKeywordBox" style="display:<?php echo ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'manual_keywords' ) ? 'block' : 'none'; ?>;margin:14px 0 18px;">
                    <label style="display:block;">
                        <strong>Keyword manual multi-keyword</strong><br>
                        <textarea name="auto_news[manual_keywords]" rows="5" class="large-text code" placeholder="Contoh:&#10;politik indonesia&#10;harga emas&#10;persib, persija, timnas indonesia"><?php echo esc_textarea( $settings['manual_keywords'] ?? '' ); ?></textarea>
                        <span class="description">Pisahkan keyword dengan baris baru atau koma. Sistem memproses berurutan dari keyword pertama, satu keyword setiap jadwal atau setiap klik Mulai Sekarang.</span>
                    </label>

                    <div style="margin-top:14px;border:1px solid #dcdcde;border-radius:10px;padding:14px;background:#f8fafc;">
                        <h3 style="margin:0 0 8px;">Status Keyword Manual</h3>
                        <p style="margin:0 0 10px;"><strong><?php echo esc_html( $keyword_done_count ); ?></strong> dari <strong><?php echo esc_html( $keyword_total_count ); ?></strong> keyword sudah berhasil dibuat. Jika seluruh keyword sudah selesai, jadwal Auto Artikel akan dihentikan otomatis.</p>
                        <?php if ( ! empty( $keyword_status_rows ) ) : ?>
                            <table class="widefat striped" style="margin-top:8px;">
                                <thead><tr><th>Keyword</th><th>Status</th><th>Artikel</th><th>Waktu</th></tr></thead>
                                <tbody>
                                    <?php foreach ( $keyword_status_rows as $row ) : ?>
                                        <tr>
                                            <td><code><?php echo esc_html( $row['keyword'] ?? '' ); ?></code></td>
                                            <td><?php echo ! empty( $row['done'] ) ? '<span style="color:#008a20;font-weight:600;">Sudah dibuat</span>' : '<span style="color:#8a6d00;font-weight:600;">Belum</span>'; ?></td>
                                            <td>
                                                <?php if ( ! empty( $row['url'] ) ) : ?>
                                                    <a href="<?php echo esc_url( $row['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $row['title'] ?: ( 'Post #' . absint( $row['post_id'] ?? 0 ) ) ); ?></a>
                                                    <br><small>Status post: <?php echo esc_html( $row['status'] ?? '' ); ?></small>
                                                <?php else : ?>
                                                    —
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo ! empty( $row['time'] ) ? esc_html( wp_date( 'Y-m-d H:i:s', absint( $row['time'] ) ) ) : '—'; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else : ?>
                            <p class="description">Belum ada daftar keyword yang bisa ditampilkan.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div id="heajAutoProxyBox" style="display:<?php echo ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'manual_keywords' ) ? 'none' : 'block'; ?>;border:1px solid #dcdcde;border-radius:12px;padding:16px;margin:14px 0 18px;background:#fff;">
                    <h3 style="margin-top:0;">Proxy RSS Google Trends / Global Trends</h3>
                    <textarea name="auto_news[feed_proxy_urls]" rows="3" class="large-text code" placeholder="Contoh: https://website-yang-bisa-baca-rss.com/wp-json/heaj-auto-artikel/v1/rss-proxy?url={url}"><?php echo esc_textarea( $settings['feed_proxy_urls'] ?? '' ); ?></textarea>
                    <p class="description">Opsional. Isi URL proxy RSS jika IP hosting website ini diblokir/rate-limit oleh Google Trends atau TrendHunter. Proxy mendukung placeholder <code>{url}</code>; jika tidak ada, plugin akan menambahkan parameter <code>?url=...</code>.</p>
                    <p class="description">Plugin ini juga menyediakan endpoint proxy bawaan di website yang lisensinya valid: <code><?php echo esc_html( rest_url( 'heaj-auto-artikel/v1/rss-proxy?url={url}' ) ); ?></code></p>
                </div>

                <div style="border:1px solid #dcdcde;border-radius:12px;padding:16px;margin:14px 0 18px;background:#fff;">
                    <h3 style="margin-top:0;">Jadwal Auto Posting</h3>
                    <div id="heajAutoGtSchedule" style="display:<?php echo ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'manual_keywords' ) ? 'none' : 'block'; ?>;">
                        <strong>Jadwal Google Trends / Global Trends</strong>
                        <label style="display:block;margin:8px 0;"><input type="radio" name="auto_news[gt_schedule_type]" value="realtime" <?php checked( $settings['gt_schedule_type'] ?? 'realtime', 'realtime' ); ?>> Realtime</label>
                        <label style="display:block;margin:8px 0;"><input type="radio" name="auto_news[gt_schedule_type]" value="hours" <?php checked( $settings['gt_schedule_type'] ?? 'realtime', 'hours' ); ?>> Setiap xx jam</label>
                        <label style="display:block;margin:8px 0;"><input type="radio" name="auto_news[gt_schedule_type]" value="days" <?php checked( $settings['gt_schedule_type'] ?? 'realtime', 'days' ); ?>> Setiap xx hari</label>
                        <label style="display:block;margin:8px 0 0 24px;">Nilai xx: <input type="number" min="1" max="30" name="auto_news[gt_schedule_value]" value="<?php echo esc_attr( absint( $settings['gt_schedule_value'] ?? 1 ) ); ?>" style="width:74px;"></label>
                    </div>
                    <div id="heajAutoKwSchedule" style="display:<?php echo ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'manual_keywords' ) ? 'block' : 'none'; ?>;">
                        <strong>Jadwal Keyword Manual</strong>
                        <label style="display:block;margin:8px 0;"><input type="radio" name="auto_news[kw_schedule_type]" value="minutes" <?php checked( $settings['kw_schedule_type'] ?? 'hours', 'minutes' ); ?>> Setiap xx menit</label>
                        <label style="display:block;margin:8px 0;"><input type="radio" name="auto_news[kw_schedule_type]" value="hours" <?php checked( $settings['kw_schedule_type'] ?? 'hours', 'hours' ); ?>> Setiap xx jam</label>
                        <label style="display:block;margin:8px 0;"><input type="radio" name="auto_news[kw_schedule_type]" value="days" <?php checked( $settings['kw_schedule_type'] ?? 'hours', 'days' ); ?>> Setiap xx hari</label>
                        <label style="display:block;margin:8px 0 0 24px;">Nilai xx: <input type="number" min="1" max="30" name="auto_news[kw_schedule_value]" value="<?php echo esc_attr( absint( $settings['kw_schedule_value'] ?? 1 ) ); ?>" style="width:74px;"></label>
                    </div>
                </div>

                <label style="display:block;margin:14px 0 18px;max-width:360px;">
                    <strong>Bahasa Artikel</strong><br>
                    <select name="auto_news[language]" class="regular-text">
                        <?php foreach ( $langs as $lang_row ) :
                            $code = sanitize_key( $lang_row['code'] ?? '' );
                            if ( ! in_array( $code, [ 'id', 'en' ], true ) ) { continue; }
                        ?>
                            <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $settings['language'] ?? 'id', $code ); ?>><?php echo esc_html( $lang_row['label'] ?? strtoupper( $code ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label style="display:block;margin:14px 0 18px;max-width:420px;">
                    <strong>Profil Penulis</strong><br>
                    <select name="auto_news[author_user_id]" class="regular-text">
                        <?php if ( empty( $auto_news_author_users ) ) : ?>
                            <option value="<?php echo esc_attr( get_current_user_id() ); ?>"><?php echo esc_html( wp_get_current_user()->display_name ); ?></option>
                        <?php else : ?>
                            <?php foreach ( $auto_news_author_users as $user_row ) : ?>
                                <option value="<?php echo esc_attr( absint( $user_row->ID ) ); ?>" <?php selected( $selected_author_id, absint( $user_row->ID ) ); ?>><?php echo esc_html( $user_row->display_name . ' (@' . $user_row->user_login . ') #' . $user_row->ID ); ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <span class="description" style="display:block;margin-top:4px;">Artikel auto akan memakai profil penulis yang dipilih, bukan otomatis user yang terakhir menyimpan pengaturan.</span>
                </label>
            </fieldset>

            <p class="submit" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                <button type="submit" class="button button-primary" <?php disabled( ! $auto_news_license_valid ); ?>>Simpan &amp; Aktifkan Auto Artikel</button>
                <button type="button" id="heajAutoRunNowBtn" class="button button-secondary" <?php disabled( ! $auto_news_license_valid ); ?>>Mulai Sekarang</button>
                <span id="heajAutoRunSpinner" class="spinner" style="float:none;margin:0;"></span>
            </p>
            <div id="heajAutoRunFeedback" style="display:none;margin-top:10px;padding:12px;border-left:4px solid #2271b1;background:#f6f7f7;"></div>
        </form>
        <?php if ( $auto_news_license_valid ) : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
                <?php wp_nonce_field( 'heaj_auto_news_reset_keywords' ); ?>
                <input type="hidden" name="action" value="heaj_auto_news_reset_keywords">
                <button type="submit" class="button button-link-delete" onclick="return confirm('Reset status keyword manual? Keyword yang sudah dibuat akan dianggap belum diproses lagi.');">Reset Status Keyword Manual</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="heaj-card" style="max-width:980px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px;margin-top:16px;">
        <h2 style="margin-top:0;">Status Singkat</h2>
        <p><strong>Next cron:</strong> <?php echo $next_run ? esc_html( wp_date( 'Y-m-d H:i:s', $next_run ) ) : 'Belum terjadwal'; ?></p>
        <p><strong>Last run selesai:</strong> <?php echo $last_run ? esc_html( wp_date( 'Y-m-d H:i:s', $last_run ) ) : 'Belum pernah tercatat'; ?></p>
        <?php if ( ! empty( $last_result ) ) : ?>
            <p><strong>Hasil terakhir:</strong>
                checked <?php echo esc_html( absint( $last_result['checked'] ?? 0 ) ); ?>,
                queued <?php echo esc_html( absint( $last_result['queued_now'] ?? 0 ) ); ?>,
                processed <?php echo esc_html( absint( $last_result['processed_queue'] ?? 0 ) ); ?>,
                created <?php echo esc_html( absint( $last_result['created'] ?? 0 ) ); ?>,
                skipped <?php echo esc_html( absint( $last_result['skipped'] ?? 0 ) ); ?>,
                failed <?php echo esc_html( absint( $last_result['failed'] ?? 0 ) ); ?>
            </p>
            <?php
                $heaj_last_error = '';
                if ( ! empty( $last_result['last_error'] ) ) { $heaj_last_error = (string) $last_result['last_error']; }
                elseif ( ! empty( $last_result['worker']['last_error'] ) ) { $heaj_last_error = (string) $last_result['worker']['last_error']; }
            ?>
            <?php if ( ! empty( $last_result['message'] ) ) : ?>
                <p><strong>Pesan:</strong> <?php echo esc_html( $last_result['message'] ); ?></p>
            <?php endif; ?>
            <?php if ( $heaj_last_error !== '' ) : ?>
                <p><strong>Error terakhir:</strong> <?php echo esc_html( $heaj_last_error ); ?></p>
            <?php endif; ?>
        <?php endif; ?>
        <p><strong>Queue:</strong>
            queued <?php echo esc_html( absint( $queue_counts['queued'] ) ); ?>,
            retry <?php echo esc_html( absint( $queue_counts['retry'] ) ); ?>,
            processing <?php echo esc_html( absint( $queue_counts['processing'] ) ); ?>,
            drafted <?php echo esc_html( absint( $queue_counts['drafted'] ) ); ?>,
            published <?php echo esc_html( absint( $queue_counts['published'] ) ); ?>,
            skipped <?php echo esc_html( absint( $queue_counts['skipped_no_image'] ) ); ?>,
            failed <?php echo esc_html( absint( $queue_counts['failed'] ) ); ?>
        </p>
        <p class="description">Halaman admin tidak menjalankan Auto Artikel. Trigger aktif hanya jadwal cron/heartbeat non-admin dan tombol Mulai Sekarang.</p>
    </div>
</div>
<script>
(function(){
    function syncAutoArticleMode(){
        var mode = document.querySelector('input[name="auto_news[feed_mode]"]:checked');
        var isKeyword = mode && mode.value === 'manual_keywords';
        var keywordBox = document.getElementById('heajAutoKeywordBox');
        var gtSchedule = document.getElementById('heajAutoGtSchedule');
        var kwSchedule = document.getElementById('heajAutoKwSchedule');
        var proxyBox = document.getElementById('heajAutoProxyBox');
        if (keywordBox) keywordBox.style.display = isKeyword ? 'block' : 'none';
        if (gtSchedule) gtSchedule.style.display = isKeyword ? 'none' : 'block';
        if (kwSchedule) kwSchedule.style.display = isKeyword ? 'block' : 'none';
        if (proxyBox) proxyBox.style.display = isKeyword ? 'none' : 'block';
    }
    document.querySelectorAll('input[name="auto_news[feed_mode]"]').forEach(function(el){ el.addEventListener('change', syncAutoArticleMode); });
    syncAutoArticleMode();

    var runBtn = document.getElementById('heajAutoRunNowBtn');
    var form = document.getElementById('heajAutoArticleForm');
    var feedback = document.getElementById('heajAutoRunFeedback');
    var spinner = document.getElementById('heajAutoRunSpinner');
    function setFeedback(type, html){
        if (!feedback) return;
        feedback.style.display = 'block';
        feedback.style.borderLeftColor = type === 'error' ? '#d63638' : (type === 'success' ? '#00a32a' : '#2271b1');
        feedback.innerHTML = html;
    }
    if (runBtn && form) {
        runBtn.addEventListener('click', function(){
            var data = new FormData(form);
            data.set('action', 'heaj_auto_news_run_now_ui');
            data.set('nonce', '<?php echo esc_js( wp_create_nonce( 'heaj_auto_news_run_now_ui' ) ); ?>');
            runBtn.disabled = true;
            if (spinner) spinner.classList.add('is-active');
            setFeedback('info', '<strong>Memulai Auto Artikel...</strong><br>Menyimpan pengaturan, membaca feed/keyword, memasukkan item ke queue, lalu memproses 1 artikel. Mohon tunggu, proses AI/scrape bisa memakan waktu.');
            fetch(window.ajaxurl || ajaxurl, { method: 'POST', credentials: 'same-origin', body: data })
                .then(function(res){ return res.json(); })
                .then(function(json){
                    var ok = json && json.success;
                    var payload = ok ? json.data : (json && json.data ? json.data : {});
                    var result = payload.result || {};
                    var html = '<strong>' + (payload.message || (ok ? 'Proses selesai.' : 'Proses gagal.')) + '</strong>';
                    html += '<br>Checked: ' + (result.checked || 0) + ', queued: ' + (result.queued_now || 0) + ', processed: ' + (result.processed_queue || 0) + ', created: ' + (result.created || 0) + ', skipped: ' + (result.skipped || 0) + ', failed: ' + (result.failed || 0) + '.';
                    if (result.worker && result.worker.message) html += '<br>Worker: ' + result.worker.message;
                    setFeedback(ok && (result.created || 0) > 0 ? 'success' : (ok ? 'info' : 'error'), html);
                })
                .catch(function(err){
                    setFeedback('error', '<strong>Proses gagal dijalankan.</strong><br>' + (err && err.message ? err.message : 'Request error.'));
                })
                .finally(function(){
                    runBtn.disabled = false;
                    if (spinner) spinner.classList.remove('is-active');
                });
        });
    }
})();
</script>

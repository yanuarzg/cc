<?php
if (!defined('ABSPATH')) { exit; }
?>
<div id="heaj-app" class="heaj-wrap heaj-v340 text-slate-800 antialiased min-h-screen flex flex-col">
<!-- Header -->
    <header class="heaj-hero he-generator-hero text-white relative z-10">
        <div class="he-generator-hero-inner max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
            <div class="he-generator-brand">
                <?php if ( ! empty( $brand_settings['logo_url'] ) ) : ?><img class="he-white-label-logo" src="<?php echo esc_url( $brand_settings['logo_url'] ); ?>" alt="<?php echo esc_attr( $brand_settings['brand_name'] ?? 'Logo' ); ?>"><?php endif; ?>
                <div>
                    <h1 class="he-generator-title"><?php echo esc_html( $brand_settings['brand_name'] ?? 'YZG AI Journalist' ); ?> <span>Pro Tools</span></h1>
                    <p class="he-generator-subtitle"><?php echo esc_html( $brand_settings['brand_voice'] ?? 'Tulis ulang berita berbasis sumber, kunci data penting, siapkan SEO, lalu kirim ke Draft WordPress.' ); ?></p>
                    <p class="he-generator-version">Versi <?php echo esc_html( HE_Journalist_Pro_Tools::VERSION ); ?></p>
                </div>
            </div>
            <div class="he-generator-pills">
                <span><i data-lucide="shield-check" class="w-3.5 h-3.5"></i> Fact-lock</span>
                <span><i data-lucide="sparkles" class="w-3.5 h-3.5"></i> Multi AI</span>
                <span><i data-lucide="send" class="w-3.5 h-3.5"></i> Draft Ready</span>
            </div>
        </div>
    </header>

    <!-- Main Content -->

    <?php if ( empty( $has_any_ai_provider ) ) : ?>
    <section class="heaj-no-api-alert max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-5 w-full">
        <div class="heaj-no-api-card">
            <div class="heaj-no-api-icon"><i data-lucide="key-round" class="w-5 h-5"></i></div>
            <div>
                <strong>Tidak ada API key terdaftar</strong>
                <p>Tambahkan minimal satu API key Gemini, Grok/xAI, Groq, atau Z.AI agar generator artikel bisa digunakan.</p>
            </div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=he-journalist-settings' ) ); ?>" class="heaj-no-api-btn">Pengaturan API</a>
        </div>
    </section>
    <?php endif; ?>
    <section class="heaj-workflow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 w-full">
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div class="heaj-flow-card">
                <span class="heaj-flow-icon"><i data-lucide="link" class="w-4 h-4"></i></span>
                <div><strong>1. Sumber</strong><small>Tempel URL atau teks berita</small></div>
            </div>
            <div class="heaj-flow-card">
                <span class="heaj-flow-icon"><i data-lucide="shield-check" class="w-4 h-4"></i></span>
                <div><strong>2. Validasi Fakta</strong><small>Tanggal, angka & kutipan dikunci</small></div>
            </div>
            <div class="heaj-flow-card">
                <span class="heaj-flow-icon"><i data-lucide="send" class="w-4 h-4"></i></span>
                <div><strong>3. Draft</strong><small>Pilih SEO lalu kirim ke WordPress</small></div>
            </div>
        </div>
    </section>

    <main class="heaj-main flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        <!-- Left Column: Input -->
        <div class="heaj-sidebar lg:col-span-5 flex flex-col gap-6">
            <div class="heaj-panel bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden transition-shadow hover:shadow-md">
                <div class="border-b border-slate-100 bg-slate-50/80 px-5 py-4 flex items-center gap-2">
                    <div class="bg-red-100 p-1.5 rounded-lg text-red-600"><i data-lucide="file-edit" class="w-4 h-4"></i></div>
                    <h2 class="font-semibold text-slate-800">Mau Nulis Berita Apa?</h2>
                </div>
                
                <div class="p-5 flex flex-col gap-5">
                    <!-- Input Referensi -->
                    <div>
                        <div class="flex flex-col mb-2">
                            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Topik/Sumber Berita</label>
                        </div>
                        <div class="he-source-tools flex items-center gap-2 mb-3">
                            <a href="https://trends.google.com/trending?geo=ID&amp;status=active&amp;hours=4" target="_blank" rel="noopener noreferrer" class="he-source-tool-link" title="Google Trends Indonesia">
                                <i data-lucide="chart-no-axes-combined" class="w-4 h-4"></i><span>Trends</span>
                            </a>
                            <a href="https://news.google.com/home?hl=id" target="_blank" rel="noopener noreferrer" class="he-source-tool-link" title="Google News">
                                <i data-lucide="newspaper" class="w-4 h-4"></i><span>News</span>
                            </a>
                            <a href="https://www.msn.com/id-id" target="_blank" rel="noopener noreferrer" class="he-source-tool-link" title="MSN Indonesia">
                                <i data-lucide="globe-2" class="w-4 h-4"></i><span>Msn</span>
                            </a>
                        </div>
                        <textarea id="sourceInput" rows="5" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm input-ring transition-colors resize-none" placeholder="Paste link sumber artikel di sini... (semakin banyak semakin joss)"><?php echo isset( $_GET['heaj_restore_source'] ) ? esc_textarea( wp_unslash( $_GET['heaj_restore_source'] ) ) : ''; ?></textarea>
                    </div>

                    <!-- Pengaturan Terpadu -->
                    <div class="he-control-panel">
                        <details class="he-control-collapse">
                            <summary class="he-control-head">
                                <div class="he-control-title-wrap">
                                    <span class="he-control-icon"><i data-lucide="sliders-horizontal" class="w-4 h-4"></i></span>
                                    <div>
                                        <h3>Pengaturan Konten</h3>
                                    </div>
                                </div>
                                <span class="he-collapse-indicator"><i data-lucide="chevron-down" class="w-4 h-4"></i></span>
                            </summary>
                            <div class="he-control-collapse-body">

                        <div class="he-control-divider"></div>

                        <label class="he-ai-card" for="aiProviderSelect">
                            <div class="he-ai-copy">
                                <span class="he-ai-icon"><i data-lucide="cpu" class="w-5 h-5"></i></span>
                                <div>
                                    <span class="he-ai-label">Pilih AI</span>
                                    <strong id="heSelectedAIName">Gemini</strong>
                                    <small id="aiProviderHelp">Pilihan AI mengikuti API key yang tersedia.</small>
                                </div>
                            </div>
                            <select id="aiProviderSelect" class="he-select he-ai-select">
                                <option value="gemini">Gemini</option>
                                <option value="grok">Grok / xAI</option>
                                <option value="groqcloud">Groq</option>
                                <option value="zai">Z.AI</option>
                                <option value="openrouter">OpenRouter</option>
                            </select>
                        </label>

                        <div class="he-control-divider"></div>

                        <label class="he-field-card he-field-full" for="promptSelect">
                            <span class="he-field-top"><span class="he-field-icon"><i data-lucide="newspaper" class="w-4 h-4"></i></span><span>Gaya Penulisan (prompt)</span></span>
                            <select id="promptSelect" class="he-select">
                                    <?php foreach ( ( $this->get_custom_settings()['prompts'] ?? [] ) as $prompt_row ) : ?>
                                        <option value="<?php echo esc_attr( $prompt_row['key'] ?? '' ); ?>"><?php echo esc_html( $prompt_row['label'] ?? '' ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                        </label>

                        <div class="he-control-divider"></div>

                        <div class="he-control-grid he-control-grid-2 he-control-compact-row">
                            <label class="he-field-card" for="wordCountSelect">
                                <span class="he-field-top"><span class="he-field-icon"><i data-lucide="align-left" class="w-4 h-4"></i></span><span>Panjang</span></span>
                                <select id="wordCountSelect" class="he-select">
                                    <?php foreach ( ( $this->get_custom_settings()['lengths'] ?? [] ) as $length_row ) : ?>
                                        <option value="<?php echo esc_attr( $length_row['value'] ?? '' ); ?>"><?php echo esc_html( $length_row['label'] ?? '' ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>

                            <label class="he-field-card" for="languageSelect">
                                <span class="he-field-top"><span class="he-field-icon"><i data-lucide="languages" class="w-4 h-4"></i></span><span>Bahasa</span></span>
                                <select id="languageSelect" class="he-select">
                                    <?php foreach ( ( $this->get_custom_settings()['languages'] ?? [] ) as $lang_row ) : ?>
                                        <option value="<?php echo esc_attr( $lang_row['code'] ?? '' ); ?>" <?php selected( ( $lang_row['code'] ?? '' ), $default_language_code ?? 'id' ); ?>><?php echo esc_html( $lang_row['label'] ?? '' ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                        </div>

                        <div class="he-control-divider"></div>
                            </div>
                        </details>

                        <div class="he-control-grid he-control-grid-2 he-control-compact-row">
                            <label class="he-field-card" for="authorSelect">
                                <span class="he-field-top"><span class="he-field-icon"><i data-lucide="pen-line" class="w-4 h-4"></i></span><span>Penulis</span><em>Opsional</em></span>
                                <select id="authorSelect" class="he-select">
                                    <option value="">-- Kosong --</option>
                                    <?php foreach ( ( $author_names ?? [] ) as $name ) : ?>
                                        <option value="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>

                            <label class="he-field-card" for="editorSelect">
                                <span class="he-field-top"><span class="he-field-icon"><i data-lucide="check-square" class="w-4 h-4"></i></span><span>Editor</span><em>Opsional</em></span>
                                <select id="editorSelect" class="he-select">
                                    <option value="">-- Kosong --</option>
                                    <?php foreach ( ( $editor_names ?? [] ) as $name ) : ?>
                                        <option value="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                        </div>

                        <div class="hidden items-center justify-between bg-white border border-slate-200 p-2.5 rounded-lg">
                            <span class="text-xs font-medium text-slate-600">Sertakan Sumber Referensi?</span>
                            <div class="flex gap-4">
                                <label class="flex items-center gap-1.5 text-sm text-slate-700 cursor-pointer">
                                    <input type="radio" name="showSource" value="yes" checked class="w-3.5 h-3.5 text-red-600 focus:ring-red-500 border-gray-300"> Ya
                                </label>
                                <label class="flex items-center gap-1.5 text-sm text-slate-700 cursor-pointer">
                                    <input type="radio" name="showSource" value="no" class="w-3.5 h-3.5 text-red-600 focus:ring-red-500 border-gray-300"> Tidak
                                </label>
                            </div>
                        </div>

                        <div class="he-control-divider"></div>

                        <button id="generateBtn" onclick="processArticle()" class="heaj-primary-btn w-full text-white font-semibold py-3 px-4 rounded-xl transition-all shadow-sm hover:shadow active:scale-[0.98] flex items-center justify-center gap-2">
                            <i data-lucide="sparkles" class="w-4 h-4"></i> Buat Artikel
                        </button>
                    </div>
                </div>

                <!-- Guidelines Info -->
                <div class="heaj-guide-card rounded-xl p-4 m-5 mt-0 flex gap-3">
                    <i data-lucide="info" class="w-5 h-5 text-indigo-500 shrink-0 mt-0.5"></i>
                    <div>
                        <h3 class="text-sm font-semibold text-indigo-900 mb-1">Serba Otomatis ke WordPress!</h3>
                        <p class="text-xs text-indigo-700 leading-relaxed">
                            Auto ke Draft WordPress Kategori, Judul, Slug, Meta Deskripsi, Tags, Penulis & Editor, dan Isi Artikel. Bonus Ringkasan, Video Script hingga Draft Sosmed!
                        </p>
                    </div>
                </div>

            </div>
        </div>

        <!-- Right Column: Output -->
        <div class="heaj-output lg:col-span-7 flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 relative min-h-[600px] h-fit overflow-hidden">
            
            <!-- Output Header -->
            <div class="heaj-output-toolbar border-b border-slate-100 bg-slate-50/80 px-5 py-3 flex items-center justify-between z-10 rounded-t-xl">
                <div class="flex items-center gap-3">
                    <button id="btnCopyCategory" class="flex items-center gap-1.5 bg-red-100 hover:bg-red-200 transition-colors px-3 py-1 rounded-full group focus:outline-none" title="Copy Kategori">
                        <span id="badgeCategory" class="text-red-700 text-[11px] font-bold uppercase tracking-wider">Kategori</span>
                        <i data-lucide="copy" class="w-3 h-3 text-red-600 opacity-60 group-hover:opacity-100"></i>
                    </button>
                    <select id="existingCategorySelect" class="he-category-select text-[11px] border border-slate-200 bg-white text-slate-600 rounded-full px-2 py-1 focus:outline-none focus:ring-2 focus:ring-red-100" title="Pilih kategori yang sudah ada">
                        <option value="">Kategori tersedia</option>
                        <?php foreach ( get_categories( [ 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ] ) as $heaj_cat ) : ?>
                            <option value="<?php echo esc_attr( $heaj_cat->name ); ?>"><?php echo esc_html( $heaj_cat->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span class="text-xs text-slate-400 font-medium border-l border-slate-300 pl-3" id="promptLabel">Hasil Generator</span>
                </div>
                <button id="btnReset" onclick="resetAll()" class="text-slate-400 hover:text-red-600 hover:bg-red-50 p-1.5 rounded-md transition-colors flex items-center gap-1.5 text-xs font-medium" title="Reset Halaman">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Reset
                </button>
            </div>

            <!-- Area Tampilan -->
            <div class="heaj-output-body relative flex-grow flex flex-col p-6">
                
                <!-- 1. EMPTY STATE -->
                <div id="emptyState" class="absolute inset-0 flex flex-col items-center justify-center p-12 text-center bg-white z-20 rounded-b-xl">
                    <div class="bg-slate-50 border border-slate-100 p-5 rounded-full mb-4 text-slate-300">
                        <i data-lucide="layout-template" class="w-10 h-10"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-slate-700">Ruang Kerja Kosong</h3>
                    <p class="text-slate-500 text-sm max-w-sm mt-2 leading-relaxed">Isi form referensi di panel sebelah kiri dan klik <strong>Buat Artikel</strong> untuk memulai pembuatan artikel oleh AI ini.</p>
                </div>

                <!-- 2. LOADING STATE -->
                <div id="loadingState" class="hidden absolute inset-0 flex-col items-center justify-center p-8 text-center bg-white/95 backdrop-blur z-20 rounded-b-xl">
                    <div class="loader mb-5"></div>
                    <h3 class="text-base font-bold text-slate-800">Menyusun Naskah...</h3>
                    <p id="heajLoadingStepText" class="text-slate-500 text-sm max-w-sm mt-2 leading-relaxed animate-pulse">Membaca sumber...</p>
                    <div class="heaj-loading-steps mt-6" aria-label="Progress generate">
                        <span class="heaj-loading-step is-active">1. Sumber</span>
                        <span class="heaj-loading-step">2. Fakta</span>
                        <span class="heaj-loading-step">3. Tulis</span>
                        <span class="heaj-loading-step">4. Media</span>
                        <span class="heaj-loading-step">5. Draft</span>
                    </div>
                </div>

                <!-- 3. RESULT STATE -->
                <div id="outputContainer" class="hidden flex-col w-full h-auto">
                    
                    <!-- Meta Data Box -->
                    <div class="heaj-meta-card mb-8 p-5 rounded-xl text-sm shadow-sm relative">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-2">
                            <div>
                                <h4 class="font-semibold text-slate-700 mb-2 text-[10px] uppercase tracking-wider opacity-80">Pilihan SEO Title</h4>
                                <div id="outTitleOptions" class="space-y-2"></div>
                            </div>
                            <div>
                                <h4 class="font-semibold text-slate-700 mb-2 text-[10px] uppercase tracking-wider opacity-80">Pilihan Slug</h4>
                                <div id="outSlugs" class="space-y-2"></div>
                            </div>
                        </div>
                        <div class="mt-5">
                            <h4 class="font-semibold text-slate-700 mb-2 text-[10px] uppercase tracking-wider opacity-80">Meta Deskripsi / Post Subtitle (Max 160 Karakter)</h4>
                            <div id="outMeta" class="space-y-2"></div>
                        </div>
                        <div class="mt-5">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="font-semibold text-slate-700 text-[10px] uppercase tracking-wider opacity-80">Tags Relevan</h4>
                            </div>
                            <div id="outTags" class="flex flex-wrap gap-2 text-sm text-slate-700 bg-white p-3 border border-slate-200 rounded-lg leading-relaxed">
                                <!-- Chip tags -->
                            </div>
                        </div>
                    </div>

                    <!-- Source Images -->
                    <div id="sourceImagesSection" class="hidden heaj-image-card mb-8 p-5 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <div>
                                <h4 class="font-semibold text-slate-800 text-sm flex items-center gap-2"><i data-lucide="image" class="w-4 h-4 text-indigo-500"></i> Gambar dari Sumber</h4>
                                <p class="text-[11px] text-slate-500 mt-1">Preview image yang terdeteksi dari link referensi. Tetap cek hak pakai gambar sebelum publish.</p>
                            </div>
                            <span id="sourceImagesCount" class="text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-1 rounded-full">0</span>
                        </div>
                        <div id="sourceImagesGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"></div>
                        <div id="manualImageUploadBox" class="he-manual-image-upload mt-4 border border-dashed border-slate-300 rounded-xl bg-white p-4">
                            <label for="manualImageUpload" class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 cursor-pointer">
                                <span>
                                    <strong class="block text-xs text-slate-700">Upload gambar tambahan sendiri</strong>
                                    <small class="block text-[11px] text-slate-500 mt-1">Gambar manual ikut dipilih sebagai featured/sisipan, lalu otomatis resize dan compress saat dikirim ke Draft.</small>
                                </span>
                                <span class="heaj-secondary-btn text-xs px-3 py-2 rounded-lg inline-flex items-center gap-2 justify-center"><i data-lucide="upload" class="w-3.5 h-3.5"></i> Upload Image</span>
                            </label>
                            <input id="manualImageUpload" type="file" accept="image/jpeg,image/png,image/webp" multiple class="hidden">
                        </div>
                    </div>

                    <!-- Editorial Fact Audit -->
                    <div id="factAuditSection" class="hidden heaj-audit-card mb-8 p-5 rounded-xl shadow-sm">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
                            <div>
                                <h4 class="font-semibold text-slate-800 text-sm flex items-center gap-2"><i data-lucide="shield-check" class="w-4 h-4"></i> Audit Fakta Sebelum Draft</h4>
                                <p class="text-[11px] text-slate-500 mt-1">Pemeriksaan awal: kutipan, tanggal, jam, angka, sumber URL, dan mode parafrase.</p>
                            </div>
                            <button type="button" onclick="toggleSourceCompare()" class="heaj-secondary-btn text-xs px-3 py-2 rounded-lg inline-flex items-center justify-center gap-2">
                                <i data-lucide="columns-2" class="w-3.5 h-3.5"></i> Compare
                            </button>
                        </div>
                        <div id="factAuditList" class="heaj-audit-list"></div>
                        <div id="factAuditMissing" class="heaj-audit-missing mt-3"></div>
                    </div>

                    <!-- Source Compare -->
                    <div id="sourceCompareSection" class="hidden heaj-compare-card mb-8 p-5 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <h4 class="font-semibold text-slate-800 text-sm flex items-center gap-2"><i data-lucide="columns-2" class="w-4 h-4"></i> Bandingkan dengan Sumber</h4>
                            <button type="button" onclick="toggleSourceCompare()" class="text-slate-400 hover:text-slate-700"><i data-lucide="x" class="w-4 h-4"></i></button>
                        </div>
                        <div class="heaj-compare-grid">
                            <div><strong>Sumber hasil ekstraksi</strong><pre id="sourceCompareOriginal"></pre></div>
                            <div><strong>Hasil rewrite</strong><pre id="sourceCompareArticle"></pre></div>
                        </div>
                    </div>


                    <!-- Article Info Bar -->
                    <div class="heaj-preview-bar flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4 border border-slate-100 bg-slate-50 rounded-xl p-3">
                        <div class="flex items-center gap-3">
                            <span class="inline-flex w-8 h-8 items-center justify-center rounded-lg bg-slate-900 text-white"><i data-lucide="newspaper" class="w-4 h-4"></i></span>
                            <div>
                                <h3 class="text-sm font-bold text-slate-800 leading-tight">Pratinjau Artikel</h3>
                                <p class="text-[11px] text-slate-500">Cek judul, tanggal, kutipan, angka, dan nama narasumber sebelum publish.</p>
                            </div>
                        </div>
                        <span id="wordCountDisplay" class="text-[10px] font-medium text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-1 rounded-full w-fit flex"></span>
                    </div>

                    <!-- Article Body Area -->
                    <div class="heaj-article-card bg-white py-4 mb-8">
                        <h1 id="articleH1" class="text-2xl sm:text-3xl font-bold text-slate-900 mb-6 leading-tight article-font"></h1>
                        <div id="articleContent" class="prose max-w-none article-font text-justify text-slate-700"></div>
                    </div>



                    <!-- References -->
                    <div id="referencesSection" class="mb-8 pt-6 border-t border-slate-200 bg-slate-50 rounded-xl p-5 border border-slate-100 hidden">
                        <h4 class="font-semibold text-slate-700 mb-3 flex items-center gap-2 text-sm">
                            <i data-lucide="link-2" class="w-4 h-4 text-slate-400"></i> Sumber &amp; Referensi Otomatis
                        </h4>
                        <ul id="outReferences" class="space-y-2 text-xs text-blue-600 break-words"></ul>
                    </div>



                    <!-- Editorial Quality Score -->
                    <div id="editorialScoreSection" class="hidden heaj-score-card mb-8 p-5 rounded-xl shadow-sm">
                        <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                            <div>
                                <h4 class="font-semibold text-slate-800 text-sm flex items-center gap-2"><i data-lucide="gauge" class="w-4 h-4"></i> Quality Score Artikel</h4>
                                <p class="text-[11px] text-slate-500 mt-1">Skor awal berdasarkan kelengkapan SEO, struktur artikel, kecocokan fakta, dan tingkat kemiripan narasi.</p>
                            </div>
                            <div class="heaj-score-badge" id="qualityScoreBadge">0</div>
                        </div>
                        <div class="heaj-score-meter mt-4"><span id="qualityScoreBar"></span></div>
                        <div id="qualityScoreDetails" class="heaj-score-details mt-4"></div>
                        <div id="duplicationPanel" class="heaj-dup-panel mt-4">
                            <div>
                                <strong id="duplicationLabel">Kemiripan narasi: -</strong>
                                <span id="duplicationInfo">Menunggu hasil perhitungan.</span>
                            </div>
                            <button id="btnParaphraseAgain" type="button" onclick="regenerateParaphraseNarrative()" class="heaj-secondary-btn text-xs px-3 py-2 rounded-lg inline-flex items-center justify-center gap-2 hidden">
                                <i data-lucide="wand-sparkles" class="w-3.5 h-3.5"></i> Parafrase Ulang
                            </button>
                        </div>
                    </div>


                    <!-- Send to WordPress Draft -->
                    <div class="heaj-action-row mb-8 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
                        <button id="btnCopyArticleHtml" type="button" onclick="copyArticleHTML(this)" class="bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold px-5 py-3 rounded-xl transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                            <i data-lucide="copy" class="w-4 h-4"></i> HTML
                        </button>
                        <button id="btnAddDraft" type="button" class="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-5 py-3 rounded-xl transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                            <i data-lucide="send" class="w-4 h-4"></i> Draft
                        </button>
                        <div id="draftStatus" class="hidden text-xs font-medium px-3 py-2 rounded-lg border"></div>
                    </div>



                    <!-- Peringatan Redaksi -->
                    <div id="heajWarningCard" class="heaj-warning-card mb-8 rounded-xl p-5 flex gap-4 shadow-sm relative overflow-hidden">
                        <div class="absolute -right-4 -top-4 opacity-[0.03] pointer-events-none">
                            <i data-lucide="shield-alert" class="w-32 h-32 text-red-900"></i>
                        </div>
                        <div class="bg-red-200/50 p-2 rounded-full h-fit shrink-0 text-red-600">
                            <i data-lucide="alert-triangle" class="w-5 h-5"></i>
                        </div>
                        <div class="relative z-10 flex-1">
                            <h3 class="text-sm font-bold text-red-800 mb-2.5 tracking-wide">Pentingnya keakuratan berita!</h3>
                            <ul class="text-xs text-red-700 leading-relaxed list-disc list-outside ml-4 space-y-1.5">
                                <li><strong>AI dapat membuat kesalahan.</strong> Selalu periksa ulang fakta, kutipan, nama, tanggal, angka, dan sumber sebelum publish.</li>
                                <li>Demi menjamin keakuratan berita dan kredibilitas <?php echo esc_html( $media_name ?? ( wp_parse_url( home_url(), PHP_URL_HOST ) ?: get_bloginfo( 'name' ) ) ); ?>, selalu lakukan pengecekan isi artikel dan sumber yang diberikan.</li>
                                <li>“Setiap Orang dengan sengaja dan tanpa hak menyebarkan berita bohong dan menyesatkan yang mengakibatkan kerugian konsumen dalam Transaksi Elektronik.” <span class="font-semibold">| Pasal 28 Ayat (1) UU ITE</span></li>
                                <li>Ancaman pidana bagi pelanggar Pasal 28 Ayat (1), Penjara maksimal <strong>6 tahun</strong> dan/atau denda maksimal <strong>Rp1 miliar</strong> <span class="font-semibold">| Pasal 45A Ayat (1) UU 19/2016</span></li>
                                <?php if ( ! empty( $brand_settings['warning_text'] ) ) : ?><li><?php echo esc_html( $brand_settings['warning_text'] ); ?></li><?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- Ekstra Fitur Gemini Buttons -->
                    <div class="heaj-extra-card pt-6">
                        <h3 class="text-sm font-bold text-slate-800 mb-3">Fitur Ekstra</h3>
                        <div class="flex flex-wrap items-center gap-2 w-full">
                            <button id="btnRingkasan" onclick="generateRingkasan()" class="heaj-extra-outline-btn flex-1 sm:flex-none text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center justify-center gap-2">
                                <i data-lucide="list-checks" class="w-3.5 h-3.5"></i> Ringkasan Cepat
                            </button>
                            <button id="btnSosmed" onclick="generateSosmed()" class="heaj-extra-outline-btn flex-1 sm:flex-none text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center justify-center gap-2">
                                <i data-lucide="share-2" class="w-3.5 h-3.5"></i> Draft Sosmed
                            </button>
                            <button id="btnSosmedImage" onclick="generateSocialImages()" class="heaj-extra-outline-btn flex-1 sm:flex-none text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center justify-center gap-2">
                                <i data-lucide="image-plus" class="w-3.5 h-3.5"></i> Image Sosmed
                            </button>
                            <button id="btnVideoScript" onclick="generateVideoScript()" class="heaj-extra-outline-btn flex-1 sm:flex-none text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center justify-center gap-2">
                                <i data-lucide="video" class="w-3.5 h-3.5"></i> Skrip TikTok/Reels
                            </button>
                        </div>
                    </div>

                    <!-- Fitur Baru 1: Hasil Ringkasan -->
                    <div id="ringkasanContainer" class="hidden heaj-feature-result heaj-feature-green mt-8 rounded-xl p-5 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="font-bold text-emerald-900 flex items-center gap-2 text-sm">
                                <i data-lucide="list-checks" class="w-4 h-4 text-emerald-600"></i> Poin Utama Berita (Key Takeaways)
                            </h4>
                            <div class="flex items-center gap-2">
                                <button onclick="copyElementText('outRingkasan', this)" class="text-emerald-600 hover:text-emerald-800 transition-colors text-xs font-semibold flex items-center gap-1">
                                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy
                                </button>
                                <span class="text-emerald-200">|</span>
                                <button onclick="closeFeature('ringkasanContainer')" class="text-emerald-400 hover:text-emerald-700 transition-colors" title="Tutup Panel">
                                    <i data-lucide="x" class="w-4 h-4"></i>
                                </button>
                            </div>
                        </div>

                        <div id="ringkasanLoading" class="hidden flex-col items-center justify-center py-6">
                            <div class="loader-ringkasan mb-3"></div>
                            <span class="text-xs font-medium text-emerald-600">AI sedang mengekstrak ringkasan...</span>
                        </div>

                        <div id="outRingkasan" class="hidden">
                            <ul id="ringkasanList" class="list-disc list-outside ml-4 space-y-2 text-sm text-slate-700 marker:text-emerald-500">
                                <!-- Ringkasan di-render di sini -->
                            </ul>
                        </div>
                    </div>

                    <!-- Fitur Baru 2: Hasil Social Media Kit -->
                    <div id="sosmedContainer" class="hidden heaj-feature-result heaj-feature-indigo mt-8 rounded-xl p-5 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="font-bold text-indigo-900 flex items-center gap-2 text-sm">
                                <i data-lucide="share-2" class="w-4 h-4 text-indigo-500"></i> Social Media Kit
                            </h4>
                            <button onclick="closeFeature('sosmedContainer')" class="text-indigo-400 hover:text-indigo-700 transition-colors" title="Tutup Panel">
                                <i data-lucide="x" class="w-4 h-4"></i>
                            </button>
                        </div>

                        <!-- Loading Sosmed -->
                        <div id="sosmedLoading" class="hidden flex-col items-center justify-center py-6">
                            <div class="loader-sosmed mb-3"></div>
                            <span class="text-xs font-medium text-indigo-600">AI sedang menyusun draft sosmed...</span>
                        </div>

                        <!-- Content Sosmed -->
                        <div id="sosmedContent" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- Twitter -->
                            <div class="bg-white border border-indigo-100 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-bold text-slate-700 flex items-center gap-1.5">Twitter Thread</span>
                                    <button onclick="copyElementText('outTwitter', this)" class="text-indigo-600 hover:bg-indigo-50 p-1 rounded transition text-xs"><i data-lucide="copy" class="w-3 h-3"></i></button>
                                </div>
                                <div id="outTwitter" class="text-xs text-slate-600 space-y-3 whitespace-pre-wrap"></div>
                            </div>
                            
                            <!-- IG & FB combined -->
                            <div class="bg-white border border-indigo-100 rounded-lg p-4 h-fit">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                                        IG &amp; FB Caption
                                    </span>
                                    <button onclick="copyElementText('outIgFb', this)" class="text-indigo-600 hover:bg-indigo-50 p-1 rounded transition text-xs"><i data-lucide="copy" class="w-3 h-3"></i></button>
                                </div>
                                <div id="outIgFb" class="text-xs text-slate-600 whitespace-pre-wrap leading-relaxed"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Fitur Baru 2B: Social Media Image Generator -->
                    <div id="sosmedImageContainer" class="hidden heaj-feature-result heaj-feature-sosmed-image mt-8 rounded-xl p-5 shadow-sm">
                        <div class="heaj-sosmed-image-toolbar mb-4">
                            <div>
                                <h4 class="font-bold text-slate-900 flex items-center gap-2 text-sm">
                                    <i data-lucide="image-plus" class="w-4 h-4 text-red-600"></i> Social Media Image
                                </h4>
                                <p class="text-[11px] text-slate-500 mt-1">Generate otomatis image sosial media dengan AI yang dipilih di Article Generator. Jika AI terpilih gagal/tidak mendukung image, sistem otomatis memakai GD Fallback Lokal.</p>
                            </div>
                            <div class="heaj-sosmed-image-toolbar-actions shrink-0">
                                <button onclick="generateSocialImages()" class="heaj-sosmed-image-copy-all text-xs font-semibold inline-flex items-center gap-1.5 px-3 py-2 rounded-lg">
                                    <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> Generate Ulang
                                </button>
                                <button onclick="copySocialImagePromptBundle(this)" class="heaj-sosmed-image-copy-all text-xs font-semibold inline-flex items-center gap-1.5 px-3 py-2 rounded-lg" title="Copy prompt untuk dipakai di AI lain">
                                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy Prompt
                                </button>
                                <button onclick="closeFeature('sosmedImageContainer')" class="text-slate-400 hover:text-slate-700 transition-colors" title="Tutup Panel">
                                    <i data-lucide="x" class="w-4 h-4"></i>
                                </button>
                            </div>
                        </div>
                        <div id="sosmedImageLoading" class="hidden items-center justify-center py-8 text-xs font-semibold text-red-600 gap-2">
                            <span class="loader-mini"></span> Membuat image sosial media dengan AI terpilih...
                        </div>
                        <div id="sosmedImagePromptGrid" class="heaj-sosmed-image-grid"></div>
                    </div>

                    <!-- Fitur Baru 3: Hasil Skrip Video -->
                    <div id="videoScriptContainer" class="hidden heaj-feature-result heaj-feature-rose mt-8 rounded-xl p-5 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="font-bold text-rose-900 flex items-center gap-2 text-sm">
                                <i data-lucide="video" class="w-4 h-4 text-rose-600"></i> Skrip Video Vertikal (TikTok/Reels/Shorts)
                            </h4>
                            <div class="flex items-center gap-2">
                                <button onclick="copyElementText('outVideoScript', this)" class="text-rose-600 hover:text-rose-800 transition-colors text-xs font-semibold flex items-center gap-1">
                                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy Skrip
                                </button>
                                <span class="text-rose-200">|</span>
                                <button onclick="closeFeature('videoScriptContainer')" class="text-rose-400 hover:text-rose-700 transition-colors" title="Tutup Panel">
                                    <i data-lucide="x" class="w-4 h-4"></i>
                                </button>
                            </div>
                        </div>

                        <div id="videoScriptLoading" class="hidden flex-col items-center justify-center py-6">
                            <div class="loader-video mb-3"></div>
                            <span class="text-xs font-medium text-rose-600">AI sedang menulis naskah video...</span>
                        </div>

                        <div id="outVideoScript" class="hidden bg-white border border-rose-100 rounded-lg p-5">
                            <div class="mb-4 pb-4 border-b border-rose-50">
                                <span class="inline-block bg-rose-100 text-rose-700 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider mb-2">Ide Visual / B-Roll</span>
                                <p id="outVideoVisuals" class="text-xs text-slate-600 italic leading-relaxed"></p>
                            </div>
                            <div class="space-y-4 text-sm text-slate-800">
                                <div>
                                    <span class="font-bold text-rose-600 text-xs uppercase tracking-wide block mb-1">Hook (0-3 Detik)</span>
                                    <p id="outVideoHook" class="font-medium bg-rose-50 p-2 rounded-md border-l-2 border-rose-400"></p>
                                </div>
                                <div>
                                    <span class="font-bold text-slate-500 text-xs uppercase tracking-wide block mb-1">Isi Cerita (Voiceover)</span>
                                    <div id="outVideoBody" class="space-y-2"></div>
                                </div>
                                <div>
                                    <span class="font-bold text-indigo-500 text-xs uppercase tracking-wide block mb-1">Call to Action (CTA)</span>
                                    <p id="outVideoCta" class="font-medium bg-indigo-50 p-2 rounded-md border-l-2 border-indigo-400"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="heaj-footer bg-slate-900 border-t border-slate-800 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-xs font-medium">
            <p><?php echo esc_html( $brand_settings['copyright_text'] ?? 'Hak Cipta © 2026 YanuarZG' ); ?></p>
            <div class="flex items-center gap-4">
                <a href="https://yanuarzg.github.io/" target="_blank" class="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1.5 font-semibold">
                    <i data-lucide="badge-check" class="w-3.5 h-3.5"></i> Beli lisensi
                </a>
            </div>
        </div>
    </footer>

    <!-- Toast Notification -->
    <div id="toast" class="fixed bottom-6 right-6 transform translate-y-24 opacity-0 transition-all duration-300 ease-out bg-slate-800 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 z-[100] border border-slate-700">
        <i id="toastIcon" data-lucide="info" class="w-5 h-5 text-blue-400"></i>
        <span id="toastMessage" class="text-sm font-medium tracking-wide">Pesan Notifikasi</span>
    </div>
</div>
<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="he-settings-app" class="wrap he-settings-wrap heaj-wrap heaj-settings-page">
    <section class="he-settings-hero">
        <div class="he-settings-hero-inner">
            <div class="he-settings-brand">
                <div>
                    <h1>Pengaturan API</h1>
                    <p class="he-settings-subtitle">Kelola provider AI, model Gemini, rotasi API key, dan keamanan key dari satu halaman yang lebih rapi.</p>
                </div>
            </div>
            <div class="he-settings-metrics" aria-label="Ringkasan API aktif">
                <div><strong><?php echo esc_html( $all_count ); ?></strong><span>Gemini</span></div>
                <div><strong><?php echo esc_html( $grok_keys_count ); ?></strong><span>Grok/xAI</span></div>
                <div><strong><?php echo esc_html( $groq_keys_count ); ?></strong><span>Groq</span></div>
                <div><strong><?php echo esc_html( $zai_keys_count ); ?></strong><span>Z.AI</span></div>
                <div><strong><?php echo esc_html( $openrouter_keys_count ); ?></strong><span>OpenRouter</span></div>
                <div><strong><?php echo $pexels_api_key ? '1' : '0'; ?></strong><span>Pexels</span></div>
            </div>
        </div>
    </section>

    <?php if ( empty( $has_any_ai_provider ) ) : ?>
    <section class="he-settings-card he-onboarding-card">
        <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="rocket" class="w-4 h-4"></i></span><div><h2>Mulai setup plugin</h2><p>Lengkapi nama media/branding di Custom Settings, lalu masukkan minimal satu API key untuk mulai generate artikel.</p></div></div>
        <div class="he-custom-toolbar"><a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=he-journalist-custom-settings' ) ); ?>">Atur Branding</a><a class="button button-secondary" href="https://aistudio.google.com/api-keys" target="_blank" rel="noopener">Ambil API Gemini</a></div>
    </section>
    <?php endif; ?>

    <?php if ( isset( $_GET['settings-updated'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Pengaturan berhasil disimpan.</strong></p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['heaj-blocked-reset'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Daftar API key terblokir sudah dikosongkan.</strong></p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['heaj-update-check'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Cache update dibersihkan. Buka Dashboard → Updates untuk melihat hasil terbaru.</strong></p></div>
    <?php endif; ?>

    <form method="post" action="options.php" class="he-settings-grid">
        <?php settings_fields( 'he_journalist_options' ); ?>

        <div class="he-settings-main">
            <section class="he-settings-card he-security-card">
                <div class="he-card-heading">
                    <span class="he-card-icon"><i data-lucide="shield-check" class="w-4 h-4"></i></span>
                    <div>
                        <h2>Keamanan API Key</h2>
                        <p>Plugin tidak menyertakan API key default di ZIP publik. Masukkan key milik Anda sendiri agar aman dari deteksi secret GitHub.</p>
                    </div>
                </div>
                <div class="he-note-grid">
                    <div><strong>Server-side</strong><span>Request AI diproses melalui AJAX WordPress, bukan exposed di JavaScript.</span></div>
                    <div><strong>Auto-block</strong><span>Key bocor/invalid/forbidden otomatis dilewati pada request berikutnya.</span></div>
                    <div><strong>Masked</strong><span>Status API hanya menampilkan key tersensor.</span></div>
                </div>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact">
                    <span class="he-card-icon red"><i data-lucide="key-round" class="w-4 h-4"></i></span>
                    <div><h2>API Key Provider</h2><p>Satu API key per baris. Isi hanya provider yang ingin dipakai.</p></div>
                </div>

                <div class="he-provider-grid">
                    <div class="he-provider-box">
                        <div class="he-provider-top">
                            <div><h3>Gemini</h3><p>Direkomendasikan untuk artikel berbasis sumber URL.</p></div>
                            <a href="https://aistudio.google.com/api-keys" target="_blank" rel="noopener" class="he-mini-btn"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Ambil Key</a>
                        </div>
                        <textarea id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>" rows="5" class="large-text code he-key-textarea" placeholder="Satu API key Gemini per baris"><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS, '' ) ); ?></textarea>
                        <p class="description he-provider-active-line">Gemini aktif: <strong><?php echo esc_html( $all_count ); ?></strong></p>

                        <button type="button" class="he-mini-btn he-test-api-btn" data-provider="gemini"><i data-lucide="activity" class="w-3.5 h-3.5"></i> Test API Key</button>

                        <div class="he-inline-test-result" data-provider-result="gemini"></div>
                    </div>

                    
                    <label class="he-prompt-field he-provider-full">
                        <span>Fallback Model Gemini</span>
                        <textarea name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GEMINI_FALLBACK_MODELS ); ?>" rows="3" class="large-text he-key-textarea" placeholder="gemini-2.5-flash-lite&#10;gemini-2.5-pro"><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_GEMINI_FALLBACK_MODELS, "gemini-2.5-flash-lite\ngemini-2.5-pro" ) ); ?></textarea>
                        <p class="description">Dicoba otomatis jika model utama Gemini gagal karena limit, overload, atau timeout. Satu model per baris.</p>
                    </label>
<div class="he-provider-box">
                        <div class="he-provider-top">
                            <div><h3>Grok / xAI <span class="he-pro-badge">PRO</span></h3><p>Paling akurat dan real-time, status akun GROK harus PRO.</p></div>
                            <a href="https://console.x.ai/" target="_blank" rel="noopener" class="he-mini-btn"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Ambil Key</a>
                        </div>
                        <textarea id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS ); ?>" rows="4" class="large-text code he-key-textarea" placeholder="xai-...&#10;xai-..."><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS, '' ) ); ?></textarea>
                        <p class="description he-provider-active-line">Grok/xAI aktif: <strong><?php echo esc_html( $grok_keys_count ); ?></strong></p>

                        <button type="button" class="he-mini-btn he-test-api-btn" data-provider="grok"><i data-lucide="activity" class="w-3.5 h-3.5"></i> Test API Key</button>

                        <div class="he-inline-test-result" data-provider-result="grok"></div>
                    </div>



                    <div class="he-provider-box">
                        <div class="he-provider-top">
                            <div><h3>Groq</h3><p>Inference cepat untuk draft alternatif berbasis OpenAI-compatible.</p></div>
                            <a href="https://console.groq.com/keys" target="_blank" rel="noopener" class="he-mini-btn"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Ambil Key</a>
                        </div>
                        <textarea id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROQ_API_KEYS ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROQ_API_KEYS ); ?>" rows="4" class="large-text code he-key-textarea" placeholder="gsk_...&#10;gsk_..."><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_GROQ_API_KEYS, '' ) ); ?></textarea>
                        <p class="description he-provider-active-line">Groq aktif: <strong><?php echo esc_html( $groq_keys_count ); ?></strong></p>

                        <button type="button" class="he-mini-btn he-test-api-btn" data-provider="groqcloud"><i data-lucide="activity" class="w-3.5 h-3.5"></i> Test API Key</button>

                        <div class="he-inline-test-result" data-provider-result="groqcloud"></div>
                    </div>

                    <div class="he-provider-box">
                        <div class="he-provider-top">
                            <div><h3>Z.AI</h3><p>Provider tambahan untuk fallback dan variasi output.</p></div>
                            <a href="https://z.ai/manage-apikey/apikey-list" target="_blank" rel="noopener" class="he-mini-btn"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Ambil Key</a>
                        </div>
                        <textarea id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS ); ?>" rows="4" class="large-text code he-key-textarea" placeholder="Z.AI API key, satu key per baris"><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS, '' ) ); ?></textarea>
                        <p class="description he-provider-active-line">Z.AI aktif: <strong><?php echo esc_html( $zai_keys_count ); ?></strong></p>

                        <button type="button" class="he-mini-btn he-test-api-btn" data-provider="zai"><i data-lucide="activity" class="w-3.5 h-3.5"></i> Test API Key</button>

                        <div class="he-inline-test-result" data-provider-result="zai"></div>
                    </div>

                    <div class="he-provider-box">
                        <div class="he-provider-top">
                            <div><h3>OpenRouter</h3><p>Provider OpenAI-compatible melalui openrouter.ai untuk akses model lintas vendor.</p></div>
                            <a href="https://openrouter.ai/keys" target="_blank" rel="noopener" class="he-mini-btn"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Ambil Key</a>
                        </div>
                        <textarea id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_OPENROUTER_API_KEYS ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_OPENROUTER_API_KEYS ); ?>" rows="4" class="large-text code he-key-textarea" placeholder="sk-or-v1-...&#10;sk-or-v1-..."><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_OPENROUTER_API_KEYS, '' ) ); ?></textarea>
                        <label class="he-prompt-field" style="margin-top:10px;display:block;">
                            <span>Model OpenRouter</span>
                            <select id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_OPENROUTER_MODEL ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_OPENROUTER_MODEL ); ?>" class="regular-text he-key-textarea">
                                <?php foreach ( HE_Journalist_Pro_Tools::openrouter_model_choices() as $model_value => $model_label ) : ?>
                                    <option value="<?php echo esc_attr( $model_value ); ?>" <?php selected( $openrouter_model, $model_value ); ?>><?php echo esc_html( $model_label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <p class="description he-provider-active-line">OpenRouter aktif: <strong><?php echo esc_html( $openrouter_keys_count ); ?></strong></p>

                        <button type="button" class="he-mini-btn he-test-api-btn" data-provider="openrouter"><i data-lucide="activity" class="w-3.5 h-3.5"></i> Test API Key</button>

                        <div class="he-inline-test-result" data-provider-result="openrouter"></div>
                    </div>

                    <div class="he-provider-box">
                        <div class="he-provider-top">
                            <div><h3>Pexels Image</h3><p>Fallback 3 gambar ilustrasi jika gambar artikel sumber tidak terbaca.</p></div>
                            <a href="https://www.pexels.com/api/" target="_blank" rel="noopener" class="he-mini-btn"><i data-lucide="external-link" class="w-3.5 h-3.5"></i> Ambil Key</a>
                        </div>
                        <input type="text" id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_PEXELS_API_KEY ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_PEXELS_API_KEY ); ?>" value="<?php echo esc_attr( get_option( HE_Journalist_Pro_Tools::OPTION_PEXELS_API_KEY, '' ) ); ?>" class="regular-text he-key-textarea" placeholder="Pexels API key">
                        <p class="description">Dipakai hanya saat gambar sumber tidak ditemukan. Gambar diberi label <strong>ilustrasi foto</strong>.</p>
                    </div>
                </div>
            </section>

            <section class="he-settings-card he-api-test-result-card" id="heApiTestResults" style="display:none;">
                <div class="he-card-heading compact">
                    <span class="he-card-icon"><i data-lucide="activity" class="w-4 h-4"></i></span>
                    <div><h2>Hasil Test API Key</h2><p>Status ini membantu mendeteksi key invalid, forbidden, quota, atau koneksi gagal.</p></div>
                </div>
                <div id="heApiTestResultList" class="he-api-test-result-list"></div>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact">
                    <span class="he-card-icon indigo"><i data-lucide="cpu" class="w-4 h-4"></i></span>
                    <div><h2>Model Gemini</h2><p>Pilih model default untuk provider Gemini.</p></div>
                </div>
                <?php $selected_model = get_option( HE_Journalist_Pro_Tools::OPTION_MODEL, 'gemini-2.5-flash' ); ?>
                <select id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>" name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>" class="regular-text he-model-select">
                    <?php foreach ( HE_Journalist_Pro_Tools::supported_models() as $model_code => $model_label ) : ?>
                        <option value="<?php echo esc_attr( $model_code ); ?>" <?php selected( $selected_model, $model_code ); ?>><?php echo esc_html( $model_label ); ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="description">Default stabil: <code>gemini-2.5-flash</code>.</p>
            </section>
        </div>

        <aside class="he-settings-side">
            <section class="he-settings-card he-sticky-side">
                <div class="he-card-heading compact">
                    <span class="he-card-icon green"><i data-lucide="activity" class="w-4 h-4"></i></span>
                    <div><h2>Status API Key</h2><p>Urutan rotasi dan status key.</p></div>
                </div>

                <?php if ( empty( $api_key_pool_all ) ) : ?>
                    <div class="he-empty-status">
                        <i data-lucide="key" class="w-8 h-8"></i>
                        <strong>Belum ada API key.</strong>
                        <span>Tambahkan minimal satu key untuk mulai generate artikel.</span>
                    </div>
                <?php else : ?>
                    <div class="he-api-status-list">
                        <?php foreach ( $api_key_pool_all as $api_item ) : ?>
                            <?php $is_blocked = ! empty( $api_item['blocked'] ); ?>
                            <div class="he-api-status-item <?php echo $is_blocked ? 'is-blocked' : 'is-active'; ?>">
                                <div class="he-api-status-head">
                                    <strong><?php echo esc_html( $api_item['provider'] ); ?></strong>
                                    <?php if ( $is_blocked ) : ?>
                                        <span class="he-status-badge he-status-blocked">Diblokir</span>
                                    <?php else : ?>
                                        <span class="he-status-badge he-status-active">Aktif</span>
                                    <?php endif; ?>
                                </div>
                                <code><?php echo esc_html( $api_item['masked'] ); ?></code>
                                <p><?php echo esc_html( $api_item['order'] ); ?> · <?php echo esc_html( $api_item['label'] ); ?></p>
                                <?php if ( $is_blocked ) : ?>
                                    <?php $block_info = is_array( $api_item['block_info'] ) ? $api_item['block_info'] : []; ?>
                                    <small title="<?php echo esc_attr( $block_info['reason'] ?? '' ); ?>"><?php echo esc_html( $block_info['blocked_at'] ?? '' ); ?> — <?php echo esc_html( wp_trim_words( $block_info['reason'] ?? 'Provider AI menolak API key ini.', 10 ) ); ?></small>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $blocked_api_keys ) ) : ?>
                    <div class="he-reset-blocked-form">
                        <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=heaj_reset_blocked_api_keys' ), 'heaj_reset_blocked_api_keys' ) ); ?>">Reset API Key Terblokir</a>
                    </div>
                <?php endif; ?>

                <div class="he-update-status-box">
                    <strong>Update Plugin</strong>
                    <span>Versi saat ini: <?php echo esc_html( HE_Journalist_Pro_Tools::VERSION ); ?></span>
                    <span>Versi terbaru: <?php echo esc_html( $latest_version ); ?></span>
                    <?php if ( $update_available ) : ?>
                        <em class="is-update">Update tersedia</em>
                    <?php else : ?>
                        <em>Plugin terbaru</em>
                    <?php endif; ?>
                    <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=heaj_check_updates_now' ), 'heaj_check_updates_now' ) ); ?>">Cek Update Sekarang</a>
                </div>

                <?php submit_button( 'Simpan Pengaturan', 'primary large', 'submit', false, [ 'class' => 'button button-primary button-large he-save-button' ] ); ?>
            </section>
        </aside>
    </form>

    <section class="he-info-card he-settings-info-card">
        <h3>Informasi Plugin</h3>
        <div class="he-info-grid">
            <div><strong>Generator Artikel</strong><span><?php echo esc_html( $brand_settings['brand_name'] ?? 'YZG AI Journalist' ); ?> → Generator Artikel</span></div>
            <div><strong>Draft WordPress</strong><span>Judul, slug, kategori, tag, meta, subtitle, dan isi artikel otomatis masuk draft.</span></div>
            <div><strong>Provider AI</strong><span>Gemini, Grok/xAI, Groq, Z.AI, dan OpenRouter aktif sesuai API yang tersedia.</span></div>
            <div><strong>Auto Block</strong><span>Key yang ditolak permanen otomatis dilewati pada request berikutnya.</span></div>
        </div>
    </section>

<script>
(function(){
    function esc(s){ return String(s||'').replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]; }); }
    document.querySelectorAll('.he-test-api-btn').forEach(function(btn){
        btn.addEventListener('click', async function(){
            var provider = btn.getAttribute('data-provider');
            var box = document.getElementById('heApiTestResults');
            var list = document.getElementById('heApiTestResultList');
            if (!box || !list) return;
            btn.insertAdjacentElement('afterend', box);
            box.style.display = '';
            list.innerHTML = '<div class="he-api-test-loading">Mengecek '+esc(provider)+'...</div>';
            btn.disabled = true;
            try {
                var fd = new FormData();
                fd.append('action','heaj_test_provider_keys');
                fd.append('nonce','<?php echo esc_js( wp_create_nonce( HE_Journalist_Pro_Tools::NONCE_ACTION ) ); ?>');
                fd.append('provider', provider);
                var res = await fetch(ajaxurl, {method:'POST', credentials:'same-origin', body:fd});
                var payload = await res.json();
                if (!payload || !payload.success) throw new Error(payload && payload.data && payload.data.message ? payload.data.message : 'Gagal test API');
                var rows = payload.data.rows || [];
                if (!rows.length) { list.innerHTML = '<div class="he-api-test-empty">Belum ada API key untuk provider ini.</div>'; return; }
                list.innerHTML = rows.map(function(r){ return '<div class="he-api-test-row is-'+esc(r.status)+'"><strong>'+esc(r.label)+' <code>'+esc(r.masked)+'</code></strong><span>'+esc(r.status)+'</span><p>'+esc(r.message)+'</p></div>'; }).join('');
            } catch(e) {
                list.innerHTML = '<div class="he-api-test-row is-error"><strong>Gagal</strong><p>'+esc(e.message||e)+'</p></div>';
            } finally { btn.disabled = false; if (window.HEAJRenderIcons) window.HEAJRenderIcons(); }
        });
    });
})();
</script>
</div>

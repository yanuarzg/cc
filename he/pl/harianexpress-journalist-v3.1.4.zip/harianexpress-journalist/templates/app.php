<?php
if (!defined('ABSPATH')) { exit; }
?>
<div id="heaj-app" class="heaj-wrap text-slate-800 antialiased min-h-screen flex flex-col">
<!-- Header -->
    <header class="bg-slate-900 text-white shadow-lg relative z-10 border-b border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3 group cursor-default">
                <div class="relative flex items-center justify-center">
                    <div class="absolute inset-0 bg-red-500 rounded-lg blur opacity-40 group-hover:opacity-70 transition duration-500"></div>
                    <svg width="40" height="32" viewBox="0 0 40 32" class="text-red-500 fill-current relative z-10 drop-shadow-md"><rect x="2" y="2" width="36" height="28" rx="6" fill="none" stroke="currentColor" stroke-width="2.5"/><text x="20" y="21" text-anchor="middle" font-family="Inter, sans-serif" font-size="14" font-weight="800" fill="currentColor" letter-spacing="0.5">HE</text></svg>
                </div>
                <div>
                    <h1 class="text-xl font-extrabold tracking-tight leading-none mb-0.5 text-white">Harian<span class="bg-gradient-to-br from-red-500 to-rose-400 bg-clip-text text-transparent">Express</span></h1>
                    <p class="text-[10px] text-slate-400 font-semibold tracking-widest uppercase opacity-80">AI Journalist Pro Tools v.<?php echo esc_html( HE_Journalist_Pro_Tools::VERSION ); ?></p>
                </div>
            </div>
            <div class="hidden sm:flex items-center gap-3 text-sm text-slate-300">
                <span class="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700 px-3 py-1.5 rounded-full text-xs font-semibold shadow-inner"><i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-400"></i> Fact-checked</span>
                <span class="flex items-center gap-1.5 bg-indigo-900/30 border border-indigo-500/30 text-indigo-100 px-3 py-1.5 rounded-full text-xs font-semibold shadow-[0_0_15px_rgba(99,102,241,0.15)]"><i data-lucide="zap" class="w-3.5 h-3.5 text-indigo-400"></i> AI Powered</span>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Left Column: Input -->
        <div class="lg:col-span-5 flex flex-col gap-6 sticky top-24">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden transition-shadow hover:shadow-md">
                <div class="border-b border-slate-100 bg-slate-50/80 px-5 py-4 flex items-center gap-2">
                    <div class="bg-red-100 p-1.5 rounded-lg text-red-600"><i data-lucide="file-edit" class="w-4 h-4"></i></div>
                    <h2 class="font-semibold text-slate-800">Mau Nulis Berita Apa?</h2>
                </div>
                
                <div class="p-5 flex flex-col gap-5">
                    <!-- Input Referensi -->
                    <div>
                        <div class="flex flex-col mb-2">
                            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Link Referensi (Per baris satu link)</label>
                            <span class="text-[11px] text-slate-500 italic leading-relaxed"><i data-lucide="info" class="w-3 h-3 inline-block -mt-0.5 mr-0.5"></i>Jika berupa link sumber, lebih banyak link maka lebih bagus hasilnya. Jika berupa keyword, tambahkan waktu sekarang agar lebih akurat (Contoh: Xavi manager chelsea Juni 2026).</span>
                        </div>
                        <textarea id="sourceInput" rows="5" class="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm input-ring transition-colors resize-none" placeholder="Paste link sumber artikel di sini... (semakin banyak semakin joss)"></textarea>
                    </div>

                    <!-- Pengaturan Terpadu -->
                    <div class="bg-slate-50 rounded-xl p-4 border border-slate-100 space-y-4">
                        <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-2">
                            <i data-lucide="settings-2" class="w-3.5 h-3.5"></i> Pengaturan Konten
                        </h3>
                        
                        <div class="grid grid-cols-1 gap-4">
                            <!-- Prompt, Word Count & Language -->
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Gaya Penulisan</label>
                                    <select id="promptSelect" class="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm input-ring">
                                        <option value="default">Standar Jurnalistik HE</option>
                                        <option value="straight_news">Straight News</option>
                                        <option value="jurnalis_heading">Rewrite Artikel</option>
                                        <option value="seo_artikel">Target SEO Page 1</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Panjang Artikel</label>
                                    <select id="wordCountSelect" class="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm input-ring">
                                        <option value="">Sesuai prompt</option>
                                        <option value="minimal 300 kata - maksimal 500 kata">Pendek (300-500)</option>
                                        <option value="minimal 1000 kata">Sedang (1000+)</option>
                                        <option value="minimal 1500 kata">Panjang (1500+)</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Bahasa Artikel</label>
                                    <select id="languageSelect" class="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm input-ring">
                                        <option value="id">Indonesia</option>
                                        <option value="en">English</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Byline -->
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Yang Nulis (Opsional)</label>
                                    <select id="authorSelect" class="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm input-ring">
                                        <option value="">-- Kosong --</option>
                                        <option value="Achmad Fauzan">Achmad Fauzan</option>
                                        <option value="Ajeng Mietaswary Annisa">Ajeng Mietaswary Annisa</option>
                                        <option value="Cavin Juliansyah">Cavin Juliansyah</option>
                                        <option value="Findy Alfiansyah">Findy Alfiansyah</option>
                                        <option value="Heri Purwadyo">Heri Purwadyo</option>
                                        <option value="Ipnu Subroto">Ipnu Subroto</option>
                                        <option value="Muklis Purwanto">Muklis Purwanto</option>
                                        <option value="Ridwan Habibie">Ridwan Habibie</option>
                                        <option value="Yanuar Zhaldy G">Yanuar Zhaldy G</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-medium text-slate-600 mb-1.5">Yang Edit (Opsional)</label>
                                    <select id="editorSelect" class="w-full bg-white border border-slate-200 rounded-lg p-2 text-sm input-ring">
                                        <option value="">-- Kosong --</option>
                                        <option value="Achmad Fauzan">Achmad Fauzan</option>
                                        <option value="Findy Alfiansyah">Findy Alfiansyah</option>
                                        <option value="Ipnu Subroto">Ipnu Subroto</option>
                                        <option value="Muklis Purwanto">Muklis Purwanto</option>
                                        <option value="Ridwan Habibie">Ridwan Habibie</option>
                                        <option value="Yanuar Zhaldy G">Yanuar Zhaldy G</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Source Visibility Toggle -->
                            <div class="hidden items-center justify-between bg-white border border-slate-200 p-2.5 rounded-lg">
                                <span class="text-xs font-medium text-slate-600">Sertakan Sumber Referensi?</span>
                                <div class="flex gap-4">
                                    <label class="flex items-center gap-1.5 text-sm text-slate-700 cursor-pointer">
                                        <input type="radio" name="showSource" value="yes" checked class="w-3.5 h-3.5 text-red-600 focus:ring-red-500 border-gray-300"> Ya
                                    </label>
                                    <label class="flex items-center gap-1.5 text-sm text-slate-700 cursor-pointer">
                                        <input type="radio" name="showSource" value="no" class="w-3.5 h-3.5 text-red-600 focus:ring-red-500 border-gray-300"> Tidak
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button id="generateBtn" onclick="processArticle()" class="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-4 rounded-xl transition-all shadow-sm hover:shadow active:scale-[0.98] flex items-center justify-center gap-2">
                        <i data-lucide="sparkles" class="w-4 h-4"></i> Buat Artikel
                    </button>
                </div>

                <!-- Guidelines Info -->
                <div class="bg-indigo-50 border border-indigo-100 rounded-xl p-4 m-5 mt-0 flex gap-3">
                    <i data-lucide="info" class="w-5 h-5 text-indigo-500 shrink-0 mt-0.5"></i>
                    <div>
                        <h3 class="text-sm font-semibold text-indigo-900 mb-1">Serba Otomatis ke WordPress!</h3>
                        <p class="text-xs text-indigo-700 leading-relaxed">
                            Auto ke Draft WordPress Kategori, Judul, Slug, Meta Deskripsi, Tags, Penulis & Editor, dan Isi Artikel. Bonus Ringkasan, Video Script hingga Draft Sosmed!
                        </p>
                    </div>
                </div>

            </div>
        </div>

        <!-- Right Column: Output -->
        <div class="lg:col-span-7 flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 relative min-h-[600px] h-fit overflow-hidden">
            
            <!-- Output Header -->
            <div class="border-b border-slate-100 bg-slate-50/80 px-5 py-3 flex items-center justify-between z-10 sticky top-0 rounded-t-xl">
                <div class="flex items-center gap-3">
                    <button id="btnCopyCategory" class="flex items-center gap-1.5 bg-red-100 hover:bg-red-200 transition-colors px-3 py-1 rounded-full group focus:outline-none" title="Copy Kategori">
                        <span id="badgeCategory" class="text-red-700 text-[11px] font-bold uppercase tracking-wider">Kategori</span>
                        <i data-lucide="copy" class="w-3 h-3 text-red-600 opacity-60 group-hover:opacity-100"></i>
                    </button>
                    <span class="text-xs text-slate-400 font-medium border-l border-slate-300 pl-3" id="promptLabel">Hasil Generator</span>
                </div>
                <button id="btnReset" onclick="resetAll()" class="text-slate-400 hover:text-red-600 hover:bg-red-50 p-1.5 rounded-md transition-colors flex items-center gap-1.5 text-xs font-medium" title="Reset Halaman">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Reset
                </button>
            </div>

            <!-- Area Tampilan -->
            <div class="relative flex-grow flex flex-col p-6">
                
                <!-- 1. EMPTY STATE -->
                <div id="emptyState" class="absolute inset-0 flex flex-col items-center justify-center p-12 text-center bg-white z-20 rounded-b-xl">
                    <div class="bg-slate-50 border border-slate-100 p-5 rounded-full mb-4 text-slate-300">
                        <i data-lucide="layout-template" class="w-10 h-10"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-slate-700">Ruang Kerja Kosong</h3>
                    <p class="text-slate-500 text-sm max-w-sm mt-2 leading-relaxed">Isi form referensi di panel sebelah kiri dan klik <strong>Buat Artikel</strong> untuk memulai pembuatan artikel oleh AI ini.</p>
                </div>

                <!-- 2. LOADING STATE -->
                <div id="loadingState" class="hidden absolute inset-0 flex-col items-center justify-center p-12 text-center bg-white/95 backdrop-blur z-20 rounded-b-xl">
                    <div class="loader mb-5"></div>
                    <h3 class="text-base font-bold text-slate-800">Menyusun Naskah...</h3>
                    <p class="text-slate-500 text-sm max-w-sm mt-2 leading-relaxed animate-pulse">Menyelaraskan tone jurnalistik, memformat tulisan, dan memastikan akurasi fakta.</p>
                </div>

                <!-- 3. RESULT STATE -->
                <div id="outputContainer" class="hidden flex-col w-full h-auto">
                    
                    <!-- Meta Data Box -->
                    <div class="mb-8 p-5 bg-slate-50 border border-slate-200 rounded-xl text-sm shadow-sm relative">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-2">
                            <div>
                                <h4 class="font-semibold text-slate-700 mb-2 text-[10px] uppercase tracking-wider opacity-80">Pilihan SEO Title</h4>
                                <div id="outTitleOptions" class="space-y-2"></div>
                            </div>
                            <div>
                                <h4 class="font-semibold text-slate-700 mb-2 text-[10px] uppercase tracking-wider opacity-80">Pilihan Slug</h4>
                                <div id="outSlugs" class="space-y-2"></div>
                            </div>
                        </div>
                        <div class="mt-5">
                            <h4 class="font-semibold text-slate-700 mb-2 text-[10px] uppercase tracking-wider opacity-80">Meta Deskripsi / Post Subtitle (Max 160 Karakter)</h4>
                            <div id="outMeta" class="space-y-2"></div>
                        </div>
                        <div class="mt-5">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="font-semibold text-slate-700 text-[10px] uppercase tracking-wider opacity-80">Tags Relevan</h4>
                            </div>
                            <div id="outTags" class="flex flex-wrap gap-2 text-sm text-slate-700 bg-white p-3 border border-slate-200 rounded-lg leading-relaxed">
                                <!-- Chip tags -->
                            </div>
                        </div>
                    </div>

                    <!-- Source Images -->
                    <div id="sourceImagesSection" class="hidden mb-8 p-5 bg-white border border-slate-200 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <div>
                                <h4 class="font-semibold text-slate-800 text-sm flex items-center gap-2"><i data-lucide="image" class="w-4 h-4 text-indigo-500"></i> Gambar dari Sumber</h4>
                                <p class="text-[11px] text-slate-500 mt-1">Preview image yang terdeteksi dari link referensi. Tetap cek hak pakai gambar sebelum publish.</p>
                            </div>
                            <span id="sourceImagesCount" class="text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-1 rounded-full">0 gambar</span>
                        </div>
                        <div id="sourceImagesGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"></div>
                    </div>


                    <!-- Article Body Area -->
                    <div class="bg-white py-4">
                        <h1 id="articleH1" class="text-2xl sm:text-3xl font-bold text-slate-900 mb-6 leading-tight article-font"></h1>
                        <div id="articleContent" class="prose max-w-none article-font text-justify text-slate-700"></div>
                    </div>

                    <!-- Send to WordPress Draft -->
                    <div class="mb-8 mt-2 flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                        <button id="btnRegenerateArticle" type="button" onclick="processArticle()" title="Generate ulang" aria-label="Generate ulang" class="bg-red-600 hover:bg-red-700 text-white text-sm font-semibold w-12 h-12 rounded-xl transition-all shadow hover:shadow-md flex items-center justify-center">
                            <i data-lucide="refresh-cw" class="w-4 h-4"></i>
                        </button>
                        <button id="btnCopyArticleHtml" type="button" onclick="copyArticleHTML(this)" class="bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold px-5 py-3 rounded-xl transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                            <i data-lucide="copy" class="w-4 h-4"></i> Copy HTML
                        </button>
                        <button id="btnAddDraft" type="button" class="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-5 py-3 rounded-xl transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                            <i data-lucide="send" class="w-4 h-4"></i> Kirim ke Draft
                        </button>
                        <div id="draftStatus" class="hidden text-xs font-medium px-3 py-2 rounded-lg border"></div>
                    </div>

                    <!-- Article Info Bar -->
                    <div class="flex items-center gap-3 mb-4 border-b border-slate-100 pb-3">
                        <h3 class="text-sm font-bold text-slate-800">Pratinjau Artikel</h3>
                        <span id="wordCountDisplay" class="text-[10px] font-medium text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full"></span>
                    </div>


                    <!-- References -->
                    <div id="referencesSection" class="mt-8 pt-6 border-t border-slate-200 hidden bg-slate-50 rounded-xl p-5 border border-slate-100">
                        <h4 class="font-semibold text-slate-700 mb-3 flex items-center gap-2 text-sm">
                            <i data-lucide="link-2" class="w-4 h-4 text-slate-400"></i> Sumber &amp; Referensi Otomatis
                        </h4>
                        <ul id="outReferences" class="space-y-2 text-xs text-blue-600 break-words"></ul>
                    </div>

                    <!-- Peringatan Redaksi -->
                    <div class="mt-8 bg-red-50/80 border border-red-100 rounded-xl p-5 flex gap-4 shadow-sm relative overflow-hidden">
                        <div class="absolute -right-4 -top-4 opacity-[0.03] pointer-events-none">
                            <i data-lucide="shield-alert" class="w-32 h-32 text-red-900"></i>
                        </div>
                        <div class="bg-red-200/50 p-2 rounded-full h-fit shrink-0 text-red-600">
                            <i data-lucide="alert-triangle" class="w-5 h-5"></i>
                        </div>
                        <div class="relative z-10 flex-1">
                            <h3 class="text-sm font-bold text-red-800 mb-2.5 tracking-wide">Pentingnya keakuratan berita!</h3>
                            <ul class="text-xs text-red-700 leading-relaxed list-disc list-outside ml-4 space-y-1.5 mb-5">
                                <li>Demi menjamin keakuratan berita dan kredibilitas HarianExpress, selalu lakukan pengecekan isi artikel dan sumber yang diberikan.</li>
                                <li>Jika ditemukan sumber berita yang <strong class="bg-red-500 text-white px-1.5 py-0.5 rounded shadow-sm inline-block mx-0.5">ERROR 404</strong> atau beda topik dengan artikel yang dibuat maka dimohon <strong>jangan mempublish</strong> artikel tersebut.</li>
                                <li>Gunakan tools dari GROK AI ini yang memiliki keakuratan pencarian real-time &plusmn;90%++.</li>
                            </ul>
                            <div>
                                <a href="https://grok.com/project/b801d03d-4f68-4ede-b08e-7800bfec02ef?tab=conversations" target="_blank" class="inline-flex items-center justify-center sm:w-auto gap-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition-all shadow-sm active:scale-[0.98]">
                                    <i data-lucide="external-link" class="w-3.5 h-3.5 text-red-400"></i> GROK HARIANEXPRESS
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Ekstra Fitur Gemini Buttons -->
                    <div class="mt-8 border-t border-slate-100 pt-6">
                        <h3 class="text-sm font-bold text-slate-800 mb-3">Fitur Ekstra</h3>
                        <div class="flex flex-wrap items-center gap-2 w-full">
                            <button id="btnRingkasan" onclick="generateRingkasan()" class="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                                <i data-lucide="list-checks" class="w-3.5 h-3.5"></i> Ringkasan Cepat
                            </button>
                            <button id="btnSosmed" onclick="generateSosmed()" class="flex-1 sm:flex-none bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                                <i data-lucide="share-2" class="w-3.5 h-3.5"></i> Draft Sosmed
                            </button>
                            <button id="btnVideoScript" onclick="generateVideoScript()" class="flex-1 sm:flex-none bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow hover:shadow-md flex items-center justify-center gap-2">
                                <i data-lucide="video" class="w-3.5 h-3.5"></i> Skrip TikTok/Reels
                            </button>
                        </div>
                    </div>

                    <!-- Fitur Baru 1: Hasil Ringkasan -->
                    <div id="ringkasanContainer" class="hidden mt-8 bg-emerald-50/50 border border-emerald-100 rounded-xl p-5 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="font-bold text-emerald-900 flex items-center gap-2 text-sm">
                                <i data-lucide="list-checks" class="w-4 h-4 text-emerald-600"></i> Poin Utama Berita (Key Takeaways)
                            </h4>
                            <div class="flex items-center gap-2">
                                <button onclick="copyElementText('outRingkasan', this)" class="text-emerald-600 hover:text-emerald-800 transition-colors text-xs font-semibold flex items-center gap-1">
                                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy
                                </button>
                                <span class="text-emerald-200">|</span>
                                <button onclick="closeFeature('ringkasanContainer')" class="text-emerald-400 hover:text-emerald-700 transition-colors" title="Tutup Panel">
                                    <i data-lucide="x" class="w-4 h-4"></i>
                                </button>
                            </div>
                        </div>

                        <div id="ringkasanLoading" class="hidden flex-col items-center justify-center py-6">
                            <div class="loader-ringkasan mb-3"></div>
                            <span class="text-xs font-medium text-emerald-600">AI sedang mengekstrak ringkasan...</span>
                        </div>

                        <div id="outRingkasan" class="hidden">
                            <ul id="ringkasanList" class="list-disc list-outside ml-4 space-y-2 text-sm text-slate-700 marker:text-emerald-500">
                                <!-- Ringkasan di-render di sini -->
                            </ul>
                        </div>
                    </div>

                    <!-- Fitur Baru 2: Hasil Social Media Kit -->
                    <div id="sosmedContainer" class="hidden mt-8 bg-indigo-50/50 border border-indigo-100 rounded-xl p-5 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="font-bold text-indigo-900 flex items-center gap-2 text-sm">
                                <i data-lucide="share-2" class="w-4 h-4 text-indigo-500"></i> Social Media Kit
                            </h4>
                            <button onclick="closeFeature('sosmedContainer')" class="text-indigo-400 hover:text-indigo-700 transition-colors" title="Tutup Panel">
                                <i data-lucide="x" class="w-4 h-4"></i>
                            </button>
                        </div>

                        <!-- Loading Sosmed -->
                        <div id="sosmedLoading" class="hidden flex-col items-center justify-center py-6">
                            <div class="loader-sosmed mb-3"></div>
                            <span class="text-xs font-medium text-indigo-600">AI sedang menyusun draft sosmed...</span>
                        </div>

                        <!-- Content Sosmed -->
                        <div id="sosmedContent" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- Twitter -->
                            <div class="bg-white border border-indigo-100 rounded-lg p-4">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-bold text-slate-700 flex items-center gap-1.5">Twitter Thread</span>
                                    <button onclick="copyElementText('outTwitter', this)" class="text-indigo-600 hover:bg-indigo-50 p-1 rounded transition text-xs"><i data-lucide="copy" class="w-3 h-3"></i></button>
                                </div>
                                <div id="outTwitter" class="text-xs text-slate-600 space-y-3 whitespace-pre-wrap"></div>
                            </div>
                            
                            <!-- IG & FB combined -->
                            <div class="bg-white border border-indigo-100 rounded-lg p-4 h-fit">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                                        IG &amp; FB Caption
                                    </span>
                                    <button onclick="copyElementText('outIgFb', this)" class="text-indigo-600 hover:bg-indigo-50 p-1 rounded transition text-xs"><i data-lucide="copy" class="w-3 h-3"></i></button>
                                </div>
                                <div id="outIgFb" class="text-xs text-slate-600 whitespace-pre-wrap leading-relaxed"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Fitur Baru 3: Hasil Skrip Video -->
                    <div id="videoScriptContainer" class="hidden mt-8 bg-rose-50/50 border border-rose-100 rounded-xl p-5 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="font-bold text-rose-900 flex items-center gap-2 text-sm">
                                <i data-lucide="video" class="w-4 h-4 text-rose-600"></i> Skrip Video Vertikal (TikTok/Reels/Shorts)
                            </h4>
                            <div class="flex items-center gap-2">
                                <button onclick="copyElementText('outVideoScript', this)" class="text-rose-600 hover:text-rose-800 transition-colors text-xs font-semibold flex items-center gap-1">
                                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy Skrip
                                </button>
                                <span class="text-rose-200">|</span>
                                <button onclick="closeFeature('videoScriptContainer')" class="text-rose-400 hover:text-rose-700 transition-colors" title="Tutup Panel">
                                    <i data-lucide="x" class="w-4 h-4"></i>
                                </button>
                            </div>
                        </div>

                        <div id="videoScriptLoading" class="hidden flex-col items-center justify-center py-6">
                            <div class="loader-video mb-3"></div>
                            <span class="text-xs font-medium text-rose-600">AI sedang menulis naskah video...</span>
                        </div>

                        <div id="outVideoScript" class="hidden bg-white border border-rose-100 rounded-lg p-5">
                            <div class="mb-4 pb-4 border-b border-rose-50">
                                <span class="inline-block bg-rose-100 text-rose-700 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider mb-2">Ide Visual / B-Roll</span>
                                <p id="outVideoVisuals" class="text-xs text-slate-600 italic leading-relaxed"></p>
                            </div>
                            <div class="space-y-4 text-sm text-slate-800">
                                <div>
                                    <span class="font-bold text-rose-600 text-xs uppercase tracking-wide block mb-1">Hook (0-3 Detik)</span>
                                    <p id="outVideoHook" class="font-medium bg-rose-50 p-2 rounded-md border-l-2 border-rose-400"></p>
                                </div>
                                <div>
                                    <span class="font-bold text-slate-500 text-xs uppercase tracking-wide block mb-1">Isi Cerita (Voiceover)</span>
                                    <div id="outVideoBody" class="space-y-2"></div>
                                </div>
                                <div>
                                    <span class="font-bold text-indigo-500 text-xs uppercase tracking-wide block mb-1">Call to Action (CTA)</span>
                                    <p id="outVideoCta" class="font-medium bg-indigo-50 p-2 rounded-md border-l-2 border-indigo-400"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-slate-900 border-t border-slate-800 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-xs font-medium">
            <p>Hak Cipta &copy; 2026 HarianExpress Redaksi.</p>
            <div class="flex items-center gap-4">
                <a href="https://yanuarzg.github.io/" target="_blank" class="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1.5 font-semibold">
                    <i data-lucide="badge-check" class="w-3.5 h-3.5"></i> Beli lisensi
                </a>
                <a href="https://yanuarzg.github.io/" target="_blank" class="text-red-400 hover:text-red-300 transition-colors flex items-center gap-1.5">
                    <i data-lucide="github" class="w-3.5 h-3.5"></i> Dibangun oleh YZG
                </a>
            </div>
        </div>
    </footer>

    <!-- Toast Notification -->
    <div id="toast" class="fixed bottom-6 right-6 transform translate-y-24 opacity-0 transition-all duration-300 ease-out bg-slate-800 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 z-[100] border border-slate-700">
        <i id="toastIcon" data-lucide="info" class="w-5 h-5 text-blue-400"></i>
        <span id="toastMessage" class="text-sm font-medium tracking-wide">Pesan Notifikasi</span>
    </div>
</div>
<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="wrap he-settings-wrap">
    <h1 class="he-settings-title">
        <span class="he-logo-icon">HE</span>
        HarianExpress <span class="he-red">Pengaturan API</span>
    </h1>

    <?php if ( isset( $_GET['settings-updated'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Pengaturan berhasil disimpan.</strong></p></div>
    <?php endif; ?>

    <div class="he-settings-card">
        <form method="post" action="options.php">
            <?php settings_fields( 'he_journalist_options' ); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">API Default</th>
                    <td>
                        <p>Plugin sudah membawa <strong>2 Gemini API Key default</strong>. Jika salah satu terkena limit/gagal generate, sistem akan otomatis mencoba API berikutnya.</p>
                        <ol>
                            <?php foreach ( $masked_defaults as $masked_key ) : ?>
                                <li><code><?php echo esc_html( $masked_key ); ?></code></li>
                            <?php endforeach; ?>
                        </ol>
                        <p class="description">API dipakai di server melalui AJAX WordPress, tidak dibuka langsung di JavaScript frontend.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_API_KEY ); ?>">API Key Utama Tambahan</label></th>
                    <td>
                        <input
                            type="password"
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_API_KEY ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_API_KEY ); ?>"
                            value="<?php echo esc_attr( get_option( HE_Journalist_Pro_Tools::OPTION_API_KEY, '' ) ); ?>"
                            class="regular-text"
                            autocomplete="off"
                        />
                        <p class="description">Opsional. API ini akan dipakai setelah 2 API default.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>">API Key Tambahan</label></th>
                    <td>
                        <textarea
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>"
                            rows="7"
                            class="large-text code"
                            placeholder="Satu API key per baris"
                        ><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS, '' ) ); ?></textarea>
                        <p class="description">Tambahkan API lain jika ingin menambah antrean rotasi. Total API aktif saat ini: <strong><?php echo esc_html( $all_count ); ?></strong>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>">Model Gemini</label></th>
                    <td>
                        <?php $selected_model = get_option( HE_Journalist_Pro_Tools::OPTION_MODEL, 'gemini-2.5-flash' ); ?>
                        <select
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>"
                            class="regular-text"
                        >
                            <?php foreach ( HE_Journalist_Pro_Tools::supported_models() as $model_code => $model_label ) : ?>
                                <option value="<?php echo esc_attr( $model_code ); ?>" <?php selected( $selected_model, $model_code ); ?>><?php echo esc_html( $model_label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Daftar berisi model teks Gemini yang relevan untuk generate artikel. Default stabil: <code>gemini-2.5-flash</code>. Model preview lama <code>gemini-2.5-flash-preview-09-2025</code> sudah tidak tersedia.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Simpan Pengaturan' ); ?>
        </form>
    </div>

    <div class="he-info-card he-license-card">
        <h3>Lisensi Domain via GitHub</h3>
        <p>Daftar domain pembeli lisensi dibaca otomatis dari:</p>
        <p><code>https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/licenses.json</code></p>
        <p>Untuk menambahkan domain baru, cukup edit file <code>he/pl/licenses.json</code> di GitHub. Format mendukung domain exact seperti <code>client.com</code> dan wildcard seperti <code>*.client.com</code>.</p>
        <p><a class="button button-secondary" href="https://github.com/yanuarzg/cc/tree/main/he/pl/" target="_blank" rel="noopener">Buka folder update GitHub</a></p>
    </div>

    <div class="he-info-card">
        <h3>Informasi Plugin</h3>
        <ul>
            <li><strong>Menu Generator:</strong> HE Journalist → Generator Artikel</li>
            <li><strong>Draft WordPress:</strong> Judul, slug, kategori, tag, dan meta deskripsi otomatis masuk ke post draft.</li>
            <li><strong>Rotasi API:</strong> Default API 1 → Default API 2 → API utama tambahan → API tambahan per baris.</li>
        </ul>
    </div>
</div>

<style>
.he-settings-wrap{max-width:850px}.he-settings-title{display:flex;align-items:center;gap:10px;margin-bottom:20px}.he-logo-icon{background:#dc2626;color:#fff;font-weight:800;padding:4px 10px;border-radius:6px;font-size:14px}.he-red{color:#dc2626}.he-settings-card{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:24px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.05)}.he-info-card{background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:20px}.he-info-card h3{margin-top:0;color:#1e40af}.he-info-card ul{margin:0;padding-left:20px;color:#1e3a8a}.he-info-card li{margin-bottom:8px}.he-license-card{background:#f8fafc;border-color:#cbd5e1;margin-bottom:20px}.he-license-card h3{color:#0f172a}.he-license-card p{color:#334155}
</style>

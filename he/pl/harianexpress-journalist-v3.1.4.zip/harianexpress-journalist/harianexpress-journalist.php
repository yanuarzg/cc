<?php
/**
 * Plugin Name: HarianExpress AI Journalist Pro Tools
 * Plugin URI:  https://harianexpress.com
 * Description: AI Journalist Generator untuk HarianExpress. Generator tampil di sidebar admin, mendukung rotasi Gemini API Key, SEO metadata, draft sosmed, skrip video, dan kirim artikel ke Draft WordPress.
 * Version:     3.1.4
 * Author:      YZG / HarianExpress Redaksi
 * Author URI:  https://yanuarzg.github.io/
 * License:     GPL v2 or later
 * Text Domain: he-journalist
 * Update URI:  https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class HE_Journalist_Pro_Tools {
    const VERSION = '3.1.4';
    const LICENSE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/licenses.json';
    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json';
    const UPDATE_INFO_URL = 'https://github.com/yanuarzg/cc/tree/main/he/pl/';
    const OPTION_API_KEY = 'he_journalist_gemini_api_key';
    const OPTION_EXTRA_API_KEYS = 'he_journalist_gemini_extra_api_keys';
    const OPTION_MODEL = 'he_journalist_gemini_model';
    const NONCE_ACTION = 'he_journalist_nonce';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_init', [ $this, 'enforce_license_domain' ], 1 );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
        add_action( 'wp_ajax_heaj_generate_content', [ $this, 'ajax_generate_content' ] );
        add_action( 'wp_ajax_he_create_draft', [ $this, 'ajax_create_draft' ] );
        add_action( 'wp_ajax_heaj_fetch_source_images', [ $this, 'ajax_fetch_source_images' ] );
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_update_info' ], 10, 3 );
        register_activation_hook( __FILE__, [ __CLASS__, 'activate' ] );
    }


    private function normalize_host( $host ) {
        $host = strtolower( trim( (string) $host ) );
        $host = preg_replace( '#:\\d+$#', '', $host );
        $host = preg_replace( '#^www\\.#', 'www.', $host );
        return $host;
    }

    private function builtin_license_domains() {
        return [
            'geky.page.gd',
            'harianexpress.com',
            'www.harianexpress.com',
            '*.harianexpress.com',
            'harianexpress.id',
            'www.harianexpress.id',
            '*.harianexpress.id',
        ];
    }

    private function get_remote_license_domains() {
        $cache_key = 'he_journalist_license_domains_v1';
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $domains = [];
        $response = wp_remote_get( self::LICENSE_JSON_URL, [
            'timeout' => 10,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( ! is_wp_error( $response ) ) {
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code >= 200 && $code < 300 ) {
                $data = json_decode( wp_remote_retrieve_body( $response ), true );
                if ( is_array( $data ) ) {
                    if ( isset( $data['domains'] ) && is_array( $data['domains'] ) ) {
                        $domains = array_merge( $domains, $data['domains'] );
                    }
                    if ( isset( $data['allowed_domains'] ) && is_array( $data['allowed_domains'] ) ) {
                        $domains = array_merge( $domains, $data['allowed_domains'] );
                    }
                }
            }
        }

        $domains = array_values( array_unique( array_filter( array_map( function( $domain ) {
            $domain = strtolower( trim( (string) $domain ) );
            $domain = preg_replace( '#^https?://#', '', $domain );
            $domain = preg_replace( '#/.*$#', '', $domain );
            $domain = preg_replace( '#:\d+$#', '', $domain );
            return $domain;
        }, $domains ) ) ) );

        set_transient( $cache_key, $domains, 30 * MINUTE_IN_SECONDS );
        return $domains;
    }

    private function domain_rule_matches( $host, $rule ) {
        $host = $this->normalize_host( $host );
        $rule = strtolower( trim( (string) $rule ) );
        $rule = preg_replace( '#^https?://#', '', $rule );
        $rule = preg_replace( '#/.*$#', '', $rule );
        $rule = preg_replace( '#:\d+$#', '', $rule );

        if ( $host === '' || $rule === '' ) { return false; }
        if ( $host === $rule ) { return true; }

        if ( strpos( $rule, '*.' ) === 0 ) {
            $suffix = substr( $rule, 2 );
            return $host === $suffix || substr( $host, -strlen( '.' . $suffix ) ) === '.' . $suffix;
        }

        return false;
    }

    private function is_allowed_license_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }

        $rules = array_merge( $this->builtin_license_domains(), $this->get_remote_license_domains() );
        foreach ( $rules as $rule ) {
            if ( $this->domain_rule_matches( $host, $rule ) ) {
                return true;
            }
        }

        return false;
    }

    public function enforce_license_domain() {
        if ( ! is_admin() || wp_doing_ajax() || wp_doing_cron() ) { return; }
        if ( $this->is_allowed_license_domain() ) { return; }

        wp_redirect( 'https://yanuarzg.github.io/' );
        exit;
    }

    private function reject_if_unlicensed_ajax() {
        if ( $this->is_allowed_license_domain() ) { return; }
        wp_send_json_error( [
            'message'      => 'Plugin hanya dapat dipakai pada domain yang memiliki lisensi aktif.',
            'redirect_url' => 'https://yanuarzg.github.io/',
        ], 403 );
    }

    public static function activate() {
        if ( ! get_option( self::OPTION_MODEL ) ) {
            add_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        }
        if ( false === get_option( self::OPTION_API_KEY, false ) ) {
            add_option( self::OPTION_API_KEY, '' );
        }
        if ( false === get_option( self::OPTION_EXTRA_API_KEYS, false ) ) {
            add_option( self::OPTION_EXTRA_API_KEYS, '' );
        }
    }

    private function plugin_dir() { return plugin_dir_path( __FILE__ ); }
    private function plugin_url() { return plugin_dir_url( __FILE__ ); }

    private function default_api_keys() {
        return [
            'AIzaSyCAC4HtcnX7bvCLvO3e7_HO3pwj0388Bp4',
            'AIzaSyCHdR8oRdY2Yo_H0nJEqPaZgsRD9eiCWiE',
        ];
    }


    public static function supported_models() {
        return [
            'gemini-2.5-flash' => 'Gemini 2.5 Flash — default stabil, cepat, cocok untuk artikel harian',
            'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash-Lite — lebih ringan dan ekonomis',
            'gemini-2.5-pro' => 'Gemini 2.5 Pro — reasoning lebih kuat untuk artikel panjang/kompleks',
            'gemini-3.1-flash-lite-preview' => 'Gemini 3.1 Flash-Lite Preview — preview, cepat dan ringan',
        ];
    }

    public function sanitize_api_keys_textarea( $value ) {
        $value = is_string( $value ) ? wp_unslash( $value ) : '';
        $lines = preg_split( '/\r\n|\r|\n/', $value );
        $keys = [];
        foreach ( $lines as $line ) {
            $key = trim( $line );
            if ( $key !== '' ) { $keys[] = sanitize_text_field( $key ); }
        }
        return implode( "\n", array_values( array_unique( $keys ) ) );
    }

    private function get_extra_api_keys() {
        $raw = get_option( self::OPTION_EXTRA_API_KEYS, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) );
    }

    private function get_all_api_keys() {
        $manual_main = get_option( self::OPTION_API_KEY, '' );
        $keys = array_merge(
            $this->default_api_keys(),
            ! empty( $manual_main ) ? [ $manual_main ] : [],
            $this->get_extra_api_keys()
        );
        return array_values( array_unique( array_filter( array_map( 'trim', $keys ) ) ) );
    }


    private function extract_json_from_text( $text ) {
        $text = trim( (string) $text );
        if ( $text === '' ) { return null; }

        $direct = json_decode( $text, true );
        if ( is_array( $direct ) ) { return $direct; }

        if ( preg_match( '/```(?:json)?\s*(\{.*?\})\s*```/s', $text, $matches ) ) {
            $decoded = json_decode( trim( $matches[1] ), true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        $start = strpos( $text, '{' );
        $end   = strrpos( $text, '}' );
        if ( $start !== false && $end !== false && $end > $start ) {
            $candidate = substr( $text, $start, $end - $start + 1 );
            $decoded = json_decode( $candidate, true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        return null;
    }


    private function normalize_model_name( $model ) {
        $model = trim( (string) $model );
        $deprecated = [
            '',
            'gemini-2.5-flash-preview-09-2025',
            'models/gemini-2.5-flash-preview-09-2025',
            'gemini-2.0-flash',
            'models/gemini-2.0-flash',
        ];
        if ( in_array( $model, $deprecated, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        $model = preg_replace( '#^models/#', '', $model );
        $model = sanitize_text_field( $model );
        $supported = array_keys( self::supported_models() );
        if ( ! in_array( $model, $supported, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        return $model;
    }


    private function is_retryable_gemini_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) {
            return true;
        }

        $retryable_phrases = [
            'high demand',
            'overloaded',
            'temporarily unavailable',
            'try again later',
            'resource exhausted',
            'quota',
            'rate limit',
            'deadline',
            'timeout',
            'timed out',
            'internal error',
            'service unavailable',
        ];

        foreach ( $retryable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return false;
    }

    private function retry_delay_seconds( $round ) {
        $round = max( 1, (int) $round );
        return min( 8, 2 ** $round );
    }

    private function mask_api_key( $key ) {
        $key = (string) $key;
        if ( strlen( $key ) <= 12 ) { return str_repeat( '•', strlen( $key ) ); }
        return substr( $key, 0, 7 ) . str_repeat( '•', max( 6, strlen( $key ) - 14 ) ) . substr( $key, -7 );
    }


    public function sanitize_model_name( $value ) {
        return $this->normalize_model_name( wp_unslash( $value ) );
    }

    public function register_settings() {
        register_setting( 'he_journalist_options', self::OPTION_API_KEY, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_EXTRA_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_MODEL, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_model_name' ],
            'default'           => 'gemini-2.5-flash',
        ] );

        $stored_model = get_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        $fixed_model  = $this->normalize_model_name( $stored_model );
        if ( $stored_model !== $fixed_model ) {
            update_option( self::OPTION_MODEL, $fixed_model );
        }
    }

    public function add_menu() {
        add_menu_page(
            'HE AI Journalist',
            'HE Journalist',
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ],
            'dashicons-edit-large',
            30
        );
        add_submenu_page(
            'he-journalist',
            'Generator Artikel',
            'Generator Artikel',
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ]
        );
        add_submenu_page(
            'he-journalist',
            'Semua Subdomain',
            'Semua Subdomain',
            'edit_posts',
            'he-journalist-subdomains',
            [ $this, 'render_subdomains_page' ]
        );
        add_submenu_page(
            'he-journalist',
            'Pengaturan API',
            'Pengaturan API',
            'manage_options',
            'he-journalist-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    public function admin_enqueue_assets( $hook ) {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( strpos( $hook, 'he-journalist' ) === false && strpos( $page, 'he-journalist' ) === false ) { return; }

        $this->enqueue_common_assets();

        if ( $page === 'he-journalist' ) {
            $this->enqueue_generator_assets();
        } elseif ( $page === 'he-journalist-subdomains' ) {
            $this->enqueue_subdomains_assets();
        }
    }

    private function enqueue_common_assets() {
        wp_enqueue_script( 'tailwindcss-cdn', 'https://cdn.tailwindcss.com', [], null, false );
        wp_enqueue_style( 'heaj-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Merriweather:wght@400;700&display=swap', [], null );
        wp_enqueue_script( 'lucide-cdn', 'https://unpkg.com/lucide@latest', [], null, true );
        wp_enqueue_style( 'he-journalist-app', $this->plugin_url() . 'assets/css/app.css', [], self::VERSION );
    }

    private function enqueue_generator_assets() {
        wp_enqueue_script( 'he-journalist-app', $this->plugin_url() . 'assets/js/app.js', [ 'lucide-cdn' ], self::VERSION, true );
        wp_localize_script( 'he-journalist-app', 'HEAJ', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( self::NONCE_ACTION ),
            'version'  => self::VERSION,
        ] );
    }

    private function enqueue_subdomains_assets() {
        wp_enqueue_script( 'he-domain-groups-external', 'https://yanuarzg.github.io/cc/he/all.js', [], null, true );
        wp_enqueue_script( 'he-journalist-subdomains', $this->plugin_url() . 'assets/js/subdomains.js', [ 'he-domain-groups-external', 'lucide-cdn' ], self::VERSION, true );
    }

    private function enqueue_assets() {
        $this->enqueue_common_assets();
        $this->enqueue_generator_assets();
    }

    public function render_generator_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        echo '<div class="wrap he-admin-generator">';
        include $this->plugin_dir() . 'templates/app.php';
        echo '</div>';
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $defaults       = $this->default_api_keys();
        $masked_defaults = array_map( [ $this, 'mask_api_key' ], $defaults );
        $all_count      = count( $this->get_all_api_keys() );
        include $this->plugin_dir() . 'templates/settings.php';
    }

    public function render_subdomains_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        echo '<div class="wrap he-admin-subdomains">';
        include $this->plugin_dir() . 'templates/subdomains.php';
        echo '</div>';
    }



    private function get_update_manifest() {
        $response = wp_remote_get( self::UPDATE_JSON_URL, [ 'timeout' => 15 ] );
        if ( is_wp_error( $response ) ) { return null; }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) { return null; }
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        return is_array( $data ) ? $data : null;
    }

    public function check_plugin_update( $transient ) {
        if ( empty( $transient ) || ! is_object( $transient ) ) { return $transient; }
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) || empty( $manifest['version'] ) ) { return $transient; }
        if ( ! version_compare( $manifest['version'], self::VERSION, '>' ) ) { return $transient; }

        $plugin_file = plugin_basename( __FILE__ );
        $package = $manifest['download_url'] ?? $manifest['package'] ?? '';
        $transient->response[ $plugin_file ] = (object) [
            'id'            => self::UPDATE_JSON_URL,
            'slug'          => dirname( $plugin_file ),
            'plugin'        => $plugin_file,
            'new_version'   => sanitize_text_field( $manifest['version'] ),
            'url'           => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
            'package'       => esc_url_raw( $package ),
            'requires'      => sanitize_text_field( $manifest['requires'] ?? '6.0' ),
            'tested'        => sanitize_text_field( $manifest['tested'] ?? '' ),
            'requires_php'  => sanitize_text_field( $manifest['requires_php'] ?? '7.4' ),
        ];
        return $transient;
    }

    public function plugin_update_info( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || empty( $args->slug ) || $args->slug !== 'harianexpress-journalist' ) {
            return $result;
        }
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) ) { return $result; }
        return (object) [
            'name'          => $manifest['name'] ?? 'HarianExpress AI Journalist Pro Tools',
            'slug'          => 'harianexpress-journalist',
            'version'       => $manifest['version'] ?? self::VERSION,
            'author'        => $manifest['author'] ?? 'YZG / HarianExpress Redaksi',
            'homepage'      => $manifest['homepage'] ?? self::UPDATE_INFO_URL,
            'requires'      => $manifest['requires'] ?? '6.0',
            'tested'        => $manifest['tested'] ?? '',
            'requires_php'  => $manifest['requires_php'] ?? '7.4',
            'download_link' => $manifest['download_url'] ?? $manifest['package'] ?? '',
            'sections'      => $manifest['sections'] ?? [ 'description' => 'AI Journalist Pro Tools untuk HarianExpress.', 'changelog' => '' ],
        ];
    }

    private function extract_urls_from_text( $text ) {
        preg_match_all( '#https?://[^\s<>"]+#i', (string) $text, $matches );
        return array_values( array_unique( array_map( 'esc_url_raw', $matches[0] ?? [] ) ) );
    }

    private function absolutize_url( $src, $base_url ) {
        $src = html_entity_decode( trim( (string) $src ), ENT_QUOTES | ENT_HTML5 );
        if ( $src === '' || stripos( $src, 'data:' ) === 0 ) { return ''; }
        if ( preg_match( '#^https?://#i', $src ) ) { return esc_url_raw( $src ); }
        $base = wp_parse_url( $base_url );
        if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) { return ''; }
        if ( strpos( $src, '//' ) === 0 ) { return esc_url_raw( $base['scheme'] . ':' . $src ); }
        $root = $base['scheme'] . '://' . $base['host'];
        if ( ! empty( $base['port'] ) ) { $root .= ':' . $base['port']; }
        if ( strpos( $src, '/' ) === 0 ) { return esc_url_raw( $root . $src ); }
        $path = isset( $base['path'] ) ? preg_replace( '#/[^/]*$#', '/', $base['path'] ) : '/';
        return esc_url_raw( $root . $path . $src );
    }


    private function extract_article_like_html( $html ) {
        $html = (string) $html;
        $blocks = [];

        if ( preg_match_all( '#<article\\b[^>]*>.*?</article>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( '#<main\\b[^>]*>.*?</main>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<div\\b[^>]+class=[\"'][^\"']*(?:entry-content|post-content|article-content|single-content|content-detail|td-post-content|jeg_inner_content|jl_content|post-entry)[^\"']*[\"'][^>]*>.*?</div>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }

        if ( empty( $blocks ) ) {
            return [ 'html' => $html, 'strict_article' => false ];
        }

        usort( $blocks, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
        return [ 'html' => $blocks[0], 'strict_article' => true ];
    }

    private function parse_img_tag_srcs( $tag ) {
        $candidates = [];
        foreach ( [ 'src', 'data-src', 'data-lazy-src', 'data-original', 'data-image' ] as $attr ) {
            if ( preg_match( "#\\s" . preg_quote( $attr, '#' ) . "=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
                $candidates[] = $m[1];
            }
        }
        if ( preg_match( "#\\ssrcset=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
            $parts = array_map( 'trim', explode( ',', $m[1] ) );
            foreach ( $parts as $part ) {
                if ( preg_match( '#^(\\S+)\\s+(\\d+)w#', $part, $sm ) ) {
                    $candidates[] = $sm[1];
                }
            }
        }
        return array_values( array_unique( array_filter( $candidates ) ) );
    }

    private function parse_img_tag_width( $tag ) {
        $width = 0;
        if ( preg_match( "#\\swidth=[\"']?(\\d+)[\"']?#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssizes=[\"'][^\"']*(\\d+)px#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssrcset=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
            if ( preg_match_all( '#\\s(\\d+)w(?:,|$)#', $m[1], $wm ) ) {
                foreach ( $wm[1] as $w ) { $width = max( $width, (int) $w ); }
            }
        }
        return $width;
    }

    private function remote_image_width( $url ) {
        $url = esc_url_raw( $url );
        if ( ! $url ) { return 0; }
        $cache_key = 'heaj_img_w_' . md5( $url );
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) { return (int) $cached; }

        $response = wp_remote_get( $url, [
            'timeout'             => 8,
            'redirection'         => 3,
            'limit_response_size' => 450000,
            'headers'             => [ 'User-Agent' => 'HarianExpressBot/1.0' ],
        ] );
        $width = 0;
        if ( ! is_wp_error( $response ) ) {
            $body = wp_remote_retrieve_body( $response );
            if ( is_string( $body ) && $body !== '' && function_exists( 'getimagesizefromstring' ) ) {
                $info = @getimagesizefromstring( $body );
                if ( is_array( $info ) && ! empty( $info[0] ) ) { $width = (int) $info[0]; }
            }
        }
        set_transient( $cache_key, $width, DAY_IN_SECONDS );
        return $width;
    }

    public function ajax_fetch_source_images() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin mengambil gambar sumber.' ], 403 );
        }

        $source = isset( $_POST['source'] ) ? wp_unslash( $_POST['source'] ) : '';
        $urls = array_slice( $this->extract_urls_from_text( $source ), 0, 8 );
        $images = [];
        $min_width = 320;

        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 20,
                'redirection' => 5,
                'headers'     => [ 'User-Agent' => 'HarianExpressBot/1.0' ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || $html === '' ) { continue; }

            $article = $this->extract_article_like_html( $html );
            $scan_html = $article['html'];
            $strict_article = ! empty( $article['strict_article'] );

            if ( ! preg_match_all( '#<img\\b[^>]*>#i', $scan_html, $tags ) ) { continue; }
            foreach ( $tags[0] as $tag ) {
                $tag_width = $this->parse_img_tag_width( $tag );
                $srcs = $this->parse_img_tag_srcs( $tag );
                foreach ( $srcs as $src ) {
                    $img = $this->absolutize_url( $src, $url );
                    if ( ! $img || ! preg_match( '#\\.(jpe?g|png|webp|gif)(\\?.*)?$#i', $img ) ) { continue; }

                    $width = $tag_width;
                    if ( $width < $min_width ) {
                        $width = $this->remote_image_width( $img );
                    }

                    if ( $width < $min_width ) { continue; }

                    $key = md5( $img );
                    $images[ $key ] = [
                        'url'    => $img,
                        'source' => $url,
                        'width'  => $width,
                        'scope'  => $strict_article ? 'article' : 'page-filtered',
                    ];
                    if ( count( $images ) >= 24 ) { break 3; }
                }
            }
        }

        wp_send_json_success( [ 'images' => array_values( $images ) ] );
    }

    public function ajax_generate_content() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin memakai generator.' ], 403 );
        }

        $api_keys = $this->get_all_api_keys();
        if ( empty( $api_keys ) ) {
            wp_send_json_error( [ 'message' => 'Tidak ada Gemini API Key aktif.' ], 400 );
        }

        $system_prompt = isset( $_POST['systemPrompt'] ) ? wp_unslash( $_POST['systemPrompt'] ) : '';
        $user_text     = isset( $_POST['userText'] ) ? wp_unslash( $_POST['userText'] ) : '';
        $schema_raw    = isset( $_POST['schema'] ) ? wp_unslash( $_POST['schema'] ) : '';
        $use_search    = ! empty( $_POST['useSearch'] ) && $_POST['useSearch'] === '1';
        $schema        = json_decode( $schema_raw, true );

        if ( empty( $system_prompt ) || empty( $user_text ) || ! is_array( $schema ) ) {
            wp_send_json_error( [ 'message' => 'Payload tidak lengkap atau schema JSON tidak valid.' ], 400 );
        }

        $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        /**
         * Gemini 2.5 Flash rejects google_search when combined with responseMimeType=responseSchema.
         * For search-enabled requests we ask for JSON in the prompt and parse it server-side.
         * Non-search requests still use structured output for stricter JSON.
         */
        if ( $use_search ) {
            $json_contract = "\n\nFORMAT OUTPUT WAJIB:\n" .
                "Balas HANYA dengan JSON object valid tanpa markdown, tanpa ```json, tanpa teks tambahan. " .
                "JSON harus mengikuti schema ini secara ketat:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

            $payload = [
                'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt . $json_contract ] ] ],
                'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
                'tools'             => [ [ 'google_search' => new stdClass() ] ],
            ];
        } else {
            $payload = [
                'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt ] ] ],
                'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
                'generationConfig'  => [
                    'responseMimeType' => 'application/json',
                    'responseSchema'   => $schema,
                ],
            ];
        }

        $last_error = 'Request Gemini gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        for ( $round = 1; $round <= $max_rounds; $round++ ) {
            $round_has_retryable_error = false;

            foreach ( $api_keys as $index => $api_key ) {
                $endpoint = sprintf(
                    'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
                    rawurlencode( $model ),
                    rawurlencode( $api_key )
                );

                $response = wp_remote_post( $endpoint, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $last_status = 500;
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'status' => 'wp_error', 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $last_error = $decoded['error']['message'] ?? 'Request Gemini gagal.';
                    $retryable = $this->is_retryable_gemini_error( $code, $last_error );
                    if ( $retryable ) {
                        $round_has_retryable_error = true;
                    }
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'status' => $code, 'retryable' => $retryable, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons Gemini bukan JSON valid.';
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'status' => $code, 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                wp_send_json_success( [
                    'result'         => $result,
                    'api_index_used' => $index + 1,
                    'round_used'     => $round,
                    'attempts'       => count( $attempts ) + 1,
                ] );
            }

            if ( ! $round_has_retryable_error || $round >= $max_rounds ) {
                break;
            }

            sleep( $this->retry_delay_seconds( $round ) );
        }

        $friendly_message = $last_error;
        if ( $this->is_retryable_gemini_error( $last_status, $last_error ) ) {
            $friendly_message = 'Gemini sedang sibuk/limit sementara. Plugin sudah mencoba ulang dan merotasi API key, tapi belum berhasil. Silakan klik Generate Ulang beberapa saat lagi.';
        }

        wp_send_json_error( [
            'message'  => $friendly_message,
            'raw_message' => $last_error,
            'status'   => $last_status,
            'attempts' => $attempts,
        ], $last_status );
    }

    public function ajax_create_draft() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin membuat draft.' ], 403 );
        }

        $title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
        $slug     = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';
        $meta     = isset( $_POST['meta'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta'] ) ) : '';
        $content  = isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
        $category = isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
        $tags_raw = isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '';

        if ( empty( $title ) || empty( $content ) ) {
            wp_send_json_error( [ 'message' => 'Judul dan isi artikel tidak boleh kosong.' ], 400 );
        }

        $cat_id = 0;
        if ( $category ) {
            $term = get_term_by( 'name', $category, 'category' );
            if ( $term && ! is_wp_error( $term ) ) {
                $cat_id = (int) $term->term_id;
            } else {
                $new_term = wp_insert_term( $category, 'category' );
                if ( ! is_wp_error( $new_term ) && ! empty( $new_term['term_id'] ) ) {
                    $cat_id = (int) $new_term['term_id'];
                }
            }
        }

        $post_data = [
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        ];
        if ( $cat_id ) { $post_data['post_category'] = [ $cat_id ]; }

        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Gagal membuat draft: ' . $post_id->get_error_message() ], 500 );
        }

        if ( $tags_raw ) {
            $tags = array_filter( array_map( 'trim', explode( ',', $tags_raw ) ) );
            wp_set_post_tags( $post_id, $tags, false );
        }

        if ( $meta ) {
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta );
            update_post_meta( $post_id, 'rank_math_description', $meta );
            update_post_meta( $post_id, '_seopress_titles_desc', $meta );
            update_post_meta( $post_id, '_he_meta_description', $meta );

            // Tema/editor HarianExpress memakai custom field ini untuk input:
            // <input type="text" name="single_post_subtitle" id="input-single_post_subtitle">
            // Isi dengan meta deskripsi yang dipilih agar langsung muncul di Post Subtitle.
            update_post_meta( $post_id, 'single_post_subtitle', $meta );
            update_post_meta( $post_id, '_single_post_subtitle', $meta );
        }

        wp_send_json_success( [
            'message'  => 'Draft berhasil dibuat!',
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link( $post_id, 'raw' ),
        ] );
    }
}

new HE_Journalist_Pro_Tools();

=== HarianExpress AI Journalist Pro Tools ===
Contributors: yanuarzg
Tags: ai, journalist, gemini, seo, harianexpress
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 3.1.4
License: GPLv2 or later

AI Journalist Generator untuk HarianExpress dengan rotasi Gemini API Key, output SEO, draft sosial media, skrip video, draft WordPress, dan directory Semua Subdomain.

== Changelog ==

= 3.1.4 =
* Lisensi domain dibaca dari GitHub licenses.json.
* Tambah contoh licenses.json untuk menambah domain pembeli lisensi tanpa rilis ulang plugin.

= 3.1.3 =
* Filter gambar sumber: hanya dari area artikel atau image minimal 320px agar ikon/gambar kecil tidak tampil.
* Tambah pembatasan lisensi domain untuk harianexpress.com, subdomain harianexpress.com, harianexpress.id, subdomain harianexpress.id, dan geky.page.gd.
* Redirect domain tidak terdaftar ke https://yanuarzg.github.io/.
* Tambah tombol Beli Lisensi di footer sebelum Dibangun oleh YZG.

= 3.1 =
* mobile responsive

= 2.5.12 =
* Perbaikan author artikel terbaru dan tambah sortir berdasarkan update terbaru/terlama.

= 2.5.10 =
* Update halaman Semua Subdomain: domain utama di atas, tombol ikon, artikel terbaru, tombol +domain WhatsApp, copyright YZG.
* Update Generator Artikel: footer YZG ke yanuarzg.github.io dan versi header dinamis.
* Update Pengaturan API: model Gemini menjadi dropdown pilihan model dan shortcode dihapus.

= 2.5.8 =
* Menambahkan halaman Semua Subdomain dari all.js.

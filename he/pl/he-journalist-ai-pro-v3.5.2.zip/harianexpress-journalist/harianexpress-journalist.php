<?php
/**
 * Plugin Name: YZG AI Journalist
 * Plugin URI:  https://yanuarzg.github.io/
 * Description: White-label AI editorial assistant untuk generate artikel, audit fakta, SEO metadata, gambar sumber/Pexels, dan kirim ke Draft WordPress.
 * Version:     3.5.2
 * Author:      YZG
 * Author URI:  https://yanuarzg.github.io/
 * License:     GPL v2 or later
 * Text Domain: he-journalist
 * Update URI:  https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


/**
 * Small provider key manager introduced in v3.5.0.
 * It keeps API key loading, de-duplication, masking, and blocked-state checks away from the generator flow.
 */
class HEAJ_API_Key_Manager {
    private $provider;
    private $blocked;

    public function __construct( $provider = 'gemini', $blocked = [] ) {
        $this->provider = sanitize_key( $provider );
        $this->blocked  = is_array( $blocked ) ? $blocked : [];
    }

    private function hash_key( $key ) {
        return hash_hmac( 'sha256', trim( (string) $key ), wp_salt( 'auth' ) );
    }

    private function mask_key( $key ) {
        $key = (string) $key;
        if ( strlen( $key ) <= 12 ) { return str_repeat( '•', strlen( $key ) ); }
        return substr( $key, 0, 7 ) . str_repeat( '•', max( 6, strlen( $key ) - 14 ) ) . substr( $key, -7 );
    }

    private function textarea_keys( $option ) {
        $raw = get_option( $option, '' );
        if ( is_array( $raw ) ) { return array_values( array_filter( array_map( 'trim', $raw ) ) ); }
        $rows = preg_split( '/\r\n|\r|\n/', (string) $raw );
        return array_values( array_filter( array_map( 'trim', $rows ) ) );
    }

    private function raw_items() {
        $items = [];
        if ( $this->provider === 'gemini' ) {
            $main = trim( (string) get_option( 'he_journalist_gemini_api_key', '' ) );
            if ( $main !== '' ) { $items[] = [ 'key' => $main, 'label' => 'Primary Gemini', 'source' => 'primary' ]; }
            foreach ( $this->textarea_keys( 'he_journalist_gemini_extra_api_keys' ) as $i => $key ) {
                $items[] = [ 'key' => $key, 'label' => 'API Tambahan #' . ( $i + 1 ), 'source' => 'extra' ];
            }
            return $items;
        }
        $map = [
            'grok'      => [ 'option' => 'he_journalist_grok_api_keys', 'label' => 'Grok/xAI' ],
            'groqcloud' => [ 'option' => 'he_journalist_groq_api_keys', 'label' => 'GroqCloud' ],
            'zai'       => [ 'option' => 'he_journalist_zai_api_keys', 'label' => 'Z.AI' ],
        ];
        if ( isset( $map[ $this->provider ] ) ) {
            foreach ( $this->textarea_keys( $map[ $this->provider ]['option'] ) as $i => $key ) {
                $items[] = [ 'key' => $key, 'label' => $map[ $this->provider ]['label'] . ' #' . ( $i + 1 ), 'source' => $this->provider ];
            }
        }
        return $items;
    }

    public function get_pool( $include_blocked = false ) {
        $unique = [];
        $pool = [];
        foreach ( $this->raw_items() as $item ) {
            $key = trim( (string) ( $item['key'] ?? '' ) );
            if ( $key === '' ) { continue; }
            $hash = $this->hash_key( $key );
            if ( isset( $unique[ $hash ] ) ) { continue; }
            $unique[ $hash ] = true;
            $item['key'] = $key;
            $item['hash'] = $hash;
            $item['masked'] = $this->mask_key( $key );
            $item['blocked'] = isset( $this->blocked[ $hash ] );
            $item['block_info'] = $this->blocked[ $hash ] ?? null;
            if ( $include_blocked || ! $item['blocked'] ) { $pool[] = $item; }
        }
        return $pool;
    }

    public function count_available() {
        return count( $this->get_pool( false ) );
    }
}

final class HE_Journalist_Pro_Tools {
    const VERSION = '3.5.2';
    const LICENSE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/licenses.json';
    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json';
    const UPDATE_INFO_URL = 'https://github.com/yanuarzg/cc/tree/main/he/pl/';
    const OPTION_API_KEY = 'he_journalist_gemini_api_key';
    const OPTION_EXTRA_API_KEYS = 'he_journalist_gemini_extra_api_keys';
    const OPTION_BLOCKED_API_KEYS = 'he_journalist_blocked_api_keys';
    const OPTION_MODEL = 'he_journalist_gemini_model';
    const OPTION_GEMINI_FALLBACK_MODELS = 'he_journalist_gemini_fallback_models';
    const OPTION_GROK_API_KEYS = 'he_journalist_grok_api_keys';
    const OPTION_GROQ_API_KEYS = 'he_journalist_groq_api_keys';
    const OPTION_ZAI_API_KEYS = 'he_journalist_zai_api_keys';
    const OPTION_HISTORY = 'he_journalist_history';
    const OPTION_PROMPT_OVERRIDES = 'he_journalist_prompt_overrides';
    const OPTION_PEXELS_API_KEY = 'he_journalist_pexels_api_key';
    const OPTION_CUSTOM_SETTINGS = 'he_journalist_custom_settings';
    const NONCE_ACTION = 'he_journalist_nonce';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_init', [ $this, 'enforce_license_domain' ], 1 );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'init', [ __CLASS__, 'maybe_schedule_cleanup_history' ] );
        add_action( 'he_journalist_cleanup_history', [ __CLASS__, 'cleanup_history' ] );
        add_filter( 'option_page_capability_he_journalist_options', [ $this, 'allow_editor_admin_option_page' ] );
        add_filter( 'option_page_capability_he_journalist_custom_options', [ $this, 'allow_editor_admin_option_page' ] );
        add_action( 'admin_post_heaj_reset_blocked_api_keys', [ $this, 'handle_reset_blocked_api_keys' ] );
        add_action( 'admin_post_heaj_check_updates_now', [ $this, 'handle_check_updates_now' ] );
        add_action( 'admin_post_heaj_reset_custom_settings', [ $this, 'handle_reset_custom_settings' ] );
        add_action( 'admin_post_heaj_clear_generate_history', [ $this, 'handle_clear_generate_history' ] );
        add_action( 'admin_post_heaj_delete_generate_history', [ $this, 'handle_delete_generate_history' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
        add_action( 'wp_ajax_heaj_generate_content', [ $this, 'ajax_generate_content' ] );
        add_action( 'wp_ajax_he_create_draft', [ $this, 'ajax_create_draft' ] );
        add_action( 'wp_ajax_heaj_fetch_source_images', [ $this, 'ajax_fetch_source_images' ] );
        add_action( 'wp_ajax_heaj_test_provider_keys', [ $this, 'ajax_test_provider_keys' ] );
        add_action( 'wp_ajax_heaj_fetch_pexels_images', [ $this, 'ajax_fetch_pexels_images' ] );
        add_action( 'wp_ajax_heaj_update_history_meta', [ $this, 'ajax_update_history_meta' ] );
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_update_info' ], 10, 3 );
        register_activation_hook( __FILE__, [ __CLASS__, 'activate' ] );
        register_deactivation_hook( __FILE__, [ __CLASS__, 'deactivate' ] );
    }



    private function current_admin_locale() {
        $locale = function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
        if ( ! $locale ) { $locale = get_locale(); }
        return strtolower( (string) $locale );
    }

    private function is_id_locale() {
        return 0 === strpos( $this->current_admin_locale(), 'id' );
    }

    private function ui_language() {
        return $this->is_id_locale() ? 'id' : 'en';
    }

    private function ui_translations() {
        return [
            'AI dapat membuat kesalahan. Selalu periksa ulang fakta, kutipan, nama, tanggal, angka, dan sumber sebelum publish.' => 'AI can make mistakes. Always recheck facts, quotes, names, dates, numbers, and sources before publishing.',
            'Generator Artikel' => 'Article Generator',
            'Tulis ulang berita berbasis sumber, kunci data penting, siapkan SEO, lalu kirim ke Draft WordPress.' => 'Rewrite source-based articles, lock key data, prepare SEO, then send to WordPress Drafts.',
            'Pengaturan API' => 'API Settings',
            'Riwayat Generate' => 'Generation History',
            'Custom Settings' => 'Custom Settings',
            'Network Sites' => 'Network Sites',
            'Mau Nulis Berita Apa?' => 'What article do you want to write?',
            'Topik/Sumber Berita' => 'Topik/Sumber Berita',
            'Pengaturan Konten' => 'Content Settings',
            'Gaya Penulisan (prompt)' => 'Writing Style (prompt)',
            'Panjang Artikel' => 'Article Length',
            'Bahasa' => 'Language',
            'Penulis' => 'Author',
            'Editor' => 'Editor',
            '-- Kosong --' => '-- Empty --',
            'Buat Artikel' => 'Generate Article',
            'Reset' => 'Reset',
            'Ruang Kerja Kosong' => 'Empty Workspace',
            'Isi form referensi di panel sebelah kiri dan klik' => 'Fill in the reference form on the left panel and click',
            'untuk memulai pembuatan artikel oleh AI ini.' => 'to start generating an article with AI.',
            'Menyusun Naskah...' => 'Preparing Draft...',
            'Menyelaraskan tone jurnalistik, memformat tulisan, dan memastikan akurasi fakta.' => 'Aligning the journalistic tone, formatting the article, and checking factual accuracy.',
            'Kategori' => 'Category',
            'Hasil Generator' => 'Generator Result',
            'Pilihan SEO Title' => 'SEO Title Options',
            'Pilihan Slug' => 'Slug Options',
            'Meta Deskripsi (Max 160 Karakter)' => 'Meta Description (Max 160 Characters)',
            'Tags Relevan' => 'Relevant Tags',
            'Pratinjau Artikel' => 'Article Preview',
            'Copy HTML' => 'Copy HTML',
            'Kirim ke Draft WordPress' => 'Send to WordPress Draft',
            'Draft berhasil dibuat.' => 'Draft created successfully.',
            'Edit draft' => 'Edit draft',
            'Gambar dari Sumber' => 'Images from Source',
            'Pilih gambar untuk featured image/sisipan artikel.' => 'Select images for featured image/article insertions.',
            'ilustrasi foto' => 'illustrative photo',
            'Bukan foto ist/istimewa.' => 'Not an ist/istimewa photo.',
            'Caption tidak terdeteksi' => 'Caption not detected',
            'Audit Fakta' => 'Fact Audit',
            'Perlu dicek manual' => 'Needs manual check',
            'Quality Score' => 'Quality Score',
            'Sumber terbaca' => 'Source readable',
            'Data pasti cocok' => 'Confirmed data matched',
            'SEO lengkap' => 'SEO complete',
            'Paragraf rapi' => 'Clean paragraphs',
            'Gambar siap' => 'Image ready',
            'Kemiripan narasi rendah' => 'Low narrative similarity',
            'Pentingnya keakuratan berita!' => 'The importance of article accuracy!',
            'Demi menjamin keakuratan berita dan kredibilitas' => 'To ensure article accuracy and the credibility of',
            'selalu lakukan pengecekan isi artikel dan sumber yang diberikan.' => 'always check the article content and provided sources.',
            'Jika ditemukan sumber berita yang' => 'If a news source is found to be',
            'atau beda topik dengan artikel yang dibuat maka dimohon' => 'or unrelated to the generated article, please',
            'jangan mempublish' => 'do not publish',
            'artikel tersebut.' => 'the article.',
            'Ancaman pidana bagi pelanggar' => 'Criminal penalties for violations of',
            'Penjara maksimal' => 'maximum imprisonment of',
            'dan/atau denda maksimal' => 'and/or maximum fine of',
            'Sumber & Referensi Otomatis' => 'Automatic Sources & References',
            'Ringkasan Cepat' => 'Quick Summary',
            'Draft Sosmed' => 'Social Draft',
            'Skrip TikTok/Reels' => 'TikTok/Reels Script',
            'Poin Utama Berita (Key Takeaways)' => 'Main Article Points (Key Takeaways)',
            'AI sedang mengekstrak ringkasan...' => 'AI is extracting the summary...',
            'Social Media Kit' => 'Social Media Kit',
            'AI sedang menyusun draft sosmed...' => 'AI is preparing the social draft...',
            'Skrip Video Vertikal (TikTok/Reels/Shorts)' => 'Vertical Video Script (TikTok/Reels/Shorts)',
            'Copy Skrip' => 'Copy Script',
            'AI sedang menulis naskah video...' => 'AI is writing the video script...',
            'Ide Visual / B-Roll' => 'Visual Ideas / B-Roll',
            'Hook (0-3 Detik)' => 'Hook (0-3 Seconds)',
            'Isi Cerita (Voiceover)' => 'Story Body (Voiceover)',
            'Call to Action (CTA)' => 'Call to Action (CTA)',
            'Simpan Pengaturan' => 'Save Settings',
            'Simpan Custom Settings' => 'Save Custom Settings',
            'Mulai setup plugin' => 'Start plugin setup',
            'Lengkapi nama media/branding di Custom Settings, lalu masukkan minimal satu API key untuk mulai generate artikel.' => 'Complete media/branding in Custom Settings, then enter at least one API key to start generating articles.',
            'Atur Branding' => 'Set Branding',
            'Ambil API Gemini' => 'Get Gemini API',
            'AI Provider' => 'AI Provider',
            'API Key Provider' => 'API Key Provider',
            'Test API Key' => 'Test API Key',
            'aktif' => 'active',
            'Tambahkan API key per provider. Sistem akan memakai rotasi key dan otomatis melewati key yang error.' => 'Add API keys per provider. The system will rotate keys and automatically skip keys with errors.',
            'Branding White-label' => 'White-label Branding',
            'Sesuaikan nama plugin, nama media, logo, profil brand, dan mode lisensi.' => 'Customize plugin name, media name, logo, brand profile, and license mode.',
            'Nama Brand Plugin' => 'Plugin Brand Name',
            'Nama Media / Website' => 'Media / Website Name',
            'Organisasi / Redaksi' => 'Organization / Editorial Team',
            'Logo URL' => 'Logo URL',
            'Warna Utama' => 'Primary Color',
            'License Type' => 'License Type',
            'Sumber Penulis/Editor' => 'Author/Editor Source',
            'Brand Voice' => 'Brand Voice',
            'Kata/Frasa yang Dihindari' => 'Words/Phrases to Avoid',
            'Teks Warning Redaksi Tambahan' => 'Additional Editorial Warning Text',
            'Kota Default' => 'Default City',
            'Tambah, hapus, atau edit prompt yang muncul di dropdown Gaya Penulisan.' => 'Add, remove, or edit prompts that appear in the Writing Style dropdown.',
            'Tambah Prompt' => 'Add Prompt',
            'Prompt Custom Global' => 'Global Custom Prompt',
            'Instruksi tambahan global yang disisipkan ke semua gaya penulisan.' => 'Additional global instructions inserted into all writing styles.',
            'Kelola opsi pendek, sedang, panjang, atau opsi baru lain.' => 'Manage short, medium, long, or other custom length options.',
            'Tambah Panjang' => 'Add Length',
            'Tambah bahasa baru dan instruksi outputnya.' => 'Add a new language and its output instruction.',
            'Tambah Bahasa' => 'Add Language',
            'Penulis & Editor' => 'Authors & Editors',
            'Satu nama per baris untuk dropdown Penulis dan Editor.' => 'One name per line for the Author and Editor dropdowns.',
            'Import/Sync WP' => 'Import/Sync WP',
            'Export / Import JSON' => 'Export / Import JSON',
            'Gunakan untuk menyalin pengaturan ke subdomain lain.' => 'Use this to copy settings to another subdomain.',
            'Export JSON' => 'Export JSON',
            'Import JSON' => 'Import JSON',
            'Reset Default' => 'Reset Default',
            'Hapus Seluruh Riwayat Generate' => 'Delete All Generation History',
            'Perubahan akan langsung mempengaruhi halaman Generator Artikel.' => 'Changes will immediately affect the Article Generator page.',
            'Belum ke Draft' => 'Not Drafted Yet',
            'Dilanjutkan ke Draft' => 'Continued to Draft',
            'Draft dibuat' => 'Draft Created',
            'Restore' => 'Restore',
            'Hapus' => 'Delete',
            'Pilihan AI' => 'AI Choice',
            'Gaya Penulisan' => 'Writing Style',
            'Sumber Image' => 'Image Source',
            'Sumber' => 'Source',
            'Pexels' => 'Pexels',
            'Tidak ada riwayat generate.' => 'No generation history yet.',
            'Halaman' => 'Page',
            'dari' => 'of',
            'Sebelumnya' => 'Previous',
            'Berikutnya' => 'Next',
            'Disalin ke clipboard!' => 'Copied to clipboard!',
            'Gagal menyalin.' => 'Failed to copy.',
            'Mohon masukkan tautan atau teks sumber.' => 'Please enter a source link or text.',
            'Artikel berhasil dibuat!' => 'Article generated successfully!',
            'Gagal memproses artikel. Coba lagi.' => 'Failed to process the article. Please try again.',
            'Silakan buat artikel terlebih dahulu.' => 'Please generate an article first.',
            'Ringkasan berhasil dibuat!' => 'Summary generated successfully!',
            'Gagal menyusun ringkasan.' => 'Failed to prepare the summary.',
            'Draft sosial media berhasil dibuat!' => 'Social media draft generated successfully!',
            'Gagal membuat draft sosmed.' => 'Failed to create social media draft.',
            'Skrip video berhasil dibuat!' => 'Video script generated successfully!',
            'Gagal menyusun skrip video.' => 'Failed to prepare the video script.',
            'Ruang kerja dibersihkan.' => 'Workspace cleared.',
            'Memproses...' => 'Processing...',
            'Copy' => 'Copy',
            'Simpan' => 'Save',
            'Batal' => 'Cancel',
            'Tutup' => 'Close',
            'Lihat' => 'View',
            'Pilih' => 'Select',
            'Cek' => 'Check',
        ];
    }

    private function tr_ui( $text ) {
        $text = (string) $text;
        if ( $this->is_id_locale() ) { return $text; }
        $dict = $this->ui_translations();
        return $dict[ $text ] ?? $text;
    }

    private function translate_admin_html( $html ) {
        if ( $this->is_id_locale() || ! is_string( $html ) || $html === '' ) { return $html; }
        $dict = $this->ui_translations();
        uksort( $dict, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
        return strtr( $html, $dict );
    }

    private function admin_language_bridge_script() {
        $payload = wp_json_encode( [
            'lang' => $this->ui_language(),
            'locale' => $this->current_admin_locale(),
            'dictionary' => $this->ui_translations(),
        ] );
        return "window.HEAJ_I18N = {$payload};" . <<<'JS'
(function(){
  function tr(text){
    var cfg = window.HEAJ_I18N || {};
    if (cfg.lang === 'id') return text;
    var dict = cfg.dictionary || {};
    var out = String(text || '');
    Object.keys(dict).sort(function(a,b){return b.length-a.length;}).forEach(function(k){
      if (!k) return;
      out = out.split(k).join(dict[k]);
    });
    return out;
  }
  window.HEAJTr = tr;
  function translateNode(node){
    if (!node || !node.parentNode) return;
    if (/^(SCRIPT|STYLE|TEXTAREA|CODE|PRE)$/.test(node.parentNode.nodeName)) return;
    var value = node.nodeValue;
    if (!value || !value.trim()) return;
    var next = tr(value);
    if (next !== value) node.nodeValue = next;
  }
  function translateAttrs(el){
    ['placeholder','title','aria-label','value'].forEach(function(attr){
      if (!el || !el.hasAttribute || !el.hasAttribute(attr)) return;
      if (attr === 'value' && !/^(INPUT|BUTTON)$/.test(el.nodeName)) return;
      var old = el.getAttribute(attr);
      var next = tr(old);
      if (next !== old) el.setAttribute(attr, next);
    });
  }
  function translatePage(){
    var cfg = window.HEAJ_I18N || {};
    if (cfg.lang === 'id') return;
    var root = document.querySelector('#heaj-app,#he-settings-app,#he-history-app,#he-custom-settings-app,#he-subdomains-app,.heaj-settings-page') || document.body;
    if (!root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(translateNode);
    root.querySelectorAll('[placeholder],[title],[aria-label],input[type="button"],input[type="submit"],button').forEach(translateAttrs);
  }
  window.HEAJTranslatePage = translatePage;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', translatePage); else translatePage();
  setTimeout(translatePage, 250); setTimeout(translatePage, 1000); setTimeout(translatePage, 2200);
})();
JS;
    }

    private function normalize_host( $host ) {
        $host = strtolower( trim( (string) $host ) );
        $host = preg_replace( '#:\\d+$#', '', $host );
        $host = preg_replace( '#^www\\.#', 'www.', $host );
        return $host;
    }

    private function builtin_license_domains() {
        return [
            'geky.page.gd',
            'harianexpress.com',
            'www.harianexpress.com',
            '*.harianexpress.com',
            'harianexpress.id',
            'www.harianexpress.id',
            '*.harianexpress.id',
        ];
    }

    private function get_remote_license_domains() {
        $cache_key = 'he_journalist_license_domains_v1';
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $domains = [];
        $response = wp_remote_get( self::LICENSE_JSON_URL, [
            'timeout' => 10,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( ! is_wp_error( $response ) ) {
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code >= 200 && $code < 300 ) {
                $data = json_decode( wp_remote_retrieve_body( $response ), true );
                if ( is_array( $data ) ) {
                    if ( isset( $data['domains'] ) && is_array( $data['domains'] ) ) {
                        $domains = array_merge( $domains, $data['domains'] );
                    }
                    if ( isset( $data['allowed_domains'] ) && is_array( $data['allowed_domains'] ) ) {
                        $domains = array_merge( $domains, $data['allowed_domains'] );
                    }
                }
            }
        }

        $domains = array_values( array_unique( array_filter( array_map( function( $domain ) {
            $domain = strtolower( trim( (string) $domain ) );
            $domain = preg_replace( '#^https?://#', '', $domain );
            $domain = preg_replace( '#/.*$#', '', $domain );
            $domain = preg_replace( '#:\d+$#', '', $domain );
            return $domain;
        }, $domains ) ) ) );

        set_transient( $cache_key, $domains, 30 * MINUTE_IN_SECONDS );
        return $domains;
    }

    private function domain_rule_matches( $host, $rule ) {
        $host = $this->normalize_host( $host );
        $rule = strtolower( trim( (string) $rule ) );
        $rule = preg_replace( '#^https?://#', '', $rule );
        $rule = preg_replace( '#/.*$#', '', $rule );
        $rule = preg_replace( '#:\d+$#', '', $rule );

        if ( $host === '' || $rule === '' ) { return false; }
        if ( $host === $rule ) { return true; }

        if ( strpos( $rule, '*.' ) === 0 ) {
            $suffix = substr( $rule, 2 );
            return $host === $suffix || substr( $host, -strlen( '.' . $suffix ) ) === '.' . $suffix;
        }

        return false;
    }

    private function is_allowed_license_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }

        $rules = array_merge( $this->builtin_license_domains(), $this->get_remote_license_domains() );
        foreach ( $rules as $rule ) {
            if ( $this->domain_rule_matches( $host, $rule ) ) {
                return true;
            }
        }

        return false;
    }

    private function is_harianexpress_com_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }
        return $host === 'harianexpress.com' || substr( $host, -strlen( '.harianexpress.com' ) ) === '.harianexpress.com';
    }

    public function enforce_license_domain() {
        if ( ! is_admin() || wp_doing_ajax() || wp_doing_cron() ) { return; }
        if ( $this->is_allowed_license_domain() ) { return; }

        wp_redirect( 'https://yanuarzg.github.io/' );
        exit;
    }

    private function reject_if_unlicensed_ajax() {
        if ( $this->is_allowed_license_domain() ) { return; }
        wp_send_json_error( [
            'message'      => 'Plugin hanya dapat dipakai pada domain yang memiliki lisensi aktif.',
            'redirect_url' => 'https://yanuarzg.github.io/',
        ], 403 );
        wp_die();
    }

    public static function activate() {
        if ( ! get_option( self::OPTION_MODEL ) ) {
            add_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        }
        if ( false === get_option( self::OPTION_GEMINI_FALLBACK_MODELS, false ) ) {
            add_option( self::OPTION_GEMINI_FALLBACK_MODELS, "gemini-2.5-flash-lite\ngemini-2.5-pro" );
        }
        if ( false === get_option( self::OPTION_API_KEY, false ) ) {
            add_option( self::OPTION_API_KEY, '' );
        }
        if ( false === get_option( self::OPTION_EXTRA_API_KEYS, false ) ) {
            add_option( self::OPTION_EXTRA_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_BLOCKED_API_KEYS, false ) ) {
            add_option( self::OPTION_BLOCKED_API_KEYS, [] );
        }
        if ( false === get_option( self::OPTION_GROK_API_KEYS, false ) ) {
            add_option( self::OPTION_GROK_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_GROQ_API_KEYS, false ) ) {
            add_option( self::OPTION_GROQ_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_ZAI_API_KEYS, false ) ) {
            add_option( self::OPTION_ZAI_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_HISTORY, false ) ) {
            add_option( self::OPTION_HISTORY, [] );
        }
        if ( false === get_option( self::OPTION_PROMPT_OVERRIDES, false ) ) {
            add_option( self::OPTION_PROMPT_OVERRIDES, [] );
        }
        if ( false === get_option( self::OPTION_PEXELS_API_KEY, false ) ) {
            add_option( self::OPTION_PEXELS_API_KEY, '' );
        }
        if ( false === get_option( self::OPTION_CUSTOM_SETTINGS, false ) ) {
            add_option( self::OPTION_CUSTOM_SETTINGS, self::default_custom_settings() );
        }
        if ( ! wp_next_scheduled( 'he_journalist_cleanup_history' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'he_journalist_cleanup_history' );
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( 'he_journalist_cleanup_history' );
    }

    private function plugin_dir() { return plugin_dir_path( __FILE__ ); }
    private function plugin_url() { return plugin_dir_url( __FILE__ ); }

    private function default_api_keys() {
        return [];
    }



    private function default_grok_api_keys() {
        return [];
    }

    private function default_groqcloud_api_keys() {
        return [];
    }

    private function default_zai_api_keys() {
        return [];
    }

    private function parse_api_keys_option( $option_name ) {
        $raw = get_option( $option_name, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_unique( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) ) );
    }

    private function filter_unblocked_api_keys( array $keys, $include_blocked = false ) {
        $keys = array_values( array_unique( array_filter( array_map( 'trim', $keys ) ) ) );
        if ( $include_blocked ) { return $keys; }
        return array_values( array_filter( $keys, function( $key ) {
            return ! $this->is_api_key_blocked( $key );
        } ) );
    }

    private function get_grok_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_grok_api_keys(), $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ) ), $include_blocked );
    }

    private function get_groqcloud_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_groqcloud_api_keys(), $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ) ), $include_blocked );
    }

    private function get_zai_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_zai_api_keys(), $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ) ), $include_blocked );
    }

    private function get_provider_key_status_rows() {
        $groups = [
            'Gemini' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_api_keys(), array_keys( $this->default_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->get_extra_api_keys(), array_keys( $this->get_extra_api_keys() ) )
            ),
            'Grok / xAI' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_grok_api_keys(), array_keys( $this->default_grok_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ) ) )
            ),
            'Groq' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_groqcloud_api_keys(), array_keys( $this->default_groqcloud_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ) ) )
            ),
            'Z.AI' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_zai_api_keys(), array_keys( $this->default_zai_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ) ) )
            ),
        ];

        $rows = [];
        $blocked = $this->get_blocked_api_keys();
        foreach ( $groups as $provider => $items ) {
            $seen = [];
            $order = 1;
            foreach ( $items as $item ) {
                $key = trim( (string) ( $item['key'] ?? '' ) );
                if ( $key === '' ) { continue; }
                $hash = $this->api_key_hash( $key );
                if ( isset( $seen[ $hash ] ) ) { continue; }
                $seen[ $hash ] = true;
                $rows[] = [
                    'provider'   => $provider,
                    'order'      => $order++,
                    'label'      => $item['label'],
                    'masked'     => $this->mask_api_key( $key ),
                    'blocked'    => isset( $blocked[ $hash ] ),
                    'block_info' => $blocked[ $hash ] ?? null,
                ];
            }
        }
        return $rows;
    }

    private function get_available_ai_providers() {
        return [
            'gemini' => count( $this->get_api_key_pool( false ) ),
            'grok'      => count( $this->get_grok_api_keys() ),
            'groqcloud' => count( $this->get_groqcloud_api_keys() ),
            'zai'       => count( $this->get_zai_api_keys() ),
        ];
    }

    public static function supported_models() {
        return [
            'gemini-2.5-flash' => 'Gemini 2.5 Flash — default stabil, cepat, cocok untuk artikel harian',
            'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash-Lite — lebih ringan dan ekonomis',
            'gemini-2.5-pro' => 'Gemini 2.5 Pro — reasoning lebih kuat untuk artikel panjang/kompleks',
            'gemini-3.1-flash-lite-preview' => 'Gemini 3.1 Flash-Lite Preview — preview, cepat dan ringan',
        ];
    }





    public function sanitize_fallback_models_textarea( $value ) {
        $value = is_string( $value ) ? wp_unslash( $value ) : '';
        $rows = preg_split( '/\r\n|\r|\n|,/', $value );
        $supported = array_keys( self::supported_models() );
        $clean = [];
        foreach ( $rows as $row ) {
            $model = $this->normalize_model_name( $row );
            if ( in_array( $model, $supported, true ) && ! in_array( $model, $clean, true ) ) {
                $clean[] = $model;
            }
        }
        return implode( "\n", $clean );
    }

    private function get_gemini_model_chain( $primary_model = '' ) {
        $primary = $this->normalize_model_name( $primary_model ?: get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        $raw = get_option( self::OPTION_GEMINI_FALLBACK_MODELS, "gemini-2.5-flash-lite\ngemini-2.5-pro" );
        $rows = preg_split( '/\r\n|\r|\n|,/', (string) $raw );
        $chain = [ $primary ];
        foreach ( $rows as $row ) {
            $model = $this->normalize_model_name( $row );
            if ( $model && ! in_array( $model, $chain, true ) ) { $chain[] = $model; }
        }
        return $chain;
    }

    private function build_gemini_payload( $model, $system_prompt, $user_text, $schema, $use_search ) {
        if ( $use_search ) {
            $json_contract = "\n\nFORMAT OUTPUT WAJIB:\n" .
                "Balas HANYA dengan JSON object valid tanpa markdown, tanpa ```json, tanpa teks tambahan. " .
                "JSON harus mengikuti schema ini secara ketat:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            return [
                'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt . $json_contract ] ] ],
                'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
                'tools'             => [ [ 'google_search' => new stdClass() ] ],
            ];
        }
        return [
            'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt ] ] ],
            'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
            'generationConfig'  => [
                'responseMimeType' => 'application/json',
                'responseSchema'   => $schema,
            ],
        ];
    }

    public static function builtin_prompt( $key ) {
        $prompts = [
            'default' => <<<'HEAJ_PROMPT_DEFAULT'
{
  "role": "Asisten Jurnalistik Profesional untuk media/website pengguna",
  "task": "Menulis ulang artikel berita secara SANGAT AKURAT berdasarkan sumber (link atau teks) yang diberikan pengguna dengan menerapkan prinsip Piramida Terbalik.",
  
  "input": { 
    "source": "[Diberikan pengguna: URL, teks, atau transkrip video]" 
  },
  
  "strict_accuracy_rules": {
    "rule_1": "Bila berupa URL, WAJIB gunakan alat pencari untuk MEMBACA ISI TAUTAN tersebut secara langsung.",
    "rule_2": "DILARANG KERAS berhalusinasi, menambahkan opini, cerita, nama tokoh, atau kejadian yang tidak terdapat dalam sumber asli. Fokus pada parafrase fakta.",
    "rule_3": "Tulis ulang HANYA berdasarkan data mutlak dari input."
  },

  "journalistic_structure": {
    "principle": "Piramida Terbalik (Inverted Pyramid)",
    "description": "Susun berita dari informasi paling penting di bagian atas hingga informasi paling tidak penting di bagian bawah.",
    "structure_order": [
      {
        "section": "Headline",
        "position": "Paling atas",
        "rules": [
          "Singkat (maksimal 60 karakter)",
          "Padat, jelas, dan menarik",
          "Mengandung unsur utama (biasanya What + Who)",
          "Gunakan kata kerja aktif dan kuat"
        ]
      },
      {
        "section": "Lead (Teras Berita)",
        "position": "Paragraf pertama",
        "rules": [
          "Langsung menyampaikan inti berita (What, Who, Where, When)",
          "Maksimal 35 kata",
          "Format: [NAMA MEDIA], [KOTA] - [Inti berita]. [Hari,] (DD/MM/YYYY)",
          "Harus bisa berdiri sendiri sebagai ringkasan utama"
        ]
      },
      {
        "section": "Body",
        "position": "Isi utama",
        "inverted_pyramid_rule": "Susun dari yang paling penting ke yang kurang penting",
        "paragraph_order": [
          "Paragraf 2: Detail utama (kondisi, jumlah, dampak langsung, penanganan)",
          "Paragraf 3: Kronologi kejadian secara urut",
          "Paragraf 4: Kutipan narasumber resmi",
          "Paragraf 5 dst: Data pendukung, latar belakang, informasi tambahan"
        ]
      },
      {
        "section": "Tail (Penutup)",
        "position": "Paling bawah",
        "rules": [
          "Berisi informasi pelengkap yang tidak krusial",
          "Bisa berupa imbauan, rencana tindak lanjut, atau fakta tambahan",
          "Boleh dipotong oleh editor tanpa merusak inti berita"
        ]
      }
    ]
  },

  "writing_goals": {
    "language": "Bahasa Indonesia",
    "style": "Jurnalistik profesional, lugas, jelas, dan to the point",
    "tone": "Netral, profesional, tanpa clickbait atau sensasionalisme",
    "uniqueness": "Parafrase narasi dengan susunan kalimat baru dan gaya sendiri agar tidak duplikasi konten. HANYA menggunakan informasi dari referensi, 100% bebas halusinasi.",
    "voice": "Aktif; hindari kalimat pasif",
    "length_rule": "Ikuti kelengkapan fakta sumber, tetapi tulis ulang narasi dengan struktur dan kalimat baru"
  },

  "article_structure": {
    "headline": { 
      "max_length": 60, 
      "requirement": "SEO-friendly, informatif, sangat relevan dengan inti sumber" 
    },
    "lead": {
      "max_words": 35,
      "format": "[NAMA MEDIA], [KOTA ASAL KEJADIAN DARI SUMBER] - [kalimat SPOK]. (DD/MM/YYYY)",
      "note": "KOTA dan TANGGAL wajib diambil tepat seperti di sumber"
    },
    "body": {
      "use_headings": "Gunakan heading (H2, H3) jika sesuai untuk memecah teks",
      "quotes": {
        "format": "\"[KUTIPAN AKURAT SAMA PERSIS DENGAN SUMBER MENTAH]\" ujar [NAMA LENGKAP] ([JABATAN]) di [LOKASI], [HARI/TANGGAL]."
      },
      "dates_times": "Pertahankan waktu dan tanggal persis seperti di sumber, JANGAN MENGARANG."
    },
    "footer": { 
      "references": "Sertakan link sumber referensi asli" 
    }
  },

  "seo_requirements": {
    "slug": "Buat 3 opsi slug SEO-friendly singkat",
    "meta_description": "Buat 3-5 opsi meta deskripsi (maks 160 karakter)",
    "tags": "Minimal 10 tag relevan (tanpa tanda #) huruf kecil semua",
    "category": "Tentukan kategori / label yang relevan"
  },

  "final_instruction": "Selalu terapkan prinsip Piramida Terbalik secara ketat: letakkan informasi paling penting di Lead dan awal Body, kemudian susun secara menurun pentingnya hingga Tail."
}
HEAJ_PROMPT_DEFAULT,
            'straight_news' => <<<'HEAJ_PROMPT_STRAIGHT'
{
  "role": "Professional Journalist & SEO Content Writer",
  "task": "Tulis ulang artikel berita menjadi Straight News yang SANGAT AKURAT berdasarkan tautan/sumber.",
  "strict_accuracy_rules": { 
    "rule_1": "DILARANG KERAS menambahkan fakta, cerita, tokoh, atau spekulasi baru. Hanya gunakan informasi murni yang ada di dalam referensi.",
    "rule_2": "Gunakan alat pencarian HANYA untuk mengekstrak isi teks sebenarnya dari URL yang diberikan pengguna."
  },
  "writing_goals": {
    "language_style": "Jurnalistik + Santai",
    "tone": "Netral, Objektif, Seimbang",
    "plagiarism": "100% unik dengan parafrase, tetapi TANPA mengubah esensi fakta",
    "fact_policy": "Fakta 100% WAJIB HANYA berasal dari sumber."
  },
  "journalistic_standards": {
    "mandatory_elements_lead": "lead [3W+1H maks 160 word]",
    "mandatory_elements_content": "content [5W+1H]",
    "structure": "Piramida Terbalik",
    "accuracy": "Semua fakta harus sesuai dengan sumbernya."
  },
  "article_structure": {
    "title": { "rules": ["Menarik dan informatif", "Mencerminkan isi nyata berita"] },
    "meta_description": { "max_length": 160, "rules": ["Standar jurnalistik", "Berisi intisari berita"] },
    "content": {
      "min_word_count": 350,
      "sections": ["Lead (ringkasan inti berita standar jurnalistik)", "Detail peristiwa murni dari sumber", "Kronologi peristiwa jika ada di sumber", "Dampak pihak terkait", "Gunakan <h2>/<h3> untuk subtopik penting", "Gunakan <ul><li> jika ada poin penting", "Gunakan <blockquote> untuk kutipan", "<strong> untuk kata penting"],
      "writing_style_rules": ["Gunakan bahasa santai namun profesional.", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan", "Transisi halus"]
    }
  },
  "output_format": [
    "TITLE:", 
    "SLUG: Buat 3 opsi slug",
    "META DESCRIPTION: Buat 3-5 opsi meta",
    "ARTICLE CONTENT:",
    "BUAT 10 TAG SESUAI DENGAN ARTIKEL (koma, tanpa #, huruf kecil)",
    "category: Tentukan kategori"
  ]
}
HEAJ_PROMPT_STRAIGHT,
            'jurnalis_heading' => <<<'HEAJ_PROMPT_REWRITE'
{ "role": "Jurnalis Profesional & SEO Content Writer", "task": "Menulis ulang artikel berita dengan SANGAT AKURAT sesuai link sumber yang diberikan", "strict_accuracy_rules": { "rule_1": "Bila berupa URL, gunakan tool untuk ekstraksi teks halaman tersebut", "rule_2": "JANGAN PERNAH menyertakan data, kejadian, opini, atau waktu yang tidak tercantum di dalam teks sumber" }, "writing_goals": { "language_style": "Santai", "tone": "Netral, Objektif", "fact_policy": "100% FAKTA DARI SUMBER ASLI, DILARANG MENGARANG" }, "journalistic_standards": { "mandatory_elements_lead": "lead [3W+1H maks 160 word]", "mandatory_elements_content": "content [5W+1H]", "structure": "Piramida Terbalik", "accuracy": "Semua fakta wajib sama persis dengan sumber" }, "article_structure": { "title": { "rules": ["Menarik", "Tidak clickbait", "Sesuai sumber"] }, "meta_description": { "max_length": 160, "rules": ["Intisari berita"] }, "content": { "min_word_count": 800, "sections": ["H2: Topik utama", "H3: Penjelasan detail", "Lead", "Detail peristiwa", "Kronologi (jika ada di sumber)", "Buat blockquote Pernyataan narasumber", "Bold keyword", "Bullet list bila relevan"], "writing_style_rules": ["Bahasa santai profesional", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan"] } } }
HEAJ_PROMPT_REWRITE,
            'seo_artikel' => <<<'HEAJ_PROMPT_SEO'
{ "role": "SEO Content Writer Professional", "goal": "Membuat artikel SEO SANGAT AKURAT dari referensi pengguna", "strict_accuracy_rules": { "rule_1": "Wajib mendasarkan seluruh konten murni pada fakta di teks/URL referensi", "rule_2": "Dilarang keras berhalusinasi atau menambahkan konteks luar" }, "general_criteria": { "minimum_word_count": 1000, "language": "Bahasa Indonesia", "writing_style": "Casual / Santai", "tone": "Informatif + Solutif", "readability": "Mudah dipahami", "seo_requirements": ["SEO-friendly", "Gunakan active voice"] }, "article_structure": { "title": { "format": "H1", "requirements": ["Mengandung keyword", "SEO optimized"] }, "meta_description": { "max_length": 160, "requirements": ["Mengandung keyword", "Relevan"] }, "introduction": { "paragraphs": "2-3 paragraphs", "requirements": ["Gaya santai", "Menarik"] }, "main_content": { "heading_structure": { "H2": "Topik utama", "H3": "Penjelasan detail" }, "mandatory_elements": ["Penjelasan mendalam murni dari sumber", "Gunakan heading H2/H3", "Gunakan bullet point", "Gunakan bold/blockquote bila relevan", "Bahas sesuai fakta referensi semata"] }, "faq_section": { "minimum_questions": 5, "format": "Tanya jawab", "requirements": ["Pertanyaan relevan dengan konten", "Jawaban akurat"] }, "conclusion": { "requirements": ["Ringkas isi artikel"] } } }
HEAJ_PROMPT_SEO,
        ];
        return isset( $prompts[ $key ] ) ? $prompts[ $key ] : '';
    }

    public static function default_brand_settings() {
        return [
            'brand_name'       => 'YZG AI Journalist',
            'media_name'       => '',
            'organization'     => '',
            'logo_url'         => '',
            'primary_color'    => '#0f172a',
            'developer_name'   => 'YanuarZG',
            'developer_url'    => 'https://yanuarzg.github.io/',
            'copyright_text'   => 'Hak Cipta © 2026 YanuarZG',
            'warning_text'     => '',
            'brand_voice'      => 'Jurnalistik profesional, netral, faktual, dan mudah dipahami.',
            'forbidden_words'  => '',
            'default_city'     => '',
            'footer_style'     => 'media',
            'seo_style'        => 'news',
            'license_type'     => 'auto',
            'authors_source'   => 'manual',
        ];
    }

    private function get_brand_settings() {
        $settings = $this->get_custom_settings();
        $brand = isset( $settings['branding'] ) && is_array( $settings['branding'] ) ? $settings['branding'] : [];
        return array_merge( self::default_brand_settings(), $brand );
    }

    private function get_media_name() {
        $brand = $this->get_brand_settings();
        $name = trim( (string) ( $brand['media_name'] ?: $brand['organization'] ?: get_bloginfo( 'name' ) ) );
        return $name !== '' ? $name : ( wp_parse_url( home_url(), PHP_URL_HOST ) ?: 'Website' );
    }

    private function get_plugin_brand_name() {
        $brand = $this->get_brand_settings();
        return trim( (string) ( $brand['brand_name'] ?: 'YZG AI Journalist' ) );
    }

    private function get_brand_instruction() {
        $brand = $this->get_brand_settings();
        $parts = [];
        $parts[] = 'Nama media/website: ' . $this->get_media_name();
        if ( ! empty( $brand['organization'] ) ) { $parts[] = 'Organisasi/redaksi: ' . $brand['organization']; }
        if ( ! empty( $brand['brand_voice'] ) ) { $parts[] = 'Brand voice: ' . $brand['brand_voice']; }
        if ( ! empty( $brand['default_city'] ) ) { $parts[] = 'Kota default jika relevan dan ada di sumber: ' . $brand['default_city']; }
        if ( ! empty( $brand['seo_style'] ) ) { $parts[] = 'Gaya SEO: ' . $brand['seo_style']; }
        if ( ! empty( $brand['footer_style'] ) ) { $parts[] = 'Gaya penutup/footer artikel: ' . $brand['footer_style']; }
        if ( ! empty( $brand['forbidden_words'] ) ) { $parts[] = 'Hindari kata/frasa: ' . $brand['forbidden_words']; }
        return implode( "\n", $parts );
    }

    private function get_author_editor_names( $type = 'authors' ) {
        $settings = $this->get_custom_settings();
        $brand = $this->get_brand_settings();
        $manual = isset( $settings[ $type ] ) && is_array( $settings[ $type ] ) ? $settings[ $type ] : [];
        $source = $brand['authors_source'] ?? 'manual';
        $wp_names = [];
        if ( in_array( $source, [ 'wp_users', 'both' ], true ) ) {
            $wp_names = $this->get_author_editor_names_from_wp( $type );
        }
        if ( $source === 'wp_users' ) { return array_values( array_unique( $wp_names ) ); }
        if ( $source === 'both' ) { return array_values( array_unique( array_merge( $manual, $wp_names ) ) ); }
        return array_values( array_unique( $manual ) );
    }

    private function is_network_directory_enabled() {
        $brand = $this->get_brand_settings();
        $mode = $brand['license_type'] ?? 'auto';
        if ( $mode === 'harianexpress_network' || $mode === 'agency' ) { return true; }
        if ( $mode === 'single_site' ) { return false; }
        return $this->is_harianexpress_com_domain();
    }

    public static function default_custom_settings() {
        return [
            'prompts' => [
                [ 'key' => 'default', 'label' => 'Standar Jurnalistik', 'prompt' => self::builtin_prompt( 'default' ) ],
                [ 'key' => 'straight_news', 'label' => 'Straight News', 'prompt' => self::builtin_prompt( 'straight_news' ) ],
                [ 'key' => 'jurnalis_heading', 'label' => 'Rewrite Artikel', 'prompt' => self::builtin_prompt( 'jurnalis_heading' ) ],
                [ 'key' => 'seo_artikel', 'label' => 'Target SEO Page 1', 'prompt' => self::builtin_prompt( 'seo_artikel' ) ],
            ],
            'lengths' => [
                [ 'label' => 'Sesuai prompt', 'value' => '' ],
                [ 'label' => 'Pendek (300-500)', 'value' => 'minimal 300 kata - maksimal 500 kata' ],
                [ 'label' => 'Sedang (1000+)', 'value' => 'minimal 1000 kata' ],
                [ 'label' => 'Panjang (1500+)', 'value' => 'minimal 1500 kata' ],
            ],
            'languages' => [
                [ 'code' => 'id', 'label' => 'Indonesia', 'instruction' => 'Tulis output dalam Bahasa Indonesia.' ],
                [ 'code' => 'en', 'label' => 'English', 'instruction' => 'Write the output in English.' ],
            ],
            'branding' => self::default_brand_settings(),
            'global_prompt' => '',
            'authors' => [ 'Achmad Fauzan', 'Ajeng Mietaswary Annisa', 'Cavin Juliansyah', 'Findy Alfiansyah', 'Heri Purwadyo', 'Ipnu Subroto', 'Muklis Purwanto', 'Ridwan Habibie', 'Yanuar Zhaldy G' ],
            'editors' => [ 'Achmad Fauzan', 'Findy Alfiansyah', 'Ipnu Subroto', 'Muklis Purwanto', 'Ridwan Habibie', 'Yanuar Zhaldy G' ],
        ];
    }

    public function sanitize_custom_settings( $value ) {
        if ( is_string( $value ) ) {
            $decoded = json_decode( wp_unslash( $value ), true );
            $value = is_array( $decoded ) ? $decoded : [];
        }
        if ( ! is_array( $value ) ) { $value = []; }
        $defaults = self::default_custom_settings();
        $clean = [ 'prompts' => [], 'lengths' => [], 'languages' => [], 'authors' => [], 'editors' => [], 'branding' => self::default_brand_settings(), 'global_prompt' => '' ];

        if ( isset( $value['prompts'] ) && is_array( $value['prompts'] ) ) {
            foreach ( $value['prompts'] as $row ) {
                if ( ! is_array( $row ) ) { continue; }
                $label = sanitize_text_field( $row['label'] ?? '' );
                $key = sanitize_key( $row['key'] ?? '' );
                $prompt = sanitize_textarea_field( $row['prompt'] ?? '' );
                if ( $label === '' ) { continue; }
                if ( $key === '' ) { $key = 'custom_' . substr( md5( $label ), 0, 10 ); }
                // Backward compatibility: exported JSON from v3.3.11 stored built-in prompts as blank.
                // Refill built-in prompts so import/export never makes default generators empty.
                if ( $prompt === '' && in_array( $key, [ 'default', 'straight_news', 'jurnalis_heading', 'seo_artikel' ], true ) ) {
                    $prompt = self::builtin_prompt( $key );
                }
                $clean['prompts'][] = [ 'key' => $key, 'label' => $label, 'prompt' => $prompt ];
            }
        }
        if ( isset( $value['lengths'] ) && is_array( $value['lengths'] ) ) {
            foreach ( $value['lengths'] as $row ) {
                if ( ! is_array( $row ) ) { continue; }
                $label = sanitize_text_field( $row['label'] ?? '' );
                $val = sanitize_text_field( $row['value'] ?? '' );
                if ( $label !== '' ) { $clean['lengths'][] = [ 'label' => $label, 'value' => $val ]; }
            }
        }
        if ( isset( $value['languages'] ) && is_array( $value['languages'] ) ) {
            foreach ( $value['languages'] as $row ) {
                if ( ! is_array( $row ) ) { continue; }
                $code = sanitize_key( $row['code'] ?? '' );
                $label = sanitize_text_field( $row['label'] ?? '' );
                $instruction = sanitize_text_field( $row['instruction'] ?? '' );
                if ( $code !== '' && $label !== '' ) { $clean['languages'][] = [ 'code' => $code, 'label' => $label, 'instruction' => $instruction ]; }
            }
        }
        if ( isset( $value['branding'] ) && is_array( $value['branding'] ) ) {
            $bd = array_merge( self::default_brand_settings(), $value['branding'] );
            $clean['branding'] = [
                'brand_name'       => sanitize_text_field( $bd['brand_name'] ?? '' ),
                'media_name'       => sanitize_text_field( $bd['media_name'] ?? '' ),
                'organization'     => sanitize_text_field( $bd['organization'] ?? '' ),
                'logo_url'         => esc_url_raw( $bd['logo_url'] ?? '' ),
                'primary_color'    => sanitize_hex_color( $bd['primary_color'] ?? '#0f172a' ) ?: '#0f172a',
                'developer_name'   => sanitize_text_field( $bd['developer_name'] ?? '' ),
                'developer_url'    => esc_url_raw( $bd['developer_url'] ?? '' ),
                'copyright_text'   => sanitize_text_field( $bd['copyright_text'] ?? '' ),
                'warning_text'     => sanitize_textarea_field( $bd['warning_text'] ?? '' ),
                'brand_voice'      => sanitize_textarea_field( $bd['brand_voice'] ?? '' ),
                'forbidden_words'  => sanitize_textarea_field( $bd['forbidden_words'] ?? '' ),
                'default_city'     => sanitize_text_field( $bd['default_city'] ?? '' ),
                'footer_style'     => sanitize_key( $bd['footer_style'] ?? 'media' ),
                'seo_style'        => sanitize_key( $bd['seo_style'] ?? 'news' ),
                'license_type'     => sanitize_key( $bd['license_type'] ?? 'auto' ),
                'authors_source'   => sanitize_key( $bd['authors_source'] ?? 'manual' ),
            ];
        }
        $clean['global_prompt'] = sanitize_textarea_field( $value['global_prompt'] ?? '' );

        foreach ( [ 'authors', 'editors' ] as $key ) {
            $names_source = $value[ $key ] ?? [];
            if ( is_string( $names_source ) ) {
                $names_source = preg_split( '/\r?\n/', wp_unslash( $names_source ) );
            }
            if ( is_array( $names_source ) ) {
                foreach ( $names_source as $name ) {
                    $name = sanitize_text_field( $name );
                    if ( $name !== '' && ! in_array( $name, $clean[ $key ], true ) ) { $clean[ $key ][] = $name; }
                }
            }
        }
        foreach ( $clean as $key => $rows ) {
            if ( empty( $rows ) && isset( $defaults[ $key ] ) ) { $clean[ $key ] = $defaults[ $key ]; }
        }
        return $clean;
    }

    private function get_custom_settings() {
        $settings = get_option( self::OPTION_CUSTOM_SETTINGS, self::default_custom_settings() );
        return $this->sanitize_custom_settings( is_array( $settings ) ? $settings : [] );
    }

    public function sanitize_pexels_api_key( $value ) {
        return sanitize_text_field( trim( (string) $value ) );
    }


    public static function maybe_schedule_cleanup_history() {
        if ( ! wp_next_scheduled( 'he_journalist_cleanup_history' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'he_journalist_cleanup_history' );
        }
    }

    public static function cleanup_history() {
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { return; }
        $cutoff = time() - ( 30 * DAY_IN_SECONDS );
        $clean = [];
        foreach ( $history as $item ) {
            if ( ! is_array( $item ) ) { continue; }
            $time = isset( $item['time'] ) ? strtotime( (string) $item['time'] ) : 0;
            if ( ! $time || $time >= $cutoff ) { $clean[] = $item; }
        }
        $clean = array_slice( $clean, 0, 150 );
        update_option( self::OPTION_HISTORY, $clean, false );
    }

    private function sanitize_ai_json_value( $value, $key = '' ) {
        if ( is_array( $value ) ) {
            $clean = [];
            foreach ( $value as $k => $v ) {
                $clean_key = is_string( $k ) ? sanitize_key( $k ) : $k;
                $clean[ $clean_key ] = $this->sanitize_ai_json_value( $v, is_string( $k ) ? $k : $key );
            }
            return $clean;
        }
        if ( is_string( $value ) ) {
            $key = strtolower( (string) $key );
            if ( in_array( $key, [ 'references', 'source_url', 'source_urls', 'url', 'image', 'imageurl' ], true ) ) {
                return esc_url_raw( $value );
            }
            if ( in_array( $key, [ 'articlebody', 'article_body', 'content', 'html' ], true ) ) {
                return wp_kses_post( $value );
            }
            return sanitize_text_field( $value );
        }
        if ( is_bool( $value ) || is_numeric( $value ) || null === $value ) { return $value; }
        return '';
    }

    private function sanitize_ai_json_result( $result, $schema = [] ) {
        if ( ! is_array( $result ) ) { return []; }
        $clean = [];
        foreach ( $result as $key => $value ) {
            $clean_key = sanitize_key( (string) $key );
            if ( $clean_key === '' ) { continue; }
            $clean[ $clean_key ] = $this->sanitize_ai_json_value( $value, $key );
        }
        // Preserve expected camelCase keys used by the frontend while still sanitizing values.
        $expected = [ 'titleOptions', 'slugOptions', 'metaDescriptions', 'category', 'tags', 'articleBody', 'references', 'twitterThread', 'igFbCaption', 'takeaways', 'visualCues', 'hook', 'body', 'cta', 'imageKeywords' ];
        foreach ( $expected as $key ) {
            if ( array_key_exists( $key, $result ) ) {
                $clean[ $key ] = $this->sanitize_ai_json_value( $result[ $key ], $key );
            }
        }
        return $clean;
    }

    private function gemini_cache_key( $model, $system_prompt, $user_text, $schema, $use_search ) {
        return 'heaj_gem_' . md5( wp_json_encode( [ $model, $system_prompt, $user_text, $schema, (bool) $use_search ] ) );
    }

    public function handle_reset_custom_settings() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_reset_custom_settings' );
        update_option( self::OPTION_CUSTOM_SETTINGS, self::default_custom_settings(), false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-custom-settings', 'heaj-custom-reset' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_clear_generate_history() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_clear_generate_history' );
        update_option( self::OPTION_HISTORY, [], false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-custom-settings', 'heaj-history-cleared' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    public function handle_delete_generate_history() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        $id = isset( $_GET['id'] ) ? sanitize_key( wp_unslash( $_GET['id'] ) ) : '';
        check_admin_referer( 'heaj_delete_generate_history_' . $id );
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( is_array( $history ) && $id !== '' ) {
            $history = array_values( array_filter( $history, function( $item ) use ( $id ) {
                return ! ( is_array( $item ) && isset( $item['id'] ) && $item['id'] === $id );
            } ) );
            update_option( self::OPTION_HISTORY, $history, false );
        }
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-history', 'heaj-deleted' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    public static function editor_admin_capability() {
        return 'edit_others_posts';
    }

    public function allow_editor_admin_option_page( $capability ) {
        return self::editor_admin_capability();
    }

    public function sanitize_api_keys_textarea( $value ) {
        $value = is_string( $value ) ? wp_unslash( $value ) : '';
        $lines = preg_split( '/\r\n|\r|\n/', $value );
        $keys = [];
        $seen = [];
        foreach ( $lines as $line ) {
            $key = trim( $line );
            if ( $key === '' ) { continue; }
            $key = sanitize_text_field( $key );
            $hash = hash_hmac( 'sha256', $key, wp_salt( 'auth' ) );
            if ( isset( $seen[ $hash ] ) ) { continue; }
            $seen[ $hash ] = true;
            $keys[] = $key;
        }
        return implode( "\n", $keys );
    }



    public function sanitize_prompt_overrides( $value ) {
        $value = is_array( $value ) ? $value : [];
        $allowed = [ 'default', 'straight_news', 'jurnalis_heading', 'seo_artikel', 'global' ];
        $clean = [];
        foreach ( $allowed as $key ) {
            $raw = isset( $value[ $key ] ) ? wp_unslash( $value[ $key ] ) : '';
            $raw = is_string( $raw ) ? trim( $raw ) : '';
            if ( $raw !== '' ) {
                $clean[ $key ] = sanitize_textarea_field( $raw );
            }
        }
        return $clean;
    }

    private function get_prompt_overrides() {
        $value = get_option( self::OPTION_PROMPT_OVERRIDES, [] );
        return is_array( $value ) ? $value : [];
    }

    private function add_history_event( array $event ) {
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { $history = []; }
        $defaults = [
            'time'       => current_time( 'mysql' ),
            'user_id'    => get_current_user_id(),
            'user'       => wp_get_current_user()->display_name ?: wp_get_current_user()->user_login,
            'domain'     => wp_parse_url( home_url(), PHP_URL_HOST ),
            'id'         => 'heh_' . wp_generate_uuid4(),
            'title'      => '',
            'source_url' => '',
            'source_urls'=> [],
            'draft_status' => 'not_sent',
            'provider'   => '',
            'status'     => 'generated',
            'post_id'    => 0,
            'edit_url'   => '',
            'title_index' => 0,
            'slug_index' => 0,
            'meta_index' => 0,
            'image_source' => '',
            'selected_image_url' => '',
        ];
        $event = array_merge( $defaults, $event );
        $event['id'] = sanitize_key( $event['id'] );
        $event['title'] = sanitize_text_field( $event['title'] );
        $event['source_url'] = esc_url_raw( $event['source_url'] );
        $event['source_urls'] = isset( $event['source_urls'] ) && is_array( $event['source_urls'] ) ? array_values( array_unique( array_filter( array_map( 'esc_url_raw', $event['source_urls'] ) ) ) ) : [];
        $event['draft_status'] = sanitize_key( $event['draft_status'] );
        $event['provider'] = sanitize_text_field( $event['provider'] );
        $event['status'] = sanitize_text_field( $event['status'] );
        $event['post_id'] = absint( $event['post_id'] );
        $event['edit_url'] = esc_url_raw( $event['edit_url'] );
        $event['title_index'] = absint( $event['title_index'] ?? 0 );
        $event['slug_index'] = absint( $event['slug_index'] ?? 0 );
        $event['meta_index'] = absint( $event['meta_index'] ?? 0 );
        $event['image_source'] = sanitize_text_field( $event['image_source'] ?? '' );
        $event['selected_image_url'] = esc_url_raw( $event['selected_image_url'] ?? '' );
        foreach ( [ 'source_input', 'prompt_style', 'prompt_label', 'language', 'image_source', 'model_used' ] as $field ) {
            if ( isset( $event[ $field ] ) ) { $event[ $field ] = sanitize_text_field( $event[ $field ] ); }
        }
        if ( isset( $event['cached'] ) ) { $event['cached'] = (bool) $event['cached']; }
        array_unshift( $history, $event );
        $history = array_slice( $history, 0, 150 );
        update_option( self::OPTION_HISTORY, $history, false );
        return $event['id'];
    }

    private function update_history_generated_to_draft( $history_id, $post_id, $edit_url ) {
        $history_id = sanitize_key( $history_id );
        if ( ! $history_id ) { return; }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { return; }
        foreach ( $history as &$item ) {
            if ( isset( $item['id'] ) && $item['id'] === $history_id ) {
                $item['draft_status'] = 'sent';
                $item['linked_post_id'] = absint( $post_id );
                $item['linked_edit_url'] = esc_url_raw( $edit_url );
                break;
            }
        }
        unset( $item );
        update_option( self::OPTION_HISTORY, $history, false );
    }

    public function handle_check_updates_now() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_check_updates_now' );
        delete_site_transient( 'update_plugins' );
        wp_clean_plugins_cache( true );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-settings', 'heaj-update-check' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    private function get_extra_api_keys() {
        $raw = get_option( self::OPTION_EXTRA_API_KEYS, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) );
    }

    private function api_key_hash( $key ) {
        return hash_hmac( 'sha256', (string) $key, wp_salt( 'auth' ) );
    }

    private function get_blocked_api_keys() {
        $blocked = get_option( self::OPTION_BLOCKED_API_KEYS, [] );
        return is_array( $blocked ) ? $blocked : [];
    }

    private function is_api_key_blocked( $key ) {
        $hash = $this->api_key_hash( $key );
        $blocked = $this->get_blocked_api_keys();
        return isset( $blocked[ $hash ] );
    }

    private function block_api_key( $key, $reason = '' ) {
        $key = trim( (string) $key );
        if ( $key === '' ) { return; }
        $hash = $this->api_key_hash( $key );
        $blocked = $this->get_blocked_api_keys();
        $blocked[ $hash ] = [
            'masked'     => $this->mask_api_key( $key ),
            'reason'     => sanitize_text_field( $reason ?: 'API key ditolak permanen oleh provider AI.' ),
            'blocked_at' => current_time( 'mysql' ),
        ];
        update_option( self::OPTION_BLOCKED_API_KEYS, $blocked, false );
    }

    private function get_api_key_pool( $include_blocked = false ) {
        $manager = new HEAJ_API_Key_Manager( 'gemini', $this->get_blocked_api_keys() );
        return $manager->get_pool( $include_blocked );
    }

    private function get_provider_key_pool( $provider, $include_blocked = false ) {
        $manager = new HEAJ_API_Key_Manager( $provider, $this->get_blocked_api_keys() );
        return $manager->get_pool( $include_blocked );
    }

    private function get_all_api_keys() {
        return array_values( array_map( function( $item ) { return $item['key']; }, $this->get_api_key_pool( false ) ) );
    }

    public function handle_reset_blocked_api_keys() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_reset_blocked_api_keys' );
        update_option( self::OPTION_BLOCKED_API_KEYS, [], false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-settings', 'heaj-blocked-reset' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    private function extract_json_from_text( $text ) {
        $text = trim( (string) $text );
        if ( $text === '' ) { return null; }

        $direct = json_decode( $text, true );
        if ( is_array( $direct ) ) { return $direct; }

        if ( preg_match( '/```(?:json)?\s*(\{.*?\})\s*```/s', $text, $matches ) ) {
            $decoded = json_decode( trim( $matches[1] ), true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        $start = strpos( $text, '{' );
        $end   = strrpos( $text, '}' );
        if ( $start !== false && $end !== false && $end > $start ) {
            $candidate = substr( $text, $start, $end - $start + 1 );
            $decoded = json_decode( $candidate, true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        return null;
    }


    private function normalize_model_name( $model ) {
        $model = trim( (string) $model );
        $deprecated = [
            '',
            'gemini-2.5-flash-preview-09-2025',
            'models/gemini-2.5-flash-preview-09-2025',
            'gemini-2.0-flash',
            'models/gemini-2.0-flash',
        ];
        if ( in_array( $model, $deprecated, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        $model = preg_replace( '#^models/#', '', $model );
        $model = sanitize_text_field( $model );
        $supported = array_keys( self::supported_models() );
        if ( ! in_array( $model, $supported, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        return $model;
    }


    private function is_retryable_gemini_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) {
            return true;
        }

        $retryable_phrases = [
            'high demand',
            'overloaded',
            'temporarily unavailable',
            'try again later',
            'resource exhausted',
            'quota',
            'rate limit',
            'deadline',
            'timeout',
            'timed out',
            'internal error',
            'service unavailable',
        ];

        foreach ( $retryable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return false;
    }


    private function is_blockable_gemini_api_key_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        $blockable_phrases = [
            'api key was reported as leaked',
            'reported as leaked',
            'please use another api key',
            'api key not valid',
            'api_key_invalid',
            'invalid api key',
            'permission_denied',
            'api key expired',
            'api key has expired',
            'api key disabled',
            'key disabled',
        ];

        foreach ( $blockable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return in_array( $status, [ 400, 401, 403 ], true ) && false !== strpos( $message, 'api key' );
    }

    private function retry_delay_seconds( $round ) {
        $round = max( 1, (int) $round );
        return min( 8, 2 ** $round );
    }

    private function mask_api_key( $key ) {
        $key = (string) $key;
        if ( strlen( $key ) <= 12 ) { return str_repeat( '•', strlen( $key ) ); }
        return substr( $key, 0, 7 ) . str_repeat( '•', max( 6, strlen( $key ) - 14 ) ) . substr( $key, -7 );
    }


    public function sanitize_model_name( $value ) {
        return $this->normalize_model_name( wp_unslash( $value ) );
    }

    public function register_settings() {
        register_setting( 'he_journalist_options', self::OPTION_EXTRA_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GROK_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GROQ_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_ZAI_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_PROMPT_OVERRIDES, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_prompt_overrides' ],
            'default'           => [],
        ] );
        register_setting( 'he_journalist_options', self::OPTION_PEXELS_API_KEY, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_pexels_api_key' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_custom_options', self::OPTION_CUSTOM_SETTINGS, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_custom_settings' ],
            'default'           => self::default_custom_settings(),
        ] );
        register_setting( 'he_journalist_options', self::OPTION_MODEL, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_model_name' ],
            'default'           => 'gemini-2.5-flash',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GEMINI_FALLBACK_MODELS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_fallback_models_textarea' ],
            'default'           => "gemini-2.5-flash-lite\ngemini-2.5-pro",
        ] );

        $stored_model = get_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        $fixed_model  = $this->normalize_model_name( $stored_model );
        if ( $stored_model !== $fixed_model ) {
            update_option( self::OPTION_MODEL, $fixed_model );
        }
    }

    public function add_menu() {
        add_menu_page(
            $this->get_plugin_brand_name(),
            $this->get_plugin_brand_name(),
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ],
            'dashicons-edit-large',
            30
        );
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Generator Artikel' ),
            $this->tr_ui( 'Generator Artikel' ),
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ]
        );
        if ( $this->is_network_directory_enabled() ) {
            add_submenu_page(
                'he-journalist',
                $this->tr_ui( 'Network Sites' ),
                $this->tr_ui( 'Network Sites' ),
                'edit_posts',
                'he-journalist-subdomains',
                [ $this, 'render_subdomains_page' ]
            );
        }
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Riwayat Generate' ),
            $this->tr_ui( 'Riwayat Generate' ),
            self::editor_admin_capability(),
            'he-journalist-history',
            [ $this, 'render_history_page' ]
        );
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Custom Settings' ),
            $this->tr_ui( 'Custom Settings' ),
            self::editor_admin_capability(),
            'he-journalist-custom-settings',
            [ $this, 'render_custom_settings_page' ]
        );
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Pengaturan API' ),
            $this->tr_ui( 'Pengaturan API' ),
            self::editor_admin_capability(),
            'he-journalist-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    public function admin_enqueue_assets( $hook ) {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( strpos( $hook, 'he-journalist' ) === false && strpos( $page, 'he-journalist' ) === false ) { return; }

        $this->enqueue_common_assets();

        if ( $page === 'he-journalist' ) {
            $this->enqueue_generator_assets();
        } elseif ( $page === 'he-journalist-subdomains' ) {
            $this->enqueue_subdomains_assets();
        }
    }

    private function enqueue_common_assets() {
        wp_enqueue_script( 'tailwindcss-cdn', 'https://cdn.tailwindcss.com', [], null, false );
        wp_enqueue_style( 'heaj-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Merriweather:wght@400;700&display=swap', [], null );
        wp_enqueue_script( 'lucide-cdn', 'https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js', [], null, true );
        wp_add_inline_script( 'lucide-cdn', $this->admin_language_bridge_script() . "\n" . $this->admin_notice_relocator_script() . "\n" . $this->lucide_icon_bootstrap_script(), 'after' );
        wp_enqueue_style( 'he-journalist-app', $this->plugin_url() . 'assets/css/app.css', [], self::VERSION );
        $brand = $this->get_brand_settings();
        $primary = sanitize_hex_color( $brand['primary_color'] ?? '#0f172a' ) ?: '#0f172a';
        wp_add_inline_style( 'he-journalist-app', ':root{--heaj-primary:' . esc_html( $primary ) . ';}.he-generator-header,.he-settings-hero,.he-history-hero,.he-directory-hero{background:var(--heaj-primary)!important}.he-card-icon,.he-settings-card .he-card-icon{background:color-mix(in srgb,var(--heaj-primary) 12%,#fff)!important;color:var(--heaj-primary)!important}.he-save-button,.button-primary{background:var(--heaj-primary)!important;border-color:var(--heaj-primary)!important}' );
    }

    private function admin_notice_relocator_script() {
        return <<<'JS'
(function(){
  function moveHEAdminNotices(){
    var app = document.querySelector('#heaj-app, #he-subdomains-app, #he-settings-app, #he-history-app, .heaj-settings-page');
    if (!app || !app.parentNode) { return; }

    var wrap = app.closest('.wrap') || app.parentNode;
    var tray = document.getElementById('heaj-admin-notice-tray');
    if (!tray) {
      tray = document.createElement('div');
      tray.id = 'heaj-admin-notice-tray';
      tray.className = 'heaj-admin-notice-tray';
      app.parentNode.insertBefore(tray, app);
    }

    var found = [];
    [app, wrap].forEach(function(root){
      if (!root || !root.querySelectorAll) { return; }
      root.querySelectorAll('.notice, .updated, .error, .update-nag').forEach(function(el){
        if (!el || el === tray || tray.contains(el)) { return; }
        if (el.closest('#heaj-admin-notice-tray')) { return; }
        if (el.id === 'heSubdomainStatus' || el.id === 'toast') { return; }
        if (el.closest('#toast')) { return; }
        found.push(el);
      });
    });

    found.forEach(function(el){
      el.classList.add('heaj-relocated-notice');
      tray.appendChild(el);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', moveHEAdminNotices);
  } else {
    moveHEAdminNotices();
  }
  setTimeout(moveHEAdminNotices, 120);
  setTimeout(moveHEAdminNotices, 700);
  setTimeout(moveHEAdminNotices, 1600);
})();
JS;
    }



    private function lucide_icon_bootstrap_script() {
        return <<<'JS'
(function(){
  function fallbackIcon(el){
    if (!el || el.dataset.heIconFallback === '1') return;
    var name = el.getAttribute('data-lucide') || 'circle';
    var cls = el.getAttribute('class') || '';
    var color = 'currentColor';
    var paths = {
      'shield-check':'<path d="M12 3l7 3v5c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-3z"/><path d="M9 12l2 2 4-5"/>',
      'key-round':'<circle cx="7.5" cy="14.5" r="3.5"/><path d="M10 12l7-7 3 3-2 2 2 2-2 2-2-2-3 3"/>',
      'cpu':'<rect x="7" y="7" width="10" height="10" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M4 9h3M4 15h3M17 9h3M17 15h3M9 4v3M15 4v3M9 17v3M15 17v3"/>',
      'activity':'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
      'key':'<circle cx="7.5" cy="14.5" r="3.5"/><path d="M10 12l8-8 3 3-8 8"/>',
      'external-link':'<path d="M14 3h7v7"/><path d="M10 14L21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/>',
      'network':'<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="3" y="16" width="6" height="6" rx="1"/><rect x="15" y="16" width="6" height="6" rx="1"/><path d="M12 8v4M6 16v-2h12v2"/>',
      'search':'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
      'refresh-cw':'<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/>',
      'plus-circle':'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
      'newspaper':'<path d="M4 5h13a3 3 0 0 1 3 3v11H6a2 2 0 0 1-2-2V5z"/><path d="M8 9h6M8 13h8M8 17h5"/>',
      'clock-3':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
      'tag':'<path d="M20 10l-8 8-8-8V4h6l10 10z"/><circle cx="8" cy="8" r="1"/>',
      'star':'<path d="M12 3l2.7 5.5 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1-4.4-4.3 6.1-.9L12 3z"/>',
      'log-in':'<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/>',
      'layout-dashboard':'<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
      'wand-sparkles':'<path d="M15 4l5 5-11 11-5-5L15 4z"/><path d="M14 5l5 5"/><path d="M5 3v4M3 5h4M19 15v4M17 17h4"/>'
    };
    var svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('xmlns','http://www.w3.org/2000/svg');
    svg.setAttribute('viewBox','0 0 24 24');
    svg.setAttribute('fill','none');
    svg.setAttribute('stroke', color);
    svg.setAttribute('stroke-width','2');
    svg.setAttribute('stroke-linecap','round');
    svg.setAttribute('stroke-linejoin','round');
    svg.setAttribute('class', cls + ' he-lucide-fallback');
    svg.setAttribute('aria-hidden','true');
    svg.innerHTML = paths[name] || '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>';
    el.dataset.heIconFallback = '1';
    el.replaceWith(svg);
  }

  function renderHEIcons(){
    try {
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
        return true;
      }
    } catch(e) {}
    return false;
  }

  function ensureHEIcons(){
    if (renderHEIcons()) return;
    if (!document.getElementById('he-lucide-jsdelivr-fallback')) {
      var s = document.createElement('script');
      s.id = 'he-lucide-jsdelivr-fallback';
      s.src = 'https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js';
      s.onload = renderHEIcons;
      document.head.appendChild(s);
    }
    setTimeout(function(){
      if (!renderHEIcons()) {
        document.querySelectorAll('i[data-lucide]').forEach(fallbackIcon);
      }
    }, 1400);
  }

  window.HEAJRenderIcons = ensureHEIcons;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureHEIcons);
  } else {
    ensureHEIcons();
  }
  window.addEventListener('load', ensureHEIcons);
  setTimeout(ensureHEIcons, 150);
  setTimeout(ensureHEIcons, 700);
  setTimeout(ensureHEIcons, 1800);
})();
JS;
    }

    private function enqueue_generator_assets() {
        wp_enqueue_script( 'he-journalist-app', $this->plugin_url() . 'assets/js/app.js', [ 'lucide-cdn' ], self::VERSION, true );
        $custom_settings_for_js = $this->get_custom_settings();
        $prompt_overrides_for_js = $this->get_prompt_overrides();
        if ( ! empty( $custom_settings_for_js['global_prompt'] ) ) {
            $prompt_overrides_for_js['global'] = $custom_settings_for_js['global_prompt'];
        }
        wp_localize_script( 'he-journalist-app', 'HEAJ', [
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
            'version'   => self::VERSION,
            'providers' => $this->get_available_ai_providers(),
            'promptOverrides' => $prompt_overrides_for_js,
            'customSettings' => $this->get_custom_settings(),
            'brand' => $this->get_brand_settings(),
            'brandInstruction' => $this->get_brand_instruction(),
            'mediaName' => $this->get_media_name(),
            'uiLang' => $this->ui_language(),
            'locale' => $this->current_admin_locale(),
        ] );
    }

    private function enqueue_subdomains_assets() {
        wp_enqueue_script( 'he-domain-groups-external', 'https://yanuarzg.github.io/cc/he/all.js', [], null, true );
        wp_enqueue_script( 'he-journalist-subdomains', $this->plugin_url() . 'assets/js/subdomains.js', [ 'he-domain-groups-external', 'lucide-cdn' ], self::VERSION, true );
    }

    private function enqueue_assets() {
        $this->enqueue_common_assets();
        $this->enqueue_generator_assets();
    }

    public function render_generator_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        $available_ai_providers = $this->get_available_ai_providers();
        $has_any_ai_provider = array_sum( array_map( 'absint', $available_ai_providers ) ) > 0;
        $brand_settings = $this->get_brand_settings();
        $media_name = $this->get_media_name();
        $author_names = $this->get_author_editor_names( 'authors' );
        $editor_names = $this->get_author_editor_names( 'editors' );
        $default_language_code = $this->ui_language() === 'en' ? 'en' : 'id';
        echo '<div class="wrap he-admin-generator">';
        ob_start();
        include $this->plugin_dir() . 'templates/app.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_history_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { $history = []; }
        $total_history = count( $history );
        $per_page = 20;
        $paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
        $total_pages = max( 1, (int) ceil( $total_history / $per_page ) );
        if ( $paged > $total_pages ) { $paged = $total_pages; }
        $history_all = $history;
        $history = array_slice( $history_all, ( $paged - 1 ) * $per_page, $per_page );
        echo '<div class="wrap he-admin-history">';
        ob_start();
        include $this->plugin_dir() . 'templates/history.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_settings_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $defaults       = $this->default_api_keys();
        $masked_defaults = array_map( [ $this, 'mask_api_key' ], $defaults );
        $api_key_pool_all = $this->get_provider_key_status_rows();
        $active_api_key_pool = $this->get_api_key_pool( false );
        $blocked_api_keys = $this->get_blocked_api_keys();
        $prompt_overrides = $this->get_prompt_overrides();
        $update_manifest = $this->get_update_manifest();
        $latest_version = is_array( $update_manifest ) && ! empty( $update_manifest['version'] ) ? $update_manifest['version'] : self::VERSION;
        $update_available = version_compare( $latest_version, self::VERSION, '>' );
        $all_count      = count( $active_api_key_pool );
        $grok_keys_count = count( $this->get_grok_api_keys() );
        $groq_keys_count = count( $this->get_groqcloud_api_keys() );
        $zai_keys_count  = count( $this->get_zai_api_keys() );
        $pexels_api_key = get_option( self::OPTION_PEXELS_API_KEY, '' );
        $brand_settings = $this->get_brand_settings();
        $media_name = $this->get_media_name();
        $has_any_ai_provider = array_sum( array_map( 'absint', $this->get_available_ai_providers() ) ) > 0;
        ob_start();
        include $this->plugin_dir() . 'templates/settings.php';
        echo $this->translate_admin_html( ob_get_clean() );
    }


    private function get_author_editor_names_from_wp( $type = 'authors' ) {
        $roles = $type === 'editors' ? [ 'administrator', 'editor' ] : [ 'administrator', 'editor', 'author' ];
        $names = [];
        if ( function_exists( 'get_users' ) ) {
            $users = get_users( [
                'role__in' => $roles,
                'fields'   => [ 'display_name', 'user_login' ],
                'orderby'  => 'display_name',
                'order'    => 'ASC',
            ] );
            foreach ( (array) $users as $user ) {
                $name = '';
                if ( is_object( $user ) ) {
                    $name = trim( (string) ( $user->display_name ?: $user->user_login ) );
                }
                if ( $name !== '' && ! in_array( $name, $names, true ) ) {
                    $names[] = $name;
                }
            }
        }
        return $names;
    }

    public function render_custom_settings_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $custom_settings = $this->get_custom_settings();
        $brand_settings = $this->get_brand_settings();
        $wp_author_names = $this->get_author_editor_names_from_wp( 'authors' );
        $wp_editor_names = $this->get_author_editor_names_from_wp( 'editors' );
        echo '<div class="wrap he-admin-custom-settings">';
        ob_start();
        include $this->plugin_dir() . 'templates/custom-settings.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_subdomains_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        if ( ! $this->is_network_directory_enabled() ) {
            wp_safe_redirect( admin_url( 'admin.php?page=he-journalist' ) );
            exit;
        }
        echo '<div class="wrap he-admin-subdomains">';
        ob_start();
        include $this->plugin_dir() . 'templates/subdomains.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }



    private function get_update_manifest() {
        $response = wp_remote_get( self::UPDATE_JSON_URL, [ 'timeout' => 15 ] );
        if ( is_wp_error( $response ) ) { return null; }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) { return null; }
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        return is_array( $data ) ? $data : null;
    }

    public function check_plugin_update( $transient ) {
        if ( empty( $transient ) || ! is_object( $transient ) ) { return $transient; }
        $plugin_file = plugin_basename( __FILE__ );
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) || empty( $manifest['version'] ) ) {
            if ( isset( $transient->response[ $plugin_file ] ) ) { unset( $transient->response[ $plugin_file ] ); }
            return $transient;
        }
        if ( ! version_compare( $manifest['version'], self::VERSION, '>' ) ) {
            if ( isset( $transient->response[ $plugin_file ] ) ) { unset( $transient->response[ $plugin_file ] ); }
            if ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
                $transient->no_update[ $plugin_file ] = (object) [
                    'id'          => self::UPDATE_JSON_URL,
                    'slug'        => dirname( $plugin_file ),
                    'plugin'      => $plugin_file,
                    'new_version' => self::VERSION,
                    'url'         => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
                    'package'     => '',
                ];
            }
            return $transient;
        }

        $package = $manifest['download_url'] ?? $manifest['package'] ?? '';
        $transient->response[ $plugin_file ] = (object) [
            'id'            => self::UPDATE_JSON_URL,
            'slug'          => dirname( $plugin_file ),
            'plugin'        => $plugin_file,
            'new_version'   => sanitize_text_field( $manifest['version'] ),
            'url'           => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
            'package'       => esc_url_raw( $package ),
            'requires'      => sanitize_text_field( $manifest['requires'] ?? '6.0' ),
            'tested'        => sanitize_text_field( $manifest['tested'] ?? '' ),
            'requires_php'  => sanitize_text_field( $manifest['requires_php'] ?? '7.4' ),
        ];
        return $transient;
    }

    public function plugin_update_info( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || empty( $args->slug ) || $args->slug !== 'harianexpress-journalist' ) {
            return $result;
        }
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) ) { return $result; }
        return (object) [
            'name'          => $manifest['name'] ?? 'YZG AI Journalist',
            'slug'          => 'harianexpress-journalist',
            'version'       => $manifest['version'] ?? self::VERSION,
            'author'        => $manifest['author'] ?? 'YZG',
            'homepage'      => $manifest['homepage'] ?? self::UPDATE_INFO_URL,
            'requires'      => $manifest['requires'] ?? '6.0',
            'tested'        => $manifest['tested'] ?? '',
            'requires_php'  => $manifest['requires_php'] ?? '7.4',
            'download_link' => $manifest['download_url'] ?? $manifest['package'] ?? '',
            'sections'      => $manifest['sections'] ?? [ 'description' => 'White-label AI editorial assistant.', 'changelog' => '' ],
        ];
    }

    private function extract_urls_from_text( $text ) {
        preg_match_all( '#https?://[^\s<>"]+#i', (string) $text, $matches );
        return array_values( array_unique( array_map( 'esc_url_raw', $matches[0] ?? [] ) ) );
    }

    private function absolutize_url( $src, $base_url ) {
        $src = html_entity_decode( trim( (string) $src ), ENT_QUOTES | ENT_HTML5 );
        if ( $src === '' || stripos( $src, 'data:' ) === 0 ) { return ''; }
        if ( preg_match( '#^https?://#i', $src ) ) { return esc_url_raw( $src ); }
        $base = wp_parse_url( $base_url );
        if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) { return ''; }
        if ( strpos( $src, '//' ) === 0 ) { return esc_url_raw( $base['scheme'] . ':' . $src ); }
        $root = $base['scheme'] . '://' . $base['host'];
        if ( ! empty( $base['port'] ) ) { $root .= ':' . $base['port']; }
        if ( strpos( $src, '/' ) === 0 ) { return esc_url_raw( $root . $src ); }
        $path = isset( $base['path'] ) ? preg_replace( '#/[^/]*$#', '/', $base['path'] ) : '/';
        return esc_url_raw( $root . $path . $src );
    }


    private function extract_article_like_html( $html ) {
        $html = (string) $html;
        $blocks = [];

        if ( preg_match_all( '#<article\\b[^>]*>.*?</article>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( '#<main\\b[^>]*>.*?</main>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<div\\b[^>]+class=[\"'][^\"']*(?:cover-photo|entry-content|post-content|article-content|single-content|content-detail|content_body|contentbody|td-post-content|jeg_inner_content|jl_content|post-entry|detail__body|detail__body-text|detail_text|detail__text|read__content|read__article|article__content|article-content-body)[^\"']*[\"'][^>]*>.*?</div>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<section\\b[^>]+class=[\"'][^\"']*(?:cover-photo|entry-content|post-content|article-content|single-content|content-detail|detail__body|detail__body-text|read__content|article__content)[^\"']*[\"'][^>]*>.*?</section>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }

        if ( empty( $blocks ) ) {
            return [ 'html' => $html, 'strict_article' => false ];
        }

        usort( $blocks, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
        return [ 'html' => $blocks[0], 'strict_article' => true ];
    }

    private function html_article_to_plain_text( $html ) {
        $html = (string) $html;
        if ( $html === '' ) { return ''; }

        $html = preg_replace( '#<script\\b[^>]*>.*?</script>#is', ' ', $html );
        $html = preg_replace( '#<style\\b[^>]*>.*?</style>#is', ' ', $html );
        $html = preg_replace( '#<noscript\\b[^>]*>.*?</noscript>#is', ' ', $html );
        $html = preg_replace( '#<(?:p|div|h1|h2|h3|h4|h5|h6|blockquote|li|br|tr)\\b[^>]*>#i', "\n", $html );
        $html = preg_replace( '#</(?:p|div|h1|h2|h3|h4|h5|h6|blockquote|li|tr)>#i', "\n", $html );
        $text = wp_strip_all_tags( $html, false );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $text = preg_replace( "/[ \t\r\0\x0B]+/u", ' ', $text );
        $text = preg_replace( "/\n\s*\n\s*\n+/u", "\n\n", $text );
        $lines = array_map( 'trim', preg_split( "/\n+/u", $text ) );
        $lines = array_values( array_filter( $lines, function( $line ) {
            if ( $line === '' ) { return false; }
            if ( mb_strlen( $line ) < 3 ) { return false; }
            $junk = strtolower( $line );
            foreach ( [ 'advertisement', 'scroll to continue', 'baca juga', 'lihat juga', 'share', 'komentar', 'tag:', 'copyright' ] as $needle ) {
                if ( $junk === $needle ) { return false; }
            }
            return true;
        } ) );

        $text = trim( implode( "\n", $lines ) );
        if ( mb_strlen( $text ) > 18000 ) {
            $text = mb_substr( $text, 0, 18000 ) . "\n[TEKS SUMBER DIPOTONG KARENA TERLALU PANJANG]";
        }
        return $text;
    }

    private function fetch_source_text_context( $raw_text ) {
        $urls = array_slice( $this->extract_urls_from_text( $raw_text ), 0, 5 );
        if ( empty( $urls ) ) { return ''; }

        $items = [];
        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 25,
                'redirection' => 5,
                'headers'     => [
                    'User-Agent' => 'Mozilla/5.0 (compatible; YZGAIJournalist/3.4; +https://yanuarzg.github.io/)',
                    'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $code = (int) wp_remote_retrieve_response_code( $response );
            if ( $code < 200 || $code >= 300 ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || trim( $html ) === '' ) { continue; }

            $article = $this->extract_article_like_html( $html );
            $text = $this->html_article_to_plain_text( $article['html'] );
            if ( mb_strlen( $text ) < 120 ) {
                $text = $this->html_article_to_plain_text( $html );
            }
            if ( mb_strlen( $text ) < 120 ) { continue; }

            $items[] = "URL SUMBER: " . $url . "\nTEKS SUMBER HASIL EKSTRAKSI SERVER:\n" . $text;
        }

        if ( empty( $items ) ) { return ''; }

        return "\n\n================ SUMBER RESMI HASIL EKSTRAKSI SERVER ================\n" .
            implode( "\n\n---------------- SUMBER BERIKUTNYA ----------------\n\n", $items ) .
            "\n================ AKHIR SUMBER RESMI ================\n";
    }

    private function parse_img_tag_srcs( $tag ) {
        $candidates = [];
        foreach ( [ 'src', 'data-src', 'data-lazy-src', 'data-original', 'data-image', 'data-full-url', 'data-large_image' ] as $attr ) {
            if ( preg_match( "#\\s" . preg_quote( $attr, '#' ) . "=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
                $candidates[] = $m[1];
            }
        }
        foreach ( [ 'srcset', 'data-srcset', 'data-lazy-srcset' ] as $srcset_attr ) {
            if ( preg_match( "#\\s" . preg_quote( $srcset_attr, '#' ) . "=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
                $parts = array_map( 'trim', explode( ',', $m[1] ) );
                foreach ( $parts as $part ) {
                    if ( preg_match( '#^(\\S+)\\s+(\\d+)w#', $part, $sm ) ) {
                        $candidates[] = $sm[1];
                    }
                }
            }
        }
        return array_values( array_unique( array_filter( $candidates ) ) );
    }

    private function parse_img_tag_width( $tag ) {
        $width = 0;
        if ( preg_match( "#\\swidth=[\"']?(\\d+)[\"']?#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssizes=[\"'][^\"']*(\\d+)px#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssrcset=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
            if ( preg_match_all( '#\\s(\\d+)w(?:,|$)#', $m[1], $wm ) ) {
                foreach ( $wm[1] as $w ) { $width = max( $width, (int) $w ); }
            }
        }
        return $width;
    }


    private function extract_caption_near_image( $html, $img_tag ) {
        $window = $img_tag;
        $pos = strpos( $html, $img_tag );
        if ( $pos !== false ) {
            $window = substr( $html, max( 0, $pos - 2500 ), strlen( $img_tag ) + 5000 );
        }
        $caption = '';
        $patterns = [
            '#<figure\b[^>]*>.*?' . preg_quote( $img_tag, '#' ) . '.*?<figcaption\b[^>]*>(.*?)</figcaption>.*?</figure>#is',
            '#<figcaption\b[^>]*>(.*?)</figcaption>#is',
            '#<[^>]+class=["\'][^"\']*(?:caption|wp-caption-text|image-caption|photo-caption|cover-caption|detail__caption)[^"\']*["\'][^>]*>(.*?)</[^>]+>#is',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $window, $m ) ) {
                $caption = $this->html_article_to_plain_text( $m[1] );
                break;
            }
        }
        if ( $caption === '' && preg_match( '#\salt=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        if ( $caption === '' && preg_match( '#\stitle=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        if ( $caption === '' && preg_match( '#\sdata-caption=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        $caption = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $caption ) ) );
        return sanitize_text_field( mb_substr( $caption, 0, 300 ) );
    }

    private function extract_credit_near_image( $html, $img_tag ) {
        $window = $img_tag;
        $pos = strpos( $html, $img_tag );
        if ( $pos !== false ) {
            $window = substr( $html, max( 0, $pos - 2500 ), strlen( $img_tag ) + 5000 );
        }
        $credit = '';
        $patterns = [
            '#<[^>]+class=["\'][^"\']*(?:credit-source|source-credit|photo-credit|image-credit|credit|sumber|source)[^"\']*["\'][^>]*>(.*?)</[^>]+>#is',
            '#<[^>]+(?:data-credit|data-source|data-sumber)=["\']([^"\']{3,240})["\'][^>]*>#is',
            '#(?:Sumber|Source|Foto|Photo)\s*[:：]\s*([^<\n\r]{3,160})#iu',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $window, $m ) ) {
                $credit = $this->html_article_to_plain_text( $m[1] );
                break;
            }
        }
        $credit = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $credit ) ) );
        if ( $credit && ! preg_match( '/^(sumber|source|foto|photo)\s*:/iu', $credit ) ) {
            $credit = 'Sumber: ' . $credit;
        }
        return sanitize_text_field( mb_substr( $credit, 0, 220 ) );
    }

    private function normalize_source_image_name_key( $image_url ) {
        $path = wp_parse_url( (string) $image_url, PHP_URL_PATH );
        $base = strtolower( basename( (string) $path ) );
        $base = preg_replace( '/\.(jpe?g|png|webp|gif)$/i', '', $base );
        $base = preg_replace( '/[-_](?:\d{2,5}x\d{2,5}|scaled|cropped|thumbnail|thumb|small|medium|large|full)$/i', '', $base );
        $base = preg_replace( '/(?:[-_]\d{2,5}){1,2}$/', '', $base );
        $base = preg_replace( '/[^a-z0-9]+/', '-', $base );
        $base = trim( $base, '-' );
        return $base !== '' ? $base : md5( (string) $image_url );
    }


    private function remote_image_width( $url ) {
        $url = esc_url_raw( (string) $url );
        if ( ! $url ) { return 0; }
        $response = wp_remote_get( $url, [
            'timeout'     => 12,
            'redirection' => 3,
            'headers'     => [
                'User-Agent' => 'Mozilla/5.0 (compatible; YZGAIJournalist/3.4; +https://yanuarzg.github.io/)',
                'Accept'     => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            ],
        ] );
        if ( is_wp_error( $response ) ) { return 0; }
        $body = wp_remote_retrieve_body( $response );
        if ( ! is_string( $body ) || $body === '' ) { return 0; }
        $size = @getimagesizefromstring( $body );
        return is_array( $size ) && ! empty( $size[0] ) ? (int) $size[0] : 0;
    }

    private function extract_meta_image_urls( $html, $base_url ) {
        $urls = [];
        $patterns = [
            '#<meta[^>]+(?:property|name|itemprop)=["\'](?:og:image|og:image:secure_url|twitter:image|image)["\'][^>]+content=["\']([^"\']+)["\'][^>]*>#i',
            '#<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name|itemprop)=["\'](?:og:image|og:image:secure_url|twitter:image|image)["\'][^>]*>#i',
            '#<link[^>]+rel=["\'][^"\']*(?:image_src|preload)[^"\']*["\'][^>]+href=["\']([^"\']+)["\'][^>]*>#i',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match_all( $pattern, $html, $m ) ) {
                foreach ( $m[1] as $src ) {
                    $url = $this->absolutize_url( $src, $base_url );
                    if ( $url ) { $urls[] = $url; }
                }
            }
        }
        return array_values( array_unique( $urls ) );
    }

    public function ajax_fetch_source_images() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin mengambil gambar sumber.' ], 403 );
        }

        $source = isset( $_POST['source'] ) ? wp_unslash( $_POST['source'] ) : '';
        $urls = array_slice( $this->extract_urls_from_text( $source ), 0, 8 );
        $images = [];
        $seen_names = [];
        $min_width = 320;

        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 20,
                'redirection' => 5,
                'headers'     => [ 'User-Agent' => 'YZGAIJournalist/3.4' ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || $html === '' ) { continue; }

            $article = $this->extract_article_like_html( $html );
            $scan_html = $article['html'];
            // Tambahan deteksi gambar utama/cover dari class .cover-photo meskipun berada di luar body artikel utama.
            if ( preg_match_all( '#<(?:div|figure|picture)\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>.*?</(?:div|figure|picture)>#is', $html, $cover_blocks ) ) {
                $scan_html .= "\n" . implode( "\n", $cover_blocks[0] );
            }
            if ( preg_match_all( '#<img\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>#is', $html, $cover_imgs ) ) {
                $scan_html .= "\n" . implode( "\n", $cover_imgs[0] );
            }
            $strict_article = ! empty( $article['strict_article'] );

            if ( ! preg_match_all( '#<img\\b[^>]*>#i', $scan_html, $tags ) ) { continue; }
            foreach ( $tags[0] as $tag ) {
                $tag_width = $this->parse_img_tag_width( $tag );
                $srcs = $this->parse_img_tag_srcs( $tag );
                foreach ( $srcs as $src ) {
                    $img = $this->absolutize_url( $src, $url );
                    if ( ! $img || ! preg_match( '#\\.(jpe?g|png|webp|gif)(\\?.*)?$#i', $img ) ) { continue; }

                    $width = $tag_width;
                    if ( $width < $min_width ) {
                        $width = $this->remote_image_width( $img );
                    }

                    if ( $width < $min_width ) { continue; }

                    $name_key = $this->normalize_source_image_name_key( $img );
                    if ( isset( $seen_names[ $name_key ] ) ) { continue; }
                    $seen_names[ $name_key ] = true;

                    $key = md5( $img );
                    $images[ $key ] = [
                        'url'    => $img,
                        'source' => $url,
                        'width'  => $width,
                        'scope'  => $strict_article ? 'article' : 'page-filtered',
                        'caption'=> $this->extract_caption_near_image( $scan_html, $tag ),
                        'credit' => $this->extract_credit_near_image( $scan_html, $tag ),
                    ];
                    if ( count( $images ) >= 24 ) { break 3; }
                }
            }
        }

        wp_send_json_success( [ 'images' => array_values( $images ) ] );
    }


    private function build_pexels_query( $query ) {
        // JDH-inspired: Pexels bekerja lebih baik dengan keyword pendek, literal, dan visual.
        $query = wp_strip_all_tags( (string) $query );
        $query = preg_replace( '#https?://\S+#i', ' ', $query );
        $query = preg_replace( '/\b(ilustrasi\s*foto|foto\s*ilustrasi|ilustrasi|foto|gambar|berita|artikel|news|photo|image|picture|pexels|caption|sumber|source|editorial|kamera|camera|jurnalis|wartawan|reporter|media|breaking|viral)\b/iu', ' ', $query );
        $query = preg_replace( '/[^\p{L}\p{N}\s-]+/u', ' ', $query );
        $query = trim( preg_replace( '/\s+/u', ' ', $query ) );
        if ( $query === '' || mb_strlen( $query ) < 4 ) { return ''; }

        $topic_rules = [
            '/\b(banjir|katulampa|ciliwung|tma|bendungan|bendung|sungai|meluap|debit|siaga|hujan|puncak|bogor)\b/iu' => 'flood river rain dam',
            '/\b(kebakaran|api|terbakar|pemadam)\b/iu' => 'fire emergency smoke',
            '/\b(gempa|magnitudo|bencana|tsunami)\b/iu' => 'earthquake disaster damage',
            '/\b(longsor|tanah longsor|tebing)\b/iu' => 'landslide disaster mountain',
            '/\b(kecelakaan|tabrakan|jalan raya|kendaraan|lalu lintas)\b/iu' => 'traffic accident road cars',
            '/\b(haji|umrah|jamaah|mekah|madinah|arab saudi|ka bah|kakbah)\b/iu' => 'hajj pilgrimage mecca kaaba',
            '/\b(sekolah|siswa|guru|kelas|kampus|mahasiswa|pendidikan|universitas)\b/iu' => 'education students classroom school',
            '/\b(teknologi|kecerdasan buatan|ai|aplikasi|digital|gadget|komputer|internet|startup)\b/iu' => 'technology artificial intelligence computer',
            '/\b(ekonomi|keuangan|bisnis|umkm|pasar|investasi|saham|bank|rupiah|uang)\b/iu' => 'business economy finance money',
            '/\b(kesehatan|rumah sakit|dokter|pasien|vaksin|penyakit|medis)\b/iu' => 'healthcare hospital doctor patient',
            '/\b(wisata|travel|pantai|gunung|hotel|kuliner|liburan|destinasi|pariwisata)\b/iu' => 'travel destination landscape',
            '/\b(bola|sepak bola|sepakbola|liga|pemain|pelatih|olahraga|stadion)\b/iu' => 'football stadium sports',
            '/\b(properti|rumah|perumahan|apartemen|real estate|hunian)\b/iu' => 'real estate housing property',
            '/\b(otomotif|mobil|motor|kendaraan|mesin)\b/iu' => 'automotive car road',
            '/\b(politik|pemerintah|menteri|presiden|dpr|pemilu|pilkada|rapat)\b/iu' => 'government meeting politics',
            '/\b(pertanian|petani|sawah|padi|panen|perkebunan)\b/iu' => 'farm agriculture rice field',
            '/\b(laut|nelayan|ikan|kapal|pelabuhan)\b/iu' => 'fishermen boat sea harbor',
        ];
        $matched = [];
        foreach ( $topic_rules as $pattern => $english ) {
            if ( preg_match( $pattern, $query ) ) { $matched[] = $english; }
        }
        if ( ! empty( $matched ) ) { return mb_substr( implode( ' ', array_unique( $matched ) ), 0, 100 ); }

        $stopwords = [ 'dan','atau','yang','dari','untuk','dengan','pada','dalam','ini','itu','akan','telah','adalah','ke','di','sebagai','oleh','kata','ujar','menurut','menyebut','hari','bulan','tahun','wib','the','and','for','with','from','into','about','update' ];
        $words = preg_split( '/\s+/u', mb_strtolower( $query ) );
        $clean = [];
        foreach ( $words as $word ) {
            $word = trim( $word, '- ' );
            if ( $word === '' || mb_strlen( $word ) < 4 || in_array( $word, $stopwords, true ) ) { continue; }
            if ( preg_match( '/^\d+$/', $word ) ) { continue; }
            $clean[] = $word;
        }
        $clean = array_values( array_unique( $clean ) );
        return mb_substr( implode( ' ', array_slice( $clean, 0, 5 ) ), 0, 100 );
    }


    public function ajax_update_history_meta() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal.' ], 403 );
        }
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin.' ], 403 );
        }
        $history_id = isset( $_POST['history_id'] ) ? sanitize_key( wp_unslash( $_POST['history_id'] ) ) : '';
        $title_index = isset( $_POST['title_index'] ) ? absint( $_POST['title_index'] ) : 0;
        $slug_index = isset( $_POST['slug_index'] ) ? absint( $_POST['slug_index'] ) : 0;
        $meta_index = isset( $_POST['meta_index'] ) ? absint( $_POST['meta_index'] ) : 0;
        $image_source = isset( $_POST['image_source'] ) ? sanitize_text_field( wp_unslash( $_POST['image_source'] ) ) : '';
        if ( ! $history_id ) { wp_send_json_error( [ 'message' => 'History ID kosong.' ], 400 ); }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { wp_send_json_error( [ 'message' => 'Riwayat kosong.' ], 404 ); }
        foreach ( $history as &$item ) {
            if ( is_array( $item ) && isset( $item['id'] ) && $item['id'] === $history_id ) {
                foreach ( [ 'image_source_type', 'image_count', 'has_source_image', 'has_pexels_image' ] as $field ) {
                    if ( isset( $_POST[ $field ] ) ) {
                        $item[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
                    }
                }
                update_option( self::OPTION_HISTORY, $history, false );
                wp_send_json_success( [ 'message' => 'Riwayat diperbarui.' ] );
            }
        }
        wp_send_json_error( [ 'message' => 'Riwayat tidak ditemukan.' ], 404 );
    }

    public function ajax_fetch_pexels_images() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin.' ], 403 );
        }
        $api_key = trim( (string) get_option( self::OPTION_PEXELS_API_KEY, '' ) );
        if ( $api_key === '' ) {
            wp_send_json_success( [ 'images' => [], 'message' => 'API key Pexels belum diisi.' ] );
        }
        $query = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';
        $query = $this->build_pexels_query( $query );
        if ( $query === '' ) {
            wp_send_json_success( [ 'images' => [], 'message' => 'Query Pexels tidak cukup spesifik.' ] );
        }
        $response = wp_remote_get( add_query_arg( [
            'query' => $query,
            'per_page' => 5,
            'orientation' => 'landscape',
            'size' => 'large',
            'locale' => 'en-US',
        ], 'https://api.pexels.com/v1/search' ), [
            'timeout' => 18,
            'headers' => [
                'Authorization' => $api_key,
                'Accept' => 'application/json',
            ],
        ] );
        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => $response->get_error_message() ], 500 );
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Gagal mengambil gambar Pexels. HTTP ' . $code ], $code ?: 500 );
        }
        $images = [];
        $photos = (array) ( $data['photos'] ?? [] );
        if ( count( $photos ) > 3 ) { shuffle( $photos ); }
        foreach ( array_slice( $photos, 0, 3 ) as $photo ) {
            $src = is_array( $photo['src'] ?? null ) ? $photo['src'] : [];
            $url = $src['large2x'] ?? $src['large'] ?? $src['original'] ?? '';
            if ( ! $url ) { continue; }
            $photographer = sanitize_text_field( $photo['photographer'] ?? 'Pexels' );
            $images[] = [
                'url' => esc_url_raw( $url ),
                'source' => esc_url_raw( $photo['url'] ?? 'https://www.pexels.com' ),
                'width' => absint( $photo['width'] ?? 0 ),
                'scope' => 'pexels',
                'caption' => 'Ilustrasi foto',
                'credit' => 'Foto: ' . $photographer . ' / Pexels',
                'label' => 'ilustrasi foto',
                'source_type' => 'pexels',
                'pexels_id' => absint( $photo['id'] ?? 0 ),
            ];
        }
        wp_send_json_success( [ 'images' => $images, 'query' => $query ] );
    }


    private function openai_provider_config( $provider ) {
        if ( $provider === 'grok' ) {
            return [
                'name'     => 'Grok xAI',
                'endpoint' => 'https://api.x.ai/v1/chat/completions',
                'model'    => 'grok-4.3',
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'grok', false ) ) ),
            ];
        }
        if ( $provider === 'groqcloud' ) {
            return [
                'name'     => 'Groq',
                'endpoint' => 'https://api.groq.com/openai/v1/chat/completions',
                'model'    => 'llama-3.3-70b-versatile',
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'groqcloud', false ) ) ),
            ];
        }
        if ( $provider === 'zai' ) {
            return [
                'name'     => 'Z.AI',
                'endpoint' => 'https://api.z.ai/api/paas/v4/chat/completions',
                'model'    => 'glm-4.5-flash',
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'zai', false ) ) ),
            ];
        }
        return null;
    }

    private function is_retryable_openai_compatible_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );
        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) { return true; }
        foreach ( [ 'rate limit', 'quota', 'temporarily', 'timeout', 'timed out', 'overloaded', 'service unavailable', 'try again' ] as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) { return true; }
        }
        return false;
    }

    private function is_blockable_openai_compatible_key_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );
        if ( in_array( $status, [ 401, 403 ], true ) ) { return true; }
        foreach ( [ 'invalid api key', 'incorrect api key', 'unauthorized', 'forbidden', 'permission', 'blocked', 'disabled', 'expired', 'invalid authorization', 'no authorization', 'does not have permission' ] as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) { return true; }
        }
        return false;
    }

    private function friendly_openai_compatible_error( $provider_name, $status, $message ) {
        $status = (int) $status;
        $message = trim( (string) $message );
        if ( $status === 403 ) {
            return $provider_name . ' HTTP 403: API key/team tidak punya permission, diblokir, belum punya credits, atau model/endpoint belum diizinkan. Key tersebut sudah diblokir otomatis dan plugin mencoba key lain atau fallback ke Gemini.';
        }
        if ( $status === 401 ) {
            return $provider_name . ' HTTP 401: API key tidak valid/authorization salah. Key tersebut sudah diblokir otomatis dan plugin mencoba key lain atau fallback ke Gemini.';
        }
        return $message ?: ( $provider_name . ' HTTP ' . $status );
    }

    private function call_openai_compatible_json( $provider, $system_prompt, $user_text, $schema ) {
        $config = $this->openai_provider_config( $provider );
        if ( ! $config ) {
            return new WP_Error( 'heaj_provider_invalid', 'Provider AI tidak valid.' );
        }
        if ( empty( $config['keys'] ) ) {
            return new WP_Error( 'heaj_provider_no_key', 'API key untuk ' . $config['name'] . ' belum tersedia.' );
        }

        $json_contract = "\n\nOUTPUT CONTRACT: Reply ONLY with a valid JSON object. Do not use markdown fences or extra text. JSON schema:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $messages = [
            [ 'role' => 'system', 'content' => $system_prompt . $json_contract ],
            [ 'role' => 'user', 'content' => $user_text ],
        ];
        $last_error = 'Request ' . $config['name'] . ' gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        for ( $round = 1; $round <= $max_rounds; $round++ ) {
            $retryable_round = false;
            foreach ( $config['keys'] as $i => $key ) {
                if ( $this->is_api_key_blocked( $key ) ) {
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => 'skipped', 'retryable' => false, 'blocked' => true, 'message' => 'API key provider ini sudah masuk daftar blokir otomatis.' ];
                    continue;
                }
                $payload = [
                    'model'       => $config['model'],
                    'messages'    => $messages,
                    'temperature' => 0.35,
                ];
                // OpenAI-compatible providers may ignore response_format if unsupported; JSON contract remains in prompt.
                $payload['response_format'] = [ 'type' => 'json_object' ];

                $response = wp_remote_post( $config['endpoint'], [
                    'headers' => [
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'Bearer ' . trim( $key ),
                    ],
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $retryable_round = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => 'wp_error', 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $raw_error = $decoded['error']['message'] ?? $decoded['message'] ?? ( $config['name'] . ' HTTP ' . $code );
                    $last_error = $this->friendly_openai_compatible_error( $config['name'], $code, $raw_error );
                    $blockable = $this->is_blockable_openai_compatible_key_error( $code, $raw_error );
                    if ( $blockable ) {
                        $this->block_api_key( $key, $last_error );
                        $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => false, 'blocked' => true, 'message' => $last_error ];
                        continue;
                    }
                    $retryable = $this->is_retryable_openai_compatible_error( $code, $raw_error );
                    if ( $retryable ) { $retryable_round = true; }
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => $retryable, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['choices'][0]['message']['content'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons ' . $config['name'] . ' bukan JSON valid.';
                    $retryable_round = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                return [
                    'result'          => $result,
                    'provider_label'  => $config['name'],
                    'api_index_used'  => $i + 1,
                    'round_used'      => $round,
                    'attempts'        => count( $attempts ) + 1,
                ];
            }
            if ( ! $retryable_round || $round >= $max_rounds ) { break; }
            sleep( $this->retry_delay_seconds( $round ) );
        }

        return new WP_Error( 'heaj_provider_failed', $last_error, [ 'status' => $last_status, 'attempts' => $attempts ] );
    }



    private function first_source_url_from_text( $text ) {
        $urls = $this->extract_urls_from_text( $text );
        return ! empty( $urls[0] ) ? $urls[0] : '';
    }


    private function all_source_urls_from_text( $text ) {
        return array_values( array_unique( array_map( 'esc_url_raw', $this->extract_urls_from_text( (string) $text ) ) ) );
    }
    private function quick_extract_source_plain_text( $raw_text ) {
        $context = $this->fetch_source_text_context( $raw_text );
        $context = preg_replace( '/=+ SUMBER RESMI HASIL EKSTRAKSI SERVER =+|=+ AKHIR SUMBER RESMI =+|URL SUMBER:.*?\nTEKS SUMBER HASIL EKSTRAKSI SERVER:/s', '', $context );
        return trim( wp_strip_all_tags( $context ) );
    }

    public function ajax_test_provider_keys() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal.' ], 403 );
        }
        if ( ! current_user_can( self::editor_admin_capability() ) ) {
            wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
        }
        $provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : 'gemini';
        $rows = [];
        if ( $provider === 'gemini' ) {
            $pool = $this->get_api_key_pool( true );
            $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
            foreach ( $pool as $i => $item ) {
                if ( ! empty( $item['blocked'] ) ) {
                    $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'blocked', 'message' => 'Diblokir lokal' ];
                    continue;
                }
                $endpoint = sprintf( 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', rawurlencode( $model ), rawurlencode( $item['key'] ) );
                $res = wp_remote_post( $endpoint, [ 'timeout' => 25, 'headers' => [ 'Content-Type' => 'application/json' ], 'body' => wp_json_encode( [ 'contents' => [ [ 'parts' => [ [ 'text' => 'Reply OK only.' ] ] ] ] ] ) ] );
                if ( is_wp_error( $res ) ) { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'error', 'message' => $res->get_error_message() ]; continue; }
                $code = wp_remote_retrieve_response_code( $res );
                $body = json_decode( wp_remote_retrieve_body( $res ), true );
                $msg = $body['error']['message'] ?? 'Aktif';
                if ( $code >= 200 && $code < 300 ) { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'active', 'message' => 'Aktif' ]; }
                else { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'error', 'message' => wp_trim_words( $msg, 18 ) ]; }
            }
        } else {
            $config = $this->openai_provider_config( $provider );
            if ( ! $config ) { wp_send_json_error( [ 'message' => 'Provider tidak valid.' ], 400 ); }
            foreach ( $config['keys'] as $i => $key ) {
                $masked = $this->mask_api_key( $key );
                if ( $this->is_api_key_blocked( $key ) ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'blocked', 'message' => 'Diblokir lokal' ]; continue; }
                $payload = [ 'model' => $config['model'], 'messages' => [ [ 'role' => 'user', 'content' => 'Reply OK only.' ] ], 'temperature' => 0 ];
                $res = wp_remote_post( $config['endpoint'], [ 'timeout' => 30, 'headers' => [ 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . trim( $key ) ], 'body' => wp_json_encode( $payload ) ] );
                if ( is_wp_error( $res ) ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'error', 'message' => $res->get_error_message() ]; continue; }
                $code = wp_remote_retrieve_response_code( $res );
                $body = json_decode( wp_remote_retrieve_body( $res ), true );
                $msg = $body['error']['message'] ?? $body['message'] ?? 'Aktif';
                if ( $code >= 200 && $code < 300 ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'active', 'message' => 'Aktif' ]; }
                else { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'error', 'message' => wp_trim_words( $msg, 18 ) ]; }
            }
        }
        wp_send_json_success( [ 'provider' => $provider, 'rows' => $rows ] );
    }

    public function ajax_generate_content() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin memakai generator.' ], 403 );
        }

        $system_prompt = isset( $_POST['systemPrompt'] ) ? wp_unslash( $_POST['systemPrompt'] ) : '';
        $user_text     = isset( $_POST['userText'] ) ? wp_unslash( $_POST['userText'] ) : '';
        $schema_raw    = isset( $_POST['schema'] ) ? wp_unslash( $_POST['schema'] ) : '';
        $use_search    = ! empty( $_POST['useSearch'] ) && $_POST['useSearch'] === '1';
        $schema        = json_decode( $schema_raw, true );
        $ai_provider   = isset( $_POST['aiProvider'] ) ? sanitize_key( wp_unslash( $_POST['aiProvider'] ) ) : 'gemini';
        $prompt_style  = isset( $_POST['promptStyle'] ) ? sanitize_text_field( wp_unslash( $_POST['promptStyle'] ) ) : '';
        $prompt_label  = isset( $_POST['promptLabel'] ) ? sanitize_text_field( wp_unslash( $_POST['promptLabel'] ) ) : '';
        $language_code = isset( $_POST['language'] ) ? sanitize_key( wp_unslash( $_POST['language'] ) ) : '';
        $source_input_raw = isset( $_POST['sourceInput'] ) ? sanitize_textarea_field( wp_unslash( $_POST['sourceInput'] ) ) : '';
        if ( ! in_array( $ai_provider, [ 'gemini', 'grok', 'groqcloud', 'zai' ], true ) ) { $ai_provider = 'gemini'; }

        if ( empty( $system_prompt ) || empty( $user_text ) || ! is_array( $schema ) ) {
            wp_send_json_error( [ 'message' => 'Payload tidak lengkap atau schema JSON tidak valid.' ], 400 );
        }

        $source_context = $this->fetch_source_text_context( $user_text );
        if ( $source_context !== '' ) {
            $system_prompt .= "

MODE SUMBER URL TERKUNCI (WAJIB DIIKUTI): Server WordPress sudah mengambil teks artikel sumber dan melampirkannya di input. Gunakan HANYA teks sumber hasil ekstraksi server sebagai dasar fakta. Jangan mengandalkan memori model, hasil pencarian lain, atau asumsi. Semua tanggal, waktu, angka, nama narasumber, jabatan, lokasi, dan kutipan langsung wajib sama persis dengan teks sumber. Jika sebuah data tidak ada di teks sumber, jangan tulis data tersebut. DILARANG membuat tanggal default, tanggal hari ini, atau tanggal acak. Kutipan langsung di dalam tanda petik harus disalin verbatim dari sumber, bukan diparafrase. Untuk menghindari duplikasi konten, paragraf narasi di luar kutipan WAJIB ditulis ulang secara unik: ubah struktur kalimat, urutan penjelasan, dan pilihan kata tanpa mengubah fakta. Jangan menyalin paragraf sumber secara utuh atau berurutan sama persis. Parafrase hanya boleh untuk narasi, bukan untuk kutipan, angka, tanggal, nama, lokasi, atau jabatan.";
            $user_text .= $source_context;
            $use_search = false;
        }

        $provider_fallback_error = null;
        $provider_fallback_attempts = [];
        $fallback_from_provider = '';
        if ( $ai_provider !== 'gemini' ) {
            $provider_result = $this->call_openai_compatible_json( $ai_provider, $system_prompt, $user_text, $schema );
            if ( ! is_wp_error( $provider_result ) ) {
                $result_clean = $this->sanitize_ai_json_result( $provider_result['result'], $schema );
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result_clean['titleOptions'] ?? null ) ? ( $result_clean['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => $ai_provider,
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                    'source_input' => $source_input_raw ?: $user_text,
                    'prompt_style' => $prompt_style,
                    'prompt_label' => $prompt_label,
                    'language' => $language_code,
                ] );
                wp_send_json_success( [
                    'result'          => $result_clean,
                    'provider_used'   => $ai_provider,
                    'provider_label'  => $provider_result['provider_label'],
                    'api_index_used'  => $provider_result['api_index_used'],
                    'round_used'      => $provider_result['round_used'],
                    'attempts'        => $provider_result['attempts'],
                    'source_context'  => $source_context ? sanitize_textarea_field( $this->quick_extract_source_plain_text( $user_text ) ) : '',
                    'source_url'      => $this->first_source_url_from_text( $user_text ),
                    'source_urls'     => $this->all_source_urls_from_text( $user_text ),
                    'history_id'      => $history_id,
                ] );
            }

            $data = $provider_result->get_error_data();
            $provider_fallback_error = $provider_result->get_error_message();
            $provider_fallback_attempts = is_array( $data ) && isset( $data['attempts'] ) ? $data['attempts'] : [];
            $fallback_from_provider = $ai_provider;
            // Jangan hentikan proses ketika Grok/Z.AI 401/403/limit. Fallback otomatis ke Gemini jika tersedia.
        }

        $api_key_pool = $this->get_api_key_pool( false );
        if ( empty( $api_key_pool ) ) {
            $msg = 'Tidak ada Gemini API Key aktif. Semua API key mungkin kosong atau sudah diblokir otomatis karena leaked/invalid.';
            if ( $provider_fallback_error ) { $msg = $provider_fallback_error . ' Fallback ke Gemini tidak bisa dilakukan karena tidak ada Gemini API aktif.'; }
            wp_send_json_error( [ 'message' => $msg, 'provider_attempts' => $provider_fallback_attempts ], 400 );
        }

        $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        $model_chain = $this->get_gemini_model_chain( $model );

        foreach ( $model_chain as $cache_model ) {
            $cache_key = $this->gemini_cache_key( $cache_model, $system_prompt, $user_text, $schema, $use_search );
            $cached_result = get_transient( $cache_key );
            if ( is_array( $cached_result ) && ! empty( $cached_result['result'] ) && is_array( $cached_result['result'] ) ) {
                $result = $this->sanitize_ai_json_result( $cached_result['result'], $schema );
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result['titleOptions'] ?? null ) ? ( $result['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => 'gemini',
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                    'source_input' => $source_input_raw ?: $user_text,
                    'prompt_style' => $prompt_style,
                    'prompt_label' => $prompt_label,
                    'language' => $language_code,
                    'cached' => true,
                    'model_used' => $cache_model,
                ] );
                wp_send_json_success( [
                    'result'         => $result,
                    'provider_used'  => 'gemini',
                    'cached'         => true,
                    'model_used'     => $cache_model,
                    'model_chain'    => $model_chain,
                    'source_context' => $source_context ? sanitize_textarea_field( $this->quick_extract_source_plain_text( $user_text ) ) : '',
                    'source_url'     => $this->first_source_url_from_text( $user_text ),
                    'source_urls'    => $this->all_source_urls_from_text( $user_text ),
                    'history_id'     => $history_id,
                ] );
            }
        }

        $last_error = 'Request Gemini gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        foreach ( $model_chain as $try_model ) {
            $payload = $this->build_gemini_payload( $try_model, $system_prompt, $user_text, $schema, $use_search );
            $cache_key = $this->gemini_cache_key( $try_model, $system_prompt, $user_text, $schema, $use_search );
            for ( $round = 1; $round <= $max_rounds; $round++ ) {
                $round_has_retryable_error = false;

                foreach ( $api_key_pool as $index => $api_item ) {
                $api_key = $api_item['key'];
                $api_label = $api_item['label'] ?? ( 'API #' . ( $index + 1 ) );
                if ( $this->is_api_key_blocked( $api_key ) ) {
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => 'skipped', 'retryable' => false, 'blocked' => true, 'message' => 'API key sudah masuk daftar blokir otomatis.' ];
                    continue;
                }
                $endpoint = sprintf(
                    'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
                    rawurlencode( $try_model ),
                    rawurlencode( $api_key )
                );

                $response = wp_remote_post( $endpoint, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $last_status = 500;
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => 'wp_error', 'retryable' => true, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $last_error = $decoded['error']['message'] ?? 'Request Gemini gagal.';
                    $blockable = $this->is_blockable_gemini_api_key_error( $code, $last_error );
                    if ( $blockable ) {
                        $this->block_api_key( $api_key, $last_error );
                        $attempts[] = [
                            'round' => $round,
                            'api_index' => $index + 1,
                            'api_label' => $api_label,
                            'status' => $code,
                            'retryable' => false,
                            'blocked' => true,
                            'message' => $last_error,
                        ];
                        continue;
                    }
                    $retryable = $this->is_retryable_gemini_error( $code, $last_error );
                    if ( $retryable ) {
                        $round_has_retryable_error = true;
                    }
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => $code, 'retryable' => $retryable, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons Gemini bukan JSON valid.';
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => $code, 'retryable' => true, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $result = $this->sanitize_ai_json_result( $result, $schema );
                set_transient( $cache_key, [ 'result' => $result, 'timestamp' => time(), 'model' => $try_model ], HOUR_IN_SECONDS );
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result['titleOptions'] ?? null ) ? ( $result['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => 'gemini',
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                    'source_input' => $source_input_raw ?: $user_text,
                    'prompt_style' => $prompt_style,
                    'prompt_label' => $prompt_label,
                    'language' => $language_code,
                    'cached' => false,
                    'model_used' => $try_model,
                ] );
                wp_send_json_success( [
                    'result'         => $result,
                    'provider_used'  => 'gemini',
                    'fallback_from'  => $fallback_from_provider,
                    'fallback_error' => $provider_fallback_error,
                    'provider_attempts' => $provider_fallback_attempts,
                    'api_index_used' => $index + 1,
                    'api_label_used' => $api_label,
                    'round_used'     => $round,
                    'attempts'       => count( $attempts ) + 1,
                    'cached'        => false,
                    'model_used'    => $try_model,
                    'source_context' => $source_context ? sanitize_textarea_field( $this->quick_extract_source_plain_text( $user_text ) ) : '',
                    'source_url'     => $this->first_source_url_from_text( $user_text ),
                    'source_urls'    => $this->all_source_urls_from_text( $user_text ),
                    'history_id'     => $history_id,
                ] );
            }

            if ( ! $round_has_retryable_error || $round >= $max_rounds ) {
                break;
            }

            sleep( $this->retry_delay_seconds( $round ) );
            }
            // If this model failed because of retryable overload/limit, try the next fallback model.
        }

        $friendly_message = $last_error;
        if ( $provider_fallback_error ) {
            $friendly_message = $provider_fallback_error . ' Fallback ke Gemini juga belum berhasil: ' . $last_error;
        }
        if ( $this->is_blockable_gemini_api_key_error( $last_status, $last_error ) ) {
            $friendly_message = 'API key terakhir ditolak permanen oleh Gemini dan sudah diblokir otomatis. Plugin akan memakai API aktif lain pada request berikutnya. Tambahkan API key baru jika semua key sudah terblokir.';
        } elseif ( $this->is_retryable_gemini_error( $last_status, $last_error ) ) {
            $friendly_message = 'Gemini sedang sibuk/limit sementara. Plugin sudah mencoba ulang dan merotasi API key, tapi belum berhasil. Silakan klik Generate Ulang beberapa saat lagi.';
        }
        if ( $provider_fallback_error ) {
            $friendly_message = $provider_fallback_error . ' Fallback ke Gemini juga belum berhasil: ' . $friendly_message;
        }

        wp_send_json_error( [
            'message'  => $friendly_message,
            'raw_message' => $last_error,
            'status'   => $last_status,
            'attempts' => $attempts,
            'provider_attempts' => $provider_fallback_attempts,
            'model_chain' => isset( $model_chain ) ? $model_chain : [],
        ], $last_status );
    }



    private function optimize_downloaded_source_image( $tmp, $filename ) {
        if ( ! $tmp || ! file_exists( $tmp ) ) {
            return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
        }

        if ( ! function_exists( 'wp_get_image_editor' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $editor = wp_get_image_editor( $tmp );
        if ( is_wp_error( $editor ) ) {
            return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
        }

        $size = $editor->get_size();
        if ( ! empty( $size['width'] ) && (int) $size['width'] > 1280 ) {
            $editor->resize( 1280, null, false );
        }
        if ( method_exists( $editor, 'set_quality' ) ) {
            $editor->set_quality( 82 );
        }

        $dir = dirname( $tmp );
        $base = pathinfo( $filename, PATHINFO_FILENAME );
        $base = sanitize_file_name( $base ? $base : 'he-source-image' );
        $supports_webp = function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( [ 'mime_type' => 'image/webp' ] );

        if ( $supports_webp ) {
            $webp_filename = wp_unique_filename( $dir, $base . '.webp' );
            $webp_path = trailingslashit( $dir ) . $webp_filename;
            $saved = $editor->save( $webp_path, 'image/webp' );
            if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && file_exists( $saved['path'] ) ) {
                @unlink( $tmp );
                return [ 'tmp' => $saved['path'], 'filename' => basename( $saved['path'] ), 'optimized' => true, 'format' => 'webp' ];
            }
        }

        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        if ( ! $ext ) { $ext = 'jpg'; }
        $fallback_filename = wp_unique_filename( $dir, $base . '-optimized.' . $ext );
        $fallback_path = trailingslashit( $dir ) . $fallback_filename;
        $saved = $editor->save( $fallback_path );
        if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && file_exists( $saved['path'] ) ) {
            @unlink( $tmp );
            return [ 'tmp' => $saved['path'], 'filename' => basename( $saved['path'] ), 'optimized' => true, 'format' => 'fallback' ];
        }

        return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
    }

    private function sideload_featured_image( $image_url, $post_id, $title = '', $caption = '' ) {
        $image_url = esc_url_raw( $image_url );
        if ( ! $image_url || ! $post_id ) {
            return new WP_Error( 'heaj_featured_image_invalid', 'URL featured image tidak valid.' );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url( $image_url, 30 );
        if ( is_wp_error( $tmp ) ) { return $tmp; }

        $path = wp_parse_url( $image_url, PHP_URL_PATH );
        $filename = sanitize_file_name( basename( (string) $path ) );
        if ( ! $filename || strpos( $filename, '.' ) === false ) {
            $filename = 'he-source-image-' . time() . '.jpg';
        }

        $optimized = $this->optimize_downloaded_source_image( $tmp, $filename );
        $tmp = $optimized['tmp'];
        $filename = $optimized['filename'];

        $file_array = [
            'name'     => $filename,
            'tmp_name' => $tmp,
        ];

        $attachment_id = media_handle_sideload( $file_array, $post_id, $caption ?: $title );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            return $attachment_id;
        }
        if ( $title ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $title ) );
        }
        if ( $caption ) {
            wp_update_post( [
                'ID' => $attachment_id,
                'post_excerpt' => $caption,
            ] );
        }
        update_post_meta( $attachment_id, '_he_source_image_original_url', $image_url );
        update_post_meta( $attachment_id, '_he_source_image_optimized', ! empty( $optimized['optimized'] ) ? '1' : '0' );
        update_post_meta( $attachment_id, '_he_source_image_format', sanitize_text_field( $optimized['format'] ) );
        return $attachment_id;
    }

    private function parse_selected_source_images_from_request() {
        $raw = isset( $_POST['source_images'] ) ? wp_unslash( $_POST['source_images'] ) : '';
        if ( ! is_string( $raw ) || $raw === '' ) {
            return [];
        }
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            return [];
        }
        $items = [];
        foreach ( $decoded as $item ) {
            if ( ! is_array( $item ) || empty( $item['url'] ) ) { continue; }
            $url = esc_url_raw( $item['url'] );
            if ( ! $url ) { continue; }
            $caption = isset( $item['caption'] ) ? sanitize_text_field( $item['caption'] ) : '';
            $credit = isset( $item['credit'] ) ? sanitize_text_field( $item['credit'] ) : '';
            if ( $credit && stripos( $caption, $credit ) === false ) {
                $caption = trim( $caption ? $caption . ' | ' . $credit : $credit );
            }
            $items[] = [
                'url'     => $url,
                'caption' => $caption,
                'source'  => isset( $item['source'] ) ? esc_url_raw( $item['source'] ) : '',
            ];
        }
        return array_slice( $items, 0, 8 );
    }

    private function build_inserted_image_html( $attachment_id, $caption = '' ) {
        $src = wp_get_attachment_url( $attachment_id );
        if ( ! $src ) { return ''; }
        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $html = '<figure class="wp-caption aligncenter">';
        $html .= '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" />';
        if ( $caption ) {
            $html .= '<figcaption class="wp-caption-text">' . esc_html( $caption ) . '</figcaption>';
        }
        $html .= '</figure>';
        return $html;
    }

    public function ajax_create_draft() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin membuat draft.' ], 403 );
        }

        $title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
        $slug     = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';
        $meta     = isset( $_POST['meta'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta'] ) ) : '';
        $content  = isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
        $category = isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
        $tags_raw = isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '';
        $source_url = isset( $_POST['source_url'] ) ? esc_url_raw( wp_unslash( $_POST['source_url'] ) ) : '';
        $source_urls_raw = isset( $_POST['source_urls'] ) ? wp_unslash( $_POST['source_urls'] ) : '';
        $source_urls = [];
        if ( is_string( $source_urls_raw ) && $source_urls_raw !== '' ) {
            $decoded_source_urls = json_decode( $source_urls_raw, true );
            if ( is_array( $decoded_source_urls ) ) {
                $source_urls = array_values( array_unique( array_filter( array_map( 'esc_url_raw', $decoded_source_urls ) ) ) );
            }
        }
        $history_id = isset( $_POST['history_id'] ) ? sanitize_key( wp_unslash( $_POST['history_id'] ) ) : '';
        $title_index = isset( $_POST['title_index'] ) ? absint( $_POST['title_index'] ) : 0;
        $slug_index = isset( $_POST['slug_index'] ) ? absint( $_POST['slug_index'] ) : 0;
        $meta_index = isset( $_POST['meta_index'] ) ? absint( $_POST['meta_index'] ) : 0;
        $image_source = isset( $_POST['image_source'] ) ? sanitize_text_field( wp_unslash( $_POST['image_source'] ) ) : '';
        $ai_provider = isset( $_POST['ai_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['ai_provider'] ) ) : '';
        $excerpt = isset( $_POST['excerpt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['excerpt'] ) ) : '';
        $featured_image_url = isset( $_POST['featured_image_url'] ) ? esc_url_raw( wp_unslash( $_POST['featured_image_url'] ) ) : '';
        $featured_image_caption = isset( $_POST['featured_image_caption'] ) ? sanitize_text_field( wp_unslash( $_POST['featured_image_caption'] ) ) : '';
        $selected_source_images = $this->parse_selected_source_images_from_request();

        if ( empty( $title ) || empty( $content ) ) {
            wp_send_json_error( [ 'message' => 'Judul dan isi artikel tidak boleh kosong.' ], 400 );
        }

        $cat_id = 0;
        if ( $category ) {
            $term = get_term_by( 'name', $category, 'category' );
            if ( $term && ! is_wp_error( $term ) ) {
                $cat_id = (int) $term->term_id;
            } else {
                $new_term = wp_insert_term( $category, 'category' );
                if ( ! is_wp_error( $new_term ) && ! empty( $new_term['term_id'] ) ) {
                    $cat_id = (int) $new_term['term_id'];
                }
            }
        }

        $post_data = [
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        ];
        if ( $excerpt ) { $post_data['post_excerpt'] = $excerpt; }
        if ( $cat_id ) { $post_data['post_category'] = [ $cat_id ]; }

        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Gagal membuat draft: ' . $post_id->get_error_message() ], 500 );
        }

        if ( $tags_raw ) {
            $tags = array_filter( array_map( 'trim', explode( ',', $tags_raw ) ) );
            wp_set_post_tags( $post_id, $tags, false );
        }

        if ( $source_url ) { update_post_meta( $post_id, '_he_source_url', $source_url ); }
        if ( ! empty( $source_urls ) ) { update_post_meta( $post_id, '_he_source_urls', $source_urls ); }
        if ( $ai_provider ) { update_post_meta( $post_id, '_he_ai_provider', $ai_provider ); }
        update_post_meta( $post_id, '_he_generated_by', 'YZG AI Journalist ' . self::VERSION );

        if ( $meta ) {
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta );
            update_post_meta( $post_id, 'rank_math_description', $meta );
            update_post_meta( $post_id, '_seopress_titles_desc', $meta );
            update_post_meta( $post_id, '_he_meta_description', $meta );

            // Support theme NewsPress meta description field:
            // <input id="newspress_meta_description" name="newspress_meta_description">
            update_post_meta( $post_id, 'newspress_meta_description', $meta );
            update_post_meta( $post_id, '_newspress_meta_description', $meta );

            // Tema/editor tertentu memakai custom field ini untuk input:
            // <input type="text" name="single_post_subtitle" id="input-single_post_subtitle">
            // Isi dengan meta deskripsi yang dipilih agar langsung muncul di Post Subtitle.
            update_post_meta( $post_id, 'single_post_subtitle', $meta );
            update_post_meta( $post_id, '_single_post_subtitle', $meta );
        }



        $inserted_image_html = [];
        if ( ! empty( $selected_source_images ) ) {
            foreach ( $selected_source_images as $idx => $img ) {
                $img_url = $img['url'];
                $img_caption = $img['caption'];
                $attachment_id = $this->sideload_featured_image( $img_url, $post_id, $title, $img_caption );
                if ( ! is_wp_error( $attachment_id ) && $attachment_id ) {
                    if ( $idx === 0 ) {
                        set_post_thumbnail( $post_id, $attachment_id );
                        update_post_meta( $post_id, '_he_featured_image_source_url', $img_url );
                        if ( $img_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $img_caption ); }
                    } else {
                        $inserted = $this->build_inserted_image_html( $attachment_id, $img_caption );
                        if ( $inserted ) { $inserted_image_html[] = $inserted; }
                    }
                } else {
                    update_post_meta( $post_id, '_he_source_image_error_' . $idx, is_wp_error( $attachment_id ) ? $attachment_id->get_error_message() : 'Gagal mengunggah gambar sumber.' );
                }
            }
        } elseif ( $featured_image_url ) {
            $attachment_id = $this->sideload_featured_image( $featured_image_url, $post_id, $title, $featured_image_caption );
            if ( ! is_wp_error( $attachment_id ) && $attachment_id ) {
                set_post_thumbnail( $post_id, $attachment_id );
                update_post_meta( $post_id, '_he_featured_image_source_url', $featured_image_url );
                if ( $featured_image_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $featured_image_caption ); }
            } else {
                update_post_meta( $post_id, '_he_featured_image_error', is_wp_error( $attachment_id ) ? $attachment_id->get_error_message() : 'Gagal mengunggah featured image.' );
            }
        }

        if ( ! empty( $inserted_image_html ) ) {
            $content_with_images = $content . "\n\n" . implode( "\n\n", $inserted_image_html );
            wp_update_post( [
                'ID'           => $post_id,
                'post_content' => $content_with_images,
            ] );
            update_post_meta( $post_id, '_he_inserted_source_images_count', count( $inserted_image_html ) );
        }

        $this->add_history_event( [
            'title'      => $title,
            'source_url' => $source_url,
            'source_urls'=> ! empty( $source_urls ) ? $source_urls : ( $source_url ? [ $source_url ] : [] ),
            'provider'   => $ai_provider,
            'status'     => 'draft_created',
            'post_id'    => $post_id,
            'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
            'title_index' => $title_index,
            'slug_index' => $slug_index,
            'meta_index' => $meta_index,
            'image_source' => $image_source,
            'selected_image_url' => $featured_image_url,
        ] );

        $this->update_history_generated_to_draft( $history_id, $post_id, get_edit_post_link( $post_id, 'raw' ) );

        wp_send_json_success( [
            'message'  => 'Draft berhasil dibuat!',
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link( $post_id, 'raw' ),
        ] );
    }
}

new HE_Journalist_Pro_Tools();

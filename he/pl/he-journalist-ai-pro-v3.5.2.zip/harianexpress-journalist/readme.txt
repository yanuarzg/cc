=== YZG AI Journalist ===
Contributors: yanuarzg
Tags: ai, journalist, gemini, grok, zai, seo, harianexpress
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 3.5.2
License: GPLv2 or later

White-label AI editorial assistant dengan rotasi API, output SEO, audit fakta, gambar sumber/Pexels, draft sosial media, skrip video, dan kirim ke Draft WordPress.

== Changelog ==

= 3.3.12 =
* Revisi header generator, settings, filter gambar mirip, threshold kemiripan narasi, dan visibilitas halaman subdomain.

= 3.3.3 =
* Hapus indikator API aktif dari halaman Generator Artikel.
* Perbaiki error JavaScript Cannot access lastSourceText before initialization.
* Perbaiki heading Riwayat Generate agar terlihat jelas.
* Prompt Custom di Pengaturan API disederhanakan hanya menjadi Instruksi Global Tambahan.

= 3.2.5 =
* Halaman Semua Subdomain: tombol di dalam card dihapus, icon buka website dipindahkan setelah nama domain, dan icon login ditempatkan di pojok kanan atas card.
* Sortir baru berdasarkan jumlah total artikel terbanyak/tersedikit.
* CSS dibuat lebih netral tanpa gradient dan tanpa warna terlalu colorfull.

= 3.1.7 =
* Perbaikan error Grok/xAI HTTP 403.
* API key Grok/Z.AI yang ditolak 401/403 otomatis diblokir dan dilewati.
* Fallback otomatis ke Gemini jika Grok/Z.AI gagal.

= 3.1.6 =
* Tambah dukungan provider AI Grok/xAI dan Z.AI pada Generator Artikel.
* Tambah input API Grok/xAI dan Z.AI di Pengaturan API.
* Hapus block info Lisensi Domain via GitHub dari halaman Pengaturan API.
* Tambah tautan Ambil API Key Gemini sebelum input API Key Tambahan.

= 3.1.5 =
* Auto-block API key bocor/invalid/expired/disabled dari respons Gemini.
* Status API key aktif/terblokir di Pengaturan API.
* Perbaikan update checker agar notifikasi update tidak muncul saat versi remote sama.

= 3.1.4 =
* Lisensi domain dibaca dari GitHub licenses.json.
* Tambah contoh licenses.json untuk menambah domain pembeli lisensi tanpa rilis ulang plugin.

= 3.1.3 =
* Filter gambar sumber: hanya dari area artikel atau image minimal 320px agar ikon/gambar kecil tidak tampil.
* Tambah pembatasan lisensi domain untuk harianexpress.com, subdomain harianexpress.com, harianexpress.id, subdomain harianexpress.id, dan geky.page.gd.
* Redirect domain tidak terdaftar ke https://yanuarzg.github.io/.
* Tambah tombol Beli Lisensi di footer sebelum Dibangun oleh YZG.

= 3.1 =
* Mobile responsive.

= 3.3.12 =
* Revisi header generator, settings, filter gambar mirip, threshold kemiripan narasi, dan visibilitas halaman subdomain.

= 3.3.3 =
* Tambah Quality Score artikel dan deteksi kemiripan narasi.
* Revisi label tombol HTML dan Draft.

= 3.4.7 =
* Fixed Custom Settings persistence by using native WordPress option array fields.
* Branding, prompt, language, author, and editor settings now apply reliably after save.

= 3.5.2 =
* Plugin UI now follows WordPress admin/user locale: Indonesian for id_ID, English for other locales.

= 3.5.2 =
* Performance & Architecture Update: API Key Manager, Gemini fallback model chain, and richer history tracking.

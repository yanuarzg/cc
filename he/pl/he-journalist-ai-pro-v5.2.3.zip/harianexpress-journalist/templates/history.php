<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="he-history-app" class="heaj-wrap he-history-wrap">
    <section class="he-history-hero">
        <div>
            <h1>Riwayat Generate</h1>
            <p>Catatan artikel yang digenerate dan draft yang dibuat oleh plugin di domain ini.</p>
        </div>
        <div class="he-history-count"><strong><?php echo esc_html( isset( $total_history ) ? $total_history : count( $history ) ); ?></strong><span>aktivitas</span></div>
    </section>

    <?php if ( isset( $_GET['heaj-deleted'] ) ) : ?><div class="notice notice-success is-dismissible"><p><strong>Riwayat berhasil dihapus.</strong></p></div><?php endif; ?>

    <?php if ( empty( $history ) ) : ?>
        <div class="he-history-empty">
            <i data-lucide="clock-3" class="w-8 h-8"></i>
            <strong>Belum ada riwayat.</strong>
            <span>Riwayat akan terisi setelah generate artikel atau kirim draft.</span>
        </div>
    <?php else : ?>
        <div class="he-history-list">
            <?php foreach ( $history as $item ) : ?>
                <?php
                    $status = $item['status'] ?? 'generated';
                    $title = $item['title'] ?? '(Tanpa judul)';
                    $time = $item['time'] ?? '';
                    $provider = $item['provider'] ?? '';
                    $prompt_label = $item['prompt_label'] ?? ( $item['prompt_style'] ?? '' );
                    $language = $item['language'] ?? '';
                    $image_source_type = $item['image_source_type'] ?? '';
                    $image_count = isset( $item['image_count'] ) ? absint( $item['image_count'] ) : 0;
                    $sources = [];
                    if ( ! empty( $item['source_urls'] ) && is_array( $item['source_urls'] ) ) { $sources = $item['source_urls']; }
                    elseif ( ! empty( $item['source_url'] ) ) { $sources = [ $item['source_url'] ]; }
                    $source_input = trim( (string) ( $item['source_input'] ?? '' ) );
                    if ( $source_input === '' && ! empty( $sources ) ) { $source_input = implode( "\n", $sources ); }
                    $edit = $item['edit_url'] ?? '';
                    $linked_edit = $item['linked_edit_url'] ?? '';
                    $user = $item['user'] ?? '';
                    $draft_status = $item['draft_status'] ?? ( $status === 'draft_created' ? 'sent' : 'not_sent' );
                    $draft_badge = $status === 'draft_created' ? 'Draft dibuat' : ( $draft_status === 'sent' ? 'Dilanjutkan ke Draft' : 'Belum ke Draft' );
                    $draft_class = $status === 'draft_created' || $draft_status === 'sent' ? 'is-sent' : 'is-not-sent';
                ?>
                <article class="he-history-item is-<?php echo esc_attr( $status ); ?>">
                    <div class="he-history-main">
                        <div class="he-history-badges">
                            <span class="he-history-status"><?php echo esc_html( $status === 'draft_created' ? 'Draft' : 'Generate' ); ?></span>
                            <span class="he-history-draft <?php echo esc_attr( $draft_class ); ?>"><?php echo esc_html( $draft_badge ); ?></span>
                        </div>
                        <h2><?php echo esc_html( $title ); ?></h2>
                        <p>
                            <span><?php echo esc_html( $time ); ?></span>
                            <?php if ( $provider ) : ?><span><i data-lucide="cpu" class="w-3 h-3"></i> AI: <?php echo esc_html( strtoupper( $provider ) ); ?></span><?php endif; ?>
                            <?php if ( $prompt_label ) : ?><span><i data-lucide="file-pen-line" class="w-3 h-3"></i> Gaya: <?php echo esc_html( $prompt_label ); ?></span><?php endif; ?>
                            <?php if ( $language ) : ?><span><i data-lucide="languages" class="w-3 h-3"></i> <?php echo esc_html( strtoupper( $language ) ); ?></span><?php endif; ?>
                            <?php if ( $image_source_type ) : ?><span><i data-lucide="image" class="w-3 h-3"></i> Image: <?php echo esc_html( $image_source_type === 'pexels' ? 'Pexels' : ( $image_source_type === 'source' ? 'Sumber' : $image_source_type ) ); ?><?php echo $image_count ? ' (' . esc_html( $image_count ) . ')' : ''; ?></span><?php endif; ?>
                            <?php if ( $user ) : ?><span><?php echo esc_html( $user ); ?></span><?php endif; ?>
                        </p>
                        <?php if ( ! empty( $sources ) ) : ?>
                            <div class="he-history-sources">
                                <?php foreach ( $sources as $source ) : ?>
                                    <a href="<?php echo esc_url( $source ); ?>" target="_blank" rel="noopener" class="he-history-source"><?php echo esc_html( $source ); ?></a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="he-history-actions">
                        <?php if ( $draft_status !== 'sent' && $status !== 'draft_created' && $source_input !== '' ) : ?>
                            <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'he-journalist', 'heaj_restore_source' => $source_input ], admin_url( 'admin.php' ) ) ); ?>" class="button button-secondary"><i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Restore</a>
                        <?php endif; ?>
                        <?php if ( $edit ) : ?>
                            <a href="<?php echo esc_url( $edit ); ?>" target="_blank" rel="noopener" class="button button-primary">Edit Draft</a>
                        <?php elseif ( $linked_edit ) : ?>
                            <a href="<?php echo esc_url( $linked_edit ); ?>" target="_blank" rel="noopener" class="button button-secondary">Lihat Draft</a>
                        <?php endif; ?>
                        <?php if ( ! empty( $item['id'] ) ) : ?>
                            <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'heaj_delete_generate_history', 'id' => $item['id'] ], admin_url( 'admin-post.php' ) ), 'heaj_delete_generate_history_' . $item['id'] ) ); ?>" class="button he-history-delete" onclick="return confirm('Hapus riwayat ini?')" title="Hapus"><i data-lucide="trash-2" class="w-4 h-4"></i></a>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php if ( isset( $total_pages ) && $total_pages > 1 ) : ?>
            <div class="he-history-pagination">
                <?php
                    echo paginate_links( [
                        'base'      => add_query_arg( 'paged', '%#%' ),
                        'format'    => '',
                        'current'   => isset( $paged ) ? $paged : 1,
                        'total'     => $total_pages,
                        'prev_text' => '‹',
                        'next_text' => '›',
                    ] );
                ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

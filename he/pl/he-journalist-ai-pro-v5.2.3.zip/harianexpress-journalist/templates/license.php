<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$status = is_array( $license_status ?? null ) ? $license_status : [];
$valid = ! empty( $status['valid'] );
$badge_class = $valid ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200';
$badge_text = $valid ? 'Aktif' : 'Tidak Aktif';
$masked_license = $license_key ? substr( $license_key, 0, 12 ) . str_repeat( '•', max( 10, strlen( $license_key ) - 24 ) ) . substr( $license_key, -12 ) : '';
?>
<div id="he-license-app" class="heaj-settings-page max-w-5xl mx-auto p-4 md:p-8">
    <div class="he-settings-hero rounded-2xl p-6 md:p-8 text-white shadow-lg mb-6">
        <p class="uppercase tracking-[0.2em] text-xs opacity-80 mb-2">YZTheme License</p>
        <h1 class="text-2xl md:text-3xl font-black m-0">Lisensi <?php echo esc_html( $brand_settings['brand_name'] ?? 'YZG AI Journalist' ); ?></h1>
        <p class="mt-2 opacity-90 max-w-2xl">Aktivasi produk <strong><?php echo esc_html( HE_Journalist_Pro_Tools::LICENSE_PRODUCT_ID ); ?></strong> memakai lisensi encrypted JSON annual dari Member Area YZTheme.</p>
    </div>


    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div class="lg:col-span-2 bg-white border border-slate-200 rounded-2xl shadow-sm p-5 md:p-6">
            <div class="flex items-start justify-between gap-3 mb-5">
                <div>
                    <h2 class="text-lg font-black text-slate-900 m-0">Aktivasi Lisensi</h2>
                    <p class="text-sm text-slate-500 mt-1">Paste license code dari <a href="https://www.yztheme.my.id/p/member-area.html" target="_blank" rel="noopener" class="font-bold text-red-600 hover:text-red-700">Member Area YZTheme</a> setelah domain website didaftarkan.</p>
                </div>
                <span class="inline-flex items-center px-3 py-1 rounded-full border text-xs font-bold <?php echo esc_attr( $badge_class ); ?>"><?php echo esc_html( $badge_text ); ?></span>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="space-y-4">
                <?php wp_nonce_field( 'heaj_save_license' ); ?>
                <input type="hidden" name="action" value="heaj_save_license">

                <label class="block">
                    <span class="block text-xs font-bold uppercase tracking-wide text-slate-500 mb-1">Domain Website Ini</span>
                    <input type="text" value="<?php echo esc_attr( $license_domain ); ?>" readonly class="regular-text w-full bg-slate-50 border-slate-200">
                    <span class="block text-[11px] text-slate-500 mt-1">Domain ini harus sama dengan domain yang didaftarkan di <a href="https://www.yztheme.my.id/p/member-area.html" target="_blank" rel="noopener" class="font-bold text-red-600 hover:text-red-700">Member Area YZTheme</a>.</span>
                </label>

                <label class="block">
                    <span class="block text-xs font-bold uppercase tracking-wide text-slate-500 mb-1">Product ID</span>
                    <input type="text" value="<?php echo esc_attr( HE_Journalist_Pro_Tools::LICENSE_PRODUCT_ID ); ?>" readonly class="regular-text w-full bg-slate-50 border-slate-200">
                </label>

                <label class="block">
                    <span class="block text-xs font-bold uppercase tracking-wide text-slate-500 mb-1">License Code</span>
                    <textarea name="heaj_license_key" rows="7" class="large-text code w-full" placeholder="Paste license code encrypted JSON annual di sini"><?php echo esc_textarea( $license_key ); ?></textarea>
                </label>

                <div class="flex flex-wrap gap-2 pt-2">
                    <button type="submit" class="button button-primary">Aktifkan / Verifikasi Ulang</button>
                    <a class="button" href="https://wa.me/6289507785333?text=Halo%20YZTheme%2C%20saya%20butuh%20support%20lisensi%20YZG%20AI%20Journalist" target="_blank" rel="noopener">WA Support</a>
                    <a class="button" href="https://www.yztheme.my.id/p/member-area.html" target="_blank" rel="noopener">Member Area YZTheme</a>
                    <?php if ( $license_key ) : ?>
                        <a class="he-license-clear-link text-xs font-bold text-red-600 hover:text-red-700 underline underline-offset-2" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=heaj_clear_license' ), 'heaj_clear_license' ) ); ?>" onclick="return confirm('Hapus lisensi lokal?')">hapus lisensi</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 md:p-6">
            <h2 class="text-lg font-black text-slate-900 m-0 mb-4">Status</h2>
            <div class="space-y-3 text-sm">
                <div><span class="block text-xs text-slate-500">Status</span><strong class="<?php echo $valid ? 'text-emerald-700' : 'text-red-700'; ?>"><?php echo esc_html( $badge_text ); ?></strong></div>
                <div><span class="block text-xs text-slate-500">Pesan</span><strong><?php echo esc_html( $status['message'] ?? '-' ); ?></strong></div>
                <div><span class="block text-xs text-slate-500">Kode</span><code><?php echo esc_html( $status['code'] ?? '-' ); ?></code></div>
                <div><span class="block text-xs text-slate-500">License Domain</span><code><?php echo esc_html( $status['licenseDomain'] ?? '-' ); ?></code></div>
                <div><span class="block text-xs text-slate-500">Expired At</span><strong><?php echo esc_html( $status['expiresAt'] ?? '-' ); ?></strong></div>
                <div><span class="block text-xs text-slate-500">Sisa Hari</span><strong><?php echo isset( $status['remainingDays'] ) && $status['remainingDays'] !== null ? esc_html( (string) $status['remainingDays'] ) : '-'; ?></strong></div>
                <div><span class="block text-xs text-slate-500">Last Check</span><strong><?php echo ! empty( $status['last_checked'] ) ? esc_html( date_i18n( 'Y-m-d H:i:s', (int) $status['last_checked'] ) ) : '-'; ?></strong></div>
                <?php if ( $masked_license ) : ?>
                    <div><span class="block text-xs text-slate-500">License Tersimpan</span><code class="break-all"><?php echo esc_html( $masked_license ); ?></code></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

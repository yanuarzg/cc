<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$option_name = HE_Journalist_Pro_Tools::OPTION_CUSTOM_SETTINGS; ?>
<div id="he-custom-settings-app" class="wrap he-settings-wrap heaj-wrap heaj-settings-page he-custom-settings-page">
    <section class="he-settings-hero">
        <div class="he-settings-hero-inner">
            <div class="he-settings-brand">
                <div>
                    <h1>Custom Settings</h1>
                    <p class="he-settings-subtitle">Kelola branding white-label, brand profile, prompt, bahasa, penulis, dan editor. Semua tersimpan di database sehingga aman untuk update plugin.</p>
                </div>
            </div>
        </div>
    </section>

    <?php if ( isset( $_GET['settings-updated'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Custom settings berhasil disimpan.</strong></p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['heaj-custom-reset'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Custom settings dikembalikan ke default.</strong></p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['heaj-history-cleared'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Seluruh riwayat generate berhasil dihapus.</strong></p></div>
    <?php endif; ?>

    <form method="post" action="options.php" id="heCustomSettingsForm" class="he-settings-grid">
        <?php settings_fields( 'he_journalist_custom_options' ); ?>
        <input type="hidden" id="heCustomSettingsJson" value="<?php echo esc_attr( wp_json_encode( $custom_settings ) ); ?>">

        <div class="he-settings-main">
            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="badge-check" class="w-4 h-4"></i></span><div><h2>Branding White-label</h2><p>Sesuaikan nama plugin, nama media, logo, profil brand, dan mode lisensi.</p></div></div>
                <div class="he-brand-grid">
                    <label class="he-prompt-field"><span>Nama Brand Plugin</span><small>Berpengaruh ke menu admin dan judul halaman plugin.</small><input id="heBrandName" name="<?php echo esc_attr( $option_name ); ?>[branding][brand_name]" type="text" class="regular-text" placeholder="YZG AI Journalist"></label>
                    <label class="he-prompt-field"><span>Nama Media / Website</span><small>Dipakai di warning redaksi dan brand profile prompt.</small><input id="heMediaName" name="<?php echo esc_attr( $option_name ); ?>[branding][media_name]" type="text" class="regular-text" placeholder="NamaMedia"></label>
                    <label class="he-prompt-field"><span>Organisasi / Redaksi</span><input id="heOrganization" name="<?php echo esc_attr( $option_name ); ?>[branding][organization]" type="text" class="regular-text"></label>
                    <label class="he-prompt-field"><span>Logo URL</span><input id="heLogoUrl" name="<?php echo esc_attr( $option_name ); ?>[branding][logo_url]" type="url" class="regular-text" placeholder="https://.../logo.png"></label>
                    <label class="he-prompt-field"><span>Warna Utama</span><small>Dipakai sebagai aksen visual halaman plugin.</small><input id="hePrimaryColor" name="<?php echo esc_attr( $option_name ); ?>[branding][primary_color]" type="color" value="#0f172a"></label>
                    <label class="he-prompt-field"><span>License Type</span><select id="heLicenseType" name="<?php echo esc_attr( $option_name ); ?>[branding][license_type]"><option value="auto">Auto</option><option value="single_site">Single Site</option><option value="harianexpress_network">HarianExpress Network</option><option value="agency">Agency / Multi Site</option></select></label>
                    <label class="he-prompt-field"><span>Sumber Penulis/Editor</span><select id="heAuthorsSource" name="<?php echo esc_attr( $option_name ); ?>[branding][authors_source]"><option value="manual">Manual</option><option value="wp_users">WordPress Users</option><option value="both">Manual + WordPress Users</option></select></label>
                    <label class="he-prompt-field"><span>Footer Style</span><select id="heFooterStyle" name="<?php echo esc_attr( $option_name ); ?>[branding][footer_style]"><option value="media">Media</option><option value="corporate">Corporate</option><option value="minimal">Minimal</option></select></label>
                    <label class="he-prompt-field"><span>SEO Style</span><select id="heSeoStyle" name="<?php echo esc_attr( $option_name ); ?>[branding][seo_style]"><option value="news">News</option><option value="blog">Blog</option><option value="corporate">Corporate</option><option value="review">Review</option></select></label>
                    <label class="he-prompt-field he-brand-wide"><span>Brand Voice</span><textarea id="heBrandVoice" name="<?php echo esc_attr( $option_name ); ?>[branding][brand_voice]" class="large-text" rows="3"></textarea></label>
                    <label class="he-prompt-field he-brand-wide"><span>Kata/Frasa yang Dihindari</span><textarea id="heForbiddenWords" name="<?php echo esc_attr( $option_name ); ?>[branding][forbidden_words]" class="large-text" rows="3"></textarea></label>
                    <label class="he-prompt-field he-brand-wide"><span>Teks Warning Redaksi Tambahan</span><textarea id="heWarningText" name="<?php echo esc_attr( $option_name ); ?>[branding][warning_text]" class="large-text" rows="3"></textarea></label>
                    <label class="he-prompt-field"><span>Kota Default</span><input id="heDefaultCity" name="<?php echo esc_attr( $option_name ); ?>[branding][default_city]" type="text" class="regular-text" placeholder="Jakarta"></label>
                </div>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="file-pen-line" class="w-4 h-4"></i></span><div><h2>Gaya Penulisan (prompt)</h2><p>Tambah, hapus, atau edit prompt yang muncul di dropdown Gaya Penulisan.</p></div></div>
                <div id="heCustomPrompts" class="he-custom-list"></div>
                <button type="button" class="button button-secondary" data-add="prompts">+ Tambah Prompt</button>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="message-square-text" class="w-4 h-4"></i></span><div><h2>Prompt Custom Global</h2><p>Instruksi tambahan yang akan diterapkan ke semua gaya penulisan.</p></div></div>
                <label class="he-prompt-field"><span>Instruksi Global Tambahan</span><textarea id="heGlobalPrompt" name="<?php echo esc_attr( $option_name ); ?>[global_prompt]" class="large-text he-key-textarea" rows="5" placeholder="Contoh: Gunakan gaya bahasa formal, hindari istilah tertentu, dan sesuaikan dengan brand voice."></textarea></label>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="align-left" class="w-4 h-4"></i></span><div><h2>Panjang Artikel</h2><p>Kelola opsi pendek, sedang, panjang, atau opsi baru lain.</p></div></div>
                <div id="heCustomLengths" class="he-custom-list"></div>
                <button type="button" class="button button-secondary" data-add="lengths">+ Tambah Panjang</button>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="languages" class="w-4 h-4"></i></span><div><h2>Bahasa</h2><p>Tambah bahasa baru dan instruksi outputnya.</p></div></div>
                <div id="heCustomLanguages" class="he-custom-list"></div>
                <button type="button" class="button button-secondary" data-add="languages">+ Tambah Bahasa</button>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="users" class="w-4 h-4"></i></span><div><h2>Penulis & Editor</h2><p>Satu nama per baris untuk dropdown Penulis dan Editor.</p></div></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label class="he-prompt-field"><span>Penulis <button type="button" class="button button-small he-sync-wp-users" data-target="heCustomAuthors" data-users="authors">Import/Sync WP</button></span><textarea id="heCustomAuthors" name="<?php echo esc_attr( $option_name ); ?>[authors]" class="large-text he-key-textarea" rows="8"></textarea></label>
                    <label class="he-prompt-field"><span>Editor <button type="button" class="button button-small he-sync-wp-users" data-target="heCustomEditors" data-users="editors">Import/Sync WP</button></span><textarea id="heCustomEditors" name="<?php echo esc_attr( $option_name ); ?>[editors]" class="large-text he-key-textarea" rows="8"></textarea></label>
                </div>
            </section>

            <section class="he-settings-card">
                <div class="he-card-heading compact"><span class="he-card-icon"><i data-lucide="file-json" class="w-4 h-4"></i></span><div><h2>Export / Import JSON</h2><p>Gunakan untuk menyalin pengaturan ke subdomain lain.</p></div></div>
                <textarea id="heCustomImport" class="large-text he-json-import" placeholder="Paste JSON pengaturan di sini untuk import"></textarea>
                <div class="he-custom-toolbar">
                    <button type="button" class="button button-secondary" id="heExportSettings">Export JSON</button>
                    <button type="button" class="button button-secondary" id="heImportSettings">Import JSON</button>
                    <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=heaj_reset_custom_settings' ), 'heaj_reset_custom_settings' ) ); ?>" onclick="return confirm('Kembalikan semua custom settings ke default?')">Reset Default</a>
                    <a class="button button-link-delete he-danger-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=heaj_clear_generate_history' ), 'heaj_clear_generate_history' ) ); ?>" onclick="return confirm('Hapus seluruh riwayat generate? Tindakan ini tidak bisa dibatalkan.')">Hapus Seluruh Riwayat Generate</a>
                </div>
            </section>
        </div>
        <aside class="he-settings-side"><section class="he-settings-card he-sticky-side"><div class="he-card-heading compact"><span class="he-card-icon green"><i data-lucide="save" class="w-4 h-4"></i></span><div><h2>Simpan</h2><p>Perubahan akan langsung mempengaruhi halaman Generator Artikel setelah tombol Simpan diklik.</p><p class="he-custom-save-note">Data kini disimpan sebagai field WordPress native, bukan hanya JSON sementara.</p></div></div><?php submit_button( 'Simpan Custom Settings', 'primary large', 'submit', false, [ 'class' => 'button button-primary button-large he-save-button' ] ); ?></section></aside>
    </form>
</div>
<script>
(function(){
    const optionName = <?php echo wp_json_encode( HE_Journalist_Pro_Tools::OPTION_CUSTOM_SETTINGS ); ?>;
    const defaults = <?php echo wp_json_encode( HE_Journalist_Pro_Tools::default_custom_settings() ); ?>;
    const wpUsers = { authors: <?php echo wp_json_encode( $wp_author_names ?? [] ); ?>, editors: <?php echo wp_json_encode( $wp_editor_names ?? [] ); ?> };
    let state = <?php echo wp_json_encode( $custom_settings ); ?> || defaults;
    state.branding = Object.assign({}, (defaults.branding || {}), (state.branding || {}));
    const hidden = document.getElementById('heCustomSettingsJson');
    function esc(v){return String(v||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
    function val(id){ const el=document.getElementById(id); return el ? el.value : ''; }
    function setVal(id,v){ const el=document.getElementById(id); if(el) el.value = v || ''; }
    function sync(){
        state.branding = Object.assign({}, state.branding || {}, {
            brand_name: val('heBrandName'), media_name: val('heMediaName'), organization: val('heOrganization'), logo_url: val('heLogoUrl'), primary_color: val('hePrimaryColor') || '#0f172a', license_type: val('heLicenseType') || 'auto', authors_source: val('heAuthorsSource') || 'manual', footer_style: val('heFooterStyle') || 'media', seo_style: val('heSeoStyle') || 'news', brand_voice: val('heBrandVoice'), forbidden_words: val('heForbiddenWords'), warning_text: val('heWarningText'), default_city: val('heDefaultCity')
        });
        state.global_prompt = val('heGlobalPrompt');
        state.authors = document.getElementById('heCustomAuthors').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
        state.editors = document.getElementById('heCustomEditors').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
        if (hidden) hidden.value = JSON.stringify(state);
    }
    function render(){
        state.branding = Object.assign({}, (defaults.branding || {}), (state.branding || {}));
        setVal('heBrandName', state.branding.brand_name); setVal('heMediaName', state.branding.media_name); setVal('heOrganization', state.branding.organization); setVal('heLogoUrl', state.branding.logo_url); setVal('hePrimaryColor', state.branding.primary_color || '#0f172a'); setVal('heGlobalPrompt', state.global_prompt || ''); setVal('heLicenseType', state.branding.license_type || 'auto'); setVal('heAuthorsSource', state.branding.authors_source || 'manual'); setVal('heFooterStyle', state.branding.footer_style || 'media'); setVal('heSeoStyle', state.branding.seo_style || 'news'); setVal('heBrandVoice', state.branding.brand_voice); setVal('heForbiddenWords', state.branding.forbidden_words); setVal('heWarningText', state.branding.warning_text); setVal('heDefaultCity', state.branding.default_city);
        const prompts = document.getElementById('heCustomPrompts');
        prompts.innerHTML = (state.prompts||[]).map((r,i)=>`<div class="he-custom-row" data-type="prompts" data-index="${i}"><input name="${optionName}[prompts][${i}][label]" data-field="label" placeholder="Label" value="${esc(r.label)}"><textarea name="${optionName}[prompts][${i}][prompt]" data-field="prompt" placeholder="Isi prompt. Kosongkan untuk memakai prompt bawaan jika key default.">${esc(r.prompt)}</textarea><button type="button" class="button" data-remove>Hapus</button><input name="${optionName}[prompts][${i}][key]" type="hidden" data-field="key" value="${esc(r.key)}"></div>`).join('');
        const lengths = document.getElementById('heCustomLengths');
        lengths.innerHTML = (state.lengths||[]).map((r,i)=>`<div class="he-custom-row" data-type="lengths" data-index="${i}"><input name="${optionName}[lengths][${i}][label]" data-field="label" placeholder="Label" value="${esc(r.label)}"><input name="${optionName}[lengths][${i}][value]" data-field="value" placeholder="Instruksi panjang" value="${esc(r.value)}"><button type="button" class="button" data-remove>Hapus</button></div>`).join('');
        const langs = document.getElementById('heCustomLanguages');
        langs.innerHTML = (state.languages||[]).map((r,i)=>`<div class="he-custom-row" data-type="languages" data-index="${i}"><input name="${optionName}[languages][${i}][label]" data-field="label" placeholder="Label" value="${esc(r.label)}"><textarea name="${optionName}[languages][${i}][instruction]" data-field="instruction" placeholder="Instruksi bahasa">${esc(r.instruction)}</textarea><button type="button" class="button" data-remove>Hapus</button><input name="${optionName}[languages][${i}][code]" type="hidden" data-field="code" value="${esc(r.code)}"></div>`).join('');
        document.getElementById('heCustomAuthors').value = (state.authors||[]).join('\n');
        document.getElementById('heCustomEditors').value = (state.editors||[]).join('\n');
        sync(); if(window.HEAJRenderIcons) window.HEAJRenderIcons();
    }
    function slug(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,40) || ('custom_'+Date.now());}
    document.addEventListener('input', function(e){
        const row=e.target.closest('.he-custom-row'); if(!row) { if(e.target.closest('.he-brand-grid') || e.target.id==='heCustomAuthors'||e.target.id==='heCustomEditors') sync(); return; }
        const type=row.dataset.type, idx=parseInt(row.dataset.index,10), field=e.target.dataset.field;
        if(!state[type]||!state[type][idx]||!field) return;
        state[type][idx][field]=e.target.value;
        if(type==='prompts' && field==='label' && !state[type][idx].key) state[type][idx].key=slug(e.target.value);
        if(type==='languages' && field==='label' && !state[type][idx].code) state[type][idx].code=slug(e.target.value).slice(0,8);
        sync();
    });
    document.addEventListener('click', function(e){
        const syncBtn=e.target.closest('.he-sync-wp-users');
        if(syncBtn){ const target=document.getElementById(syncBtn.dataset.target); const list=wpUsers[syncBtn.dataset.users]||[]; if(target){ const current=target.value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean); target.value=[...new Set([...current,...list])].join('\n'); sync(); alert('Data WordPress users berhasil disinkronkan.'); } return; }
        const add=e.target.closest('[data-add]');
        if(add){const t=add.dataset.add; state[t]=state[t]||[]; if(t==='prompts')state[t].push({key:'custom_'+Date.now(),label:'Prompt Baru',prompt:''}); if(t==='lengths')state[t].push({label:'Panjang Baru',value:''}); if(t==='languages')state[t].push({code:'lang'+Date.now().toString().slice(-4),label:'Bahasa Baru',instruction:''}); render(); return;}
        const rem=e.target.closest('[data-remove]'); if(rem){const row=rem.closest('.he-custom-row'); state[row.dataset.type].splice(parseInt(row.dataset.index,10),1); render();}
    });
    document.getElementById('heCustomSettingsForm').addEventListener('submit', sync);
    document.getElementById('heExportSettings').addEventListener('click', function(){sync(); document.getElementById('heCustomImport').value=JSON.stringify(state,null,2);});
    function mergeImportedSettings(data){
        const merged = Object.assign({}, defaults, data || {}); merged.branding = Object.assign({}, (defaults.branding || {}), ((data || {}).branding || {}));
        const builtinByKey = {};
        (defaults.prompts || []).forEach(p => { if (p && p.key) builtinByKey[p.key] = p; });
        if (Array.isArray(merged.prompts)) {
            merged.prompts = merged.prompts.map(row => {
                row = Object.assign({}, row || {});
                if (row.key && builtinByKey[row.key] && !String(row.prompt || '').trim()) {
                    row.prompt = builtinByKey[row.key].prompt || '';
                }
                return row;
            });
        }
        return merged;
    }
    document.getElementById('heImportSettings').addEventListener('click', function(){try{const data=JSON.parse(document.getElementById('heCustomImport').value); if(!data||typeof data!=='object') throw new Error('JSON tidak valid'); state=mergeImportedSettings(data); render(); alert('JSON berhasil diimport. Klik Simpan Custom Settings.');}catch(err){alert(err.message||err);}});
    render();
})();
</script>

=== YZG AI Journalist ===
Contributors: yanuarzg
Tags: ai, journalist, gemini, grok, zai, seo, harianexpress
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 5.2.3
License: GPLv2 or later

White-label AI editorial assistant dengan rotasi API, output SEO, audit fakta, gambar sumber/Pexels, gambar sosial media, skrip video, dan pengiriman artikel ke Draft WordPress.

== Fitur Utama ==

* Article Generator berbasis beberapa sumber URL atau teks.
* Korelasi dan sintesis multi-sumber.
* Provider Gemini, Grok/xAI, GroqCloud, Z.AI, dan OpenRouter.
* Rotasi API key, fallback model/provider, retry, dan pemblokiran key bermasalah.
* Audit fakta, pemeriksaan SEO, dan deteksi kemiripan narasi.
* Ekstraksi gambar sumber, Pexels, upload manual, featured image, dan optimasi media.
* Generator gambar sosial media berbasis GD lokal untuk Instagram, Pinterest, dan LinkedIn.
* Pembuatan Draft WordPress beserta kategori, tag, excerpt, author, dan metadata SEO.
* Riwayat generate, pengaturan white-label, lisensi, dan updater.
* Shortcut Article Generator pada WordPress Admin Bar.

== Optional secure secret configuration ==

Credential dapat ditempatkan di wp-config.php atau environment variable agar tidak bergantung pada database WordPress. Nilai eksternal diprioritaskan, sedangkan nilai halaman Settings tetap menjadi fallback. Untuk beberapa key, gunakan satu key per baris atau array PHP.

Supported names:
* HE_JOURNALIST_GEMINI_API_KEY
* HE_JOURNALIST_GEMINI_EXTRA_API_KEYS
* HE_JOURNALIST_GROK_API_KEYS
* HE_JOURNALIST_GROQ_API_KEYS
* HE_JOURNALIST_ZAI_API_KEYS
* HE_JOURNALIST_OPENROUTER_API_KEYS
* HE_JOURNALIST_PEXELS_API_KEY
* HE_JOURNALIST_LICENSE_KEY

== Changelog ==

= 5.2.3 =
* Mengubah tombol Copy pada Quick Summary dan Video Script menjadi tombol ikon saja, lengkap dengan title dan aria-label.
* Menghapus halaman HE Network dari menu WordPress, renderer, asset loader, template, JavaScript, selector administrasi, terjemahan, dan CSS plugin.
* Memindahkan fungsi direktori HE Network ke berkas HTML mandiri dengan CSS dan JavaScript tersemat dalam satu file.

= 5.2.2 =
* Minimal LinkedIn kini memakai layout horizontal: teks di kiri dan gambar di kanan.
* Gradient LinkedIn kini memakai layout horizontal: glass panel dan teks di kiri, gambar di kanan.
* Minimal Instagram dan Pinterest kini memakai komposisi terbalik dengan seluruh copy serta footer branding di atas dan gambar di bawah.
* Menghapus label engine GD dari metadata kartu hasil Social Media Image; metadata desain dan ukuran file tetap ditampilkan.
* Quick Summary, Social Draft, dan Video Script kini menerapkan aturan bahasa mutlak di browser dan server berdasarkan pilihan Bahasa di Content Settings, termasuk bahasa kustom.
* Menambahkan tombol ikon regenerate pada panel Quick Summary, Social Draft, dan Video Script, lengkap dengan busy state bersama tombol utama.

= 5.2.1 =
* Gradient: menghapus garis merah di sisi badge kategori tanpa mengubah alignment kategori dan subkategori.
* Minimal: menghapus seluruh garis merah dekoratif pada kanvas; badge kategori solid dan titik domain tetap dipertahankan sebagai elemen non-garis.
* Bold: menghapus seluruh surface, shade, overlay, dan gradient yang berasal dari warna merah; bidang transisi kini memakai navy netral dan foto tetap tanpa tint.
* Menyesuaikan thumbnail pemilih desain agar mencerminkan komposisi terbaru.
* Mempertahankan Editorial, GD-only, anti-overflow, safe area, line-height judul yang telah ditetapkan, dan line-height deskripsi 1.75.

= 5.2.0 =
* Minimal: menghapus scrim global, gradient atas, frame rounded, dan garis footer; mengganti area bawah menjadi bidang navy solid.
* Minimal: mengganti badge kategori menjadi kotak solid dengan padding 5px 8px, memusatkan subkategori secara vertikal, dan menaikkan line-height judul menjadi 1.5.
* Editorial: menghapus pola titik dan mempertebal garis geometris footer.
* Bold: menghapus scrim pada foto dan mengganti badge kategori merah menjadi navy.
* Gradient: menghapus scrim global, gradient penuh, border panel, garis merah panel, dan garis merah footer.
* Gradient: menempatkan subkategori di dalam badge dengan alignment vertikal terpusat serta menaikkan line-height judul menjadi 1.5.
* Mempertahankan GD-only, anti-overflow, safe area, regenerasi atomik, dan line-height deskripsi 1.75.

= 5.1.9 =
* Menghapus overlay tint merah dari area foto pada preset Bold untuk Instagram, Pinterest, dan LinkedIn.
* Mengganti gradient merah global pada preset Gradient dengan shading navy netral agar warna asli foto tetap terlihat.
* Mempertahankan warna merah hanya pada badge, garis, bidang geometris, dan aksen branding.
* Menyesuaikan opacity scrim netral agar foto lebih terang tanpa mengurangi keterbacaan teks dan glass panel.
* Mempertahankan Editorial versi newsroom gelap, GD-only, anti-overflow, safe area, dan line-height deskripsi 1.75.

= 5.1.8 =
* Mengembalikan preset Editorial ke layout newsroom gelap versi 5.1.6 sesuai preferensi pengguna.
* Memperbaiki artefak sudut berlapis pada badge, glass panel, dan chip logo dengan compositing alpha satu lapis.
* Menghentikan frame Minimal sebelum footer agar garis tidak bertabrakan dengan logo dan area branding.
* Merapikan ornament Bold, mengurangi tint merah pada foto, dan mengganti badge kategori putih dengan aksen brand.
* Menghapus lingkaran besar yang memotong panel Gradient, mengecilkan ornament atas, dan menyesuaikan tinggi panel terhadap kapasitas teks.
* Mengecilkan serta memusatkan logo footer dengan safe area yang konsisten pada semua platform.
* Mempertahankan GD-only, anti-overflow, safe area, dan line-height deskripsi 1.75.

= 5.1.7 =
* Mendesain ulang empat preset Social Media Image agar memiliki komposisi visual yang benar-benar berbeda.
* Minimal kini memakai full-bleed photo, frame tipis, scrim sinematik, dan whitespace yang lebih terkontrol.
* Editorial kini memakai layout bergaya sampul majalah dengan permukaan paper, headline gelap, dan treatment foto terpisah.
* Bold kini memakai komposisi diagonal, warna berkontras tinggi, serta aksen geometris yang lebih dinamis.
* Gradient kini memakai glass panel membulat, shadow lembut, border transparan, dan elemen dekoratif sinematik.
* Memperbaiki hierarki tipografi, casing judul, badge kategori, footer branding, serta jumlah baris deskripsi.
* Mempertahankan line-height deskripsi 1.75, safe area, anti-overflow, GD-only, dan regenerasi atomik.

= 5.1.6 =
* Menambahkan empat preset desain GD lokal: Minimal, Editorial, Bold, dan Gradient.
* Menambahkan panel pilihan desain dengan thumbnail, navigasi keyboard, status aktif, serta penyimpanan preferensi pada browser dan profil pengguna setelah generate.
* Tombol Image Sosmed kini membuka panel desain terlebih dahulu sehingga pengguna dapat memilih preset sebelum proses render dimulai.
* Pergantian preset setelah image dibuat akan membuat ulang seluruh ukuran dan mengganti file lama secara aman tanpa menambah duplikat.
* Menambahkan identitas preset pada kartu hasil, nama file, status proses, dan respons backend.
* Mempertahankan anti-overflow, safe area, line-height deskripsi 1.75, serta tombol ikon Buka dan Download pada semua preset.

= 5.1.5 =
* Menambahkan sistem anti-overflow GD yang menyesuaikan ukuran font, jumlah baris, dan ellipsis berdasarkan tinggi area teks yang tersedia.
* Memperkuat pembungkusan kata panjang, safe area, kategori, subkategori, dan alamat situs agar tidak keluar dari kanvas.
* Menjaga kontras warna aksen terhadap teks putih agar label tetap mudah dibaca.
* Menambahkan tombol ikon Buat Ulang pada setiap kartu Social Media Image yang berhasil dibuat.
* Proses Buat Ulang mengganti file tervalidasi yang sama secara atomik dan memakai revision cache-busting agar tidak menumpuk file duplikat.
* Memperkuat footer kartu, tooltip, fokus keyboard, dan perilaku responsif tombol aksi.

= 5.1.4 =
* Merapikan footer kartu Social Media Image agar metadata dan tombol aksi tidak berhimpitan pada lebar kartu sempit.
* Mengubah tombol Buka dan Download menjadi tombol ikon saja, lengkap dengan label aksesibilitas dan tooltip.
* Meningkatkan line-height paragraf deskripsi menjadi 1.75 untuk Instagram, Pinterest, dan LinkedIn.

= 5.1.3 =
* Social Media Image kini hanya memakai GD lokal tanpa Gemini, provider AI, API key image, model image, reference template, atau copy prompt.
* Menghapus pengaturan dan payload lama yang terkait AI/Gemini khusus fitur Social Media Image.
* Memperlebar line-height paragraf deskripsi menjadi 1.55 untuk LinkedIn dan 1.60 untuk Instagram/Pinterest.

= 5.1.2 =
* Removed per-card Regenerate and custom AI command controls from Social Media Image previews.
* Kept independent per-platform generation, retry-on-error, validated files, and GD fallback behavior.
* Doubled the extra inter-line spacing used for GD fallback description text on all three social image formats.

= 5.1.1 =
* Added independent Instagram, Pinterest, and LinkedIn generation jobs so one failure does not hide successful previews.
* Added per-card Regenerate and custom AI edit commands using the current preview as the image reference.
* Added validated asset tokens for secure preview-based regeneration.
* Reworked preview cards with consistent canvas height, loading, error, retry, and broken-image states.
* Fixed unsafe temporary PNG replacement, output validation, duplicate GD cleanup, and cache-busting URLs.

= 5.1.0 =
* Removed the legacy scheduled article publishing module, including its menu, page template, cron jobs, queue, REST endpoints, AJAX handlers, feed collectors, automatic post creator, logs, settings, and integration callbacks.
* Retained the manual Article Generator, provider integrations, source extraction, media tools, social images, history, license, and updater features.

= 5.0.9 =
* Added SSRF protection for arbitrary article, image, provider, license, and updater URLs using the WordPress safe HTTP API.
* Enforced TLS verification and removed insecure HTTPS-to-HTTP image downgrade behavior.
* Added response/download size limits, streamed media downloads, MIME checks, and image pixel limits.
* Gemini API keys are sent through the x-goog-api-key header instead of URL query strings.
* Added wp-config.php/environment secret overrides for AI, Pexels, and license credentials.
* Cached and validated the update manifest; update packages support optional SHA-256 verification.

= 5.0.8 =
* Added a WordPress Admin Bar shortcut that opens the Article Generator for users with edit_posts capability.

= 5.0.7 =
* Article Generator labels multiple extracted URLs as SUMBER 1/2/3 with domain and title metadata.
* Added multi-source correlation rules so the angle is chosen by news value, overlap, and evidence rather than URL order.
* Improved synthesis rules for conflicting or complementary sources.

<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div id="he-subdomains-app" class="heaj-wrap he-directory-page text-slate-800 antialiased min-h-screen">
    <header class="he-directory-hero">
        <div class="he-directory-hero-bg"></div>
        <div class="he-directory-hero-inner">
            <div class="he-directory-title-group">
                <div class="he-directory-icon"><i data-lucide="network" class="w-7 h-7"></i></div>
                <div>
                    <p class="he-kicker">HarianExpress Network</p>
                    <h1>Semua Subdomain</h1>
                    <p>Directory A-Z network subdomain HarianExpress. Gunakan pintasan Login, Dashboard, atau Tools sesuai akses admin masing-masing.</p>
                </div>
            </div>
            <div class="he-directory-stats">
                <div><strong id="heSubdomainCount">0</strong><span>Subdomain</span></div>
                <div><strong id="heSubdomainGroupCount">0</strong><span>Grup</span></div>
            </div>
        </div>
    </header>

    <section class="he-directory-panel">
        <div class="he-directory-toolbar">
            <div class="he-search-control">
                <i data-lucide="search" class="w-4 h-4"></i>
                <input id="heSubdomainSearch" type="search" placeholder="Cari subdomain, contoh: tekno, bali, humaniora...">
            </div>
            <div class="he-toolbar-selects">
                <select id="heSubdomainGroupFilter"><option value="all">Grup: all</option></select>
                <select id="heSubdomainSort">
                    <option value="az">Sortir: A-Z</option>
                    <option value="latest_desc">Sortir: paling update</option>
                    <option value="latest_asc">Sortir: paling lama update</option>
                    <option value="total_desc">Sortir: artikel terbanyak</option>
                    <option value="total_asc">Sortir: artikel tersedikit</option>
                </select>
            </div>
            <div class="he-toolbar-actions">
                <button type="button" id="heSubdomainReset" class="he-dark-btn"><i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> Refresh</button>
                <a href="https://wa.me/6289507785333" target="_blank" rel="noopener" class="he-green-btn"><i data-lucide="plus-circle" class="w-3.5 h-3.5"></i> +domain</a>
            </div>
        </div>
        <div id="heAlphabetNav" class="he-alphabet-nav"></div>

        <div id="heSubdomainStatus" class="hidden he-directory-status"></div>
        <div id="heSubdomainDirectory" class="he-directory-list"></div>
    </section>

    <footer class="he-directory-footer">
        <span>Login tetap mengikuti hak akses admin di masing-masing subdomain.</span>
        <span>&copy; 2026 <a href="https://yanuarzg.github.io/" target="_blank" rel="noopener">YZG</a></span>
    </footer>
</div>

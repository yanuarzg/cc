<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="he-history-app" class="heaj-wrap he-history-wrap">
    <section class="he-history-hero">
        <div>
            <h1>Riwayat Generate</h1>
            <p>Catatan artikel yang digenerate dan draft yang dibuat oleh plugin di domain ini.</p>
        </div>
        <div class="he-history-count"><strong><?php echo esc_html( isset( $total_history ) ? $total_history : count( $history ) ); ?></strong><span>aktivitas</span></div>
    </section>

    <?php if ( empty( $history ) ) : ?>
        <div class="he-history-empty">
            <i data-lucide="clock-3" class="w-8 h-8"></i>
            <strong>Belum ada riwayat.</strong>
            <span>Riwayat akan terisi setelah generate artikel atau kirim draft.</span>
        </div>
    <?php else : ?>
        <div class="he-history-list">
            <?php foreach ( $history as $item ) : ?>
                <?php
                    $status = $item['status'] ?? 'generated';
                    $title = $item['title'] ?? '(Tanpa judul)';
                    $time = $item['time'] ?? '';
                    $provider = $item['provider'] ?? '';
                    $sources = [];
                    if ( ! empty( $item['source_urls'] ) && is_array( $item['source_urls'] ) ) { $sources = $item['source_urls']; }
                    elseif ( ! empty( $item['source_url'] ) ) { $sources = [ $item['source_url'] ]; }
                    $edit = $item['edit_url'] ?? '';
                    $linked_edit = $item['linked_edit_url'] ?? '';
                    $user = $item['user'] ?? '';
                    $draft_status = $item['draft_status'] ?? ( $status === 'draft_created' ? 'sent' : 'not_sent' );
                    $draft_badge = $status === 'draft_created' ? 'Draft dibuat' : ( $draft_status === 'sent' ? 'Dilanjutkan ke Draft' : 'Belum ke Draft' );
                    $draft_class = $status === 'draft_created' || $draft_status === 'sent' ? 'is-sent' : 'is-not-sent';
                ?>
                <article class="he-history-item is-<?php echo esc_attr( $status ); ?>">
                    <div class="he-history-main">
                        <div class="he-history-badges">
                            <span class="he-history-status"><?php echo esc_html( $status === 'draft_created' ? 'Draft' : 'Generate' ); ?></span>
                            <span class="he-history-draft <?php echo esc_attr( $draft_class ); ?>"><?php echo esc_html( $draft_badge ); ?></span>
                        </div>
                        <h2><?php echo esc_html( $title ); ?></h2>
                        <p>
                            <span><?php echo esc_html( $time ); ?></span>
                            <?php if ( $provider ) : ?><span><?php echo esc_html( strtoupper( $provider ) ); ?></span><?php endif; ?>
                            <?php if ( $user ) : ?><span><?php echo esc_html( $user ); ?></span><?php endif; ?>
                        </p>
                        <?php if ( ! empty( $sources ) ) : ?>
                            <div class="he-history-sources">
                                <?php foreach ( $sources as $source ) : ?>
                                    <a href="<?php echo esc_url( $source ); ?>" target="_blank" rel="noopener" class="he-history-source"><?php echo esc_html( $source ); ?></a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="he-history-actions">
                        <?php if ( $edit ) : ?>
                            <a href="<?php echo esc_url( $edit ); ?>" target="_blank" rel="noopener" class="button button-primary">Edit Draft</a>
                        <?php elseif ( $linked_edit ) : ?>
                            <a href="<?php echo esc_url( $linked_edit ); ?>" target="_blank" rel="noopener" class="button button-secondary">Lihat Draft</a>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php if ( isset( $total_pages ) && $total_pages > 1 ) : ?>
            <div class="he-history-pagination">
                <?php
                    echo paginate_links( [
                        'base'      => add_query_arg( 'paged', '%#%' ),
                        'format'    => '',
                        'current'   => isset( $paged ) ? $paged : 1,
                        'total'     => $total_pages,
                        'prev_text' => '‹',
                        'next_text' => '›',
                    ] );
                ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php
/**
 * Plugin Name: HarianExpress AI Journalist Pro Tools
 * Plugin URI:  https://harianexpress.com
 * Description: AI Journalist Generator untuk HarianExpress. Generator tampil di sidebar admin, mendukung rotasi Gemini API Key, SEO metadata, draft sosmed, skrip video, dan kirim artikel ke Draft WordPress.
 * Version:     3.3.10
 * Author:      YZG / HarianExpress Redaksi
 * Author URI:  https://yanuarzg.github.io/
 * License:     GPL v2 or later
 * Text Domain: he-journalist
 * Update URI:  https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class HE_Journalist_Pro_Tools {
    const VERSION = '3.3.10';
    const LICENSE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/licenses.json';
    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json';
    const UPDATE_INFO_URL = 'https://github.com/yanuarzg/cc/tree/main/he/pl/';
    const OPTION_API_KEY = 'he_journalist_gemini_api_key';
    const OPTION_EXTRA_API_KEYS = 'he_journalist_gemini_extra_api_keys';
    const OPTION_BLOCKED_API_KEYS = 'he_journalist_blocked_api_keys';
    const OPTION_MODEL = 'he_journalist_gemini_model';
    const OPTION_GROK_API_KEYS = 'he_journalist_grok_api_keys';
    const OPTION_GROQ_API_KEYS = 'he_journalist_groq_api_keys';
    const OPTION_ZAI_API_KEYS = 'he_journalist_zai_api_keys';
    const OPTION_HISTORY = 'he_journalist_history';
    const OPTION_PROMPT_OVERRIDES = 'he_journalist_prompt_overrides';
    const NONCE_ACTION = 'he_journalist_nonce';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_init', [ $this, 'enforce_license_domain' ], 1 );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_post_heaj_reset_blocked_api_keys', [ $this, 'handle_reset_blocked_api_keys' ] );
        add_action( 'admin_post_heaj_check_updates_now', [ $this, 'handle_check_updates_now' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
        add_action( 'wp_ajax_heaj_generate_content', [ $this, 'ajax_generate_content' ] );
        add_action( 'wp_ajax_he_create_draft', [ $this, 'ajax_create_draft' ] );
        add_action( 'wp_ajax_heaj_fetch_source_images', [ $this, 'ajax_fetch_source_images' ] );
        add_action( 'wp_ajax_heaj_test_provider_keys', [ $this, 'ajax_test_provider_keys' ] );
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_update_info' ], 10, 3 );
        register_activation_hook( __FILE__, [ __CLASS__, 'activate' ] );
    }


    private function normalize_host( $host ) {
        $host = strtolower( trim( (string) $host ) );
        $host = preg_replace( '#:\\d+$#', '', $host );
        $host = preg_replace( '#^www\\.#', 'www.', $host );
        return $host;
    }

    private function builtin_license_domains() {
        return [
            'geky.page.gd',
            'harianexpress.com',
            'www.harianexpress.com',
            '*.harianexpress.com',
            'harianexpress.id',
            'www.harianexpress.id',
            '*.harianexpress.id',
        ];
    }

    private function get_remote_license_domains() {
        $cache_key = 'he_journalist_license_domains_v1';
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $domains = [];
        $response = wp_remote_get( self::LICENSE_JSON_URL, [
            'timeout' => 10,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( ! is_wp_error( $response ) ) {
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code >= 200 && $code < 300 ) {
                $data = json_decode( wp_remote_retrieve_body( $response ), true );
                if ( is_array( $data ) ) {
                    if ( isset( $data['domains'] ) && is_array( $data['domains'] ) ) {
                        $domains = array_merge( $domains, $data['domains'] );
                    }
                    if ( isset( $data['allowed_domains'] ) && is_array( $data['allowed_domains'] ) ) {
                        $domains = array_merge( $domains, $data['allowed_domains'] );
                    }
                }
            }
        }

        $domains = array_values( array_unique( array_filter( array_map( function( $domain ) {
            $domain = strtolower( trim( (string) $domain ) );
            $domain = preg_replace( '#^https?://#', '', $domain );
            $domain = preg_replace( '#/.*$#', '', $domain );
            $domain = preg_replace( '#:\d+$#', '', $domain );
            return $domain;
        }, $domains ) ) ) );

        set_transient( $cache_key, $domains, 30 * MINUTE_IN_SECONDS );
        return $domains;
    }

    private function domain_rule_matches( $host, $rule ) {
        $host = $this->normalize_host( $host );
        $rule = strtolower( trim( (string) $rule ) );
        $rule = preg_replace( '#^https?://#', '', $rule );
        $rule = preg_replace( '#/.*$#', '', $rule );
        $rule = preg_replace( '#:\d+$#', '', $rule );

        if ( $host === '' || $rule === '' ) { return false; }
        if ( $host === $rule ) { return true; }

        if ( strpos( $rule, '*.' ) === 0 ) {
            $suffix = substr( $rule, 2 );
            return $host === $suffix || substr( $host, -strlen( '.' . $suffix ) ) === '.' . $suffix;
        }

        return false;
    }

    private function is_allowed_license_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }

        $rules = array_merge( $this->builtin_license_domains(), $this->get_remote_license_domains() );
        foreach ( $rules as $rule ) {
            if ( $this->domain_rule_matches( $host, $rule ) ) {
                return true;
            }
        }

        return false;
    }

    private function is_harianexpress_com_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }
        return $host === 'harianexpress.com' || substr( $host, -strlen( '.harianexpress.com' ) ) === '.harianexpress.com';
    }

    public function enforce_license_domain() {
        if ( ! is_admin() || wp_doing_ajax() || wp_doing_cron() ) { return; }
        if ( $this->is_allowed_license_domain() ) { return; }

        wp_redirect( 'https://yanuarzg.github.io/' );
        exit;
    }

    private function reject_if_unlicensed_ajax() {
        if ( $this->is_allowed_license_domain() ) { return; }
        wp_send_json_error( [
            'message'      => 'Plugin hanya dapat dipakai pada domain yang memiliki lisensi aktif.',
            'redirect_url' => 'https://yanuarzg.github.io/',
        ], 403 );
    }

    public static function activate() {
        if ( ! get_option( self::OPTION_MODEL ) ) {
            add_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        }
        if ( false === get_option( self::OPTION_API_KEY, false ) ) {
            add_option( self::OPTION_API_KEY, '' );
        }
        if ( false === get_option( self::OPTION_EXTRA_API_KEYS, false ) ) {
            add_option( self::OPTION_EXTRA_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_BLOCKED_API_KEYS, false ) ) {
            add_option( self::OPTION_BLOCKED_API_KEYS, [] );
        }
        if ( false === get_option( self::OPTION_GROK_API_KEYS, false ) ) {
            add_option( self::OPTION_GROK_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_GROQ_API_KEYS, false ) ) {
            add_option( self::OPTION_GROQ_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_ZAI_API_KEYS, false ) ) {
            add_option( self::OPTION_ZAI_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_HISTORY, false ) ) {
            add_option( self::OPTION_HISTORY, [] );
        }
        if ( false === get_option( self::OPTION_PROMPT_OVERRIDES, false ) ) {
            add_option( self::OPTION_PROMPT_OVERRIDES, [] );
        }
    }

    private function plugin_dir() { return plugin_dir_path( __FILE__ ); }
    private function plugin_url() { return plugin_dir_url( __FILE__ ); }

    private function default_api_keys() {
        return [];
    }



    private function default_grok_api_keys() {
        return [];
    }

    private function default_groqcloud_api_keys() {
        return [];
    }

    private function default_zai_api_keys() {
        return [];
    }

    private function parse_api_keys_option( $option_name ) {
        $raw = get_option( $option_name, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_unique( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) ) );
    }

    private function filter_unblocked_api_keys( array $keys, $include_blocked = false ) {
        $keys = array_values( array_unique( array_filter( array_map( 'trim', $keys ) ) ) );
        if ( $include_blocked ) { return $keys; }
        return array_values( array_filter( $keys, function( $key ) {
            return ! $this->is_api_key_blocked( $key );
        } ) );
    }

    private function get_grok_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_grok_api_keys(), $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ) ), $include_blocked );
    }

    private function get_groqcloud_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_groqcloud_api_keys(), $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ) ), $include_blocked );
    }

    private function get_zai_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_zai_api_keys(), $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ) ), $include_blocked );
    }

    private function get_provider_key_status_rows() {
        $groups = [
            'Gemini' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_api_keys(), array_keys( $this->default_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->get_extra_api_keys(), array_keys( $this->get_extra_api_keys() ) )
            ),
            'Grok / xAI' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_grok_api_keys(), array_keys( $this->default_grok_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ) ) )
            ),
            'Groq' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_groqcloud_api_keys(), array_keys( $this->default_groqcloud_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ) ) )
            ),
            'Z.AI' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_zai_api_keys(), array_keys( $this->default_zai_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ) ) )
            ),
        ];

        $rows = [];
        $blocked = $this->get_blocked_api_keys();
        foreach ( $groups as $provider => $items ) {
            $seen = [];
            $order = 1;
            foreach ( $items as $item ) {
                $key = trim( (string) ( $item['key'] ?? '' ) );
                if ( $key === '' ) { continue; }
                $hash = $this->api_key_hash( $key );
                if ( isset( $seen[ $hash ] ) ) { continue; }
                $seen[ $hash ] = true;
                $rows[] = [
                    'provider'   => $provider,
                    'order'      => $order++,
                    'label'      => $item['label'],
                    'masked'     => $this->mask_api_key( $key ),
                    'blocked'    => isset( $blocked[ $hash ] ),
                    'block_info' => $blocked[ $hash ] ?? null,
                ];
            }
        }
        return $rows;
    }

    private function get_available_ai_providers() {
        return [
            'gemini' => count( $this->get_api_key_pool( false ) ),
            'grok'      => count( $this->get_grok_api_keys() ),
            'groqcloud' => count( $this->get_groqcloud_api_keys() ),
            'zai'       => count( $this->get_zai_api_keys() ),
        ];
    }

    public static function supported_models() {
        return [
            'gemini-2.5-flash' => 'Gemini 2.5 Flash — default stabil, cepat, cocok untuk artikel harian',
            'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash-Lite — lebih ringan dan ekonomis',
            'gemini-2.5-pro' => 'Gemini 2.5 Pro — reasoning lebih kuat untuk artikel panjang/kompleks',
            'gemini-3.1-flash-lite-preview' => 'Gemini 3.1 Flash-Lite Preview — preview, cepat dan ringan',
        ];
    }

    public function sanitize_api_keys_textarea( $value ) {
        $value = is_string( $value ) ? wp_unslash( $value ) : '';
        $lines = preg_split( '/\r\n|\r|\n/', $value );
        $keys = [];
        foreach ( $lines as $line ) {
            $key = trim( $line );
            if ( $key !== '' ) { $keys[] = sanitize_text_field( $key ); }
        }
        return implode( "\n", array_values( array_unique( $keys ) ) );
    }



    public function sanitize_prompt_overrides( $value ) {
        $value = is_array( $value ) ? $value : [];
        $allowed = [ 'default', 'straight_news', 'jurnalis_heading', 'seo_artikel', 'global' ];
        $clean = [];
        foreach ( $allowed as $key ) {
            $raw = isset( $value[ $key ] ) ? wp_unslash( $value[ $key ] ) : '';
            $raw = is_string( $raw ) ? trim( $raw ) : '';
            if ( $raw !== '' ) {
                $clean[ $key ] = sanitize_textarea_field( $raw );
            }
        }
        return $clean;
    }

    private function get_prompt_overrides() {
        $value = get_option( self::OPTION_PROMPT_OVERRIDES, [] );
        return is_array( $value ) ? $value : [];
    }

    private function add_history_event( array $event ) {
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { $history = []; }
        $defaults = [
            'time'       => current_time( 'mysql' ),
            'user_id'    => get_current_user_id(),
            'user'       => wp_get_current_user()->display_name ?: wp_get_current_user()->user_login,
            'domain'     => wp_parse_url( home_url(), PHP_URL_HOST ),
            'id'         => 'heh_' . wp_generate_uuid4(),
            'title'      => '',
            'source_url' => '',
            'source_urls'=> [],
            'draft_status' => 'not_sent',
            'provider'   => '',
            'status'     => 'generated',
            'post_id'    => 0,
            'edit_url'   => '',
        ];
        $event = array_merge( $defaults, $event );
        $event['id'] = sanitize_key( $event['id'] );
        $event['title'] = sanitize_text_field( $event['title'] );
        $event['source_url'] = esc_url_raw( $event['source_url'] );
        $event['source_urls'] = isset( $event['source_urls'] ) && is_array( $event['source_urls'] ) ? array_values( array_unique( array_filter( array_map( 'esc_url_raw', $event['source_urls'] ) ) ) ) : [];
        $event['draft_status'] = sanitize_key( $event['draft_status'] );
        $event['provider'] = sanitize_text_field( $event['provider'] );
        $event['status'] = sanitize_text_field( $event['status'] );
        $event['post_id'] = absint( $event['post_id'] );
        $event['edit_url'] = esc_url_raw( $event['edit_url'] );
        array_unshift( $history, $event );
        $history = array_slice( $history, 0, 150 );
        update_option( self::OPTION_HISTORY, $history, false );
        return $event['id'];
    }

    private function update_history_generated_to_draft( $history_id, $post_id, $edit_url ) {
        $history_id = sanitize_key( $history_id );
        if ( ! $history_id ) { return; }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { return; }
        foreach ( $history as &$item ) {
            if ( isset( $item['id'] ) && $item['id'] === $history_id ) {
                $item['draft_status'] = 'sent';
                $item['linked_post_id'] = absint( $post_id );
                $item['linked_edit_url'] = esc_url_raw( $edit_url );
                break;
            }
        }
        unset( $item );
        update_option( self::OPTION_HISTORY, $history, false );
    }

    public function handle_check_updates_now() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_check_updates_now' );
        delete_site_transient( 'update_plugins' );
        wp_clean_plugins_cache( true );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-settings', 'heaj-update-check' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    private function get_extra_api_keys() {
        $raw = get_option( self::OPTION_EXTRA_API_KEYS, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) );
    }

    private function api_key_hash( $key ) {
        return hash_hmac( 'sha256', (string) $key, wp_salt( 'auth' ) );
    }

    private function get_blocked_api_keys() {
        $blocked = get_option( self::OPTION_BLOCKED_API_KEYS, [] );
        return is_array( $blocked ) ? $blocked : [];
    }

    private function is_api_key_blocked( $key ) {
        $hash = $this->api_key_hash( $key );
        $blocked = $this->get_blocked_api_keys();
        return isset( $blocked[ $hash ] );
    }

    private function block_api_key( $key, $reason = '' ) {
        $key = trim( (string) $key );
        if ( $key === '' ) { return; }
        $hash = $this->api_key_hash( $key );
        $blocked = $this->get_blocked_api_keys();
        $blocked[ $hash ] = [
            'masked'     => $this->mask_api_key( $key ),
            'reason'     => sanitize_text_field( $reason ?: 'API key ditolak permanen oleh provider AI.' ),
            'blocked_at' => current_time( 'mysql' ),
        ];
        update_option( self::OPTION_BLOCKED_API_KEYS, $blocked, false );
    }

    private function get_api_key_pool( $include_blocked = false ) {
        $items = [];

        foreach ( $this->default_api_keys() as $i => $key ) {
            $items[] = [ 'key' => trim( $key ), 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ];
        }
        foreach ( $this->get_extra_api_keys() as $i => $key ) {
            $items[] = [ 'key' => trim( $key ), 'label' => 'API Tambahan #' . ( $i + 1 ), 'source' => 'extra' ];
        }

        $unique = [];
        $pool = [];
        $blocked = $this->get_blocked_api_keys();
        foreach ( $items as $item ) {
            if ( empty( $item['key'] ) ) { continue; }
            $hash = $this->api_key_hash( $item['key'] );
            if ( isset( $unique[ $hash ] ) ) { continue; }
            $unique[ $hash ] = true;
            $item['hash'] = $hash;
            $item['masked'] = $this->mask_api_key( $item['key'] );
            $item['blocked'] = isset( $blocked[ $hash ] );
            $item['block_info'] = $blocked[ $hash ] ?? null;
            if ( $include_blocked || ! $item['blocked'] ) {
                $pool[] = $item;
            }
        }
        return $pool;
    }

    private function get_all_api_keys() {
        return array_values( array_map( function( $item ) { return $item['key']; }, $this->get_api_key_pool( false ) ) );
    }

    public function handle_reset_blocked_api_keys() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_reset_blocked_api_keys' );
        update_option( self::OPTION_BLOCKED_API_KEYS, [], false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-settings', 'heaj-blocked-reset' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    private function extract_json_from_text( $text ) {
        $text = trim( (string) $text );
        if ( $text === '' ) { return null; }

        $direct = json_decode( $text, true );
        if ( is_array( $direct ) ) { return $direct; }

        if ( preg_match( '/```(?:json)?\s*(\{.*?\})\s*```/s', $text, $matches ) ) {
            $decoded = json_decode( trim( $matches[1] ), true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        $start = strpos( $text, '{' );
        $end   = strrpos( $text, '}' );
        if ( $start !== false && $end !== false && $end > $start ) {
            $candidate = substr( $text, $start, $end - $start + 1 );
            $decoded = json_decode( $candidate, true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        return null;
    }


    private function normalize_model_name( $model ) {
        $model = trim( (string) $model );
        $deprecated = [
            '',
            'gemini-2.5-flash-preview-09-2025',
            'models/gemini-2.5-flash-preview-09-2025',
            'gemini-2.0-flash',
            'models/gemini-2.0-flash',
        ];
        if ( in_array( $model, $deprecated, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        $model = preg_replace( '#^models/#', '', $model );
        $model = sanitize_text_field( $model );
        $supported = array_keys( self::supported_models() );
        if ( ! in_array( $model, $supported, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        return $model;
    }


    private function is_retryable_gemini_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) {
            return true;
        }

        $retryable_phrases = [
            'high demand',
            'overloaded',
            'temporarily unavailable',
            'try again later',
            'resource exhausted',
            'quota',
            'rate limit',
            'deadline',
            'timeout',
            'timed out',
            'internal error',
            'service unavailable',
        ];

        foreach ( $retryable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return false;
    }


    private function is_blockable_gemini_api_key_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        $blockable_phrases = [
            'api key was reported as leaked',
            'reported as leaked',
            'please use another api key',
            'api key not valid',
            'api_key_invalid',
            'invalid api key',
            'permission_denied',
            'api key expired',
            'api key has expired',
            'api key disabled',
            'key disabled',
        ];

        foreach ( $blockable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return in_array( $status, [ 400, 401, 403 ], true ) && false !== strpos( $message, 'api key' );
    }

    private function retry_delay_seconds( $round ) {
        $round = max( 1, (int) $round );
        return min( 8, 2 ** $round );
    }

    private function mask_api_key( $key ) {
        $key = (string) $key;
        if ( strlen( $key ) <= 12 ) { return str_repeat( '•', strlen( $key ) ); }
        return substr( $key, 0, 7 ) . str_repeat( '•', max( 6, strlen( $key ) - 14 ) ) . substr( $key, -7 );
    }


    public function sanitize_model_name( $value ) {
        return $this->normalize_model_name( wp_unslash( $value ) );
    }

    public function register_settings() {
        register_setting( 'he_journalist_options', self::OPTION_EXTRA_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GROK_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GROQ_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_ZAI_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_PROMPT_OVERRIDES, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_prompt_overrides' ],
            'default'           => [],
        ] );
        register_setting( 'he_journalist_options', self::OPTION_MODEL, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_model_name' ],
            'default'           => 'gemini-2.5-flash',
        ] );

        $stored_model = get_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        $fixed_model  = $this->normalize_model_name( $stored_model );
        if ( $stored_model !== $fixed_model ) {
            update_option( self::OPTION_MODEL, $fixed_model );
        }
    }

    public function add_menu() {
        add_menu_page(
            'HE AI Journalist',
            'HE Journalist',
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ],
            'dashicons-edit-large',
            30
        );
        add_submenu_page(
            'he-journalist',
            'Generator Artikel',
            'Generator Artikel',
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ]
        );
        if ( $this->is_harianexpress_com_domain() ) {
            add_submenu_page(
                'he-journalist',
                'Semua Subdomain',
                'Semua Subdomain',
                'edit_posts',
                'he-journalist-subdomains',
                [ $this, 'render_subdomains_page' ]
            );
        }
        add_submenu_page(
            'he-journalist',
            'Riwayat Generate',
            'Riwayat Generate',
            'edit_posts',
            'he-journalist-history',
            [ $this, 'render_history_page' ]
        );
        add_submenu_page(
            'he-journalist',
            'Pengaturan API',
            'Pengaturan API',
            'manage_options',
            'he-journalist-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    public function admin_enqueue_assets( $hook ) {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( strpos( $hook, 'he-journalist' ) === false && strpos( $page, 'he-journalist' ) === false ) { return; }

        $this->enqueue_common_assets();

        if ( $page === 'he-journalist' ) {
            $this->enqueue_generator_assets();
        } elseif ( $page === 'he-journalist-subdomains' ) {
            $this->enqueue_subdomains_assets();
        }
    }

    private function enqueue_common_assets() {
        wp_enqueue_script( 'tailwindcss-cdn', 'https://cdn.tailwindcss.com', [], null, false );
        wp_enqueue_style( 'heaj-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Merriweather:wght@400;700&display=swap', [], null );
        wp_enqueue_script( 'lucide-cdn', 'https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js', [], null, true );
        wp_add_inline_script( 'lucide-cdn', $this->admin_notice_relocator_script() . "\n" . $this->lucide_icon_bootstrap_script(), 'after' );
        wp_enqueue_style( 'he-journalist-app', $this->plugin_url() . 'assets/css/app.css', [], self::VERSION );
    }

    private function admin_notice_relocator_script() {
        return <<<'JS'
(function(){
  function moveHEAdminNotices(){
    var app = document.querySelector('#heaj-app, #he-subdomains-app, #he-settings-app, #he-history-app, .heaj-settings-page');
    if (!app || !app.parentNode) { return; }

    var wrap = app.closest('.wrap') || app.parentNode;
    var tray = document.getElementById('heaj-admin-notice-tray');
    if (!tray) {
      tray = document.createElement('div');
      tray.id = 'heaj-admin-notice-tray';
      tray.className = 'heaj-admin-notice-tray';
      app.parentNode.insertBefore(tray, app);
    }

    var found = [];
    [app, wrap].forEach(function(root){
      if (!root || !root.querySelectorAll) { return; }
      root.querySelectorAll('.notice, .updated, .error, .update-nag').forEach(function(el){
        if (!el || el === tray || tray.contains(el)) { return; }
        if (el.closest('#heaj-admin-notice-tray')) { return; }
        if (el.id === 'heSubdomainStatus' || el.id === 'toast') { return; }
        if (el.closest('#toast')) { return; }
        found.push(el);
      });
    });

    found.forEach(function(el){
      el.classList.add('heaj-relocated-notice');
      tray.appendChild(el);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', moveHEAdminNotices);
  } else {
    moveHEAdminNotices();
  }
  setTimeout(moveHEAdminNotices, 120);
  setTimeout(moveHEAdminNotices, 700);
  setTimeout(moveHEAdminNotices, 1600);
})();
JS;
    }



    private function lucide_icon_bootstrap_script() {
        return <<<'JS'
(function(){
  function fallbackIcon(el){
    if (!el || el.dataset.heIconFallback === '1') return;
    var name = el.getAttribute('data-lucide') || 'circle';
    var cls = el.getAttribute('class') || '';
    var color = 'currentColor';
    var paths = {
      'shield-check':'<path d="M12 3l7 3v5c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-3z"/><path d="M9 12l2 2 4-5"/>',
      'key-round':'<circle cx="7.5" cy="14.5" r="3.5"/><path d="M10 12l7-7 3 3-2 2 2 2-2 2-2-2-3 3"/>',
      'cpu':'<rect x="7" y="7" width="10" height="10" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M4 9h3M4 15h3M17 9h3M17 15h3M9 4v3M15 4v3M9 17v3M15 17v3"/>',
      'activity':'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
      'key':'<circle cx="7.5" cy="14.5" r="3.5"/><path d="M10 12l8-8 3 3-8 8"/>',
      'external-link':'<path d="M14 3h7v7"/><path d="M10 14L21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/>',
      'network':'<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="3" y="16" width="6" height="6" rx="1"/><rect x="15" y="16" width="6" height="6" rx="1"/><path d="M12 8v4M6 16v-2h12v2"/>',
      'search':'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
      'refresh-cw':'<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/>',
      'plus-circle':'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
      'newspaper':'<path d="M4 5h13a3 3 0 0 1 3 3v11H6a2 2 0 0 1-2-2V5z"/><path d="M8 9h6M8 13h8M8 17h5"/>',
      'clock-3':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
      'tag':'<path d="M20 10l-8 8-8-8V4h6l10 10z"/><circle cx="8" cy="8" r="1"/>',
      'star':'<path d="M12 3l2.7 5.5 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1-4.4-4.3 6.1-.9L12 3z"/>',
      'log-in':'<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/>',
      'layout-dashboard':'<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
      'wand-sparkles':'<path d="M15 4l5 5-11 11-5-5L15 4z"/><path d="M14 5l5 5"/><path d="M5 3v4M3 5h4M19 15v4M17 17h4"/>'
    };
    var svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('xmlns','http://www.w3.org/2000/svg');
    svg.setAttribute('viewBox','0 0 24 24');
    svg.setAttribute('fill','none');
    svg.setAttribute('stroke', color);
    svg.setAttribute('stroke-width','2');
    svg.setAttribute('stroke-linecap','round');
    svg.setAttribute('stroke-linejoin','round');
    svg.setAttribute('class', cls + ' he-lucide-fallback');
    svg.setAttribute('aria-hidden','true');
    svg.innerHTML = paths[name] || '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>';
    el.dataset.heIconFallback = '1';
    el.replaceWith(svg);
  }

  function renderHEIcons(){
    try {
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
        return true;
      }
    } catch(e) {}
    return false;
  }

  function ensureHEIcons(){
    if (renderHEIcons()) return;
    if (!document.getElementById('he-lucide-jsdelivr-fallback')) {
      var s = document.createElement('script');
      s.id = 'he-lucide-jsdelivr-fallback';
      s.src = 'https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js';
      s.onload = renderHEIcons;
      document.head.appendChild(s);
    }
    setTimeout(function(){
      if (!renderHEIcons()) {
        document.querySelectorAll('i[data-lucide]').forEach(fallbackIcon);
      }
    }, 1400);
  }

  window.HEAJRenderIcons = ensureHEIcons;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureHEIcons);
  } else {
    ensureHEIcons();
  }
  window.addEventListener('load', ensureHEIcons);
  setTimeout(ensureHEIcons, 150);
  setTimeout(ensureHEIcons, 700);
  setTimeout(ensureHEIcons, 1800);
})();
JS;
    }

    private function enqueue_generator_assets() {
        wp_enqueue_script( 'he-journalist-app', $this->plugin_url() . 'assets/js/app.js', [ 'lucide-cdn' ], self::VERSION, true );
        wp_localize_script( 'he-journalist-app', 'HEAJ', [
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
            'version'   => self::VERSION,
            'providers' => $this->get_available_ai_providers(),
            'promptOverrides' => $this->get_prompt_overrides(),
        ] );
    }

    private function enqueue_subdomains_assets() {
        wp_enqueue_script( 'he-domain-groups-external', 'https://yanuarzg.github.io/cc/he/all.js', [], null, true );
        wp_enqueue_script( 'he-journalist-subdomains', $this->plugin_url() . 'assets/js/subdomains.js', [ 'he-domain-groups-external', 'lucide-cdn' ], self::VERSION, true );
    }

    private function enqueue_assets() {
        $this->enqueue_common_assets();
        $this->enqueue_generator_assets();
    }

    public function render_generator_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        $available_ai_providers = $this->get_available_ai_providers();
        $has_any_ai_provider = array_sum( array_map( 'absint', $available_ai_providers ) ) > 0;
        echo '<div class="wrap he-admin-generator">';
        include $this->plugin_dir() . 'templates/app.php';
        echo '</div>';
    }

    public function render_history_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { $history = []; }
        $total_history = count( $history );
        $per_page = 20;
        $paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
        $total_pages = max( 1, (int) ceil( $total_history / $per_page ) );
        if ( $paged > $total_pages ) { $paged = $total_pages; }
        $history_all = $history;
        $history = array_slice( $history_all, ( $paged - 1 ) * $per_page, $per_page );
        echo '<div class="wrap he-admin-history">';
        include $this->plugin_dir() . 'templates/history.php';
        echo '</div>';
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $defaults       = $this->default_api_keys();
        $masked_defaults = array_map( [ $this, 'mask_api_key' ], $defaults );
        $api_key_pool_all = $this->get_provider_key_status_rows();
        $active_api_key_pool = $this->get_api_key_pool( false );
        $blocked_api_keys = $this->get_blocked_api_keys();
        $prompt_overrides = $this->get_prompt_overrides();
        $update_manifest = $this->get_update_manifest();
        $latest_version = is_array( $update_manifest ) && ! empty( $update_manifest['version'] ) ? $update_manifest['version'] : self::VERSION;
        $update_available = version_compare( $latest_version, self::VERSION, '>' );
        $all_count      = count( $active_api_key_pool );
        $grok_keys_count = count( $this->get_grok_api_keys() );
        $groq_keys_count = count( $this->get_groqcloud_api_keys() );
        $zai_keys_count  = count( $this->get_zai_api_keys() );
        include $this->plugin_dir() . 'templates/settings.php';
    }

    public function render_subdomains_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        if ( ! $this->is_harianexpress_com_domain() ) {
            wp_safe_redirect( admin_url( 'admin.php?page=he-journalist' ) );
            exit;
        }
        echo '<div class="wrap he-admin-subdomains">';
        include $this->plugin_dir() . 'templates/subdomains.php';
        echo '</div>';
    }



    private function get_update_manifest() {
        $response = wp_remote_get( self::UPDATE_JSON_URL, [ 'timeout' => 15 ] );
        if ( is_wp_error( $response ) ) { return null; }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) { return null; }
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        return is_array( $data ) ? $data : null;
    }

    public function check_plugin_update( $transient ) {
        if ( empty( $transient ) || ! is_object( $transient ) ) { return $transient; }
        $plugin_file = plugin_basename( __FILE__ );
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) || empty( $manifest['version'] ) ) {
            if ( isset( $transient->response[ $plugin_file ] ) ) { unset( $transient->response[ $plugin_file ] ); }
            return $transient;
        }
        if ( ! version_compare( $manifest['version'], self::VERSION, '>' ) ) {
            if ( isset( $transient->response[ $plugin_file ] ) ) { unset( $transient->response[ $plugin_file ] ); }
            if ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
                $transient->no_update[ $plugin_file ] = (object) [
                    'id'          => self::UPDATE_JSON_URL,
                    'slug'        => dirname( $plugin_file ),
                    'plugin'      => $plugin_file,
                    'new_version' => self::VERSION,
                    'url'         => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
                    'package'     => '',
                ];
            }
            return $transient;
        }

        $package = $manifest['download_url'] ?? $manifest['package'] ?? '';
        $transient->response[ $plugin_file ] = (object) [
            'id'            => self::UPDATE_JSON_URL,
            'slug'          => dirname( $plugin_file ),
            'plugin'        => $plugin_file,
            'new_version'   => sanitize_text_field( $manifest['version'] ),
            'url'           => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
            'package'       => esc_url_raw( $package ),
            'requires'      => sanitize_text_field( $manifest['requires'] ?? '6.0' ),
            'tested'        => sanitize_text_field( $manifest['tested'] ?? '' ),
            'requires_php'  => sanitize_text_field( $manifest['requires_php'] ?? '7.4' ),
        ];
        return $transient;
    }

    public function plugin_update_info( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || empty( $args->slug ) || $args->slug !== 'harianexpress-journalist' ) {
            return $result;
        }
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) ) { return $result; }
        return (object) [
            'name'          => $manifest['name'] ?? 'HarianExpress AI Journalist Pro Tools',
            'slug'          => 'harianexpress-journalist',
            'version'       => $manifest['version'] ?? self::VERSION,
            'author'        => $manifest['author'] ?? 'YZG / HarianExpress Redaksi',
            'homepage'      => $manifest['homepage'] ?? self::UPDATE_INFO_URL,
            'requires'      => $manifest['requires'] ?? '6.0',
            'tested'        => $manifest['tested'] ?? '',
            'requires_php'  => $manifest['requires_php'] ?? '7.4',
            'download_link' => $manifest['download_url'] ?? $manifest['package'] ?? '',
            'sections'      => $manifest['sections'] ?? [ 'description' => 'AI Journalist Pro Tools untuk HarianExpress.', 'changelog' => '' ],
        ];
    }

    private function extract_urls_from_text( $text ) {
        preg_match_all( '#https?://[^\s<>"]+#i', (string) $text, $matches );
        return array_values( array_unique( array_map( 'esc_url_raw', $matches[0] ?? [] ) ) );
    }

    private function absolutize_url( $src, $base_url ) {
        $src = html_entity_decode( trim( (string) $src ), ENT_QUOTES | ENT_HTML5 );
        if ( $src === '' || stripos( $src, 'data:' ) === 0 ) { return ''; }
        if ( preg_match( '#^https?://#i', $src ) ) { return esc_url_raw( $src ); }
        $base = wp_parse_url( $base_url );
        if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) { return ''; }
        if ( strpos( $src, '//' ) === 0 ) { return esc_url_raw( $base['scheme'] . ':' . $src ); }
        $root = $base['scheme'] . '://' . $base['host'];
        if ( ! empty( $base['port'] ) ) { $root .= ':' . $base['port']; }
        if ( strpos( $src, '/' ) === 0 ) { return esc_url_raw( $root . $src ); }
        $path = isset( $base['path'] ) ? preg_replace( '#/[^/]*$#', '/', $base['path'] ) : '/';
        return esc_url_raw( $root . $path . $src );
    }


    private function extract_article_like_html( $html ) {
        $html = (string) $html;
        $blocks = [];

        if ( preg_match_all( '#<article\\b[^>]*>.*?</article>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( '#<main\\b[^>]*>.*?</main>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<div\\b[^>]+class=[\"'][^\"']*(?:cover-photo|entry-content|post-content|article-content|single-content|content-detail|content_body|contentbody|td-post-content|jeg_inner_content|jl_content|post-entry|detail__body|detail__body-text|detail_text|detail__text|read__content|read__article|article__content|article-content-body)[^\"']*[\"'][^>]*>.*?</div>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<section\\b[^>]+class=[\"'][^\"']*(?:cover-photo|entry-content|post-content|article-content|single-content|content-detail|detail__body|detail__body-text|read__content|article__content)[^\"']*[\"'][^>]*>.*?</section>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }

        if ( empty( $blocks ) ) {
            return [ 'html' => $html, 'strict_article' => false ];
        }

        usort( $blocks, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
        return [ 'html' => $blocks[0], 'strict_article' => true ];
    }

    private function html_article_to_plain_text( $html ) {
        $html = (string) $html;
        if ( $html === '' ) { return ''; }

        $html = preg_replace( '#<script\\b[^>]*>.*?</script>#is', ' ', $html );
        $html = preg_replace( '#<style\\b[^>]*>.*?</style>#is', ' ', $html );
        $html = preg_replace( '#<noscript\\b[^>]*>.*?</noscript>#is', ' ', $html );
        $html = preg_replace( '#<(?:p|div|h1|h2|h3|h4|h5|h6|blockquote|li|br|tr)\\b[^>]*>#i', "\n", $html );
        $html = preg_replace( '#</(?:p|div|h1|h2|h3|h4|h5|h6|blockquote|li|tr)>#i', "\n", $html );
        $text = wp_strip_all_tags( $html, false );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $text = preg_replace( "/[ \t\r\0\x0B]+/u", ' ', $text );
        $text = preg_replace( "/\n\s*\n\s*\n+/u", "\n\n", $text );
        $lines = array_map( 'trim', preg_split( "/\n+/u", $text ) );
        $lines = array_values( array_filter( $lines, function( $line ) {
            if ( $line === '' ) { return false; }
            if ( mb_strlen( $line ) < 3 ) { return false; }
            $junk = strtolower( $line );
            foreach ( [ 'advertisement', 'scroll to continue', 'baca juga', 'lihat juga', 'share', 'komentar', 'tag:', 'copyright' ] as $needle ) {
                if ( $junk === $needle ) { return false; }
            }
            return true;
        } ) );

        $text = trim( implode( "\n", $lines ) );
        if ( mb_strlen( $text ) > 18000 ) {
            $text = mb_substr( $text, 0, 18000 ) . "\n[TEKS SUMBER DIPOTONG KARENA TERLALU PANJANG]";
        }
        return $text;
    }

    private function fetch_source_text_context( $raw_text ) {
        $urls = array_slice( $this->extract_urls_from_text( $raw_text ), 0, 5 );
        if ( empty( $urls ) ) { return ''; }

        $items = [];
        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 25,
                'redirection' => 5,
                'headers'     => [
                    'User-Agent' => 'Mozilla/5.0 (compatible; HarianExpressBot/1.0; +https://harianexpress.com)',
                    'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $code = (int) wp_remote_retrieve_response_code( $response );
            if ( $code < 200 || $code >= 300 ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || trim( $html ) === '' ) { continue; }

            $article = $this->extract_article_like_html( $html );
            $text = $this->html_article_to_plain_text( $article['html'] );
            if ( mb_strlen( $text ) < 120 ) {
                $text = $this->html_article_to_plain_text( $html );
            }
            if ( mb_strlen( $text ) < 120 ) { continue; }

            $items[] = "URL SUMBER: " . $url . "\nTEKS SUMBER HASIL EKSTRAKSI SERVER:\n" . $text;
        }

        if ( empty( $items ) ) { return ''; }

        return "\n\n================ SUMBER RESMI HASIL EKSTRAKSI SERVER ================\n" .
            implode( "\n\n---------------- SUMBER BERIKUTNYA ----------------\n\n", $items ) .
            "\n================ AKHIR SUMBER RESMI ================\n";
    }

    private function parse_img_tag_srcs( $tag ) {
        $candidates = [];
        foreach ( [ 'src', 'data-src', 'data-lazy-src', 'data-original', 'data-image' ] as $attr ) {
            if ( preg_match( "#\\s" . preg_quote( $attr, '#' ) . "=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
                $candidates[] = $m[1];
            }
        }
        if ( preg_match( "#\\ssrcset=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
            $parts = array_map( 'trim', explode( ',', $m[1] ) );
            foreach ( $parts as $part ) {
                if ( preg_match( '#^(\\S+)\\s+(\\d+)w#', $part, $sm ) ) {
                    $candidates[] = $sm[1];
                }
            }
        }
        return array_values( array_unique( array_filter( $candidates ) ) );
    }

    private function parse_img_tag_width( $tag ) {
        $width = 0;
        if ( preg_match( "#\\swidth=[\"']?(\\d+)[\"']?#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssizes=[\"'][^\"']*(\\d+)px#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssrcset=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
            if ( preg_match_all( '#\\s(\\d+)w(?:,|$)#', $m[1], $wm ) ) {
                foreach ( $wm[1] as $w ) { $width = max( $width, (int) $w ); }
            }
        }
        return $width;
    }


    private function extract_caption_near_image( $html, $img_tag ) {
        $window = $img_tag;
        $pos = strpos( $html, $img_tag );
        if ( $pos !== false ) {
            $window = substr( $html, max( 0, $pos - 2500 ), strlen( $img_tag ) + 5000 );
        }
        $caption = '';
        $patterns = [
            '#<figure\b[^>]*>.*?' . preg_quote( $img_tag, '#' ) . '.*?<figcaption\b[^>]*>(.*?)</figcaption>.*?</figure>#is',
            '#<figcaption\b[^>]*>(.*?)</figcaption>#is',
            '#<[^>]+class=["\'][^"\']*(?:caption|wp-caption-text|image-caption|photo-caption|cover-caption|detail__caption)[^"\']*["\'][^>]*>(.*?)</[^>]+>#is',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $window, $m ) ) {
                $caption = $this->html_article_to_plain_text( $m[1] );
                break;
            }
        }
        if ( $caption === '' && preg_match( '#\salt=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        if ( $caption === '' && preg_match( '#\stitle=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        if ( $caption === '' && preg_match( '#\sdata-caption=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        $caption = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $caption ) ) );
        return sanitize_text_field( mb_substr( $caption, 0, 300 ) );
    }

    private function extract_credit_near_image( $html, $img_tag ) {
        $window = $img_tag;
        $pos = strpos( $html, $img_tag );
        if ( $pos !== false ) {
            $window = substr( $html, max( 0, $pos - 2500 ), strlen( $img_tag ) + 5000 );
        }
        $credit = '';
        $patterns = [
            '#<[^>]+class=["\'][^"\']*(?:credit-source|source-credit|photo-credit|image-credit|credit|sumber|source)[^"\']*["\'][^>]*>(.*?)</[^>]+>#is',
            '#<[^>]+(?:data-credit|data-source|data-sumber)=["\']([^"\']{3,240})["\'][^>]*>#is',
            '#(?:Sumber|Source|Foto|Photo)\s*[:：]\s*([^<\n\r]{3,160})#iu',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $window, $m ) ) {
                $credit = $this->html_article_to_plain_text( $m[1] );
                break;
            }
        }
        $credit = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $credit ) ) );
        if ( $credit && ! preg_match( '/^(sumber|source|foto|photo)\s*:/iu', $credit ) ) {
            $credit = 'Sumber: ' . $credit;
        }
        return sanitize_text_field( mb_substr( $credit, 0, 220 ) );
    }

    private function normalize_source_image_name_key( $image_url ) {
        $path = wp_parse_url( (string) $image_url, PHP_URL_PATH );
        $base = strtolower( basename( (string) $path ) );
        $base = preg_replace( '/\.(jpe?g|png|webp|gif)$/i', '', $base );
        $base = preg_replace( '/[-_](?:\d{2,5}x\d{2,5}|scaled|cropped|thumbnail|thumb|small|medium|large|full)$/i', '', $base );
        $base = preg_replace( '/(?:[-_]\d{2,5}){1,2}$/', '', $base );
        $base = preg_replace( '/[^a-z0-9]+/', '-', $base );
        $base = trim( $base, '-' );
        return $base !== '' ? $base : md5( (string) $image_url );
    }

    public function ajax_fetch_source_images() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin mengambil gambar sumber.' ], 403 );
        }

        $source = isset( $_POST['source'] ) ? wp_unslash( $_POST['source'] ) : '';
        $urls = array_slice( $this->extract_urls_from_text( $source ), 0, 8 );
        $images = [];
        $seen_names = [];
        $min_width = 320;

        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 20,
                'redirection' => 5,
                'headers'     => [ 'User-Agent' => 'HarianExpressBot/1.0' ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || $html === '' ) { continue; }

            $article = $this->extract_article_like_html( $html );
            $scan_html = $article['html'];
            // Tambahan deteksi gambar utama/cover dari class .cover-photo meskipun berada di luar body artikel utama.
            if ( preg_match_all( '#<(?:div|figure|picture)\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>.*?</(?:div|figure|picture)>#is', $html, $cover_blocks ) ) {
                $scan_html .= "\n" . implode( "\n", $cover_blocks[0] );
            }
            if ( preg_match_all( '#<img\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>#is', $html, $cover_imgs ) ) {
                $scan_html .= "\n" . implode( "\n", $cover_imgs[0] );
            }
            $strict_article = ! empty( $article['strict_article'] );

            if ( ! preg_match_all( '#<img\\b[^>]*>#i', $scan_html, $tags ) ) { continue; }
            foreach ( $tags[0] as $tag ) {
                $tag_width = $this->parse_img_tag_width( $tag );
                $srcs = $this->parse_img_tag_srcs( $tag );
                foreach ( $srcs as $src ) {
                    $img = $this->absolutize_url( $src, $url );
                    if ( ! $img || ! preg_match( '#\\.(jpe?g|png|webp|gif)(\\?.*)?$#i', $img ) ) { continue; }

                    $width = $tag_width;
                    if ( $width < $min_width ) {
                        $width = $this->remote_image_width( $img );
                    }

                    if ( $width < $min_width ) { continue; }

                    $name_key = $this->normalize_source_image_name_key( $img );
                    if ( isset( $seen_names[ $name_key ] ) ) { continue; }
                    $seen_names[ $name_key ] = true;

                    $key = md5( $img );
                    $images[ $key ] = [
                        'url'    => $img,
                        'source' => $url,
                        'width'  => $width,
                        'scope'  => $strict_article ? 'article' : 'page-filtered',
                        'caption'=> $this->extract_caption_near_image( $scan_html, $tag ),
                        'credit' => $this->extract_credit_near_image( $scan_html, $tag ),
                    ];
                    if ( count( $images ) >= 24 ) { break 3; }
                }
            }
        }

        wp_send_json_success( [ 'images' => array_values( $images ) ] );
    }


    private function openai_provider_config( $provider ) {
        if ( $provider === 'grok' ) {
            return [
                'name'     => 'Grok xAI',
                'endpoint' => 'https://api.x.ai/v1/chat/completions',
                'model'    => 'grok-4.3',
                'keys'     => $this->get_grok_api_keys(),
            ];
        }
        if ( $provider === 'groqcloud' ) {
            return [
                'name'     => 'Groq',
                'endpoint' => 'https://api.groq.com/openai/v1/chat/completions',
                'model'    => 'llama-3.3-70b-versatile',
                'keys'     => $this->get_groqcloud_api_keys(),
            ];
        }
        if ( $provider === 'zai' ) {
            return [
                'name'     => 'Z.AI',
                'endpoint' => 'https://api.z.ai/api/paas/v4/chat/completions',
                'model'    => 'glm-4.5-flash',
                'keys'     => $this->get_zai_api_keys(),
            ];
        }
        return null;
    }

    private function is_retryable_openai_compatible_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );
        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) { return true; }
        foreach ( [ 'rate limit', 'quota', 'temporarily', 'timeout', 'timed out', 'overloaded', 'service unavailable', 'try again' ] as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) { return true; }
        }
        return false;
    }

    private function is_blockable_openai_compatible_key_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );
        if ( in_array( $status, [ 401, 403 ], true ) ) { return true; }
        foreach ( [ 'invalid api key', 'incorrect api key', 'unauthorized', 'forbidden', 'permission', 'blocked', 'disabled', 'expired', 'invalid authorization', 'no authorization', 'does not have permission' ] as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) { return true; }
        }
        return false;
    }

    private function friendly_openai_compatible_error( $provider_name, $status, $message ) {
        $status = (int) $status;
        $message = trim( (string) $message );
        if ( $status === 403 ) {
            return $provider_name . ' HTTP 403: API key/team tidak punya permission, diblokir, belum punya credits, atau model/endpoint belum diizinkan. Key tersebut sudah diblokir otomatis dan plugin mencoba key lain atau fallback ke Gemini.';
        }
        if ( $status === 401 ) {
            return $provider_name . ' HTTP 401: API key tidak valid/authorization salah. Key tersebut sudah diblokir otomatis dan plugin mencoba key lain atau fallback ke Gemini.';
        }
        return $message ?: ( $provider_name . ' HTTP ' . $status );
    }

    private function call_openai_compatible_json( $provider, $system_prompt, $user_text, $schema ) {
        $config = $this->openai_provider_config( $provider );
        if ( ! $config ) {
            return new WP_Error( 'heaj_provider_invalid', 'Provider AI tidak valid.' );
        }
        if ( empty( $config['keys'] ) ) {
            return new WP_Error( 'heaj_provider_no_key', 'API key untuk ' . $config['name'] . ' belum tersedia.' );
        }

        $json_contract = "\n\nOUTPUT CONTRACT: Reply ONLY with a valid JSON object. Do not use markdown fences or extra text. JSON schema:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $messages = [
            [ 'role' => 'system', 'content' => $system_prompt . $json_contract ],
            [ 'role' => 'user', 'content' => $user_text ],
        ];
        $last_error = 'Request ' . $config['name'] . ' gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        for ( $round = 1; $round <= $max_rounds; $round++ ) {
            $retryable_round = false;
            foreach ( $config['keys'] as $i => $key ) {
                if ( $this->is_api_key_blocked( $key ) ) {
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => 'skipped', 'retryable' => false, 'blocked' => true, 'message' => 'API key provider ini sudah masuk daftar blokir otomatis.' ];
                    continue;
                }
                $payload = [
                    'model'       => $config['model'],
                    'messages'    => $messages,
                    'temperature' => 0.35,
                ];
                // OpenAI-compatible providers may ignore response_format if unsupported; JSON contract remains in prompt.
                $payload['response_format'] = [ 'type' => 'json_object' ];

                $response = wp_remote_post( $config['endpoint'], [
                    'headers' => [
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'Bearer ' . trim( $key ),
                    ],
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $retryable_round = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => 'wp_error', 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $raw_error = $decoded['error']['message'] ?? $decoded['message'] ?? ( $config['name'] . ' HTTP ' . $code );
                    $last_error = $this->friendly_openai_compatible_error( $config['name'], $code, $raw_error );
                    $blockable = $this->is_blockable_openai_compatible_key_error( $code, $raw_error );
                    if ( $blockable ) {
                        $this->block_api_key( $key, $last_error );
                        $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => false, 'blocked' => true, 'message' => $last_error ];
                        continue;
                    }
                    $retryable = $this->is_retryable_openai_compatible_error( $code, $raw_error );
                    if ( $retryable ) { $retryable_round = true; }
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => $retryable, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['choices'][0]['message']['content'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons ' . $config['name'] . ' bukan JSON valid.';
                    $retryable_round = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                return [
                    'result'          => $result,
                    'provider_label'  => $config['name'],
                    'api_index_used'  => $i + 1,
                    'round_used'      => $round,
                    'attempts'        => count( $attempts ) + 1,
                ];
            }
            if ( ! $retryable_round || $round >= $max_rounds ) { break; }
            sleep( $this->retry_delay_seconds( $round ) );
        }

        return new WP_Error( 'heaj_provider_failed', $last_error, [ 'status' => $last_status, 'attempts' => $attempts ] );
    }



    private function first_source_url_from_text( $text ) {
        $urls = $this->extract_urls_from_text( $text );
        return ! empty( $urls[0] ) ? $urls[0] : '';
    }


    private function all_source_urls_from_text( $text ) {
        return array_values( array_unique( array_map( 'esc_url_raw', $this->extract_urls_from_text( (string) $text ) ) ) );
    }
    private function quick_extract_source_plain_text( $raw_text ) {
        $context = $this->fetch_source_text_context( $raw_text );
        $context = preg_replace( '/=+ SUMBER RESMI HASIL EKSTRAKSI SERVER =+|=+ AKHIR SUMBER RESMI =+|URL SUMBER:.*?\nTEKS SUMBER HASIL EKSTRAKSI SERVER:/s', '', $context );
        return trim( wp_strip_all_tags( $context ) );
    }

    public function ajax_test_provider_keys() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal.' ], 403 );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
        }
        $provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : 'gemini';
        $rows = [];
        if ( $provider === 'gemini' ) {
            $pool = $this->get_api_key_pool( true );
            $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
            foreach ( $pool as $i => $item ) {
                if ( ! empty( $item['blocked'] ) ) {
                    $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'blocked', 'message' => 'Diblokir lokal' ];
                    continue;
                }
                $endpoint = sprintf( 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', rawurlencode( $model ), rawurlencode( $item['key'] ) );
                $res = wp_remote_post( $endpoint, [ 'timeout' => 25, 'headers' => [ 'Content-Type' => 'application/json' ], 'body' => wp_json_encode( [ 'contents' => [ [ 'parts' => [ [ 'text' => 'Reply OK only.' ] ] ] ] ] ) ] );
                if ( is_wp_error( $res ) ) { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'error', 'message' => $res->get_error_message() ]; continue; }
                $code = wp_remote_retrieve_response_code( $res );
                $body = json_decode( wp_remote_retrieve_body( $res ), true );
                $msg = $body['error']['message'] ?? 'Aktif';
                if ( $code >= 200 && $code < 300 ) { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'active', 'message' => 'Aktif' ]; }
                else { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'error', 'message' => wp_trim_words( $msg, 18 ) ]; }
            }
        } else {
            $config = $this->openai_provider_config( $provider );
            if ( ! $config ) { wp_send_json_error( [ 'message' => 'Provider tidak valid.' ], 400 ); }
            foreach ( $config['keys'] as $i => $key ) {
                $masked = $this->mask_api_key( $key );
                if ( $this->is_api_key_blocked( $key ) ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'blocked', 'message' => 'Diblokir lokal' ]; continue; }
                $payload = [ 'model' => $config['model'], 'messages' => [ [ 'role' => 'user', 'content' => 'Reply OK only.' ] ], 'temperature' => 0 ];
                $res = wp_remote_post( $config['endpoint'], [ 'timeout' => 30, 'headers' => [ 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . trim( $key ) ], 'body' => wp_json_encode( $payload ) ] );
                if ( is_wp_error( $res ) ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'error', 'message' => $res->get_error_message() ]; continue; }
                $code = wp_remote_retrieve_response_code( $res );
                $body = json_decode( wp_remote_retrieve_body( $res ), true );
                $msg = $body['error']['message'] ?? $body['message'] ?? 'Aktif';
                if ( $code >= 200 && $code < 300 ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'active', 'message' => 'Aktif' ]; }
                else { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'error', 'message' => wp_trim_words( $msg, 18 ) ]; }
            }
        }
        wp_send_json_success( [ 'provider' => $provider, 'rows' => $rows ] );
    }

    public function ajax_generate_content() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin memakai generator.' ], 403 );
        }

        $system_prompt = isset( $_POST['systemPrompt'] ) ? wp_unslash( $_POST['systemPrompt'] ) : '';
        $user_text     = isset( $_POST['userText'] ) ? wp_unslash( $_POST['userText'] ) : '';
        $schema_raw    = isset( $_POST['schema'] ) ? wp_unslash( $_POST['schema'] ) : '';
        $use_search    = ! empty( $_POST['useSearch'] ) && $_POST['useSearch'] === '1';
        $schema        = json_decode( $schema_raw, true );
        $ai_provider   = isset( $_POST['aiProvider'] ) ? sanitize_key( wp_unslash( $_POST['aiProvider'] ) ) : 'gemini';
        if ( ! in_array( $ai_provider, [ 'gemini', 'grok', 'groqcloud', 'zai' ], true ) ) { $ai_provider = 'gemini'; }

        if ( empty( $system_prompt ) || empty( $user_text ) || ! is_array( $schema ) ) {
            wp_send_json_error( [ 'message' => 'Payload tidak lengkap atau schema JSON tidak valid.' ], 400 );
        }

        $source_context = $this->fetch_source_text_context( $user_text );
        if ( $source_context !== '' ) {
            $system_prompt .= "

MODE SUMBER URL TERKUNCI (WAJIB DIIKUTI): Server WordPress sudah mengambil teks artikel sumber dan melampirkannya di input. Gunakan HANYA teks sumber hasil ekstraksi server sebagai dasar fakta. Jangan mengandalkan memori model, hasil pencarian lain, atau asumsi. Semua tanggal, waktu, angka, nama narasumber, jabatan, lokasi, dan kutipan langsung wajib sama persis dengan teks sumber. Jika sebuah data tidak ada di teks sumber, jangan tulis data tersebut. DILARANG membuat tanggal default, tanggal hari ini, atau tanggal acak. Kutipan langsung di dalam tanda petik harus disalin verbatim dari sumber, bukan diparafrase. Untuk menghindari duplikasi konten, paragraf narasi di luar kutipan WAJIB ditulis ulang secara unik: ubah struktur kalimat, urutan penjelasan, dan pilihan kata tanpa mengubah fakta. Jangan menyalin paragraf sumber secara utuh atau berurutan sama persis. Parafrase hanya boleh untuk narasi, bukan untuk kutipan, angka, tanggal, nama, lokasi, atau jabatan.";
            $user_text .= $source_context;
            $use_search = false;
        }

        $provider_fallback_error = null;
        $provider_fallback_attempts = [];
        $fallback_from_provider = '';
        if ( $ai_provider !== 'gemini' ) {
            $provider_result = $this->call_openai_compatible_json( $ai_provider, $system_prompt, $user_text, $schema );
            if ( ! is_wp_error( $provider_result ) ) {
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $provider_result['result']['titleOptions'] ?? null ) ? ( $provider_result['result']['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => $ai_provider,
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                ] );
                wp_send_json_success( [
                    'result'          => $provider_result['result'],
                    'provider_used'   => $ai_provider,
                    'provider_label'  => $provider_result['provider_label'],
                    'api_index_used'  => $provider_result['api_index_used'],
                    'round_used'      => $provider_result['round_used'],
                    'attempts'        => $provider_result['attempts'],
                    'source_context'  => $source_context ? $this->quick_extract_source_plain_text( $user_text ) : '',
                    'source_url'      => $this->first_source_url_from_text( $user_text ),
                    'source_urls'     => $this->all_source_urls_from_text( $user_text ),
                    'history_id'      => $history_id,
                ] );
            }

            $data = $provider_result->get_error_data();
            $provider_fallback_error = $provider_result->get_error_message();
            $provider_fallback_attempts = is_array( $data ) && isset( $data['attempts'] ) ? $data['attempts'] : [];
            $fallback_from_provider = $ai_provider;
            // Jangan hentikan proses ketika Grok/Z.AI 401/403/limit. Fallback otomatis ke Gemini jika tersedia.
        }

        $api_key_pool = $this->get_api_key_pool( false );
        if ( empty( $api_key_pool ) ) {
            $msg = 'Tidak ada Gemini API Key aktif. Semua API key mungkin kosong atau sudah diblokir otomatis karena leaked/invalid.';
            if ( $provider_fallback_error ) { $msg = $provider_fallback_error . ' Fallback ke Gemini tidak bisa dilakukan karena tidak ada Gemini API aktif.'; }
            wp_send_json_error( [ 'message' => $msg, 'provider_attempts' => $provider_fallback_attempts ], 400 );
        }

        $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        /**
         * Gemini 2.5 Flash rejects google_search when combined with responseMimeType=responseSchema.
         * For search-enabled requests we ask for JSON in the prompt and parse it server-side.
         * Non-search requests still use structured output for stricter JSON.
         */
        if ( $use_search ) {
            $json_contract = "\n\nFORMAT OUTPUT WAJIB:\n" .
                "Balas HANYA dengan JSON object valid tanpa markdown, tanpa ```json, tanpa teks tambahan. " .
                "JSON harus mengikuti schema ini secara ketat:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

            $payload = [
                'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt . $json_contract ] ] ],
                'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
                'tools'             => [ [ 'google_search' => new stdClass() ] ],
            ];
        } else {
            $payload = [
                'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt ] ] ],
                'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
                'generationConfig'  => [
                    'responseMimeType' => 'application/json',
                    'responseSchema'   => $schema,
                ],
            ];
        }

        $last_error = 'Request Gemini gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        for ( $round = 1; $round <= $max_rounds; $round++ ) {
            $round_has_retryable_error = false;

            foreach ( $api_key_pool as $index => $api_item ) {
                $api_key = $api_item['key'];
                $api_label = $api_item['label'] ?? ( 'API #' . ( $index + 1 ) );
                if ( $this->is_api_key_blocked( $api_key ) ) {
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => 'skipped', 'retryable' => false, 'blocked' => true, 'message' => 'API key sudah masuk daftar blokir otomatis.' ];
                    continue;
                }
                $endpoint = sprintf(
                    'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
                    rawurlencode( $model ),
                    rawurlencode( $api_key )
                );

                $response = wp_remote_post( $endpoint, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $last_status = 500;
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => 'wp_error', 'retryable' => true, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $last_error = $decoded['error']['message'] ?? 'Request Gemini gagal.';
                    $blockable = $this->is_blockable_gemini_api_key_error( $code, $last_error );
                    if ( $blockable ) {
                        $this->block_api_key( $api_key, $last_error );
                        $attempts[] = [
                            'round' => $round,
                            'api_index' => $index + 1,
                            'api_label' => $api_label,
                            'status' => $code,
                            'retryable' => false,
                            'blocked' => true,
                            'message' => $last_error,
                        ];
                        continue;
                    }
                    $retryable = $this->is_retryable_gemini_error( $code, $last_error );
                    if ( $retryable ) {
                        $round_has_retryable_error = true;
                    }
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => $code, 'retryable' => $retryable, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons Gemini bukan JSON valid.';
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => $code, 'retryable' => true, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result['titleOptions'] ?? null ) ? ( $result['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => 'gemini',
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                ] );
                wp_send_json_success( [
                    'result'         => $result,
                    'provider_used'  => 'gemini',
                    'fallback_from'  => $fallback_from_provider,
                    'fallback_error' => $provider_fallback_error,
                    'provider_attempts' => $provider_fallback_attempts,
                    'api_index_used' => $index + 1,
                    'api_label_used' => $api_label,
                    'round_used'     => $round,
                    'attempts'       => count( $attempts ) + 1,
                    'source_context' => $source_context ? $this->quick_extract_source_plain_text( $user_text ) : '',
                    'source_url'     => $this->first_source_url_from_text( $user_text ),
                    'source_urls'    => $this->all_source_urls_from_text( $user_text ),
                    'history_id'     => $history_id,
                ] );
            }

            if ( ! $round_has_retryable_error || $round >= $max_rounds ) {
                break;
            }

            sleep( $this->retry_delay_seconds( $round ) );
        }

        $friendly_message = $last_error;
        if ( $provider_fallback_error ) {
            $friendly_message = $provider_fallback_error . ' Fallback ke Gemini juga belum berhasil: ' . $last_error;
        }
        if ( $this->is_blockable_gemini_api_key_error( $last_status, $last_error ) ) {
            $friendly_message = 'API key terakhir ditolak permanen oleh Gemini dan sudah diblokir otomatis. Plugin akan memakai API aktif lain pada request berikutnya. Tambahkan API key baru jika semua key sudah terblokir.';
        } elseif ( $this->is_retryable_gemini_error( $last_status, $last_error ) ) {
            $friendly_message = 'Gemini sedang sibuk/limit sementara. Plugin sudah mencoba ulang dan merotasi API key, tapi belum berhasil. Silakan klik Generate Ulang beberapa saat lagi.';
        }
        if ( $provider_fallback_error ) {
            $friendly_message = $provider_fallback_error . ' Fallback ke Gemini juga belum berhasil: ' . $friendly_message;
        }

        wp_send_json_error( [
            'message'  => $friendly_message,
            'raw_message' => $last_error,
            'status'   => $last_status,
            'attempts' => $attempts,
            'provider_attempts' => $provider_fallback_attempts,
        ], $last_status );
    }



    private function optimize_downloaded_source_image( $tmp, $filename ) {
        if ( ! $tmp || ! file_exists( $tmp ) ) {
            return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
        }

        if ( ! function_exists( 'wp_get_image_editor' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $editor = wp_get_image_editor( $tmp );
        if ( is_wp_error( $editor ) ) {
            return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
        }

        $size = $editor->get_size();
        if ( ! empty( $size['width'] ) && (int) $size['width'] > 1280 ) {
            $editor->resize( 1280, null, false );
        }
        if ( method_exists( $editor, 'set_quality' ) ) {
            $editor->set_quality( 82 );
        }

        $dir = dirname( $tmp );
        $base = pathinfo( $filename, PATHINFO_FILENAME );
        $base = sanitize_file_name( $base ? $base : 'he-source-image' );
        $supports_webp = function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( [ 'mime_type' => 'image/webp' ] );

        if ( $supports_webp ) {
            $webp_filename = wp_unique_filename( $dir, $base . '.webp' );
            $webp_path = trailingslashit( $dir ) . $webp_filename;
            $saved = $editor->save( $webp_path, 'image/webp' );
            if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && file_exists( $saved['path'] ) ) {
                @unlink( $tmp );
                return [ 'tmp' => $saved['path'], 'filename' => basename( $saved['path'] ), 'optimized' => true, 'format' => 'webp' ];
            }
        }

        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        if ( ! $ext ) { $ext = 'jpg'; }
        $fallback_filename = wp_unique_filename( $dir, $base . '-optimized.' . $ext );
        $fallback_path = trailingslashit( $dir ) . $fallback_filename;
        $saved = $editor->save( $fallback_path );
        if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && file_exists( $saved['path'] ) ) {
            @unlink( $tmp );
            return [ 'tmp' => $saved['path'], 'filename' => basename( $saved['path'] ), 'optimized' => true, 'format' => 'fallback' ];
        }

        return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
    }

    private function sideload_featured_image( $image_url, $post_id, $title = '', $caption = '' ) {
        $image_url = esc_url_raw( $image_url );
        if ( ! $image_url || ! $post_id ) {
            return new WP_Error( 'heaj_featured_image_invalid', 'URL featured image tidak valid.' );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url( $image_url, 30 );
        if ( is_wp_error( $tmp ) ) { return $tmp; }

        $path = wp_parse_url( $image_url, PHP_URL_PATH );
        $filename = sanitize_file_name( basename( (string) $path ) );
        if ( ! $filename || strpos( $filename, '.' ) === false ) {
            $filename = 'he-source-image-' . time() . '.jpg';
        }

        $optimized = $this->optimize_downloaded_source_image( $tmp, $filename );
        $tmp = $optimized['tmp'];
        $filename = $optimized['filename'];

        $file_array = [
            'name'     => $filename,
            'tmp_name' => $tmp,
        ];

        $attachment_id = media_handle_sideload( $file_array, $post_id, $caption ?: $title );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            return $attachment_id;
        }
        if ( $title ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $title ) );
        }
        if ( $caption ) {
            wp_update_post( [
                'ID' => $attachment_id,
                'post_excerpt' => $caption,
            ] );
        }
        update_post_meta( $attachment_id, '_he_source_image_original_url', $image_url );
        update_post_meta( $attachment_id, '_he_source_image_optimized', ! empty( $optimized['optimized'] ) ? '1' : '0' );
        update_post_meta( $attachment_id, '_he_source_image_format', sanitize_text_field( $optimized['format'] ) );
        return $attachment_id;
    }

    private function parse_selected_source_images_from_request() {
        $raw = isset( $_POST['source_images'] ) ? wp_unslash( $_POST['source_images'] ) : '';
        if ( ! is_string( $raw ) || $raw === '' ) {
            return [];
        }
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            return [];
        }
        $items = [];
        foreach ( $decoded as $item ) {
            if ( ! is_array( $item ) || empty( $item['url'] ) ) { continue; }
            $url = esc_url_raw( $item['url'] );
            if ( ! $url ) { continue; }
            $caption = isset( $item['caption'] ) ? sanitize_text_field( $item['caption'] ) : '';
            $credit = isset( $item['credit'] ) ? sanitize_text_field( $item['credit'] ) : '';
            if ( $credit && stripos( $caption, $credit ) === false ) {
                $caption = trim( $caption ? $caption . ' | ' . $credit : $credit );
            }
            $items[] = [
                'url'     => $url,
                'caption' => $caption,
                'source'  => isset( $item['source'] ) ? esc_url_raw( $item['source'] ) : '',
            ];
        }
        return array_slice( $items, 0, 8 );
    }

    private function build_inserted_image_html( $attachment_id, $caption = '' ) {
        $src = wp_get_attachment_url( $attachment_id );
        if ( ! $src ) { return ''; }
        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $html = '<figure class="wp-caption aligncenter">';
        $html .= '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" />';
        if ( $caption ) {
            $html .= '<figcaption class="wp-caption-text">' . esc_html( $caption ) . '</figcaption>';
        }
        $html .= '</figure>';
        return $html;
    }

    public function ajax_create_draft() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin membuat draft.' ], 403 );
        }

        $title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
        $slug     = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';
        $meta     = isset( $_POST['meta'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta'] ) ) : '';
        $content  = isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
        $category = isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
        $tags_raw = isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '';
        $source_url = isset( $_POST['source_url'] ) ? esc_url_raw( wp_unslash( $_POST['source_url'] ) ) : '';
        $source_urls_raw = isset( $_POST['source_urls'] ) ? wp_unslash( $_POST['source_urls'] ) : '';
        $source_urls = [];
        if ( is_string( $source_urls_raw ) && $source_urls_raw !== '' ) {
            $decoded_source_urls = json_decode( $source_urls_raw, true );
            if ( is_array( $decoded_source_urls ) ) {
                $source_urls = array_values( array_unique( array_filter( array_map( 'esc_url_raw', $decoded_source_urls ) ) ) );
            }
        }
        $history_id = isset( $_POST['history_id'] ) ? sanitize_key( wp_unslash( $_POST['history_id'] ) ) : '';
        $ai_provider = isset( $_POST['ai_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['ai_provider'] ) ) : '';
        $excerpt = isset( $_POST['excerpt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['excerpt'] ) ) : '';
        $featured_image_url = isset( $_POST['featured_image_url'] ) ? esc_url_raw( wp_unslash( $_POST['featured_image_url'] ) ) : '';
        $featured_image_caption = isset( $_POST['featured_image_caption'] ) ? sanitize_text_field( wp_unslash( $_POST['featured_image_caption'] ) ) : '';
        $selected_source_images = $this->parse_selected_source_images_from_request();

        if ( empty( $title ) || empty( $content ) ) {
            wp_send_json_error( [ 'message' => 'Judul dan isi artikel tidak boleh kosong.' ], 400 );
        }

        $cat_id = 0;
        if ( $category ) {
            $term = get_term_by( 'name', $category, 'category' );
            if ( $term && ! is_wp_error( $term ) ) {
                $cat_id = (int) $term->term_id;
            } else {
                $new_term = wp_insert_term( $category, 'category' );
                if ( ! is_wp_error( $new_term ) && ! empty( $new_term['term_id'] ) ) {
                    $cat_id = (int) $new_term['term_id'];
                }
            }
        }

        $post_data = [
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        ];
        if ( $excerpt ) { $post_data['post_excerpt'] = $excerpt; }
        if ( $cat_id ) { $post_data['post_category'] = [ $cat_id ]; }

        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Gagal membuat draft: ' . $post_id->get_error_message() ], 500 );
        }

        if ( $tags_raw ) {
            $tags = array_filter( array_map( 'trim', explode( ',', $tags_raw ) ) );
            wp_set_post_tags( $post_id, $tags, false );
        }

        if ( $source_url ) { update_post_meta( $post_id, '_he_source_url', $source_url ); }
        if ( ! empty( $source_urls ) ) { update_post_meta( $post_id, '_he_source_urls', $source_urls ); }
        if ( $ai_provider ) { update_post_meta( $post_id, '_he_ai_provider', $ai_provider ); }
        update_post_meta( $post_id, '_he_generated_by', 'HE Journalist Pro Tools ' . self::VERSION );

        if ( $meta ) {
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta );
            update_post_meta( $post_id, 'rank_math_description', $meta );
            update_post_meta( $post_id, '_seopress_titles_desc', $meta );
            update_post_meta( $post_id, '_he_meta_description', $meta );

            // Tema/editor HarianExpress memakai custom field ini untuk input:
            // <input type="text" name="single_post_subtitle" id="input-single_post_subtitle">
            // Isi dengan meta deskripsi yang dipilih agar langsung muncul di Post Subtitle.
            update_post_meta( $post_id, 'single_post_subtitle', $meta );
            update_post_meta( $post_id, '_single_post_subtitle', $meta );
        }



        $inserted_image_html = [];
        if ( ! empty( $selected_source_images ) ) {
            foreach ( $selected_source_images as $idx => $img ) {
                $img_url = $img['url'];
                $img_caption = $img['caption'];
                $attachment_id = $this->sideload_featured_image( $img_url, $post_id, $title, $img_caption );
                if ( ! is_wp_error( $attachment_id ) && $attachment_id ) {
                    if ( $idx === 0 ) {
                        set_post_thumbnail( $post_id, $attachment_id );
                        update_post_meta( $post_id, '_he_featured_image_source_url', $img_url );
                        if ( $img_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $img_caption ); }
                    } else {
                        $inserted = $this->build_inserted_image_html( $attachment_id, $img_caption );
                        if ( $inserted ) { $inserted_image_html[] = $inserted; }
                    }
                } else {
                    update_post_meta( $post_id, '_he_source_image_error_' . $idx, is_wp_error( $attachment_id ) ? $attachment_id->get_error_message() : 'Gagal mengunggah gambar sumber.' );
                }
            }
        } elseif ( $featured_image_url ) {
            $attachment_id = $this->sideload_featured_image( $featured_image_url, $post_id, $title, $featured_image_caption );
            if ( ! is_wp_error( $attachment_id ) && $attachment_id ) {
                set_post_thumbnail( $post_id, $attachment_id );
                update_post_meta( $post_id, '_he_featured_image_source_url', $featured_image_url );
                if ( $featured_image_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $featured_image_caption ); }
            } else {
                update_post_meta( $post_id, '_he_featured_image_error', is_wp_error( $attachment_id ) ? $attachment_id->get_error_message() : 'Gagal mengunggah featured image.' );
            }
        }

        if ( ! empty( $inserted_image_html ) ) {
            $content_with_images = $content . "\n\n" . implode( "\n\n", $inserted_image_html );
            wp_update_post( [
                'ID'           => $post_id,
                'post_content' => $content_with_images,
            ] );
            update_post_meta( $post_id, '_he_inserted_source_images_count', count( $inserted_image_html ) );
        }

        $this->add_history_event( [
            'title'      => $title,
            'source_url' => $source_url,
            'source_urls'=> ! empty( $source_urls ) ? $source_urls : ( $source_url ? [ $source_url ] : [] ),
            'provider'   => $ai_provider,
            'status'     => 'draft_created',
            'post_id'    => $post_id,
            'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
        ] );

        $this->update_history_generated_to_draft( $history_id, $post_id, get_edit_post_link( $post_id, 'raw' ) );

        wp_send_json_success( [
            'message'  => 'Draft berhasil dibuat!',
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link( $post_id, 'raw' ),
        ] );
    }
}

new HE_Journalist_Pro_Tools();

(function () {
    'use strict';

    const app = document.getElementById('he-subdomains-app');
    if (!app) return;

    const directoryEl = document.getElementById('heSubdomainDirectory');
    const alphabetEl = document.getElementById('heAlphabetNav');
    const searchEl = document.getElementById('heSubdomainSearch');
    const filterEl = document.getElementById('heSubdomainGroupFilter');
    const sortEl = document.getElementById('heSubdomainSort');
    const resetBtn = document.getElementById('heSubdomainReset');
    const statusEl = document.getElementById('heSubdomainStatus');
    const countEl = document.getElementById('heSubdomainCount');
    const groupCountEl = document.getElementById('heSubdomainGroupCount');
    const PRIMARY_DOMAIN = 'www.harianexpress.com';
    const latestMemory = new Map();
    let applyToken = 0;

    const getGroups = function () {
        try {
            if (typeof DOMAIN_GROUPS !== 'undefined' && DOMAIN_GROUPS && typeof DOMAIN_GROUPS === 'object') {
                return DOMAIN_GROUPS;
            }
        } catch (e) {}
        return null;
    };

    const escapeHTML = function (value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    };

    const stripHTML = function (value) {
        const div = document.createElement('div');
        div.innerHTML = String(value || '');
        return div.textContent || div.innerText || '';
    };

    const timeAgo = function (dateString) {
        if (!dateString) return '';
        const then = new Date(dateString);
        if (Number.isNaN(then.getTime())) return '';
        const seconds = Math.max(1, Math.floor((Date.now() - then.getTime()) / 1000));
        const units = [
            { label: 'tahun', value: 31536000 },
            { label: 'bulan', value: 2592000 },
            { label: 'minggu', value: 604800 },
            { label: 'hari', value: 86400 },
            { label: 'jam', value: 3600 },
            { label: 'menit', value: 60 }
        ];
        for (const unit of units) {
            const amount = Math.floor(seconds / unit.value);
            if (amount >= 1) return amount + ' ' + unit.label + ' yang lalu';
        }
        return 'baru saja';
    };

    const ageStatusClass = function (dateString) {
        if (!dateString) return 'bg-slate-50 text-slate-500 border-slate-100';
        const then = new Date(dateString);
        if (Number.isNaN(then.getTime())) return 'bg-slate-50 text-slate-500 border-slate-100';
        const days = Math.floor((Date.now() - then.getTime()) / 86400000);
        if (days < 7) return 'bg-emerald-50 text-emerald-700 border-emerald-100';
        if (days < 30) return 'bg-amber-50 text-amber-700 border-amber-100';
        return 'bg-red-50 text-red-700 border-red-100';
    };

    const showStatus = function (message, type) {
        if (!statusEl) return;
        statusEl.classList.remove('hidden', 'bg-red-50', 'border-red-100', 'text-red-700', 'bg-amber-50', 'border-amber-100', 'text-amber-700', 'bg-indigo-50', 'border-indigo-100', 'text-indigo-700');
        if (!message) {
            statusEl.classList.add('hidden');
            statusEl.textContent = '';
            return;
        }
        if (type === 'error') {
            statusEl.classList.add('bg-red-50', 'border-red-100', 'text-red-700');
        } else if (type === 'info') {
            statusEl.classList.add('bg-indigo-50', 'border-indigo-100', 'text-indigo-700');
        } else {
            statusEl.classList.add('bg-amber-50', 'border-amber-100', 'text-amber-700');
        }
        statusEl.textContent = message;
    };

    const normalizeDomain = function (domain) {
        return String(domain || '')
            .replace(/^https?:\/\//i, '')
            .replace(/\/.*$/, '')
            .trim()
            .toLowerCase();
    };

    const domainsFromGroup = function (groups, groupName) {
        const raw = groups && groups[groupName] ? groups[groupName] : '';
        return String(raw)
            .split(',')
            .map(normalizeDomain)
            .filter(Boolean)
            .filter((item, index, arr) => arr.indexOf(item) === index)
            .sort((a, b) => a.localeCompare(b, 'id'));
    };

    const groupByInitial = function (domains) {
        return domains.reduce((acc, domain) => {
            const initial = (domain.charAt(0) || '#').toUpperCase();
            if (!acc[initial]) acc[initial] = [];
            acc[initial].push(domain);
            return acc;
        }, {});
    };

    const makeUrl = function (domain, path) {
        return 'https://' + domain + path;
    };

    const renderAlphabet = function (groups) {
        const initials = Object.keys(groups).sort((a, b) => a.localeCompare(b, 'id'));
        alphabetEl.innerHTML = '';
        initials.forEach((initial) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'min-w-9 h-9 rounded-lg border border-slate-200 bg-white hover:bg-red-50 hover:border-red-200 hover:text-red-700 text-xs font-extrabold text-slate-600 transition-colors';
            btn.textContent = initial;
            btn.addEventListener('click', () => {
                const target = document.getElementById('he-letter-' + initial.replace(/[^A-Z0-9]/g, ''));
                if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
            alphabetEl.appendChild(btn);
        });
    };

    const articlePlaceholder = function (domain) {
        return `
            <div class="relative mt-3 rounded-xl bg-slate-50 border border-slate-100 px-3 py-2">
                <div class="text-[10px] uppercase tracking-wider text-slate-400 font-extrabold mb-1 flex items-center gap-1.5">
                    <i data-lucide="newspaper" class="w-3 h-3"></i> Artikel terbaru
                </div>
                <div class="he-latest-article text-xs text-slate-500 leading-relaxed" data-latest-domain="${escapeHTML(domain)}">
                    Memuat judul terbaru...
                </div>
            </div>
        `;
    };

    const createCardHTML = function (domain, isPrimary) {
        const safeDomain = escapeHTML(domain);
        return `
            <article class="group bg-white border ${isPrimary ? 'border-red-200 shadow-sm' : 'border-slate-200'} hover:border-red-200 hover:shadow-md rounded-2xl p-4 transition-all relative overflow-hidden">
                <div class="absolute -right-8 -top-8 w-24 h-24 bg-red-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div class="relative min-w-0 flex items-center justify-between gap-3">
                    <h3 class="font-extrabold ${isPrimary ? 'text-xl' : 'text-xl'} text-slate-900 truncate leading-tight" title="${safeDomain}">${safeDomain}</h3>
                    ${isPrimary ? '<span class="shrink-0 inline-flex items-center gap-1 rounded-full bg-red-50 border border-red-100 px-2 py-1 text-[10px] font-extrabold uppercase tracking-wider text-red-700"><i data-lucide="star" class="w-3 h-3"></i> Utama</span>' : ''}
                </div>
                ${articlePlaceholder(domain)}
                <div class="relative mt-4 grid grid-cols-4 gap-2">
                    <a href="${makeUrl(domain, '/')}" target="_blank" rel="noopener" class="inline-flex items-center justify-center rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-100 px-2.5 py-2 transition-colors" title="Buka website ${safeDomain}">
                        <i data-lucide="external-link" class="w-4 h-4"></i><span class="sr-only">Buka website</span>
                    </a>
                    <a href="${makeUrl(domain, '/pinarak.php')}" target="_blank" rel="noopener" class="inline-flex items-center justify-center rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-100 px-2.5 py-2 transition-colors" title="Login ${safeDomain}">
                        <i data-lucide="log-in" class="w-4 h-4"></i><span class="sr-only">Login</span>
                    </a>
                    <a href="${makeUrl(domain, '/wp-admin/')}" target="_blank" rel="noopener" class="inline-flex items-center justify-center rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-100 px-2.5 py-2 transition-colors" title="Dashboard ${safeDomain}">
                        <i data-lucide="layout-dashboard" class="w-4 h-4"></i><span class="sr-only">Dashboard</span>
                    </a>
                    <a href="${makeUrl(domain, '/wp-admin/admin.php?page=he-journalist')}" target="_blank" rel="noopener" class="inline-flex items-center justify-center rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-100 px-2.5 py-2 transition-colors" title="Tulis berita di ${safeDomain}">
                        <i data-lucide="wand-sparkles" class="w-4 h-4"></i><span class="sr-only">Tools</span>
                    </a>
                </div>
            </article>
        `;
    };

    const readLatestCache = function (domain) {
        if (latestMemory.has(domain)) return latestMemory.get(domain);
        try {
            const raw = sessionStorage.getItem('he_latest_' + domain);
            if (!raw) return null;
            const cached = JSON.parse(raw);
            if (!cached || !cached.title || !cached.time) return null;
            if ((Date.now() - cached.time) > 10 * 60 * 1000) return null;
            latestMemory.set(domain, cached);
            return cached;
        } catch (e) {
            return null;
        }
    };

    const writeLatestCache = function (domain, data) {
        if (!data) return;
        const item = { ...data, time: Date.now() };
        latestMemory.set(domain, item);
        try {
            sessionStorage.setItem('he_latest_' + domain, JSON.stringify(item));
        } catch (e) {}
    };

    const getCategoryFromPost = async function (domain, post, controller) {
        const embeddedTerms = post && post._embedded && post._embedded['wp:term'] ? post._embedded['wp:term'] : null;
        if (Array.isArray(embeddedTerms)) {
            for (const group of embeddedTerms) {
                if (!Array.isArray(group)) continue;
                const category = group.find((term) => term && term.taxonomy === 'category' && term.name);
                if (category && category.name) return category.name;
            }
        }
        if (post && Array.isArray(post.categories) && post.categories.length) {
            try {
                const catId = post.categories[0];
                const catResponse = await fetch(makeUrl(domain, '/wp-json/wp/v2/categories/' + catId + '?_fields=name'), { credentials: 'omit', signal: controller.signal });
                if (catResponse.ok) {
                    const cat = await catResponse.json();
                    if (cat && cat.name) return cat.name;
                }
            } catch (e) {}
        }
        return '';
    };

    const fetchLatestData = async function (domain) {
        const cached = readLatestCache(domain);
        if (cached) return cached;

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        try {
            const response = await fetch(makeUrl(domain, '/wp-json/wp/v2/posts?per_page=1&_embed=1'), { credentials: 'omit', signal: controller.signal });
            if (!response.ok) throw new Error('HTTP ' + response.status);
            const posts = await response.json();
            const first = Array.isArray(posts) ? posts[0] : null;
            let data = null;
            if (first) {
                const category = await getCategoryFromPost(domain, first, controller);
                data = {
                    title: (first.title && (first.title.rendered || first.title.raw)) ? stripHTML(first.title.rendered || first.title.raw) : '',
                    link: first.link || '',
                    date: first.date || first.modified || '',
                    category: category || ''
                };
            }
            if (data && data.title) writeLatestCache(domain, data);
            return data;
        } catch (e) {
            return null;
        } finally {
            clearTimeout(timer);
        }
    };

    const renderLatestArticle = function (node, data) {
        if (!node) return;
        if (!data || !data.title) {
            node.innerHTML = '<span class="text-slate-400 italic">Judul terbaru tidak tersedia.</span>';
            return;
        }
        const title = escapeHTML(data.title);
        const link = data.link ? escapeHTML(data.link) : '';
        const category = data.category ? escapeHTML(data.category) : '';
        const ago = timeAgo(data.date);
        const ageClass = ageStatusClass(data.date);
        const titleHTML = link
            ? `<a href="${link}" target="_blank" rel="noopener" class="font-semibold text-slate-700 hover:text-red-600 hover:underline line-clamp-2">${title}</a>`
            : `<span class="font-semibold text-slate-700 line-clamp-2">${title}</span>`;
        const timeBadge = ago ? `<span class="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 ${ageClass}"><i data-lucide="clock-3" class="w-3 h-3"></i>${escapeHTML(ago)}</span>` : '';
        const categoryBadge = category ? `<span class="inline-flex items-center gap-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 px-2 py-0.5"><i data-lucide="tag" class="w-3 h-3"></i>${category}</span>` : '';
        node.innerHTML = `${titleHTML}<div class="mt-2 flex flex-wrap items-center gap-1.5 text-[11px] font-semibold">${timeBadge}${categoryBadge}</div>`;
        if (window.lucide) lucide.createIcons();
    };

    const fetchLatestArticle = async function (domain, node) {
        const data = await fetchLatestData(domain);
        renderLatestArticle(node, data);
    };

    const loadLatestArticles = function () {
        const nodes = Array.from(directoryEl.querySelectorAll('[data-latest-domain]'));
        nodes.forEach((node) => {
            const domain = node.getAttribute('data-latest-domain');
            if (domain) fetchLatestArticle(domain, node);
        });
    };

    const renderCards = function (domains, flatMode) {
        const primary = domains.includes(PRIMARY_DOMAIN) ? PRIMARY_DOMAIN : null;
        const rest = domains.filter((domain) => domain !== PRIMARY_DOMAIN);
        const grouped = groupByInitial(rest);
        renderAlphabet(grouped);
        directoryEl.innerHTML = '';

        if (!domains.length) {
            directoryEl.innerHTML = '<div class="text-center py-14 bg-slate-50 rounded-2xl border border-dashed border-slate-200"><div class="text-slate-400 mb-2"><i data-lucide="search-x" class="w-10 h-10 mx-auto"></i></div><h3 class="text-base font-bold text-slate-700">Tidak ada subdomain ditemukan</h3><p class="text-sm text-slate-500 mt-1">Coba refresh pencarian atau pilih grup lain.</p></div>';
            if (window.lucide) lucide.createIcons();
            return;
        }

        if (primary) {
            const utama = document.createElement('section');
            utama.className = 'scroll-mt-8';
            utama.innerHTML = `
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-11 h-11 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-sm"><i data-lucide="star" class="w-5 h-5"></i></div>
                    <div><div class="text-lg font-extrabold text-slate-900">Utama</div><p class="text-xs text-slate-500 font-medium">Website utama HarianExpress</p></div>
                    <div class="h-px bg-slate-200 flex-1"></div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">${createCardHTML(primary, true)}</div>
            `;
            directoryEl.appendChild(utama);
        }

        if (flatMode) {
            const section = document.createElement('section');
            section.className = 'scroll-mt-8';
            section.innerHTML = '<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4"></div>';
            const grid = section.querySelector('div');
            rest.forEach((domain) => {
                const wrapper = document.createElement('div');
                wrapper.innerHTML = createCardHTML(domain, false);
                grid.appendChild(wrapper.firstElementChild);
            });
            directoryEl.appendChild(section);
        } else {
            Object.keys(grouped).sort((a, b) => a.localeCompare(b, 'id')).forEach((initial) => {
                const safeInitial = initial.replace(/[^A-Z0-9]/g, '');
                const section = document.createElement('section');
                section.id = 'he-letter-' + safeInitial;
                section.className = 'scroll-mt-8';

                const title = document.createElement('div');
                title.className = 'flex items-center gap-3 mb-4';
                title.innerHTML = '<div class="w-11 h-11 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-lg font-extrabold shadow-sm">' + initial + '</div><div><p class="text-xs text-slate-500 font-medium">' + grouped[initial].length + ' subdomain</p></div><div class="h-px bg-slate-200 flex-1"></div>';
                section.appendChild(title);

                const grid = document.createElement('div');
                grid.className = 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4';

                grouped[initial].forEach((domain) => {
                    const wrapper = document.createElement('div');
                    wrapper.innerHTML = createCardHTML(domain, false);
                    grid.appendChild(wrapper.firstElementChild);
                });

                section.appendChild(grid);
                directoryEl.appendChild(section);
            });
        }

        if (window.lucide) lucide.createIcons();
        loadLatestArticles();
    };

    const sortDomainsByMode = async function (domains, mode, token) {
        if (mode !== 'latest_desc' && mode !== 'latest_asc') {
            return domains.sort((a, b) => a.localeCompare(b, 'id'));
        }
        showStatus('Mengambil data artikel terbaru untuk menyusun sortir update...', 'info');
        await Promise.all(domains.map((domain) => fetchLatestData(domain)));
        if (token !== applyToken) return domains;
        showStatus('', 'info');
        const primary = domains.includes(PRIMARY_DOMAIN) ? PRIMARY_DOMAIN : null;
        const rest = domains.filter((domain) => domain !== PRIMARY_DOMAIN);
        rest.sort((a, b) => {
            const da = readLatestCache(a);
            const db = readLatestCache(b);
            const ta = da && da.date ? Date.parse(da.date) : 0;
            const tb = db && db.date ? Date.parse(db.date) : 0;
            if (ta === tb) return a.localeCompare(b, 'id');
            if (!ta) return 1;
            if (!tb) return -1;
            return mode === 'latest_desc' ? tb - ta : ta - tb;
        });
        return primary ? [primary, ...rest] : rest;
    };

    const populateFilter = function (groups) {
        const names = Object.keys(groups || {}).sort((a, b) => a.localeCompare(b, 'id'));
        filterEl.innerHTML = '';
        names.forEach((name) => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = 'Grup: ' + name;
            filterEl.appendChild(opt);
        });
        if (names.includes('all')) filterEl.value = 'all';
        if (groupCountEl) groupCountEl.textContent = names.length;
    };

    const init = function () {
        const groups = getGroups();
        if (!groups || !groups.all) {
            showStatus('Gagal membaca DOMAIN_GROUPS dari https://yanuarzg.github.io/cc/he/all.js. Cek koneksi atau izin browser.', 'error');
            renderCards([]);
            return;
        }

        populateFilter(groups);

        const apply = async function () {
            const token = ++applyToken;
            const groupName = filterEl.value || 'all';
            const keyword = (searchEl.value || '').trim().toLowerCase();
            const sortMode = sortEl ? (sortEl.value || 'az') : 'az';
            let domains = domainsFromGroup(groups, groupName);
            if (keyword) {
                domains = domains.filter((domain) => domain.includes(keyword));
            }
            if (countEl) countEl.textContent = domains.length;
            domains = await sortDomainsByMode(domains, sortMode, token);
            if (token !== applyToken) return;
            renderCards(domains, sortMode !== 'az');
        };

        searchEl.addEventListener('input', apply);
        filterEl.addEventListener('change', apply);
        if (sortEl) sortEl.addEventListener('change', apply);
        resetBtn.addEventListener('click', function () {
            searchEl.value = '';
            if (groups.all) filterEl.value = 'all';
            if (sortEl) sortEl.value = 'az';
            apply();
            searchEl.focus();
        });

        apply();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

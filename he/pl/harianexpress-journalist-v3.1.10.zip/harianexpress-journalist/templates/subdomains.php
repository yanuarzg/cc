<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div id="he-subdomains-app" class="heaj-wrap text-slate-800 antialiased min-h-screen">
    <header class="bg-slate-900 text-white shadow-lg relative z-10 border-b border-slate-800 rounded-xl overflow-hidden mb-6">
        <div class="absolute inset-0 opacity-20 pointer-events-none" style="background: radial-gradient(circle at top right, rgba(239,68,68,.55), transparent 36%), radial-gradient(circle at bottom left, rgba(99,102,241,.35), transparent 32%);"></div>
        <div class="relative max-w-7xl mx-auto px-5 sm:px-7 lg:px-8 py-7 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
            <div class="flex items-start gap-4">
                <div class="relative flex items-center justify-center shrink-0 mt-1">
                    <div class="absolute inset-0 bg-red-500 rounded-xl blur opacity-40"></div>
                    <div class="relative z-10 bg-slate-950 border border-red-500/40 rounded-xl p-3 shadow-lg">
                        <i data-lucide="network" class="w-7 h-7 text-red-400"></i>
                    </div>
                </div>
                <div>
                    <p class="text-[11px] uppercase tracking-[0.28em] text-red-300 font-bold mb-2">HarianExpress Network</p>
                    <h1 class="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight">Semua Subdomain</h1>
                    <p class="text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">Directory A-Z network subdomain HarianExpress. Gunakan pintasan Login, Dashboard, atau Tools sesuai akses admin masing-masing.</p>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3 text-center shrink-0">
                <div class="bg-white/10 border border-white/10 rounded-2xl px-5 py-3 backdrop-blur shadow-inner">
                    <div id="heSubdomainCount" class="text-2xl font-extrabold text-white leading-none">0</div>
                    <div class="text-[10px] uppercase tracking-wider text-slate-300 mt-1 font-semibold">Subdomain</div>
                </div>
                <div class="bg-white/10 border border-white/10 rounded-2xl px-5 py-3 backdrop-blur shadow-inner">
                    <div id="heSubdomainGroupCount" class="text-2xl font-extrabold text-white leading-none">0</div>
                    <div class="text-[10px] uppercase tracking-wider text-slate-300 mt-1 font-semibold">Grup</div>
                </div>
            </div>
        </div>
    </header>

    <section class="max-w-7xl mx-auto bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div class="p-5 sm:p-6 border-b border-slate-100 bg-slate-50/80">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
                <div class="lg:col-span-5 relative">
                    <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"></i>
                    <input id="heSubdomainSearch" type="search" class="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm input-ring" placeholder="Cari subdomain, contoh: tekno, bali, humaniora...">
                </div>
                <div class="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <select id="heSubdomainGroupFilter" class="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm input-ring">
                        <option value="all">Grup: all</option>
                    </select>
                    <select id="heSubdomainSort" class="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm input-ring">
                        <option value="az">Sortir: A-Z</option>
                        <option value="latest_desc">Sortir: paling update</option>
                        <option value="latest_asc">Sortir: paling lama update</option>
                    </select>
                </div>
                <div class="lg:col-span-4 flex flex-wrap gap-2 justify-start lg:justify-end">
                    <button type="button" id="heSubdomainReset" class="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl px-4 py-3 text-xs font-bold shadow-sm transition-all">
                        <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i> Refresh
                    </button>
                    <a href="https://wa.me/6289507785333" target="_blank" rel="noopener" class="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-4 py-3 text-xs font-bold shadow-sm transition-all">
                        <i data-lucide="plus-circle" class="w-3.5 h-3.5"></i> +domain
                    </a>
                </div>
            </div>
            <div id="heAlphabetNav" class="mt-5 flex flex-wrap gap-1.5"></div>
        </div>

        <div id="heSubdomainStatus" class="hidden m-5 rounded-xl border px-4 py-3 text-sm"></div>
        <div id="heSubdomainDirectory" class="p-5 sm:p-6 space-y-8"></div>
    </section>

    <footer class="max-w-7xl mx-auto mt-6 mb-4 text-xs text-slate-500 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <span>Login tetap mengikuti hak akses admin di masing-masing subdomain.</span>
        <span>&copy; 2026 <a href="https://yanuarzg.github.io/" target="_blank" rel="noopener" class="font-bold text-red-600 hover:text-red-700">YZG</a></span>
    </footer>
</div>

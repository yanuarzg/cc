=== HarianExpress AI Journalist Pro Tools ===
Contributors: yanuarzg
Tags: ai, journalist, gemini, grok, zai, seo, harianexpress
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 3.1.10
License: GPLv2 or later

AI Journalist Generator untuk HarianExpress dengan rotasi API, output SEO, draft sosial media, skrip video, draft WordPress, dan directory Semua Subdomain.

== Changelog ==

= 3.1.10 =
* Tambah mode sumber URL terkunci: WordPress mengambil teks artikel sumber di server dan mengirimkannya langsung ke AI.
* Jika URL sumber berhasil diekstrak, pencarian AI dimatikan agar artikel hanya memakai teks sumber yang sudah diambil server.
* Perketat instruksi agar tanggal, jam, angka, lokasi, nama narasumber, jabatan, dan kutipan langsung harus sama persis dengan sumber.
* Tambah dukungan ekstraksi konten untuk class artikel umum seperti detail__body, detail__body-text, read__content, dan article__content.

= 3.1.7 =
* Perbaikan error Grok/xAI HTTP 403.
* API key Grok/Z.AI yang ditolak 401/403 otomatis diblokir dan dilewati.
* Fallback otomatis ke Gemini jika Grok/Z.AI gagal.

= 3.1.6 =
* Tambah dukungan provider AI Grok/xAI dan Z.AI pada Generator Artikel.
* Tambah input API Grok/xAI dan Z.AI di Pengaturan API.
* Hapus block info Lisensi Domain via GitHub dari halaman Pengaturan API.
* Tambah tautan Ambil API Key Gemini sebelum input API Key Tambahan.

= 3.1.5 =
* Auto-block API key bocor/invalid/expired/disabled dari respons Gemini.
* Status API key aktif/terblokir di Pengaturan API.
* Perbaikan update checker agar notifikasi update tidak muncul saat versi remote sama.

= 3.1.4 =
* Lisensi domain dibaca dari GitHub licenses.json.
* Tambah contoh licenses.json untuk menambah domain pembeli lisensi tanpa rilis ulang plugin.

= 3.1.3 =
* Filter gambar sumber: hanya dari area artikel atau image minimal 320px agar ikon/gambar kecil tidak tampil.
* Tambah pembatasan lisensi domain untuk harianexpress.com, subdomain harianexpress.com, harianexpress.id, subdomain harianexpress.id, dan geky.page.gd.
* Redirect domain tidak terdaftar ke https://yanuarzg.github.io/.
* Tambah tombol Beli Lisensi di footer sebelum Dibangun oleh YZG.

= 3.1 =
* Mobile responsive.

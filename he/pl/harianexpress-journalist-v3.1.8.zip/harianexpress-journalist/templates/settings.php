<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="wrap he-settings-wrap">
    <h1 class="he-settings-title">
        <span class="he-logo-icon">HE</span>
        HarianExpress <span class="he-red">Pengaturan API</span>
    </h1>

    <?php if ( isset( $_GET['settings-updated'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Pengaturan berhasil disimpan.</strong></p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['heaj-blocked-reset'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p><strong>Daftar API key terblokir sudah dikosongkan.</strong></p></div>
    <?php endif; ?>

    <div class="he-settings-card">
        <form method="post" action="options.php">
            <?php settings_fields( 'he_journalist_options' ); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">API Default</th>
                    <td>
                        <p>Plugin membawa API default untuk Gemini, Grok/xAI, dan Z.AI. Jika salah satu key terkena limit/gagal, sistem akan mencoba key berikutnya sesuai provider yang dipilih.</p>
                        <p class="description">API dipakai di server melalui AJAX WordPress dan ditampilkan dalam bentuk sensor.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>">API Gemini Tambahan</label></th>
                    <td>
                        <p class="he-api-actions"><a class="button button-secondary" href="https://aistudio.google.com/api-keys" target="_blank" rel="noopener">Ambil API Key Gemini</a></p>
                        <textarea
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS ); ?>"
                            rows="6"
                            class="large-text code"
                            placeholder="Satu API key Gemini per baris"
                        ><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_EXTRA_API_KEYS, '' ) ); ?></textarea>
                        <p class="description">Tambahkan API Gemini lain untuk menambah antrean rotasi. Total Gemini aktif saat ini: <strong><?php echo esc_html( $all_count ); ?></strong>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS ); ?>">API Grok / xAI Tambahan</label></th>
                    <td>
                        <p class="he-api-actions"><a class="button button-secondary" href="https://console.x.ai/" target="_blank" rel="noopener">Ambil API Key Grok / xAI</a></p>
                        <textarea
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS ); ?>"
                            rows="4"
                            class="large-text code"
                            placeholder="xai-...&#10;xai-..."
                        ><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_GROK_API_KEYS, '' ) ); ?></textarea>
                        <p class="description">Plugin sudah membawa 1 API Grok/xAI default. Tambahkan API sendiri jika ingin menambah rotasi Grok. API aktif: <strong><?php echo esc_html( $grok_keys_count ); ?></strong>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS ); ?>">API Z.AI Tambahan</label></th>
                    <td>
                        <p class="he-api-actions"><a class="button button-secondary" href="https://z.ai/manage-apikey/apikey-list" target="_blank" rel="noopener">Ambil API Key Z.AI</a></p>
                        <textarea
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS ); ?>"
                            rows="4"
                            class="large-text code"
                            placeholder="Z.AI API key, satu key per baris"
                        ><?php echo esc_textarea( get_option( HE_Journalist_Pro_Tools::OPTION_ZAI_API_KEYS, '' ) ); ?></textarea>
                        <p class="description">Plugin sudah membawa 1 API Z.AI default. Tambahkan API sendiri jika ingin menambah rotasi Z.AI. API aktif: <strong><?php echo esc_html( $zai_keys_count ); ?></strong>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Status API Key</th>
                    <td>
                        <div class="he-api-status-box">
                            <?php if ( empty( $api_key_pool_all ) ) : ?>
                                <p class="description">Belum ada API key yang terdaftar.</p>
                            <?php else : ?>
                                <table class="widefat striped he-api-status-table">
                                    <thead>
                                        <tr>
                                            <th>Provider</th>
                                            <th>Urutan</th>
                                            <th>Sumber</th>
                                            <th>API Key</th>
                                            <th>Status</th>
                                            <th>Catatan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ( $api_key_pool_all as $api_item ) : ?>
                                            <?php $is_blocked = ! empty( $api_item['blocked'] ); ?>
                                            <tr>
                                                <td><strong><?php echo esc_html( $api_item['provider'] ); ?></strong></td>
                                                <td><?php echo esc_html( $api_item['order'] ); ?></td>
                                                <td><?php echo esc_html( $api_item['label'] ); ?></td>
                                                <td><code><?php echo esc_html( $api_item['masked'] ); ?></code></td>
                                                <td>
                                                    <?php if ( $is_blocked ) : ?>
                                                        <span class="he-status-badge he-status-blocked">Diblokir otomatis</span>
                                                    <?php else : ?>
                                                        <span class="he-status-badge he-status-active">Aktif</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ( $is_blocked ) : ?>
                                                        <?php $block_info = is_array( $api_item['block_info'] ) ? $api_item['block_info'] : []; ?>
                                                        <span title="<?php echo esc_attr( $block_info['reason'] ?? '' ); ?>">
                                                            <?php echo esc_html( $block_info['blocked_at'] ?? '' ); ?> — <?php echo esc_html( wp_trim_words( $block_info['reason'] ?? 'Provider AI menolak API key ini.', 12 ) ); ?>
                                                        </span>
                                                    <?php else : ?>
                                                        Siap dipakai untuk rotasi.
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <p class="description">Jika provider melaporkan API key bocor, invalid, expired, disabled, atau forbidden, plugin otomatis menandai key tersebut dan melewatinya pada generate berikutnya.</p>
                            <?php endif; ?>

                            <?php if ( ! empty( $blocked_api_keys ) ) : ?>
                                <div class="he-reset-blocked-form">
                                    <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=heaj_reset_blocked_api_keys' ), 'heaj_reset_blocked_api_keys' ) ); ?>">Reset API Key Terblokir</a>
                                    <span class="description">Gunakan hanya setelah API key bermasalah sudah diganti atau diperbaiki.</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>">Model Gemini</label></th>
                    <td>
                        <?php $selected_model = get_option( HE_Journalist_Pro_Tools::OPTION_MODEL, 'gemini-2.5-flash' ); ?>
                        <select
                            id="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>"
                            name="<?php echo esc_attr( HE_Journalist_Pro_Tools::OPTION_MODEL ); ?>"
                            class="regular-text"
                        >
                            <?php foreach ( HE_Journalist_Pro_Tools::supported_models() as $model_code => $model_label ) : ?>
                                <option value="<?php echo esc_attr( $model_code ); ?>" <?php selected( $selected_model, $model_code ); ?>><?php echo esc_html( $model_label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Daftar berisi model teks Gemini yang relevan untuk generate artikel. Default stabil: <code>gemini-2.5-flash</code>.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Simpan Pengaturan' ); ?>
        </form>
    </div>

    <div class="he-info-card">
        <h3>Informasi Plugin</h3>
        <ul>
            <li><strong>Menu Generator:</strong> HE Journalist → Generator Artikel</li>
            <li><strong>Draft WordPress:</strong> Judul, slug, kategori, tag, dan meta deskripsi otomatis masuk ke post draft.</li>
            <li><strong>Provider AI:</strong> Generator mendukung Gemini, Grok/xAI, dan Z.AI sesuai API yang tersedia.</li>
            <li><strong>Auto Block:</strong> API key yang ditolak permanen oleh provider akan diblokir otomatis dan dilewati pada request berikutnya.</li>
        </ul>
    </div>
</div>

<style>
.he-settings-wrap{max-width:980px}.he-settings-title{display:flex;align-items:center;gap:10px;margin-bottom:20px}.he-logo-icon{background:#dc2626;color:#fff;font-weight:800;padding:4px 10px;border-radius:6px;font-size:14px}.he-red{color:#dc2626}.he-settings-card{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:24px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.05)}.he-info-card{background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:20px}.he-info-card h3{margin-top:0;color:#1e40af}.he-info-card ul{margin:0;padding-left:20px;color:#1e3a8a}.he-info-card li{margin-bottom:8px}.he-api-actions{margin-top:0;margin-bottom:8px}.he-api-status-table{margin-top:8px}.he-status-badge{display:inline-block;padding:3px 8px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}.he-status-active{background:#dcfce7;color:#166534}.he-status-blocked{background:#fee2e2;color:#991b1b}.he-reset-blocked-form{margin-top:12px;display:flex;align-items:center;gap:10px;flex-wrap:wrap}
</style>

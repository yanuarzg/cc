<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$settings = is_array( $settings ?? null ) ? $settings : HE_Journalist_Pro_Tools::default_auto_news_settings();
$next_run = wp_next_scheduled( HE_Journalist_Pro_Tools::AUTO_NEWS_MASTER_HOOK );
$last_run = absint( $last_run ?? 0 );
$last_result = is_array( $last_result ?? null ) ? $last_result : [];
$custom_settings = $this->get_custom_settings();
$langs = is_array( $custom_settings['languages'] ?? null ) ? $custom_settings['languages'] : [ [ 'code' => 'id', 'label' => 'Bahasa Indonesia' ], [ 'code' => 'en', 'label' => 'English' ] ];
$auto_news_author_users = is_array( $auto_news_author_users ?? null ) ? $auto_news_author_users : [];
$selected_author_id = absint( $settings['author_user_id'] ?? 0 ) ?: get_current_user_id();
$auto_news_license_valid = ! empty( $auto_news_license_valid );
$queue = is_array( $queue ?? null ) ? $queue : [];
$queue_counts = [ 'queued' => 0, 'retry' => 0, 'processing' => 0, 'published' => 0, 'drafted' => 0, 'skipped_no_image' => 0, 'failed' => 0 ];
foreach ( $queue as $job ) {
    $st = sanitize_key( $job['status'] ?? '' );
    if ( isset( $queue_counts[ $st ] ) ) { $queue_counts[ $st ]++; }
}
$gt_schedule_type = sanitize_key( $settings['gt_schedule_type'] ?? 'hours' );
if ( $gt_schedule_type === 'realtime' ) { $gt_schedule_type = 'minutes'; }
$gt_schedule_value = absint( $settings['gt_schedule_value'] ?? 1 );
if ( $gt_schedule_type === 'minutes' ) { $gt_schedule_value = max( 15, $gt_schedule_value ); }
?>
<div class="wrap heaj-admin-wrap">
    <h1 class="wp-heading-inline">AutoPilot Artikel</h1>

    <?php if ( ! $auto_news_license_valid ) : ?>
        <div class="notice notice-error"><p><strong>Lisensi belum valid.</strong> AutoPilot Artikel dikunci.</p></div>
    <?php endif; ?>
    <?php if ( isset( $_GET['saved'] ) ) : ?>
        <div class="notice notice-success is-dismissible"><p>Pengaturan disimpan.</p></div>
    <?php endif; ?>

    <div class="heaj-card" style="max-width:980px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:22px;margin-top:16px;">
        <form id="heajAutoArticleForm" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'heaj_save_auto_news' ); ?>
            <input type="hidden" name="action" value="heaj_save_auto_news">
            <input type="hidden" name="auto_news[enabled]" value="1">
            <input type="hidden" name="auto_news[feed_mode]" value="autopilot">
            <input type="hidden" name="auto_news[keyword_pick_mode]" value="sequential">
            <input type="hidden" name="auto_news[keywords_per_run]" value="1">
            <input type="hidden" name="auto_news[keyword_cycle_reset]" value="0">
            <input type="hidden" name="auto_news[kw_schedule_type]" value="hours">
            <input type="hidden" name="auto_news[kw_schedule_value]" value="1">

            <fieldset <?php disabled( ! $auto_news_license_valid ); ?> style="border:0;margin:0;padding:0;">
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><label for="heajAutoFocus">Topik Fokus</label></th>
                            <td>
                                <textarea id="heajAutoFocus" name="auto_news[manual_keywords]" rows="4" class="large-text code" placeholder="Opsional, satu topik per baris"><?php echo esc_textarea( $settings['manual_keywords'] ?? '' ); ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Jadwal Publish</th>
                            <td>
                                <label style="display:block;margin:0 0 8px;"><input type="radio" name="auto_news[gt_schedule_type]" value="minutes" <?php checked( $gt_schedule_type, 'minutes' ); ?>> Menit</label>
                                <label style="display:block;margin:0 0 8px;"><input type="radio" name="auto_news[gt_schedule_type]" value="hours" <?php checked( $gt_schedule_type, 'hours' ); ?>> Jam</label>
                                <label style="display:block;margin:0 0 8px;"><input type="radio" name="auto_news[gt_schedule_type]" value="days" <?php checked( $gt_schedule_type, 'days' ); ?>> Hari</label>
                                <input id="heajGtScheduleValue" type="number" min="1" max="1440" name="auto_news[gt_schedule_value]" value="<?php echo esc_attr( $gt_schedule_value ); ?>" style="width:86px;"> <span id="heajScheduleUnitLabel"></span>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="heajProxyRss">Proxy RSS</label></th>
                            <td>
                                <textarea id="heajProxyRss" name="auto_news[feed_proxy_urls]" rows="3" class="large-text code" placeholder="Opsional: https://site-proxy.com/wp-json/heaj-auto-artikel/v1/rss-proxy?url={url}"><?php echo esc_textarea( $settings['feed_proxy_urls'] ?? '' ); ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="heajAutoLang">Bahasa</label></th>
                            <td>
                                <select id="heajAutoLang" name="auto_news[language]" class="regular-text">
                                    <?php foreach ( $langs as $lang_row ) :
                                        $code = sanitize_key( $lang_row['code'] ?? '' );
                                        if ( ! in_array( $code, [ 'id', 'en' ], true ) ) { continue; }
                                    ?>
                                        <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $settings['language'] ?? 'id', $code ); ?>><?php echo esc_html( $lang_row['label'] ?? strtoupper( $code ) ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="heajAutoAuthor">Penulis</label></th>
                            <td>
                                <select id="heajAutoAuthor" name="auto_news[author_user_id]" class="regular-text">
                                    <?php foreach ( $auto_news_author_users as $user_row ) : ?>
                                        <option value="<?php echo esc_attr( absint( $user_row->ID ) ); ?>" <?php selected( $selected_author_id, absint( $user_row->ID ) ); ?>><?php echo esc_html( $user_row->display_name . ' (@' . $user_row->user_login . ')' ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </fieldset>

            <p class="submit" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                <button type="submit" class="button button-primary" <?php disabled( ! $auto_news_license_valid ); ?>>Simpan</button>
                <button type="button" id="heajAutoRunNowBtn" class="button button-secondary" <?php disabled( ! $auto_news_license_valid ); ?>>Mulai Sekarang</button>
                <span id="heajAutoRunSpinner" class="spinner" style="float:none;margin:0;"></span>
            </p>
            <div id="heajAutoRunFeedback" style="display:none;margin-top:10px;padding:12px;border-left:4px solid #2271b1;background:#f6f7f7;"></div>
        </form>
    </div>

    <div class="heaj-card" style="max-width:980px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px;margin-top:16px;">
        <h2 style="margin-top:0;">Status</h2>
        <p><strong>Master cron:</strong> <?php echo $next_run ? esc_html( wp_date( 'Y-m-d H:i:s', $next_run ) ) : 'Belum terjadwal'; ?></p>
        <p><strong>Jadwal publish:</strong> <?php echo ! empty( $auto_news_next_publish_ts ) ? esc_html( wp_date( 'Y-m-d H:i:s', absint( $auto_news_next_publish_ts ) ) ) : 'Menunggu run pertama'; ?></p>
        <p><strong>Last run:</strong> <?php echo $last_run ? esc_html( wp_date( 'Y-m-d H:i:s', $last_run ) ) : 'Belum ada'; ?></p>
        <?php if ( ! empty( $last_result ) ) : ?>
            <p><strong>Hasil:</strong>
                checked <?php echo esc_html( absint( $last_result['checked'] ?? 0 ) ); ?>,
                queued <?php echo esc_html( absint( $last_result['queued_now'] ?? 0 ) ); ?>,
                processed <?php echo esc_html( absint( $last_result['processed_queue'] ?? 0 ) ); ?>,
                created <?php echo esc_html( absint( $last_result['created'] ?? 0 ) ); ?>,
                skipped <?php echo esc_html( absint( $last_result['skipped'] ?? 0 ) ); ?>,
                failed <?php echo esc_html( absint( $last_result['failed'] ?? 0 ) ); ?>
            </p>
            <?php if ( ! empty( $last_result['message'] ) ) : ?><p><strong>Pesan:</strong> <?php echo esc_html( $last_result['message'] ); ?></p><?php endif; ?>
            <?php if ( ! empty( $last_result['last_error'] ) ) : ?><p><strong>Error:</strong> <?php echo esc_html( $last_result['last_error'] ); ?></p><?php endif; ?>
        <?php endif; ?>
        <p><strong>Queue:</strong>
            queued <?php echo esc_html( absint( $queue_counts['queued'] ) ); ?>,
            retry <?php echo esc_html( absint( $queue_counts['retry'] ) ); ?>,
            processing <?php echo esc_html( absint( $queue_counts['processing'] ) ); ?>,
            drafted <?php echo esc_html( absint( $queue_counts['drafted'] ) ); ?>,
            published <?php echo esc_html( absint( $queue_counts['published'] ) ); ?>,
            skipped <?php echo esc_html( absint( $queue_counts['skipped_no_image'] ) ); ?>,
            failed <?php echo esc_html( absint( $queue_counts['failed'] ) ); ?>
        </p>
    </div>
</div>
<script>
(function(){
    function syncScheduleBounds(){
        var checked = document.querySelector('input[name="auto_news[gt_schedule_type]"]:checked');
        var input = document.getElementById('heajGtScheduleValue');
        var unit = document.getElementById('heajScheduleUnitLabel');
        if (!checked || !input) return;
        if (checked.value === 'minutes') {
            input.min = '15'; input.max = '1440'; if (parseInt(input.value || '0', 10) < 15) input.value = '15'; if (unit) unit.textContent = 'menit';
        } else if (checked.value === 'days') {
            input.min = '1'; input.max = '30'; if (parseInt(input.value || '0', 10) > 30) input.value = '30'; if (unit) unit.textContent = 'hari';
        } else {
            input.min = '1'; input.max = '24'; if (parseInt(input.value || '0', 10) > 24) input.value = '24'; if (unit) unit.textContent = 'jam';
        }
    }
    document.querySelectorAll('input[name="auto_news[gt_schedule_type]"]').forEach(function(el){ el.addEventListener('change', syncScheduleBounds); });
    syncScheduleBounds();

    var runBtn = document.getElementById('heajAutoRunNowBtn');
    var form = document.getElementById('heajAutoArticleForm');
    var feedback = document.getElementById('heajAutoRunFeedback');
    var spinner = document.getElementById('heajAutoRunSpinner');
    function setFeedback(type, html){
        if (!feedback) return;
        feedback.style.display = 'block';
        feedback.style.borderLeftColor = type === 'error' ? '#d63638' : (type === 'success' ? '#00a32a' : '#2271b1');
        feedback.innerHTML = html;
    }
    if (runBtn && form) {
        runBtn.addEventListener('click', function(){
            var data = new FormData(form);
            data.set('action', 'heaj_auto_news_run_now_ui');
            data.set('nonce', '<?php echo esc_js( wp_create_nonce( 'heaj_auto_news_run_now_ui' ) ); ?>');
            runBtn.disabled = true;
            if (spinner) spinner.classList.add('is-active');
            setFeedback('info', '<strong>Memproses...</strong>');
            fetch(window.ajaxurl || ajaxurl, { method: 'POST', credentials: 'same-origin', body: data })
                .then(function(res){ return res.json(); })
                .then(function(json){
                    var ok = json && json.success;
                    var payload = ok ? json.data : (json && json.data ? json.data : {});
                    var result = payload.result || {};
                    var html = '<strong>' + (payload.message || (ok ? 'Selesai.' : 'Gagal.')) + '</strong>';
                    html += '<br>Checked: ' + (result.checked || 0) + ', queued: ' + (result.queued_now || 0) + ', processed: ' + (result.processed_queue || 0) + ', created: ' + (result.created || 0) + ', skipped: ' + (result.skipped || 0) + ', failed: ' + (result.failed || 0) + '.';
                    setFeedback(ok && (result.created || 0) > 0 ? 'success' : (ok ? 'info' : 'error'), html);
                })
                .catch(function(err){ setFeedback('error', '<strong>Request gagal.</strong><br>' + (err && err.message ? err.message : 'Unknown error.')); })
                .finally(function(){ runBtn.disabled = false; if (spinner) spinner.classList.remove('is-active'); });
        });
    }
})();
</script>

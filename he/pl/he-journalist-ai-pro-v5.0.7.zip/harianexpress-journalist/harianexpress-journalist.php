<?php
/**
 * Plugin Name: YZG AI Journalist
 * Plugin URI:  https://yanuarzg.github.io/
 * Description: White-label AI editorial assistant untuk generate artikel, audit fakta, SEO metadata, gambar sumber/Pexels, dan kirim ke Draft WordPress.
 * Version:     5.0.7
 * Author:      YZG
 * Author URI:  https://yanuarzg.github.io/
 * License:     GPL v2 or later
 * Text Domain: he-journalist
 * Update URI:  https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


/**
 * Small provider key manager introduced in v3.5.0.
 * It keeps API key loading, de-duplication, masking, and blocked-state checks away from the generator flow.
 */
class HEAJ_API_Key_Manager {
    private $provider;
    private $blocked;

    public function __construct( $provider = 'gemini', $blocked = [] ) {
        $this->provider = sanitize_key( $provider );
        $this->blocked  = is_array( $blocked ) ? $blocked : [];
    }

    private function hash_key( $key ) {
        return hash_hmac( 'sha256', trim( (string) $key ), wp_salt( 'auth' ) );
    }

    private function mask_key( $key ) {
        $key = (string) $key;
        if ( strlen( $key ) <= 12 ) { return str_repeat( '•', strlen( $key ) ); }
        return substr( $key, 0, 7 ) . str_repeat( '•', max( 6, strlen( $key ) - 14 ) ) . substr( $key, -7 );
    }

    private function textarea_keys( $option ) {
        $raw = get_option( $option, '' );
        if ( is_array( $raw ) ) { return array_values( array_filter( array_map( 'trim', $raw ) ) ); }
        $rows = preg_split( '/\r\n|\r|\n/', (string) $raw );
        return array_values( array_filter( array_map( 'trim', $rows ) ) );
    }

    private function raw_items() {
        $items = [];
        if ( $this->provider === 'gemini' ) {
            $main = trim( (string) get_option( 'he_journalist_gemini_api_key', '' ) );
            if ( $main !== '' ) { $items[] = [ 'key' => $main, 'label' => 'Primary Gemini', 'source' => 'primary' ]; }
            foreach ( $this->textarea_keys( 'he_journalist_gemini_extra_api_keys' ) as $i => $key ) {
                $items[] = [ 'key' => $key, 'label' => 'API Tambahan #' . ( $i + 1 ), 'source' => 'extra' ];
            }
            return $items;
        }
        $map = [
            'grok'      => [ 'option' => 'he_journalist_grok_api_keys', 'label' => 'Grok/xAI' ],
            'groqcloud' => [ 'option' => 'he_journalist_groq_api_keys', 'label' => 'GroqCloud' ],
            'zai'       => [ 'option' => 'he_journalist_zai_api_keys', 'label' => 'Z.AI' ],
            'openrouter'=> [ 'option' => 'he_journalist_openrouter_api_keys', 'label' => 'OpenRouter' ],
        ];
        if ( isset( $map[ $this->provider ] ) ) {
            foreach ( $this->textarea_keys( $map[ $this->provider ]['option'] ) as $i => $key ) {
                $items[] = [ 'key' => $key, 'label' => $map[ $this->provider ]['label'] . ' #' . ( $i + 1 ), 'source' => $this->provider ];
            }
        }
        return $items;
    }

    public function get_pool( $include_blocked = false ) {
        $unique = [];
        $pool = [];
        foreach ( $this->raw_items() as $item ) {
            $key = trim( (string) ( $item['key'] ?? '' ) );
            if ( $key === '' ) { continue; }
            $hash = $this->hash_key( $key );
            if ( isset( $unique[ $hash ] ) ) { continue; }
            $unique[ $hash ] = true;
            $item['key'] = $key;
            $item['hash'] = $hash;
            $item['masked'] = $this->mask_key( $key );
            $item['blocked'] = isset( $this->blocked[ $hash ] );
            $item['block_info'] = $this->blocked[ $hash ] ?? null;
            if ( $include_blocked || ! $item['blocked'] ) { $pool[] = $item; }
        }
        return $pool;
    }

    public function count_available() {
        return count( $this->get_pool( false ) );
    }
}

final class HE_Journalist_Pro_Tools {
    const VERSION = '5.0.7';
    const LICENSE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/licenses.json';
    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/pl/update.json';
    const UPDATE_INFO_URL = 'https://github.com/yanuarzg/cc/tree/main/he/pl/';
    const OPTION_API_KEY = 'he_journalist_gemini_api_key';
    const OPTION_EXTRA_API_KEYS = 'he_journalist_gemini_extra_api_keys';
    const OPTION_BLOCKED_API_KEYS = 'he_journalist_blocked_api_keys';
    const OPTION_MODEL = 'he_journalist_gemini_model';
    const OPTION_GEMINI_FALLBACK_MODELS = 'he_journalist_gemini_fallback_models';
    const OPTION_GROK_API_KEYS = 'he_journalist_grok_api_keys';
    const OPTION_GROQ_API_KEYS = 'he_journalist_groq_api_keys';
    const OPTION_ZAI_API_KEYS = 'he_journalist_zai_api_keys';
    const OPTION_OPENROUTER_API_KEYS = 'he_journalist_openrouter_api_keys';
    const OPTION_OPENROUTER_MODEL = 'he_journalist_openrouter_model';
    const OPTION_HISTORY = 'he_journalist_history';
    const OPTION_PROMPT_OVERRIDES = 'he_journalist_prompt_overrides';
    const OPTION_PEXELS_API_KEY = 'he_journalist_pexels_api_key';
    const OPTION_CUSTOM_SETTINGS = 'he_journalist_custom_settings';
    const OPTION_AUTO_NEWS_SETTINGS = 'he_journalist_auto_news_settings';
    const OPTION_AUTO_NEWS_LOG = 'he_journalist_auto_news_log';
    const OPTION_AUTO_NEWS_LAST_RUN = 'he_journalist_auto_news_last_run';
    const OPTION_AUTO_NEWS_LAST_RUN_STARTED = 'he_journalist_auto_news_last_run_started';
    const OPTION_AUTO_NEWS_LAST_RESULT = 'he_journalist_auto_news_last_result';
    const OPTION_AUTO_NEWS_ASYNC_TOKEN = 'he_journalist_auto_news_async_token';
    const OPTION_AUTO_NEWS_QUEUE = 'he_journalist_auto_news_queue';
    const OPTION_AUTO_NEWS_DIAGNOSTIC = 'he_journalist_auto_news_diagnostic';
    const OPTION_AUTO_NEWS_USED_KEYWORDS = 'he_journalist_auto_news_used_keywords';
    const AUTO_NEWS_CRON_HOOK = 'he_journalist_auto_news_cron';
    const AUTO_NEWS_MASTER_HOOK = 'he_journalist_auto_news_master_cron';
    const AUTO_NEWS_KEEPALIVE_HOOK = 'he_journalist_auto_news_keepalive';
    const AUTO_NEWS_QUEUE_HOOK = 'he_journalist_auto_news_queue_worker';
    const OPTION_YZ_LICENSE_KEY = 'he_journalist_yz_license_key';
    const OPTION_YZ_LICENSE_STATUS = 'he_journalist_yz_license_status';
    const OPTION_YZ_LICENSE_API_URL = 'he_journalist_yz_license_api_url';
    const OPTION_YZ_LICENSE_LAST_CHECK = 'he_journalist_yz_license_last_check';
    const NONCE_ACTION = 'he_journalist_nonce';
    const LICENSE_PRODUCT_ID = 'yzg-ai-journalist';
    const LICENSE_MODE = 'encrypted_json_annual';
    const LICENSE_API_URL = 'https://script.google.com/macros/s/AKfycbx-LoZCG7ySOXL2nOzhUeISqsPrGglmN0t5IOC_QsujU_KCd7oKSIhlLndXlIE1wiV4/exec';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_filter( 'cron_schedules', [ $this, 'auto_news_cron_schedules' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'init', [ __CLASS__, 'maybe_schedule_cleanup_history' ] );
        add_action( 'he_journalist_cleanup_history', [ __CLASS__, 'cleanup_history' ] );
        add_filter( 'option_page_capability_he_journalist_options', [ $this, 'allow_editor_admin_option_page' ] );
        add_filter( 'option_page_capability_he_journalist_custom_options', [ $this, 'allow_editor_admin_option_page' ] );
        add_filter( 'wp_kses_allowed_html', [ $this, 'allow_auto_news_source_footer_html' ], 10, 2 );
        add_action( 'admin_post_heaj_reset_blocked_api_keys', [ $this, 'handle_reset_blocked_api_keys' ] );
        add_action( 'admin_post_heaj_check_updates_now', [ $this, 'handle_check_updates_now' ] );
        add_action( 'admin_post_heaj_reset_custom_settings', [ $this, 'handle_reset_custom_settings' ] );
        add_action( 'admin_post_heaj_save_license', [ $this, 'handle_save_yz_license' ] );
        add_action( 'admin_post_heaj_clear_license', [ $this, 'handle_clear_yz_license' ] );
        add_action( 'admin_post_heaj_clear_generate_history', [ $this, 'handle_clear_generate_history' ] );
        add_action( 'admin_post_heaj_save_auto_news', [ $this, 'handle_save_auto_news_settings' ] );
        add_action( 'admin_post_heaj_auto_news_run_now', [ $this, 'handle_auto_news_run_now' ] );
        add_action( 'admin_post_heaj_auto_news_force_queue', [ $this, 'handle_auto_news_force_queue' ] );
        add_action( 'admin_post_heaj_auto_news_run_sync', [ $this, 'handle_auto_news_run_sync' ] );
        add_action( 'admin_post_heaj_auto_news_reset_keywords', [ $this, 'handle_auto_news_reset_keywords' ] );
        add_action( self::AUTO_NEWS_CRON_HOOK, [ $this, 'run_auto_news_cron' ] );
        add_action( self::AUTO_NEWS_MASTER_HOOK, [ $this, 'run_auto_news_master_cron' ] );
        add_action( self::AUTO_NEWS_CRON_HOOK, [ $this, 'schedule_next_auto_news_keepalive' ], 999 );
        add_action( self::AUTO_NEWS_MASTER_HOOK, [ $this, 'schedule_next_auto_news_keepalive' ], 999 );
        add_action( self::AUTO_NEWS_KEEPALIVE_HOOK, [ $this, 'auto_news_keepalive_handler' ] );
        add_action( 'init', [ $this, 'maybe_dispatch_auto_news_runner' ], 20 );
        add_action( 'wp_loaded', [ $this, 'maybe_dispatch_auto_news_runner' ], 20 );
        add_action( 'shutdown', [ $this, 'shutdown_auto_news_heartbeat' ], 999 );
        add_action( 'rest_api_init', [ $this, 'register_auto_news_rest_endpoint' ] );
        add_action( 'wp_footer', [ $this, 'inject_auto_news_frontend_heartbeat' ], 999 );
        add_action( 'login_footer', [ $this, 'inject_auto_news_frontend_heartbeat' ], 999 );
        add_action( 'admin_footer', [ $this, 'inject_auto_news_frontend_heartbeat' ], 999 );
        add_action( 'wp_ajax_heaj_auto_news_run_now_ui', [ $this, 'ajax_auto_news_run_now_ui' ] );
        add_action( 'wp_ajax_heaj_auto_news_async_run', [ $this, 'ajax_auto_news_async_run' ] );
        add_action( 'wp_ajax_nopriv_heaj_auto_news_async_run', [ $this, 'ajax_auto_news_async_run' ] );
        add_action( 'admin_post_heaj_delete_generate_history', [ $this, 'handle_delete_generate_history' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
        add_action( 'wp_ajax_heaj_generate_content', [ $this, 'ajax_generate_content' ] );
        add_action( 'wp_ajax_he_create_draft', [ $this, 'ajax_create_draft' ] );
        add_action( 'wp_ajax_heaj_fetch_source_images', [ $this, 'ajax_fetch_source_images' ] );
        add_action( 'wp_ajax_heaj_test_provider_keys', [ $this, 'ajax_test_provider_keys' ] );
        add_action( 'wp_ajax_heaj_fetch_pexels_images', [ $this, 'ajax_fetch_pexels_images' ] );
        add_action( 'wp_ajax_heaj_update_history_meta', [ $this, 'ajax_update_history_meta' ] );
        add_action( 'wp_ajax_heaj_generate_social_images', [ $this, 'ajax_generate_social_images' ] );
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'site_transient_update_plugins', [ $this, 'check_plugin_update' ] );
        add_filter( 'plugins_api', [ $this, 'plugin_update_info' ], 10, 3 );
        register_activation_hook( __FILE__, [ __CLASS__, 'activate' ] );
        register_deactivation_hook( __FILE__, [ __CLASS__, 'deactivate' ] );
    }



    private function current_admin_locale() {
        $locale = function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
        if ( ! $locale ) { $locale = get_locale(); }
        return strtolower( (string) $locale );
    }

    private function is_id_locale() {
        return 0 === strpos( $this->current_admin_locale(), 'id' );
    }

    private function ui_language() {
        return $this->is_id_locale() ? 'id' : 'en';
    }

    private function ui_translations() {
        return [
            'AI dapat membuat kesalahan. Selalu periksa ulang fakta, kutipan, nama, tanggal, angka, dan sumber sebelum publish.' => 'AI can make mistakes. Always recheck facts, quotes, names, dates, numbers, and sources before publishing.',
            'Generator Artikel' => 'Article Generator',
            'Tulis ulang berita berbasis sumber, kunci data penting, siapkan SEO, lalu kirim ke Draft WordPress.' => 'Rewrite source-based articles, lock key data, prepare SEO, then send to WordPress Drafts.',
            'Pengaturan API' => 'API Settings',
            'Riwayat Generate' => 'Generation History',
            'Custom Settings' => 'Custom Settings',
            'Network Sites' => 'Network Sites',
            'Mau Nulis Berita Apa?' => 'What article do you want to write?',
            'Topik/Sumber Berita' => 'Topik/Sumber Berita',
            'Pengaturan Konten' => 'Content Settings',
            'Gaya Penulisan (prompt)' => 'Writing Style (prompt)',
            'Panjang Artikel' => 'Article Length',
            'Bahasa' => 'Language',
            'Penulis' => 'Author',
            'Editor' => 'Editor',
            '-- Kosong --' => '-- Empty --',
            'Buat Artikel' => 'Generate Article',
            'Reset' => 'Reset',
            'Ruang Kerja Kosong' => 'Empty Workspace',
            'Isi form referensi di panel sebelah kiri dan klik' => 'Fill in the reference form on the left panel and click',
            'untuk memulai pembuatan artikel oleh AI ini.' => 'to start generating an article with AI.',
            'Menyusun Naskah...' => 'Preparing Draft...',
            'Menyelaraskan tone jurnalistik, memformat tulisan, dan memastikan akurasi fakta.' => 'Aligning the journalistic tone, formatting the article, and checking factual accuracy.',
            'Kategori' => 'Category',
            'Hasil Generator' => 'Generator Result',
            'Pilihan SEO Title' => 'SEO Title Options',
            'Pilihan Slug' => 'Slug Options',
            'Meta Deskripsi (Max 160 Karakter)' => 'Meta Description (Max 160 Characters)',
            'Tags Relevan' => 'Relevant Tags',
            'Pratinjau Artikel' => 'Article Preview',
            'Copy HTML' => 'Copy HTML',
            'Kirim ke Draft WordPress' => 'Send to WordPress Draft',
            'Draft berhasil dibuat.' => 'Draft created successfully.',
            'Edit draft' => 'Edit draft',
            'Gambar dari Sumber' => 'Images from Source',
            'Pilih gambar untuk featured image/sisipan artikel.' => 'Select images for featured image/article insertions.',
            'ilustrasi foto' => 'illustrative photo',
            'Bukan foto ist/istimewa.' => 'Not an ist/istimewa photo.',
            'Caption tidak terdeteksi' => 'Caption not detected',
            'Audit Fakta' => 'Fact Audit',
            'Perlu dicek manual' => 'Needs manual check',
            'Quality Score' => 'Quality Score',
            'Sumber terbaca' => 'Source readable',
            'Data pasti cocok' => 'Confirmed data matched',
            'SEO lengkap' => 'SEO complete',
            'Paragraf rapi' => 'Clean paragraphs',
            'Gambar siap' => 'Image ready',
            'Kemiripan narasi rendah' => 'Low narrative similarity',
            'Pentingnya keakuratan berita!' => 'The importance of article accuracy!',
            'Demi menjamin keakuratan berita dan kredibilitas' => 'To ensure article accuracy and the credibility of',
            'selalu lakukan pengecekan isi artikel dan sumber yang diberikan.' => 'always check the article content and provided sources.',
            'Jika ditemukan sumber berita yang' => 'If a news source is found to be',
            'atau beda topik dengan artikel yang dibuat maka dimohon' => 'or unrelated to the generated article, please',
            'jangan mempublish' => 'do not publish',
            'artikel tersebut.' => 'the article.',
            'Ancaman pidana bagi pelanggar' => 'Criminal penalties for violations of',
            'Penjara maksimal' => 'maximum imprisonment of',
            'dan/atau denda maksimal' => 'and/or maximum fine of',
            'Sumber & Referensi Otomatis' => 'Automatic Sources & References',
            'Ringkasan Cepat' => 'Quick Summary',
            'Draft Sosmed' => 'Social Draft',
            'Skrip TikTok/Reels' => 'TikTok/Reels Script',
            'Poin Utama Berita (Key Takeaways)' => 'Main Article Points (Key Takeaways)',
            'AI sedang mengekstrak ringkasan...' => 'AI is extracting the summary...',
            'Social Media Kit' => 'Social Media Kit',
            'AI sedang menyusun draft sosmed...' => 'AI is preparing the social draft...',
            'Skrip Video Vertikal (TikTok/Reels/Shorts)' => 'Vertical Video Script (TikTok/Reels/Shorts)',
            'Copy Skrip' => 'Copy Script',
            'AI sedang menulis naskah video...' => 'AI is writing the video script...',
            'Ide Visual / B-Roll' => 'Visual Ideas / B-Roll',
            'Hook (0-3 Detik)' => 'Hook (0-3 Seconds)',
            'Isi Cerita (Voiceover)' => 'Story Body (Voiceover)',
            'Call to Action (CTA)' => 'Call to Action (CTA)',
            'Simpan Pengaturan' => 'Save Settings',
            'Simpan Custom Settings' => 'Save Custom Settings',
            'Mulai setup plugin' => 'Start plugin setup',
            'Lengkapi nama media/branding di Custom Settings, lalu masukkan minimal satu API key untuk mulai generate artikel.' => 'Complete media/branding in Custom Settings, then enter at least one API key to start generating articles.',
            'Atur Branding' => 'Set Branding',
            'Ambil API Gemini' => 'Get Gemini API',
            'AI Provider' => 'AI Provider',
            'API Key Provider' => 'API Key Provider',
            'Test API Key' => 'Test API Key',
            'aktif' => 'active',
            'Tambahkan API key per provider. Sistem akan memakai rotasi key dan otomatis melewati key yang error.' => 'Add API keys per provider. The system will rotate keys and automatically skip keys with errors.',
            'Branding White-label' => 'White-label Branding',
            'Sesuaikan nama plugin, nama media, logo, profil brand, dan mode lisensi.' => 'Customize plugin name, media name, logo, brand profile, and license mode.',
            'Nama Brand Plugin' => 'Plugin Brand Name',
            'Nama Media / Website' => 'Media / Website Name',
            'Organisasi / Redaksi' => 'Organization / Editorial Team',
            'Logo URL' => 'Logo URL',
            'Warna Utama' => 'Primary Color',
            'License Type' => 'License Type',
            'Sumber Penulis/Editor' => 'Author/Editor Source',
            'Brand Voice' => 'Brand Voice',
            'Kata/Frasa yang Dihindari' => 'Words/Phrases to Avoid',
            'Teks Warning Redaksi Tambahan' => 'Additional Editorial Warning Text',
            'Kota Default' => 'Default City',
            'Tambah, hapus, atau edit prompt yang muncul di dropdown Gaya Penulisan.' => 'Add, remove, or edit prompts that appear in the Writing Style dropdown.',
            'Tambah Prompt' => 'Add Prompt',
            'Prompt Custom Global' => 'Global Custom Prompt',
            'Instruksi tambahan global yang disisipkan ke semua gaya penulisan.' => 'Additional global instructions inserted into all writing styles.',
            'Kelola opsi pendek, sedang, panjang, atau opsi baru lain.' => 'Manage short, medium, long, or other custom length options.',
            'Tambah Panjang' => 'Add Length',
            'Tambah bahasa baru dan instruksi outputnya.' => 'Add a new language and its output instruction.',
            'Tambah Bahasa' => 'Add Language',
            'Penulis & Editor' => 'Authors & Editors',
            'Satu nama per baris untuk dropdown Penulis dan Editor.' => 'One name per line for the Author and Editor dropdowns.',
            'Import/Sync WP' => 'Import/Sync WP',
            'Export / Import JSON' => 'Export / Import JSON',
            'Gunakan untuk menyalin pengaturan ke subdomain lain.' => 'Use this to copy settings to another subdomain.',
            'Export JSON' => 'Export JSON',
            'Import JSON' => 'Import JSON',
            'Reset Default' => 'Reset Default',
            'Hapus Seluruh Riwayat Generate' => 'Delete All Generation History',
            'Perubahan akan langsung mempengaruhi halaman Generator Artikel.' => 'Changes will immediately affect the Article Generator page.',
            'Belum ke Draft' => 'Not Drafted Yet',
            'Dilanjutkan ke Draft' => 'Continued to Draft',
            'Draft dibuat' => 'Draft Created',
            'Restore' => 'Restore',
            'Hapus' => 'Delete',
            'Pilihan AI' => 'AI Choice',
            'Gaya Penulisan' => 'Writing Style',
            'Sumber Image' => 'Image Source',
            'Sumber' => 'Source',
            'Pexels' => 'Pexels',
            'Tidak ada riwayat generate.' => 'No generation history yet.',
            'Halaman' => 'Page',
            'dari' => 'of',
            'Sebelumnya' => 'Previous',
            'Berikutnya' => 'Next',
            'Disalin ke clipboard!' => 'Copied to clipboard!',
            'Gagal menyalin.' => 'Failed to copy.',
            'Mohon masukkan tautan atau teks sumber.' => 'Please enter a source link or text.',
            'Artikel berhasil dibuat!' => 'Article generated successfully!',
            'Gagal memproses artikel. Coba lagi.' => 'Failed to process the article. Please try again.',
            'Silakan buat artikel terlebih dahulu.' => 'Please generate an article first.',
            'Ringkasan berhasil dibuat!' => 'Summary generated successfully!',
            'Gagal menyusun ringkasan.' => 'Failed to prepare the summary.',
            'Draft sosial media berhasil dibuat!' => 'Social media draft generated successfully!',
            'Gagal membuat draft sosmed.' => 'Failed to create social media draft.',
            'Skrip video berhasil dibuat!' => 'Video script generated successfully!',
            'Gagal menyusun skrip video.' => 'Failed to prepare the video script.',
            'Ruang kerja dibersihkan.' => 'Workspace cleared.',
            'Memproses...' => 'Processing...',
            'Copy' => 'Copy',
            'Simpan' => 'Save',
            'Batal' => 'Cancel',
            'Tutup' => 'Close',
            'Lihat' => 'View',
            'Pilih' => 'Select',
            'Cek' => 'Check',
        ];
    }

    private function tr_ui( $text ) {
        $text = (string) $text;
        if ( $this->is_id_locale() ) { return $text; }
        $dict = $this->ui_translations();
        return $dict[ $text ] ?? $text;
    }

    private function translate_admin_html( $html ) {
        if ( $this->is_id_locale() || ! is_string( $html ) || $html === '' ) { return $html; }
        $dict = $this->ui_translations();
        uksort( $dict, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
        return strtr( $html, $dict );
    }

    private function admin_language_bridge_script() {
        $payload = wp_json_encode( [
            'lang' => $this->ui_language(),
            'locale' => $this->current_admin_locale(),
            'categories' => array_map( function( $cat ) { return [ 'id' => (int) $cat->term_id, 'name' => $cat->name, 'slug' => $cat->slug ]; }, get_categories( [ 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ] ) ),
            'dictionary' => $this->ui_translations(),
        ] );
        return "window.HEAJ_I18N = {$payload};" . <<<'JS'
(function(){
  function tr(text){
    var cfg = window.HEAJ_I18N || {};
    if (cfg.lang === 'id') return text;
    var dict = cfg.dictionary || {};
    var out = String(text || '');
    Object.keys(dict).sort(function(a,b){return b.length-a.length;}).forEach(function(k){
      if (!k) return;
      out = out.split(k).join(dict[k]);
    });
    return out;
  }
  window.HEAJTr = tr;
  function translateNode(node){
    if (!node || !node.parentNode) return;
    if (/^(SCRIPT|STYLE|TEXTAREA|CODE|PRE)$/.test(node.parentNode.nodeName)) return;
    var value = node.nodeValue;
    if (!value || !value.trim()) return;
    var next = tr(value);
    if (next !== value) node.nodeValue = next;
  }
  function translateAttrs(el){
    ['placeholder','title','aria-label','value'].forEach(function(attr){
      if (!el || !el.hasAttribute || !el.hasAttribute(attr)) return;
      if (attr === 'value' && !/^(INPUT|BUTTON)$/.test(el.nodeName)) return;
      var old = el.getAttribute(attr);
      var next = tr(old);
      if (next !== old) el.setAttribute(attr, next);
    });
  }
  function translatePage(){
    var cfg = window.HEAJ_I18N || {};
    if (cfg.lang === 'id') return;
    var root = document.querySelector('#heaj-app,#he-settings-app,#he-history-app,#he-custom-settings-app,#he-subdomains-app,.heaj-settings-page') || document.body;
    if (!root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(translateNode);
    root.querySelectorAll('[placeholder],[title],[aria-label],input[type="button"],input[type="submit"],button').forEach(translateAttrs);
  }
  window.HEAJTranslatePage = translatePage;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', translatePage); else translatePage();
  setTimeout(translatePage, 250); setTimeout(translatePage, 1000); setTimeout(translatePage, 2200);
})();
JS;
    }

    private function normalize_host( $host ) {
        $host = strtolower( trim( (string) $host ) );
        $host = preg_replace( '#:\\d+$#', '', $host );
        $host = preg_replace( '#^www\\.#', 'www.', $host );
        return $host;
    }

    private function yz_license_site_domain() {
        $host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
        $host = strtolower( trim( $host ) );
        $host = preg_replace( '#^www\.#', '', $host );
        $host = preg_replace( '#:\d+$#', '', $host );
        return $host;
    }

    private function yz_license_api_url() {
        $url = esc_url_raw( get_option( self::OPTION_YZ_LICENSE_API_URL, self::LICENSE_API_URL ) );
        return $url ?: self::LICENSE_API_URL;
    }

    private function yz_default_license_status( $message = 'Lisensi belum aktif.', $code = 'inactive' ) {
        return [
            'valid'        => false,
            'ok'           => false,
            'code'         => $code,
            'message'      => $message,
            'productId'    => self::LICENSE_PRODUCT_ID,
            'licenseMode'  => self::LICENSE_MODE,
            'domain'       => $this->yz_license_site_domain(),
            'last_checked' => (int) get_option( self::OPTION_YZ_LICENSE_LAST_CHECK, 0 ),
        ];
    }

    private function yz_get_license_key() {
        return trim( (string) get_option( self::OPTION_YZ_LICENSE_KEY, '' ) );
    }

    private function yz_cached_license_status() {
        $status = get_option( self::OPTION_YZ_LICENSE_STATUS, [] );
        return is_array( $status ) ? $status : [];
    }

    private function yz_license_local_secret() {
        // Same lightweight local validation style used in NewsPress: obfuscated fragments only.
        // No Firestore/productSecrets API secret is exposed as a plain readable string.
        $parts = [
            'YWk=',
            'am91cm5hbGlzdA==',
            'QEA=',
            'IyM=',
            'Mjc=',
        ];

        $secret = '';
        foreach ( $parts as $part ) {
            $decoded = base64_decode( $part, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
            if ( false !== $decoded ) {
                $secret .= $decoded;
            }
        }

        return $secret;
    }

    private function yz_license_local_integrity_token() {
        return hash( 'sha256', self::LICENSE_PRODUCT_ID . '|local-license|cryptojs|annual|' . $this->yz_license_local_secret() );
    }

    private function yz_license_local_integrity_valid() {
        $expected = 'f01294df4ba36c7d9b24228fbe5b3e37b4ded4b5c42cf3a8cc07204cc8354642';
        return hash_equals( $expected, $this->yz_license_local_integrity_token() );
    }

    private function yz_cryptojs_evp_bytes_to_key( $password, $salt, $key_len = 32, $iv_len = 16 ) {
        $password = (string) $password;
        $salt = (string) $salt;
        $derived = '';
        $block = '';
        while ( strlen( $derived ) < ( $key_len + $iv_len ) ) {
            $block = md5( $block . $password . $salt, true );
            $derived .= $block;
        }
        return [
            'key' => substr( $derived, 0, $key_len ),
            'iv'  => substr( $derived, $key_len, $iv_len ),
        ];
    }

    private function yz_cryptojs_decrypt_local( $ciphertext, $password ) {
        if ( ! function_exists( 'openssl_decrypt' ) ) {
            return new WP_Error( 'openssl_missing', 'OpenSSL PHP tidak aktif di server.' );
        }

        $raw = base64_decode( trim( (string) $ciphertext ), true );
        if ( ! $raw || strlen( $raw ) < 24 ) {
            return new WP_Error( 'invalid_ciphertext', 'Format license tidak valid.' );
        }

        if ( substr( $raw, 0, 8 ) !== 'Salted__' ) {
            return new WP_Error( 'invalid_salted_format', 'Format license bukan CryptoJS salted AES.' );
        }

        $salt = substr( $raw, 8, 8 );
        $encrypted = substr( $raw, 16 );
        $keys = $this->yz_cryptojs_evp_bytes_to_key( (string) $password, $salt, 32, 16 );
        $plain = openssl_decrypt( $encrypted, 'AES-256-CBC', $keys['key'], OPENSSL_RAW_DATA, $keys['iv'] );

        if ( ! is_string( $plain ) || trim( $plain ) === '' ) {
            return new WP_Error( 'decrypt_failed', 'License tidak bisa didecrypt lokal.' );
        }

        return $plain;
    }

    private function yz_domain_matches_license( $license_domain, $site_domain ) {
        $license_domain = $this->normalize_host( $license_domain );
        $site_domain = $this->normalize_host( $site_domain );
        if ( $license_domain === '' || $site_domain === '' ) { return false; }
        if ( $license_domain === $site_domain ) { return true; }
        if ( $license_domain === preg_replace( '/^www\./', '', $site_domain ) ) { return true; }
        if ( preg_replace( '/^www\./', '', $license_domain ) === $site_domain ) { return true; }
        return false;
    }

    private function yz_verify_license_local( $license_key, $reason = 'License API tidak mengembalikan JSON.' ) {
        $license_key = trim( (string) $license_key );
        if ( $license_key === '' ) {
            return $this->yz_default_license_status( 'License code kosong.', 'missing_license' );
        }

        if ( ! $this->yz_license_local_integrity_valid() ) {
            $status = $this->yz_default_license_status( 'Validasi lokal lisensi tidak tersedia.', 'local_integrity_failed' );
            $status['api_debug'] = [
                'fallback' => 'local_integrity_failed',
                'reason'   => $reason,
            ];
            return $status;
        }

        $plain = $this->yz_cryptojs_decrypt_local( $license_key, $this->yz_license_local_secret() );
        if ( is_wp_error( $plain ) ) {
            $status = $this->yz_default_license_status( $plain->get_error_message(), $plain->get_error_code() );
            $status['api_debug'] = [
                'fallback' => 'local_decrypt_failed',
                'reason'   => $reason,
            ];
            return $status;
        }

        $payload = json_decode( $plain, true );
        if ( ! is_array( $payload ) ) {
            $status = $this->yz_default_license_status( 'Plaintext license bukan JSON valid.', 'invalid_license_json' );
            $status['api_debug'] = [
                'fallback' => 'local_invalid_json',
                'reason'   => $reason,
                'plain_preview' => sanitize_text_field( substr( (string) $plain, 0, 200 ) ),
            ];
            return $status;
        }

        $product = sanitize_key( $payload['product'] ?? '' );
        $mode = sanitize_key( $payload['license_mode'] ?? '' );
        $type = sanitize_key( $payload['license_type'] ?? '' );
        $license_domain = sanitize_text_field( $payload['domain'] ?? '' );
        $site_domain = $this->yz_license_site_domain();
        $expires = sanitize_text_field( $payload['expires_at'] ?? '' );
        $issued = sanitize_text_field( $payload['issued_at'] ?? '' );
        $now = time();

        $valid = true;
        $code = 'valid';
        $message = 'License valid.';

        if ( $product !== self::LICENSE_PRODUCT_ID ) {
            $valid = false;
            $code = 'product_mismatch';
            $message = 'License bukan untuk produk ' . self::LICENSE_PRODUCT_ID . '.';
        } elseif ( $mode !== self::LICENSE_MODE ) {
            $valid = false;
            $code = 'mode_mismatch';
            $message = 'License mode tidak sesuai.';
        } elseif ( $type !== 'annual' ) {
            $valid = false;
            $code = 'type_mismatch';
            $message = 'License bukan annual license.';
        } elseif ( ! $this->yz_domain_matches_license( $license_domain, $site_domain ) ) {
            $valid = false;
            $code = 'domain_mismatch';
            $message = 'License tidak cocok dengan domain ini.';
        } elseif ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $expires ) ) {
            $valid = false;
            $code = 'invalid_expiry';
            $message = 'Tanggal expired license tidak valid.';
        } else {
            $today = gmdate( 'Y-m-d' );
            $remaining = (int) floor( ( strtotime( $expires . ' 00:00:00 UTC' ) - strtotime( $today . ' 00:00:00 UTC' ) ) / DAY_IN_SECONDS );
            if ( $remaining < 0 ) {
                $valid = false;
                $code = 'expired';
                $message = 'License sudah expired pada ' . $expires . '.';
            }
        }

        $remaining_days = null;
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $expires ) ) {
            $remaining_days = (int) floor( ( strtotime( $expires . ' 00:00:00 UTC' ) - strtotime( gmdate( 'Y-m-d' ) . ' 00:00:00 UTC' ) ) / DAY_IN_SECONDS );
        }

        return [
            'valid'         => (bool) $valid,
            'ok'            => (bool) $valid,
            'code'          => $code,
            'message'       => $message,
            'productId'     => self::LICENSE_PRODUCT_ID,
            'productName'   => sanitize_text_field( $payload['product_name'] ?? self::LICENSE_PRODUCT_ID ),
            'licenseMode'   => self::LICENSE_MODE,
            'licenseType'   => 'annual',
            'domain'        => $site_domain,
            'licenseDomain' => $license_domain,
            'issuedAt'      => $issued,
            'expiresAt'     => $expires,
            'remainingDays' => $remaining_days,
            'last_checked'  => $now,
            'api_debug'     => [
                'fallback' => 'local_cryptojs_decrypt',
                'reason'   => $reason,
            ],
        ];
    }

    private function yz_license_request_payload( $license_key ) {
        return [
            'action'      => 'verify_license_public',
            'productId'   => self::LICENSE_PRODUCT_ID,
            'licenseMode' => self::LICENSE_MODE,
            'domain'      => $this->yz_license_site_domain(),
            'license'     => trim( (string) $license_key ),
        ];
    }

    private function yz_license_api_request_args( $payload ) {
        return [
            'timeout'     => 30,
            'redirection' => 10,
            'headers'     => [
                'Content-Type' => 'application/json; charset=utf-8',
                'Accept'       => 'application/json, text/plain, */*',
                'User-Agent'   => 'YZG-AI-Journalist/' . self::VERSION . '; ' . home_url( '/' ),
            ],
            'body'        => wp_json_encode( $payload ),
        ];
    }

    private function yz_extract_google_html_redirect_url( $html ) {
        $html = (string) $html;
        if ( $html === '' ) { return ''; }

        if ( preg_match( '#https://script\.googleusercontent\.com/[^\s"\']+#i', $html, $m ) ) {
            return html_entity_decode( $m[0], ENT_QUOTES, 'UTF-8' );
        }

        if ( preg_match( '#href=["\']([^"\']*script\.googleusercontent\.com[^"\']+)["\']#i', $html, $m ) ) {
            return html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
        }

        return '';
    }

    private function yz_decode_license_api_response( $response, $payload = [] ) {
        if ( is_wp_error( $response ) ) {
            return [
                'ok'      => false,
                'json'    => null,
                'message' => 'License API error: ' . $response->get_error_message(),
                'code'    => 'api_error',
                'debug'   => [
                    'transport' => 'wp_error',
                    'error'     => $response->get_error_message(),
                ],
            ];
        }

        $http = (int) wp_remote_retrieve_response_code( $response );
        $raw_body = (string) wp_remote_retrieve_body( $response );
        $content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
        $json = json_decode( $raw_body, true );

        if ( is_array( $json ) ) {
            return [
                'ok'      => true,
                'json'    => $json,
                'message' => '',
                'code'    => '',
                'debug'   => [
                    'http'         => $http,
                    'content_type' => $content_type,
                    'body_type'    => 'json',
                ],
            ];
        }

        // Some WordPress/server setups do not follow Google Apps Script HTML redirect.
        // If the HTML contains script.googleusercontent.com, follow it manually.
        $redirect_url = $this->yz_extract_google_html_redirect_url( $raw_body );
        if ( $redirect_url ) {
            $follow = wp_remote_get( esc_url_raw( $redirect_url ), [
                'timeout'     => 30,
                'redirection' => 10,
                'headers'     => [
                    'Accept'     => 'application/json, text/plain, */*',
                    'User-Agent' => 'YZG-AI-Journalist/' . self::VERSION . '; ' . home_url( '/' ),
                ],
            ] );

            if ( ! is_wp_error( $follow ) ) {
                $follow_body = (string) wp_remote_retrieve_body( $follow );
                $follow_json = json_decode( $follow_body, true );
                if ( is_array( $follow_json ) ) {
                    return [
                        'ok'      => true,
                        'json'    => $follow_json,
                        'message' => '',
                        'code'    => '',
                        'debug'   => [
                            'http'         => (int) wp_remote_retrieve_response_code( $follow ),
                            'content_type' => (string) wp_remote_retrieve_header( $follow, 'content-type' ),
                            'body_type'    => 'json_after_google_redirect',
                        ],
                    ];
                }
            }
        }

        // Final fallback: try form encoded POST. This does not change server logic,
        // but helps if a host/proxy mangles application/json POST body.
        if ( ! empty( $payload ) ) {
            $form_response = wp_remote_post( $this->yz_license_api_url(), [
                'timeout'     => 30,
                'redirection' => 10,
                'headers'     => [
                    'Accept'     => 'application/json, text/plain, */*',
                    'User-Agent' => 'YZG-AI-Journalist/' . self::VERSION . '; ' . home_url( '/' ),
                ],
                'body'        => $payload,
            ] );

            if ( ! is_wp_error( $form_response ) ) {
                $form_body = (string) wp_remote_retrieve_body( $form_response );
                $form_json = json_decode( $form_body, true );
                if ( is_array( $form_json ) ) {
                    return [
                        'ok'      => true,
                        'json'    => $form_json,
                        'message' => '',
                        'code'    => '',
                        'debug'   => [
                            'http'         => (int) wp_remote_retrieve_response_code( $form_response ),
                            'content_type' => (string) wp_remote_retrieve_header( $form_response, 'content-type' ),
                            'body_type'    => 'json_after_form_post',
                        ],
                    ];
                }
            }
        }

        $preview = trim( wp_strip_all_tags( substr( $raw_body, 0, 500 ) ) );
        $hint = 'Response License API bukan JSON valid.';
        if ( stripos( $raw_body, '<html' ) !== false || stripos( $raw_body, '<!doctype' ) !== false ) {
            $hint = 'Response License API masih berupa HTML, bukan JSON. Cek deploy Apps Script: Execute as Me, Who has access Anyone, lalu pakai URL /exec deployment terbaru.';
        } elseif ( trim( $raw_body ) === '' ) {
            $hint = 'Response License API kosong. Cek URL deploy Apps Script dan permission Web App.';
        }

        return [
            'ok'      => false,
            'json'    => null,
            'message' => $hint,
            'code'    => 'invalid_response',
            'debug'   => [
                'http'         => $http,
                'content_type' => $content_type,
                'body_type'    => 'non_json',
                'preview'      => sanitize_text_field( $preview ),
            ],
        ];
    }

    private function yz_verify_license_remote( $license_key = '' ) {
        $license_key = trim( (string) ( $license_key ?: $this->yz_get_license_key() ) );
        if ( $license_key === '' ) {
            return $this->yz_default_license_status( 'License code kosong.', 'missing_license' );
        }

        $payload = $this->yz_license_request_payload( $license_key );
        $response = wp_remote_post( $this->yz_license_api_url(), $this->yz_license_api_request_args( $payload ) );
        $now = time();

        $decoded = $this->yz_decode_license_api_response( $response, $payload );

        if ( empty( $decoded['ok'] ) ) {
            if ( ( $decoded['code'] ?? '' ) === 'api_error' ) {
                $cached = $this->yz_cached_license_status();
                if ( ! empty( $cached['valid'] ) && ! empty( $cached['last_checked'] ) && ( $now - (int) $cached['last_checked'] ) < 3 * DAY_IN_SECONDS ) {
                    $cached['grace'] = true;
                    $cached['message'] = 'License API tidak bisa dihubungi. Cache valid masih dalam grace period.';
                    return $cached;
                }
            }

            // Fallback lokal untuk encrypted_json_annual agar verifikasi tidak gagal hanya karena
            // Google Apps Script mengembalikan HTML/400 dari transport Web App.
            $status = $this->yz_verify_license_local( $license_key, $decoded['message'] ?? 'License API tidak mengembalikan JSON.' );
            $status['api_debug_remote'] = $decoded['debug'] ?? [];
            update_option( self::OPTION_YZ_LICENSE_STATUS, $status, false );
            update_option( self::OPTION_YZ_LICENSE_LAST_CHECK, $now, false );
            return $status;
        }

        $json = $decoded['json'];
        $debug = $decoded['debug'] ?? [];
        $http = isset( $debug['http'] ) ? (int) $debug['http'] : 200;

        $valid = ! empty( $json['valid'] ) || ( ! empty( $json['ok'] ) && ! empty( $json['valid'] ) );
        if ( $http < 200 || $http >= 300 ) {
            $valid = false;
        }

        $product = sanitize_key( $json['productId'] ?? $json['product'] ?? '' );
        $mode = sanitize_key( $json['licenseMode'] ?? $json['license_mode'] ?? '' );
        $type = sanitize_key( $json['licenseType'] ?? $json['license_type'] ?? '' );

        if ( $valid && $product && $product !== self::LICENSE_PRODUCT_ID ) {
            $valid = false;
            $json['code'] = 'product_mismatch';
            $json['message'] = 'License bukan untuk produk ' . self::LICENSE_PRODUCT_ID . '.';
        }
        if ( $valid && $mode && $mode !== self::LICENSE_MODE ) {
            $valid = false;
            $json['code'] = 'mode_mismatch';
            $json['message'] = 'License mode tidak sesuai.';
        }
        if ( $valid && $type && $type !== 'annual' ) {
            $valid = false;
            $json['code'] = 'type_mismatch';
            $json['message'] = 'License bukan annual license.';
        }

        $status = [
            'valid'         => (bool) $valid,
            'ok'            => ! empty( $json['ok'] ),
            'code'          => sanitize_key( $json['code'] ?? ( $valid ? 'valid' : 'invalid' ) ),
            'message'       => sanitize_text_field( $json['message'] ?? ( $valid ? 'License valid.' : 'License tidak valid.' ) ),
            'productId'     => self::LICENSE_PRODUCT_ID,
            'productName'   => sanitize_text_field( $json['productName'] ?? $json['product_name'] ?? self::LICENSE_PRODUCT_ID ),
            'licenseMode'   => self::LICENSE_MODE,
            'licenseType'   => sanitize_key( $json['licenseType'] ?? $json['license_type'] ?? 'annual' ),
            'domain'        => $this->yz_license_site_domain(),
            'licenseDomain' => sanitize_text_field( $json['licenseDomain'] ?? $json['license_domain'] ?? $json['domain'] ?? '' ),
            'expiresAt'     => sanitize_text_field( $json['expiresAt'] ?? $json['expires_at'] ?? '' ),
            'remainingDays' => isset( $json['remainingDays'] ) ? (int) $json['remainingDays'] : ( isset( $json['remaining_days'] ) ? (int) $json['remaining_days'] : null ),
            'last_checked'  => $now,
            'api_debug'     => $debug,
        ];

        update_option( self::OPTION_YZ_LICENSE_STATUS, $status, false );
        update_option( self::OPTION_YZ_LICENSE_LAST_CHECK, $now, false );

        return $status;
    }

private function yz_license_status( $force = false ) {
        $license_key = $this->yz_get_license_key();
        if ( $license_key === '' ) {
            return $this->yz_default_license_status( 'License code kosong.', 'missing_license' );
        }
        $cached = $this->yz_cached_license_status();
        if ( ! $force && ! empty( $cached['last_checked'] ) && ( time() - (int) $cached['last_checked'] ) < 12 * HOUR_IN_SECONDS ) {
            return $cached;
        }
        return $this->yz_verify_license_remote( $license_key );
    }

    private function yz_license_is_valid() {
        if ( $this->is_allowed_builtin_domain() ) { return true; }
        $status = $this->yz_license_status( false );
        return ! empty( $status['valid'] );
    }

    private function is_allowed_builtin_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        foreach ( $this->builtin_license_domains() as $rule ) {
            if ( $this->domain_rule_matches( $host, $rule ) ) { return true; }
        }
        return false;
    }

    public function handle_save_yz_license() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Akses ditolak.' ); }
        check_admin_referer( 'heaj_save_license' );

        $license = isset( $_POST['heaj_license_key'] ) ? sanitize_textarea_field( wp_unslash( $_POST['heaj_license_key'] ) ) : '';
        update_option( self::OPTION_YZ_LICENSE_KEY, trim( $license ), false );
        update_option( self::OPTION_YZ_LICENSE_API_URL, self::LICENSE_API_URL, false );
        delete_option( self::OPTION_YZ_LICENSE_STATUS );
        delete_option( self::OPTION_YZ_LICENSE_LAST_CHECK );

        $status = $this->yz_verify_license_remote( $license );
        $url = admin_url( 'admin.php?page=he-journalist-license&' . ( ! empty( $status['valid'] ) ? 'license_ok=1' : 'license_error=1' ) );
        wp_safe_redirect( $url );
        exit;
    }

    public function handle_clear_yz_license() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Akses ditolak.' ); }
        check_admin_referer( 'heaj_clear_license' );
        delete_option( self::OPTION_YZ_LICENSE_KEY );
        delete_option( self::OPTION_YZ_LICENSE_STATUS );
        delete_option( self::OPTION_YZ_LICENSE_LAST_CHECK );
        wp_safe_redirect( admin_url( 'admin.php?page=he-journalist-license&license_cleared=1' ) );
        exit;
    }

    public function admin_license_notice() {
        return;
    }

    private function builtin_license_domains() {
        return [
            'geky.page.gd',
            'harianexpress.com',
            'www.harianexpress.com',
            '*.harianexpress.com',
            'harianexpress.id',
            'www.harianexpress.id',
            '*.harianexpress.id',
        ];
    }

    private function get_remote_license_domains() {
        $cache_key = 'he_journalist_license_domains_v1';
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $domains = [];
        $response = wp_remote_get( self::LICENSE_JSON_URL, [
            'timeout' => 10,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( ! is_wp_error( $response ) ) {
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code >= 200 && $code < 300 ) {
                $data = json_decode( wp_remote_retrieve_body( $response ), true );
                if ( is_array( $data ) ) {
                    if ( isset( $data['domains'] ) && is_array( $data['domains'] ) ) {
                        $domains = array_merge( $domains, $data['domains'] );
                    }
                    if ( isset( $data['allowed_domains'] ) && is_array( $data['allowed_domains'] ) ) {
                        $domains = array_merge( $domains, $data['allowed_domains'] );
                    }
                }
            }
        }

        $domains = array_values( array_unique( array_filter( array_map( function( $domain ) {
            $domain = strtolower( trim( (string) $domain ) );
            $domain = preg_replace( '#^https?://#', '', $domain );
            $domain = preg_replace( '#/.*$#', '', $domain );
            $domain = preg_replace( '#:\d+$#', '', $domain );
            return $domain;
        }, $domains ) ) ) );

        set_transient( $cache_key, $domains, 30 * MINUTE_IN_SECONDS );
        return $domains;
    }

    private function domain_rule_matches( $host, $rule ) {
        $host = $this->normalize_host( $host );
        $rule = strtolower( trim( (string) $rule ) );
        $rule = preg_replace( '#^https?://#', '', $rule );
        $rule = preg_replace( '#/.*$#', '', $rule );
        $rule = preg_replace( '#:\d+$#', '', $rule );

        if ( $host === '' || $rule === '' ) { return false; }
        if ( $host === $rule ) { return true; }

        if ( strpos( $rule, '*.' ) === 0 ) {
            $suffix = substr( $rule, 2 );
            return $host === $suffix || substr( $host, -strlen( '.' . $suffix ) ) === '.' . $suffix;
        }

        return false;
    }

    private function is_allowed_license_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }

        $rules = array_merge( $this->builtin_license_domains(), $this->get_remote_license_domains() );
        foreach ( $rules as $rule ) {
            if ( $this->domain_rule_matches( $host, $rule ) ) { return true; }
        }

        return $this->yz_license_is_valid();
    }

    private function is_harianexpress_com_domain( $host = '' ) {
        $host = $host ? $this->normalize_host( $host ) : $this->normalize_host( wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( $host === '' ) { return false; }
        return $host === 'harianexpress.com' || substr( $host, -strlen( '.harianexpress.com' ) ) === '.harianexpress.com';
    }

    public function enforce_license_domain() {
        return;
    }

    private function reject_if_unlicensed_ajax() {
        if ( $this->is_allowed_license_domain() ) { return; }
        wp_send_json_error( [
            'message'      => 'Lisensi YZG AI Journalist belum aktif atau sudah kedaluwarsa. Aktivasi lisensi di menu Lisensi.',
            'redirect_url' => admin_url( 'admin.php?page=he-journalist-license' ),
        ], 403 );
        wp_die();
    }

    public static function activate() {
        if ( ! get_option( self::OPTION_MODEL ) ) {
            add_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        }
        if ( false === get_option( self::OPTION_GEMINI_FALLBACK_MODELS, false ) ) {
            add_option( self::OPTION_GEMINI_FALLBACK_MODELS, "gemini-2.5-flash-lite\ngemini-2.5-pro" );
        }
        if ( false === get_option( self::OPTION_API_KEY, false ) ) {
            add_option( self::OPTION_API_KEY, '' );
        }
        if ( false === get_option( self::OPTION_EXTRA_API_KEYS, false ) ) {
            add_option( self::OPTION_EXTRA_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_BLOCKED_API_KEYS, false ) ) {
            add_option( self::OPTION_BLOCKED_API_KEYS, [] );
        }
        if ( false === get_option( self::OPTION_GROK_API_KEYS, false ) ) {
            add_option( self::OPTION_GROK_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_GROQ_API_KEYS, false ) ) {
            add_option( self::OPTION_GROQ_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_ZAI_API_KEYS, false ) ) {
            add_option( self::OPTION_ZAI_API_KEYS, '' );
        }
        if ( false === get_option( self::OPTION_HISTORY, false ) ) {
            add_option( self::OPTION_HISTORY, [] );
        }
        if ( false === get_option( self::OPTION_PROMPT_OVERRIDES, false ) ) {
            add_option( self::OPTION_PROMPT_OVERRIDES, [] );
        }
        if ( false === get_option( self::OPTION_PEXELS_API_KEY, false ) ) {
            add_option( self::OPTION_PEXELS_API_KEY, '' );
        }
        if ( false === get_option( self::OPTION_CUSTOM_SETTINGS, false ) ) {
            add_option( self::OPTION_CUSTOM_SETTINGS, self::default_custom_settings() );
        }
        if ( false === get_option( self::OPTION_AUTO_NEWS_SETTINGS, false ) ) {
            add_option( self::OPTION_AUTO_NEWS_SETTINGS, self::default_auto_news_settings() );
        }
        if ( false === get_option( self::OPTION_AUTO_NEWS_LOG, false ) ) {
            add_option( self::OPTION_AUTO_NEWS_LOG, [] );
        }
        if ( false === get_option( self::OPTION_AUTO_NEWS_LAST_RESULT, false ) ) {
            add_option( self::OPTION_AUTO_NEWS_LAST_RESULT, [] );
        }
        if ( false === get_option( self::OPTION_AUTO_NEWS_QUEUE, false ) ) {
            add_option( self::OPTION_AUTO_NEWS_QUEUE, [] );
        }
        if ( false === get_option( self::OPTION_AUTO_NEWS_USED_KEYWORDS, false ) ) {
            add_option( self::OPTION_AUTO_NEWS_USED_KEYWORDS, [] );
        }
        if ( false === get_option( self::OPTION_YZ_LICENSE_API_URL, false ) ) {
            add_option( self::OPTION_YZ_LICENSE_API_URL, self::LICENSE_API_URL );
        }
        if ( ! wp_next_scheduled( 'he_journalist_cleanup_history' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'he_journalist_cleanup_history' );
        }
        self::schedule_auto_news_static();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( 'he_journalist_cleanup_history' );
        wp_clear_scheduled_hook( self::AUTO_NEWS_CRON_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_MASTER_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_QUEUE_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_KEEPALIVE_HOOK );
    }

    private function plugin_dir() { return plugin_dir_path( __FILE__ ); }
    private function plugin_url() { return plugin_dir_url( __FILE__ ); }

    public static function default_auto_news_settings() {
        return [
            'enabled'      => '0',
            'feed_mode'    => 'autopilot',
            'manual_keywords' => '',
            'feed_proxy_urls' => '',
            'keyword_pick_mode' => 'sequential',
            'keywords_per_run' => 1,
            'keyword_cycle_reset' => '0',
            'manual_rss_urls' => '',
            'schedule_mode'=> 'realtime',
            'interval_hours' => 3,
            'gt_schedule_type' => 'hours',
            'gt_schedule_value' => 1,
            'kw_schedule_type' => 'hours',
            'kw_schedule_value' => 1,
            'item_offset'  => 0,
            'publish_mode' => 'draft',
            'max_per_run'  => 2,
            'ai_provider'  => 'gemini',
            'prompt_style' => 'straight_news',
            'word_count'   => '',
            'language'     => 'id',
            'force_paraphrase' => '0',
            'author_user_id' => 0,
        ];
    }

    public static function sanitize_auto_news_settings_static( $raw ) {
        $defaults = self::default_auto_news_settings();
        $raw = is_array( $raw ) ? $raw : [];
        $settings = [];
        $settings['enabled'] = ! empty( $raw['enabled'] ) ? '1' : '0';
        $feed_mode = isset( $raw['feed_mode'] ) ? sanitize_key( $raw['feed_mode'] ) : $defaults['feed_mode'];
        $settings['feed_mode'] = in_array( $feed_mode, [ 'autopilot', 'google_trends', 'global_trends', 'manual_keywords' ], true ) ? $feed_mode : 'autopilot';
        $manual_keywords = isset( $raw['manual_keywords'] ) ? sanitize_textarea_field( $raw['manual_keywords'] ) : '';
        $settings['manual_keywords'] = trim( $manual_keywords );
        $feed_proxy_urls = isset( $raw['feed_proxy_urls'] ) ? sanitize_textarea_field( $raw['feed_proxy_urls'] ) : '';
        $settings['feed_proxy_urls'] = trim( $feed_proxy_urls );
        $keyword_pick_mode = isset( $raw['keyword_pick_mode'] ) ? sanitize_key( $raw['keyword_pick_mode'] ) : $defaults['keyword_pick_mode'];
        $settings['keyword_pick_mode'] = in_array( $keyword_pick_mode, [ 'random', 'sequential' ], true ) ? $keyword_pick_mode : 'sequential';
        if ( $settings['feed_mode'] === 'manual_keywords' ) { $settings['keyword_pick_mode'] = 'sequential'; }
        $kpr = isset( $raw['keywords_per_run'] ) ? absint( $raw['keywords_per_run'] ) : (int) $defaults['keywords_per_run'];
        $settings['keywords_per_run'] = min( 10, max( 1, $kpr ) );
        if ( $settings['feed_mode'] === 'manual_keywords' ) { $settings['keywords_per_run'] = 1; }
        $settings['keyword_cycle_reset'] = ! empty( $raw['keyword_cycle_reset'] ) ? '1' : '0';
        if ( $settings['feed_mode'] === 'manual_keywords' ) { $settings['keyword_cycle_reset'] = '0'; }
        $manual_rss_urls = isset( $raw['manual_rss_urls'] ) ? sanitize_textarea_field( $raw['manual_rss_urls'] ) : '';
        $settings['manual_rss_urls'] = trim( $manual_rss_urls );
        $ai_provider = isset( $raw['ai_provider'] ) ? sanitize_key( $raw['ai_provider'] ) : $defaults['ai_provider'];
        $settings['ai_provider'] = in_array( $ai_provider, [ 'gemini', 'grok', 'groqcloud', 'zai', 'openrouter' ], true ) ? $ai_provider : 'gemini';
        $settings['prompt_style'] = isset( $raw['prompt_style'] ) ? sanitize_key( $raw['prompt_style'] ) : $defaults['prompt_style'];
        $settings['word_count'] = isset( $raw['word_count'] ) ? sanitize_text_field( $raw['word_count'] ) : $defaults['word_count'];
        $settings['language'] = isset( $raw['language'] ) && in_array( sanitize_key( $raw['language'] ), [ 'id', 'en' ], true ) ? sanitize_key( $raw['language'] ) : 'id';
        $settings['force_paraphrase'] = ! empty( $raw['force_paraphrase'] ) ? '1' : '0';
        $mode = isset( $raw['schedule_mode'] ) ? sanitize_key( $raw['schedule_mode'] ) : $defaults['schedule_mode'];
        $settings['schedule_mode'] = in_array( $mode, [ 'realtime', 'interval' ], true ) ? $mode : 'realtime';
        $hours = isset( $raw['interval_hours'] ) ? absint( $raw['interval_hours'] ) : (int) $defaults['interval_hours'];
        $settings['interval_hours'] = min( 24, max( 1, $hours ) );
        $gt_type = isset( $raw['gt_schedule_type'] ) ? sanitize_key( $raw['gt_schedule_type'] ) : $defaults['gt_schedule_type'];
        if ( $gt_type === 'realtime' ) { $gt_type = 'minutes'; }
        $settings['gt_schedule_type'] = in_array( $gt_type, [ 'minutes', 'hours', 'days' ], true ) ? $gt_type : 'hours';
        $gt_value = isset( $raw['gt_schedule_value'] ) ? absint( $raw['gt_schedule_value'] ) : (int) $defaults['gt_schedule_value'];
        if ( $settings['gt_schedule_type'] === 'minutes' ) { $settings['gt_schedule_value'] = min( 1440, max( 15, $gt_value ) ); }
        elseif ( $settings['gt_schedule_type'] === 'days' ) { $settings['gt_schedule_value'] = min( 30, max( 1, $gt_value ) ); }
        else { $settings['gt_schedule_value'] = min( 24, max( 1, $gt_value ) ); }
        $kw_type = isset( $raw['kw_schedule_type'] ) ? sanitize_key( $raw['kw_schedule_type'] ) : $defaults['kw_schedule_type'];
        $settings['kw_schedule_type'] = in_array( $kw_type, [ 'minutes', 'hours', 'days' ], true ) ? $kw_type : 'hours';
        $kw_value = isset( $raw['kw_schedule_value'] ) ? absint( $raw['kw_schedule_value'] ) : (int) $defaults['kw_schedule_value'];
        if ( $settings['kw_schedule_type'] === 'minutes' ) { $settings['kw_schedule_value'] = min( 1440, max( 15, $kw_value ) ); }
        elseif ( $settings['kw_schedule_type'] === 'days' ) { $settings['kw_schedule_value'] = min( 30, max( 1, $kw_value ) ); }
        else { $settings['kw_schedule_value'] = min( 24, max( 1, $kw_value ) ); }
        $offset = isset( $raw['item_offset'] ) ? absint( $raw['item_offset'] ) : 0;
        $settings['item_offset'] = min( 9, max( 0, $offset ) );
        $publish_mode = isset( $raw['publish_mode'] ) ? sanitize_key( $raw['publish_mode'] ) : $defaults['publish_mode'];
        $settings['publish_mode'] = in_array( $publish_mode, [ 'publish', 'draft' ], true ) ? $publish_mode : 'draft';
        $max = isset( $raw['max_per_run'] ) ? absint( $raw['max_per_run'] ) : (int) $defaults['max_per_run'];
        $settings['max_per_run'] = min( 5, max( 1, $max ) );
        $settings['author_user_id'] = isset( $raw['author_user_id'] ) ? absint( $raw['author_user_id'] ) : absint( $defaults['author_user_id'] );
        return $settings;
    }

    private function get_auto_news_settings() {
        return self::sanitize_auto_news_settings_static( get_option( self::OPTION_AUTO_NEWS_SETTINGS, [] ) );
    }

    private function reset_auto_news_queue_if_mode_changed( array $old_settings, array $new_settings ) {
        $old_mode = sanitize_key( $old_settings['feed_mode'] ?? '' );
        $new_mode = sanitize_key( $new_settings['feed_mode'] ?? '' );
        if ( $old_mode === '' || $new_mode === '' || $old_mode === $new_mode ) { return false; }
        update_option( self::OPTION_AUTO_NEWS_QUEUE, [], false );
        wp_clear_scheduled_hook( self::AUTO_NEWS_QUEUE_HOOK );
        delete_transient( 'heaj_auto_news_queue_lock' );
        delete_transient( 'heaj_auto_news_runner_lock' );
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, [
            'checked' => 0,
            'queued_now' => 0,
            'processed_queue' => 0,
            'created' => 0,
            'skipped' => 0,
            'failed' => 0,
            'message' => 'Mode Auto Artikel berubah dari ' . $old_mode . ' ke ' . $new_mode . '; antrean mode sebelumnya dibatalkan.',
            'time' => time(),
        ], false );
        $this->add_auto_news_log( 'Mode Auto Artikel berubah dari ' . $old_mode . ' ke ' . $new_mode . '. Antrean lama dibatalkan agar metode sebelumnya tidak ikut generate.', 'settings' );
        return true;
    }

    private function reset_auto_news_runtime_state( $message = '' ) {
        update_option( self::OPTION_AUTO_NEWS_QUEUE, [], false );
        wp_clear_scheduled_hook( self::AUTO_NEWS_QUEUE_HOOK );
        delete_transient( 'heaj_auto_news_queue_lock' );
        delete_transient( 'heaj_auto_news_runner_lock' );
        delete_transient( 'heaj_auto_master_lock' );
        delete_transient( 'heaj_auto_direct_fallback_lock' );
        delete_transient( 'heaj_auto_news_dispatch_lock' );
        delete_transient( 'heaj_auto_publish_slot_lock' );
        delete_transient( 'heaj_spawn_cron_lock' );
        delete_transient( 'heaj_shutdown_cron_lock' );
        if ( $message ) { $this->add_auto_news_log( $message, 'settings' ); }
    }

    public static function schedule_auto_news_static() {
        wp_clear_scheduled_hook( self::AUTO_NEWS_CRON_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_MASTER_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_QUEUE_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_KEEPALIVE_HOOK );
        $settings = self::sanitize_auto_news_settings_static( get_option( self::OPTION_AUTO_NEWS_SETTINGS, [] ) );
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return; }
        if ( ! wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK ) ) {
            wp_schedule_event( time() + 60, 'heaj_auto_master_5min', self::AUTO_NEWS_MASTER_HOOK );
        }
        if ( ! wp_next_scheduled( self::AUTO_NEWS_KEEPALIVE_HOOK ) ) {
            wp_schedule_single_event( time() + 180, self::AUTO_NEWS_KEEPALIVE_HOOK );
        }
    }

    private static function auto_news_interval_seconds_static( array $settings ) {
        $feed_mode = sanitize_key( $settings['feed_mode'] ?? 'google_trends' );
        if ( $feed_mode === 'manual_keywords' ) {
            $type = sanitize_key( $settings['kw_schedule_type'] ?? 'hours' );
            $value = max( 1, absint( $settings['kw_schedule_value'] ?? 1 ) );
            if ( $type === 'minutes' ) { return $value * MINUTE_IN_SECONDS; }
            if ( $type === 'days' ) { return $value * DAY_IN_SECONDS; }
            return $value * HOUR_IN_SECONDS;
        }
        $type = sanitize_key( $settings['gt_schedule_type'] ?? 'hours' );
        $value = max( 1, absint( $settings['gt_schedule_value'] ?? 1 ) );
        if ( $type === 'minutes' || $type === 'realtime' ) { return max( 15, $value ) * MINUTE_IN_SECONDS; }
        if ( $type === 'days' ) { return $value * DAY_IN_SECONDS; }
        return $value * HOUR_IN_SECONDS;
    }

    private function reschedule_auto_news() {
        self::schedule_auto_news_static();
    }

    public function auto_news_cron_schedules( $schedules ) {
        $schedules['heaj_auto_master_5min'] = [
            'interval' => 5 * MINUTE_IN_SECONDS,
            'display'  => 'HEAJ Auto Artikel Master Runner (5 menit)',
        ];
        $schedules['heaj_auto_news_realtime'] = [
            'interval' => 5 * MINUTE_IN_SECONDS,
            'display'  => 'HEAJ Auto News Realtime (5 menit)',
        ];
        for ( $i = 1; $i <= 24; $i++ ) {
            $schedules[ 'heaj_auto_news_every_' . $i . '_hours' ] = [
                'interval' => $i * HOUR_IN_SECONDS,
                'display'  => 'HEAJ Auto News setiap ' . $i . ' jam',
            ];
        }
        return $schedules;
    }

    private function add_auto_news_log( $message, $type = 'info', $extra = [] ) {
        $log = get_option( self::OPTION_AUTO_NEWS_LOG, [] );
        if ( ! is_array( $log ) ) { $log = []; }
        array_unshift( $log, [
            'time'    => current_time( 'mysql' ),
            'type'    => sanitize_key( $type ),
            'message' => sanitize_text_field( $message ),
            'extra'   => is_array( $extra ) ? $extra : [],
        ] );
        $log = array_slice( $log, 0, 80 );
        update_option( self::OPTION_AUTO_NEWS_LOG, $log, false );
    }

    public function render_auto_news_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        $settings = $this->get_auto_news_settings();
        $auto_news_license_valid = $this->is_allowed_license_domain();
        // Membuka halaman Auto Artikel tidak boleh menjalankan auto posting.
        // Eksekusi hanya lewat jadwal cron/heartbeat atau tombol Mulai Sekarang.
        $log = get_option( self::OPTION_AUTO_NEWS_LOG, [] );
        $latest_items = []; // Preview feed disembunyikan pada UI Auto Artikel sederhana.
        $last_run = absint( get_option( self::OPTION_AUTO_NEWS_LAST_RUN, 0 ) );
        $last_run_started = absint( get_option( self::OPTION_AUTO_NEWS_LAST_RUN_STARTED, 0 ) );
        $last_result = get_option( self::OPTION_AUTO_NEWS_LAST_RESULT, [] );
        if ( ! is_array( $last_result ) ) { $last_result = []; }
        $last_heartbeat = absint( get_option( 'he_journalist_auto_news_last_heartbeat', 0 ) );
        $last_keepalive = absint( get_option( 'he_journalist_auto_news_last_keepalive', 0 ) );
        $auto_news_next_publish_ts = $last_run ? $last_run + $this->auto_news_interval_seconds( $settings ) : 0;
        $queue = $this->auto_news_queue();
        $diagnostic = $this->auto_news_diagnostic();
        $keyword_tracking = $this->auto_news_keyword_tracking_summary( $settings );
        $keyword_status_rows = $this->auto_news_keyword_status_rows( $settings );
        $auto_news_external_runner_url = add_query_arg( 'token', rawurlencode( $this->auto_news_async_token() ), rest_url( 'heaj-auto-artikel/v1/runner' ) );
        $auto_news_author_users = get_users( [
            'role__in' => [ 'administrator', 'editor', 'author' ],
            'orderby'  => 'display_name',
            'order'    => 'ASC',
            'fields'   => [ 'ID', 'display_name', 'user_login' ],
        ] );
        include $this->plugin_dir() . 'templates/auto-news.php';
    }

    public function handle_save_auto_news_settings() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_save_auto_news' );
        if ( ! $this->is_allowed_license_domain() ) { wp_die( 'Lisensi belum valid. Auto Artikel hanya dapat dipakai setelah lisensi aktif.' ); }
        $raw = isset( $_POST['auto_news'] ) ? wp_unslash( $_POST['auto_news'] ) : [];
        $current = self::sanitize_auto_news_settings_static( get_option( self::OPTION_AUTO_NEWS_SETTINGS, [] ) );
        $merged = array_merge( $current, is_array( $raw ) ? $raw : [] );
        $settings = self::sanitize_auto_news_settings_static( $merged );
        $this->reset_auto_news_queue_if_mode_changed( $current, $settings );
        update_option( self::OPTION_AUTO_NEWS_SETTINGS, $settings, false );
        // Save AutoPilot berarti mulai siklus jadwal baru dari saat ini dan buang queue lama.
        $this->reset_auto_news_runtime_state( 'Pengaturan AutoPilot disimpan. Queue lama direset ke 0 dan jadwal publish dimulai ulang dari sekarang.' );
        update_option( self::OPTION_AUTO_NEWS_LAST_RUN, time(), false );
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, [
            'checked' => 0,
            'queued_now' => 0,
            'processed_queue' => 0,
            'created' => 0,
            'skipped' => 0,
            'failed' => 0,
            'message' => 'Pengaturan disimpan. Queue lama direset ke 0. Jadwal publish dimulai dari sekarang.',
            'time' => time(),
        ], false );
        $this->reschedule_auto_news();
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-auto-news', 'saved' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function ajax_auto_news_run_now_ui() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) {
            wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
        }
        check_ajax_referer( 'heaj_auto_news_run_now_ui', 'nonce' );
        if ( ! $this->is_allowed_license_domain() ) { wp_send_json_error( [ 'message' => 'Lisensi belum valid. Auto Artikel hanya dapat dipakai setelah lisensi aktif.' ], 403 ); }
        $raw = isset( $_POST['auto_news'] ) ? wp_unslash( $_POST['auto_news'] ) : [];
        $current = self::sanitize_auto_news_settings_static( get_option( self::OPTION_AUTO_NEWS_SETTINGS, [] ) );
        $merged = array_merge( $current, is_array( $raw ) ? $raw : [] );
        $merged['enabled'] = '1';
        $settings = self::sanitize_auto_news_settings_static( $merged );
        $this->reset_auto_news_queue_if_mode_changed( $current, $settings );
        update_option( self::OPTION_AUTO_NEWS_SETTINGS, $settings, false );
        $this->reset_auto_news_runtime_state( 'Mulai Sekarang: queue lama direset sebelum menjalankan 1 artikel manual.' );
        $this->reschedule_auto_news();
        $this->add_auto_news_log( 'Mulai Sekarang dijalankan dari UI Auto Artikel.', 'settings' );
        $enqueue = $this->enqueue_auto_news_candidates( true );
        $worker = $this->process_auto_news_queue( 1, true, $settings['feed_mode'] ?? '' );
        $result = array_merge( [ 'queued_now' => 0, 'processed_queue' => 0, 'created' => 0, 'skipped' => 0, 'failed' => 0 ], $enqueue, [ 'worker' => $worker ] );
        $result['processed_queue'] = absint( $worker['processed'] ?? 0 );
        $result['created'] = absint( $worker['created'] ?? 0 );
        $result['skipped'] = absint( $worker['skipped'] ?? 0 );
        $result['failed'] = absint( $worker['failed'] ?? 0 );
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
        update_option( self::OPTION_AUTO_NEWS_LAST_RUN, time(), false );
        $last_error = isset( $worker['last_error'] ) ? trim( (string) $worker['last_error'] ) : '';
        $message = ! empty( $result['created'] ) ? 'Berhasil membuat artikel otomatis.' : 'Proses selesai, tetapi belum ada artikel baru dibuat. Periksa status/log queue.';
        if ( $last_error && empty( $result['created'] ) ) { $message .= ' Penyebab terakhir: ' . $last_error; }
        wp_send_json_success( [
            'message' => $message,
            'result'  => $result,
        ] );
    }

    public function handle_auto_news_run_now() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_auto_news_run_now' );
        if ( ! $this->is_allowed_license_domain() ) { wp_die( 'Lisensi belum valid. Auto Artikel hanya dapat dipakai setelah lisensi aktif.' ); }
        $settings = $this->get_auto_news_settings();
        $this->reset_auto_news_runtime_state( 'Mulai Sekarang legacy: queue lama direset sebelum menjalankan 1 artikel manual.' );
        $enqueue = $this->enqueue_auto_news_candidates( true );
        $worker = $this->process_auto_news_queue( 1, true, $settings['feed_mode'] ?? '' );
        $result = array_merge( [ 'queued_now' => 0, 'processed_queue' => 0 ], $enqueue, [ 'worker' => $worker ] );
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
        update_option( self::OPTION_AUTO_NEWS_LAST_RUN, time(), false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-auto-news', 'run' => ! empty( $worker['created'] ) ? 'created' : 'queued' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_auto_news_force_queue() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_auto_news_force_queue' );
        if ( ! $this->is_allowed_license_domain() ) { wp_die( 'Lisensi belum valid. Auto Artikel hanya dapat dipakai setelah lisensi aktif.' ); }
        $result = $this->enqueue_auto_news_candidates( true );
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-auto-news', 'queue' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_auto_news_run_sync() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_auto_news_run_sync' );
        if ( ! $this->is_allowed_license_domain() ) { wp_die( 'Lisensi belum valid. Auto Artikel hanya dapat dipakai setelah lisensi aktif.' ); }
        $settings = $this->get_auto_news_settings();
        $worker_limit = ( $settings['feed_mode'] ?? '' ) === 'manual_keywords' ? 1 : 5;
        $result = $this->process_auto_news_queue( $worker_limit, true, $settings['feed_mode'] ?? '' );
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, [ 'sync_worker' => $result ], false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-auto-news', 'sync' => ! empty( $result['created'] ) ? 'created' : 'checked' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_auto_news_reset_keywords() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_auto_news_reset_keywords' );
        if ( ! $this->is_allowed_license_domain() ) { wp_die( 'Lisensi belum valid. Auto Artikel hanya dapat dipakai setelah lisensi aktif.' ); }
        update_option( self::OPTION_AUTO_NEWS_USED_KEYWORDS, [], false );
        $this->add_auto_news_log( 'Siklus keyword manual direset.', 'settings' );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-auto-news', 'kwreset' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function run_auto_news_cron() {
        return $this->run_auto_news_master_cron( true );
    }

    public function run_auto_news_master_cron( $forced = false ) {
        @ignore_user_abort( true );
        @set_time_limit( 600 );
        @ini_set( 'max_execution_time', '600' );
        @ini_set( 'memory_limit', '512M' );
        if ( get_transient( 'heaj_auto_master_lock' ) ) {
            return [ 'checked' => 0, 'queued_now' => 0, 'processed_queue' => 0, 'created' => 0, 'skipped' => 0, 'failed' => 0, 'message' => 'Master runner masih berjalan.', 'time' => time() ];
        }
        set_transient( 'heaj_auto_master_lock', time(), 10 * MINUTE_IN_SECONDS );
        $settings = $this->get_auto_news_settings();
        $result = [ 'checked' => 0, 'queued_now' => 0, 'processed_queue' => 0, 'created' => 0, 'skipped' => 0, 'failed' => 0, 'message' => 'Master runner selesai tanpa aksi.', 'time' => time() ];
        try {
            if ( ! $this->is_allowed_license_domain() ) {
                $result['message'] = 'Auto Artikel tidak berjalan karena lisensi belum valid.';
                update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
                return $result;
            }
            if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) {
                $result['message'] = 'Auto posting nonaktif.';
                update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
                return $result;
            }
            $this->ensure_auto_news_master_cron_scheduled();
            $this->cleanup_stale_auto_news_queue();
            update_option( self::OPTION_AUTO_NEWS_LAST_RUN_STARTED, time(), false );

            $mode = sanitize_key( $settings['feed_mode'] ?? '' );
            $due = $forced || $this->is_auto_news_due_by_last_run( $settings );

            if ( $due ) {
                $enqueue = $this->enqueue_auto_news_candidates( false );
                $result = array_merge( $result, $enqueue );
                $result['message'] = 'Master runner mengecek task aktif.';
            } else {
                $result['message'] = 'Belum waktunya publish.';
            }

            if ( $due || ! empty( $result['queued_now'] ) ) {
                // Aturan AutoPilot: satu jadwal hanya memproses satu artikel.
                // Queue sisa menunggu jadwal publish berikutnya, bukan diproses terus-menerus.
                $worker = $this->process_auto_news_queue( 1, false, $mode );
                $result['worker'] = $worker;
                $result['processed_queue'] = absint( $worker['processed'] ?? 0 );
                $result['created'] = absint( $worker['created'] ?? 0 );
                $result['skipped'] = absint( $worker['skipped'] ?? 0 );
                $result['failed']  = absint( $worker['failed'] ?? 0 );
                if ( ! empty( $worker['last_error'] ) ) { $result['last_error'] = $worker['last_error']; }
                update_option( self::OPTION_AUTO_NEWS_LAST_RUN, time(), false );
            }

            update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
            update_option( 'he_journalist_auto_news_last_heartbeat', time(), false );
            return $result;
        } catch ( Throwable $e ) {
            $result = [ 'checked' => 0, 'queued_now' => 0, 'processed_queue' => 0, 'created' => 0, 'skipped' => 0, 'failed' => 1, 'message' => $e->getMessage(), 'time' => time() ];
            update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, $result, false );
            $this->add_auto_news_log( 'Fatal Auto Artikel master runner: ' . $e->getMessage(), 'error' );
            return $result;
        } finally {
            delete_transient( 'heaj_auto_master_lock' );
        }
    }

    private function ensure_auto_news_master_cron_scheduled() {
        $next = wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK );
        if ( ! $next || $next < ( time() - 10 * MINUTE_IN_SECONDS ) ) {
            wp_clear_scheduled_hook( self::AUTO_NEWS_MASTER_HOOK );
            wp_schedule_event( time() + 60, 'heaj_auto_master_5min', self::AUTO_NEWS_MASTER_HOOK );
        }
    }

    private function auto_news_interval_seconds( array $settings ) {
        return self::auto_news_interval_seconds_static( $settings );
    }

    private function auto_news_async_token() {
        $token = get_option( self::OPTION_AUTO_NEWS_ASYNC_TOKEN, '' );
        if ( ! is_string( $token ) || strlen( $token ) < 20 ) {
            $token = wp_generate_password( 48, false, false );
            update_option( self::OPTION_AUTO_NEWS_ASYNC_TOKEN, $token, false );
        }
        return $token;
    }

    private function is_auto_news_due( array $settings ) {
        return $this->is_auto_news_due_by_last_run( $settings );
    }

    private function is_auto_news_due_by_last_run( array $settings ) {
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return false; }
        $last_run = absint( get_option( self::OPTION_AUTO_NEWS_LAST_RUN, 0 ) );
        if ( ! $last_run ) { return true; }
        return ( time() - $last_run ) >= $this->auto_news_interval_seconds( $settings );
    }

    private function fire_auto_news_non_blocking_loopback() {
        $headers = [ 'user-agent' => 'HEAJ-Auto-Artikel-Cron/' . self::VERSION ];
        $args = [
            'timeout'   => 1,
            'blocking'  => false,
            'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
            'headers'   => $headers,
        ];
        $cron_url = site_url( 'wp-cron.php?doing_wp_cron=' . sprintf( '%.22F', microtime( true ) ) );
        wp_remote_post( $cron_url, $args );
        $async_url = add_query_arg( [
            'action' => 'heaj_auto_news_async_run',
            'token'  => rawurlencode( $this->auto_news_async_token() ),
        ], admin_url( 'admin-ajax.php' ) );
        wp_remote_post( $async_url, $args );
        update_option( 'he_journalist_auto_news_last_heartbeat', time(), false );
    }

    private function run_auto_news_direct_fallback_if_needed( array $settings, $reason = 'fallback' ) {
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return false; }
        if ( get_transient( 'heaj_auto_direct_fallback_lock' ) ) { return false; }
        $due = $this->is_auto_news_due_by_last_run( $settings );
        $master_next = wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK );
        if ( ! $due ) {
            if ( ! $master_next || $master_next < ( time() - 10 * MINUTE_IN_SECONDS ) ) {
                wp_clear_scheduled_hook( self::AUTO_NEWS_MASTER_HOOK );
                wp_schedule_event( time() + 60, 'heaj_auto_master_5min', self::AUTO_NEWS_MASTER_HOOK );
            }
            return false;
        }
        set_transient( 'heaj_auto_direct_fallback_lock', time(), 10 * MINUTE_IN_SECONDS );
        $this->add_auto_news_log( 'Direct fallback AutoPilot dijalankan karena scheduler overdue/loopback lambat: ' . sanitize_text_field( $reason ), 'cron' );
        $this->run_auto_news_master_cron( false );
        wp_clear_scheduled_hook( self::AUTO_NEWS_MASTER_HOOK );
        wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'heaj_auto_master_5min', self::AUTO_NEWS_MASTER_HOOK );
        return true;
    }

    public function maybe_dispatch_auto_news_runner() {
        if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) { return; }
        $last = (int) get_transient( 'heaj_spawn_cron_lock' );
        if ( $last && ( time() - $last ) < 60 ) { return; }
        set_transient( 'heaj_spawn_cron_lock', time(), 120 );

        $settings = $this->get_auto_news_settings();
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return; }
        $this->ensure_auto_news_master_cron_scheduled();
        $should_fire = false;
        $master_next = wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK );
        if ( ! $master_next || $master_next <= time() ) { $should_fire = true; }
        if ( $this->is_auto_news_due_by_last_run( $settings ) ) { $should_fire = true; }
        if ( $should_fire ) {
            $this->fire_auto_news_non_blocking_loopback();
            if ( $master_next && $master_next <= ( time() - 60 ) ) {
                $this->run_auto_news_direct_fallback_if_needed( $settings, 'master cron overdue' );
            }
        }
    }

    public function shutdown_auto_news_heartbeat() {
        if ( defined( 'DOING_CRON' ) && DOING_CRON ) { return; }
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) { return; }
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) { return; }
        $last = (int) get_transient( 'heaj_shutdown_cron_lock' );
        if ( $last && ( time() - $last ) < 120 ) { return; }
        set_transient( 'heaj_shutdown_cron_lock', time(), 180 );
        $settings = $this->get_auto_news_settings();
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return; }
        $this->ensure_auto_news_master_cron_scheduled();
        if ( $this->is_auto_news_due_by_last_run( $settings ) ) {
            $this->fire_auto_news_non_blocking_loopback();
            $this->run_auto_news_direct_fallback_if_needed( $settings, 'shutdown heartbeat' );
        }
    }

    public function register_auto_news_rest_endpoint() {
        register_rest_route( 'heaj-auto-artikel/v1', '/heartbeat', [
            'methods'             => [ 'GET', 'POST' ],
            'callback'            => [ $this, 'rest_auto_news_heartbeat' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( 'heaj-auto-artikel/v1', '/rss-proxy', [
            'methods'             => [ 'GET' ],
            'callback'            => [ $this, 'rest_auto_news_rss_proxy' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( 'heaj-auto-artikel/v1', '/runner', [
            'methods'             => [ 'GET', 'POST' ],
            'callback'            => [ $this, 'rest_auto_news_external_runner' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public function rest_auto_news_external_runner( WP_REST_Request $request ) {
        $token = sanitize_text_field( (string) $request->get_param( 'token' ) );
        if ( ! $token || ! hash_equals( $this->auto_news_async_token(), $token ) ) {
            return new WP_Error( 'heaj_runner_token_invalid', 'Token runner Auto Artikel tidak valid.', [ 'status' => 403 ] );
        }
        if ( ! $this->is_allowed_license_domain() ) {
            return new WP_Error( 'heaj_runner_license_invalid', 'Lisensi belum valid.', [ 'status' => 403 ] );
        }
        $settings = $this->get_auto_news_settings();
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) {
            return rest_ensure_response( [ 'ok' => true, 'ran' => false, 'message' => 'Auto Artikel nonaktif.' ] );
        }
        $due = $this->is_auto_news_due( $settings );
        if ( ! $due ) {
            return rest_ensure_response( [
                'ok'      => true,
                'ran'     => false,
                'message' => 'Belum waktunya berjalan.',
                'next_ts' => wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK ),
            ] );
        }
        delete_transient( 'heaj_auto_news_dispatch_lock' );
        delete_transient( 'heaj_spawn_cron_lock' );
        $result = $this->run_auto_news_cron();
        return rest_ensure_response( [
            'ok'      => true,
            'ran'     => true,
            'message' => 'External runner Auto Artikel selesai.',
            'next_ts' => wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK ),
            'result'  => $result,
        ] );
    }

    public function rest_auto_news_rss_proxy( WP_REST_Request $request ) {
        if ( ! $this->is_allowed_license_domain() ) {
            return new WP_Error( 'heaj_proxy_license_invalid', 'Lisensi belum valid.', [ 'status' => 403 ] );
        }
        $target = esc_url_raw( (string) $request->get_param( 'url' ) );
        if ( ! $this->is_allowed_auto_news_proxy_target( $target ) ) {
            return new WP_Error( 'heaj_proxy_target_invalid', 'Target proxy tidak diizinkan.', [ 'status' => 400 ] );
        }
        $result = $this->fetch_global_trends_body_direct( $target );
        $body = is_array( $result ) ? (string) ( $result['body'] ?? '' ) : '';
        if ( $body === '' || ( stripos( $body, '<rss' ) === false && stripos( $body, '<item' ) === false && stripos( $body, '<feed' ) === false ) ) {
            return new WP_Error( 'heaj_proxy_fetch_failed', 'Proxy gagal membaca RSS target: ' . sanitize_text_field( $result['error'] ?? 'body kosong' ), [ 'status' => 502 ] );
        }
        return rest_ensure_response( [
            'ok'     => true,
            'url'    => $target,
            'method' => sanitize_text_field( $result['method'] ?? 'direct' ),
            'body'   => $body,
        ] );
    }

    private function is_allowed_auto_news_proxy_target( $url ) {
        $url = esc_url_raw( $url );
        if ( ! $url ) { return false; }
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        $path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
        if ( in_array( $host, [ 'trends.google.com' ], true ) && strpos( $path, '/trending/rss' ) === 0 ) { return true; }
        if ( in_array( $host, [ 'www.trendhunter.com', 'trendhunter.com' ], true ) && $path === '/rss' ) { return true; }
        return false;
    }

    public function rest_auto_news_heartbeat( WP_REST_Request $request ) {
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? preg_replace( '/[^a-fA-F0-9\.\:]/', '', (string) $_SERVER['REMOTE_ADDR'] ) : 'unknown';
        $key = 'heaj_rest_hb_' . md5( $ip );
        if ( get_transient( $key ) ) {
            return [ 'ok' => true, 'msg' => 'Throttled', 'next_ts' => wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK ) ];
        }
        set_transient( $key, 1, 30 );
        $settings = $this->get_auto_news_settings();
        if ( ! empty( $settings['enabled'] ) && $settings['enabled'] === '1' ) {
            $this->ensure_auto_news_master_cron_scheduled();
            $this->fire_auto_news_non_blocking_loopback();
            if ( $this->is_auto_news_due_by_last_run( $settings ) ) {
                $this->run_auto_news_direct_fallback_if_needed( $settings, 'REST heartbeat' );
            }
        }
        return [ 'ok' => true, 'time' => current_time( 'mysql' ), 'next_scheduled' => wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK ), 'last_heartbeat' => get_option( 'he_journalist_auto_news_last_heartbeat', 0 ) ];
    }

    public function inject_auto_news_frontend_heartbeat() {
        $settings = $this->get_auto_news_settings();
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return; }
        $url = esc_url_raw( rest_url( 'heaj-auto-artikel/v1/heartbeat' ) );
        echo '<script>(function(){try{setTimeout(function(){fetch(' . wp_json_encode( $url ) . ',{method:"GET",cache:"no-store",credentials:"omit",keepalive:true}).catch(function(){})},3000);}catch(e){}})();</script>';
    }

    public function schedule_next_auto_news_keepalive() {
        $settings = $this->get_auto_news_settings();
        if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) { return; }
        if ( $this->auto_news_interval_seconds( $settings ) <= 6 * HOUR_IN_SECONDS && ! wp_next_scheduled( self::AUTO_NEWS_KEEPALIVE_HOOK ) ) {
            wp_schedule_single_event( time() + 300, self::AUTO_NEWS_KEEPALIVE_HOOK );
        }
        $this->fire_auto_news_non_blocking_loopback();
    }

    public function auto_news_keepalive_handler() {
        if ( get_transient( 'heaj_keepalive_running' ) ) { return; }
        set_transient( 'heaj_keepalive_running', 1, 240 );
        $settings = $this->get_auto_news_settings();
        if ( ! empty( $settings['enabled'] ) && $settings['enabled'] === '1' && $this->auto_news_interval_seconds( $settings ) <= 6 * HOUR_IN_SECONDS ) {
            wp_schedule_single_event( time() + 300, self::AUTO_NEWS_KEEPALIVE_HOOK );
            if ( $this->is_auto_news_due_by_last_run( $settings ) ) {
                $this->fire_auto_news_non_blocking_loopback();
            }
        }
        update_option( 'he_journalist_auto_news_last_keepalive', time(), false );
    }

    public function ajax_auto_news_async_run() {
        $token = isset( $_REQUEST['token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['token'] ) ) : '';
        if ( ! $token || ! hash_equals( $this->auto_news_async_token(), $token ) ) {
            wp_send_json_error( [ 'message' => 'Token Auto Artikel tidak valid.' ], 403 );
        }
        delete_transient( 'heaj_auto_news_dispatch_lock' );
        try {
            $result = $this->run_auto_news_cron();
            wp_send_json_success( [ 'message' => 'Auto Artikel runner selesai.', 'result' => $result ] );
        } catch ( Throwable $e ) {
            $this->add_auto_news_log( 'Fatal Auto Artikel runner: ' . $e->getMessage(), 'error' );
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    private function fetch_google_trends_rss_items( $limit = 20, array $settings = [] ) {
        $limit = max( 1, min( 30, absint( $limit ) ) );
        $cache_key = 'heaj_google_trends_rss_cache_' . $limit;
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) && ! empty( $cached ) ) { return $cached; }

        $backoff_until = absint( get_transient( 'heaj_google_trends_429_until' ) );
        if ( $backoff_until && $backoff_until > time() ) {
            if ( ! get_transient( 'heaj_google_trends_429_notice_lock' ) ) {
                $this->add_auto_news_log( 'Google Trends sedang rate limit sampai ' . wp_date( 'Y-m-d H:i:s', $backoff_until ) . '. Plugin tetap mencoba direct/proxy sebelum fallback.', 'warning' );
                set_transient( 'heaj_google_trends_429_notice_lock', 1, 10 * MINUTE_IN_SECONDS );
            }
        }

        $rss_url = 'https://trends.google.com/trending/rss?geo=ID&hl=id-ID';
        $response = wp_remote_get( $rss_url, [
            'timeout'     => 25,
            'redirection' => 5,
            'headers'     => [
                'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari YZG-AI-Journalist/' . self::VERSION,
                'Accept'          => 'application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.5',
                'Accept-Language' => 'id-ID,id;q=0.9,en-US;q=0.6,en;q=0.5',
                'Cache-Control'   => 'no-cache',
            ],
        ] );
        $body = '';
        $code = 0;
        $need_proxy = false;
        $error_message = '';
        if ( is_wp_error( $response ) ) {
            $need_proxy = true;
            $error_message = $response->get_error_message();
        } else {
            $code = (int) wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            if ( $code === 429 ) {
                $until = time() + 45 * MINUTE_IN_SECONDS;
                set_transient( 'heaj_google_trends_429_until', $until, 45 * MINUTE_IN_SECONDS );
                $this->add_auto_news_log( 'Google Trends RSS kena HTTP 429/rate limit. Mencoba proxy RSS sebelum fallback.', 'warning' );
                $need_proxy = true;
            } elseif ( $code < 200 || $code >= 300 || ! is_string( $body ) || trim( $body ) === '' ) {
                $need_proxy = true;
                $error_message = 'HTTP ' . $code . ' / body kosong';
            }
        }
        if ( $need_proxy ) {
            $proxy_body = $this->fetch_auto_news_rss_body_via_proxy( $rss_url, $settings );
            if ( $proxy_body !== '' ) {
                $body = $proxy_body;
                $code = 200;
                $this->add_auto_news_log( 'Google Trends RSS berhasil dibaca via proxy.', 'proxy' );
            } else {
                $this->add_auto_news_log( 'Google Trends RSS tidak bisa dibaca langsung/proxy: ' . $error_message . '. Fallback ke Google News Indonesia.', 'error' );
                return $this->fetch_google_news_top_rss_items( $limit, 'Google News fallback karena Google Trends/proxy gagal' );
            }
        }
        if ( ! is_string( $body ) || trim( $body ) === '' ) {
            return $this->fetch_google_news_top_rss_items( $limit, 'Google News fallback karena Google Trends kosong' );
        }
        $xml = @simplexml_load_string( $body, 'SimpleXMLElement', LIBXML_NOCDATA );
        if ( ! $xml || empty( $xml->channel->item ) ) {
            $this->add_auto_news_log( 'Format Google Trends RSS tidak valid atau kosong. Fallback ke Google News Indonesia.', 'error' );
            return $this->fetch_google_news_top_rss_items( $limit, 'Google News fallback karena Google Trends kosong' );
        }
        $items = [];
        foreach ( $xml->channel->item as $node ) {
            $title = sanitize_text_field( (string) $node->title );
            $link = $this->normalize_global_trends_url( (string) $node->link );
            $pub_date = sanitize_text_field( (string) $node->pubDate );
            $traffic = '';
            $picture = '';
            $picture_caption = '';
            $news_items = [];
            $namespaces = $node->getNameSpaces( true );
            if ( isset( $namespaces['ht'] ) ) {
                $ht = $node->children( $namespaces['ht'] );
                $traffic = sanitize_text_field( (string) ( $ht->approx_traffic ?? '' ) );
                $picture = esc_url_raw( (string) ( $ht->picture ?? '' ) );
                $picture_caption = $this->clean_source_image_caption( (string) ( $ht->picture_caption ?? $ht->picture_source ?? '' ) );
                if ( isset( $ht->news_item ) ) {
                    foreach ( $ht->news_item as $news ) {
                        $children = $news->children( $namespaces['ht'] );
                        $news_title = sanitize_text_field( (string) ( $children->news_item_title ?? '' ) );
                        $news_url = esc_url_raw( (string) ( $children->news_item_url ?? '' ) );
                        $news_source = sanitize_text_field( (string) ( $children->news_item_source ?? '' ) );
                        if ( $news_url ) {
                            $news_items[] = [ 'title' => $news_title, 'url' => $news_url, 'source' => $news_source ];
                        }
                    }
                }
            }
            if ( empty( $news_items ) && $link ) {
                $news_items[] = [ 'title' => $title, 'url' => $link, 'source' => 'Google Trends' ];
            }
            if ( ! $title || empty( $news_items ) ) { continue; }
            $id = md5( 'trends|' . strtolower( $title . '|' . $pub_date . '|' . wp_json_encode( wp_list_pluck( $news_items, 'url' ) ) ) );
            $items[] = [
                'id'         => $id,
                'title'      => $title,
                'link'       => $link,
                'pub_date'   => $pub_date,
                'traffic'    => $traffic ?: 'Google Trends',
                'picture'    => $picture,
                'picture_caption' => $picture_caption,
                'news_items' => $news_items,
            ];
            if ( count( $items ) >= $limit ) { break; }
        }
        if ( ! empty( $items ) ) {
            set_transient( $cache_key, $items, 12 * MINUTE_IN_SECONDS );
            return $items;
        }
        return $this->fetch_google_news_top_rss_items( $limit, 'Google News fallback karena Google Trends tanpa item valid' );
    }

    private function fetch_google_news_top_rss_items( $limit = 20, $label = 'Google News Indonesia' ) {
        $limit = max( 1, min( 30, absint( $limit ) ) );
        $cache_key = 'heaj_google_news_top_cache_' . $limit;
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) && ! empty( $cached ) ) { return $cached; }
        $items = $this->fetch_generic_rss_items( 'https://news.google.com/rss?hl=id&gl=ID&ceid=ID:id', $limit );
        if ( ! empty( $items ) ) {
            foreach ( $items as &$item ) {
                $item['traffic'] = $label;
                $item['id'] = md5( 'google_news_top|' . ( $item['id'] ?? '' ) );
            }
            unset( $item );
            set_transient( $cache_key, $items, 10 * MINUTE_IN_SECONDS );
        }
        return $items;
    }

    private function auto_article_keywords_from_settings( $manual_keywords ) {
        $raw = preg_split( '/\r\n|\r|\n|,/', (string) $manual_keywords );
        $items = [];
        foreach ( $raw as $row ) {
            $row = trim( sanitize_text_field( $row ) );
            if ( $row !== '' && ! in_array( $row, $items, true ) ) { $items[] = $row; }
        }
        return array_slice( $items, 0, 20 );
    }

    private function auto_news_used_keywords() {
        $used = get_option( self::OPTION_AUTO_NEWS_USED_KEYWORDS, [] );
        return is_array( $used ) ? $used : [];
    }

    private function mark_auto_news_keyword_used( $keyword, $post_id = 0 ) {
        $keyword = trim( sanitize_text_field( $keyword ) );
        if ( $keyword === '' ) { return; }
        $post_id = absint( $post_id );
        $used = $this->auto_news_used_keywords();
        $row = [
            'keyword' => $keyword,
            'time'    => time(),
            'post_id' => $post_id,
            'status'  => $post_id ? get_post_status( $post_id ) : '',
            'title'   => $post_id ? get_the_title( $post_id ) : '',
            'url'     => $post_id ? get_permalink( $post_id ) : '',
        ];
        $used[ md5( strtolower( $keyword ) ) ] = $row;
        update_option( self::OPTION_AUTO_NEWS_USED_KEYWORDS, $used, false );
    }

    private function auto_news_keyword_status_rows( array $settings ) {
        $keywords = $this->auto_article_keywords_from_settings( $settings['manual_keywords'] ?? '' );
        $used = $this->auto_news_used_keywords();
        $rows = [];
        foreach ( $keywords as $keyword ) {
            $key = md5( strtolower( $keyword ) );
            $hit = isset( $used[ $key ] ) && is_array( $used[ $key ] ) ? $used[ $key ] : [];
            $post_id = absint( $hit['post_id'] ?? 0 );
            $status = $post_id ? get_post_status( $post_id ) : sanitize_key( $hit['status'] ?? '' );
            $done = $post_id && in_array( $status, [ 'publish', 'draft', 'pending', 'future' ], true );
            $rows[] = [
                'keyword' => $keyword,
                'done'    => $done,
                'post_id' => $post_id,
                'status'  => $status ?: ( $done ? 'generated' : 'pending' ),
                'title'   => sanitize_text_field( $hit['title'] ?? ( $post_id ? get_the_title( $post_id ) : '' ) ),
                'url'     => esc_url_raw( $hit['url'] ?? ( $post_id ? get_permalink( $post_id ) : '' ) ),
                'time'    => absint( $hit['time'] ?? 0 ),
            ];
        }
        return $rows;
    }

    private function disable_auto_news_after_keyword_complete() {
        $settings = $this->get_auto_news_settings();
        if ( ( $settings['feed_mode'] ?? '' ) !== 'manual_keywords' ) { return; }
        if ( ( $settings['enabled'] ?? '0' ) !== '1' ) { return; }
        $settings['enabled'] = '0';
        update_option( self::OPTION_AUTO_NEWS_SETTINGS, $settings, false );
        wp_clear_scheduled_hook( self::AUTO_NEWS_CRON_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_MASTER_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_QUEUE_HOOK );
        wp_clear_scheduled_hook( self::AUTO_NEWS_KEEPALIVE_HOOK );
        delete_transient( 'heaj_auto_news_queue_lock' );
        delete_transient( 'heaj_auto_news_runner_lock' );
        $this->add_auto_news_log( 'Semua keyword manual sudah berhasil digenerate. Jadwal Auto Artikel dihentikan otomatis.', 'settings' );
    }

    private function select_auto_article_keywords( array $keywords, array $settings ) {
        $keywords = array_values( array_filter( array_unique( array_map( 'trim', $keywords ) ) ) );
        if ( empty( $keywords ) ) { return []; }
        $used = $this->auto_news_used_keywords();
        $available = [];
        foreach ( $keywords as $kw ) {
            $key = md5( strtolower( $kw ) );
            if ( empty( $used[ $key ] ) ) { $available[] = $kw; }
        }
        if ( empty( $available ) && ( $settings['keyword_cycle_reset'] ?? '1' ) === '1' ) {
            update_option( self::OPTION_AUTO_NEWS_USED_KEYWORDS, [], false );
            update_option( 'he_journalist_auto_news_keyword_cycle', absint( get_option( 'he_journalist_auto_news_keyword_cycle', 0 ) ) + 1, false );
            $available = $keywords;
            $this->add_auto_news_log( 'Semua keyword manual sudah dipakai; siklus keyword direset otomatis.', 'settings' );
        }
        if ( empty( $available ) ) { return []; }
        if ( ( $settings['keyword_pick_mode'] ?? 'random' ) === 'random' ) {
            shuffle( $available );
        }
        $take = min( count( $available ), max( 1, absint( $settings['keywords_per_run'] ?? 1 ) ) );
        return array_slice( $available, 0, $take );
    }

    private function auto_news_keyword_tracking_summary( array $settings ) {
        $keywords = $this->auto_article_keywords_from_settings( $settings['manual_keywords'] ?? '' );
        $used = $this->auto_news_used_keywords();
        $used_count = 0;
        foreach ( $keywords as $kw ) {
            if ( ! empty( $used[ md5( strtolower( $kw ) ) ] ) ) { $used_count++; }
        }
        return [
            'total'     => count( $keywords ),
            'used'      => $used_count,
            'remaining' => max( 0, count( $keywords ) - $used_count ),
            'mode'      => $settings['keyword_pick_mode'] ?? 'random',
            'per_run'   => absint( $settings['keywords_per_run'] ?? 1 ),
        ];
    }

    private function auto_news_site_rotation_seed() {
        $seed = get_option( 'he_journalist_auto_news_site_rotation_seed', '' );
        if ( ! is_string( $seed ) || $seed === '' ) {
            $seed = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : md5( home_url( '/' ) . '|' . microtime( true ) . '|' . wp_rand() );
            update_option( 'he_journalist_auto_news_site_rotation_seed', $seed, false );
        }
        return $seed;
    }

    private function order_auto_news_feed_items_for_site( array $items, array $settings ) {
        $feed_mode = sanitize_key( $settings['feed_mode'] ?? 'google_trends' );
        if ( ! in_array( $feed_mode, [ 'autopilot', 'google_trends', 'global_trends' ], true ) || count( $items ) < 2 ) { return $items; }
        $interval = max( 300, $this->auto_news_interval_seconds( $settings ) );
        $bucket = (int) floor( time() / $interval );
        $seed = $this->auto_news_site_rotation_seed() . '|' . home_url( '/' ) . '|' . $feed_mode . '|' . $bucket;
        usort( $items, function( $a, $b ) use ( $seed ) {
            $aid = (string) ( $a['id'] ?? ( $a['title'] ?? '' ) );
            $bid = (string) ( $b['id'] ?? ( $b['title'] ?? '' ) );
            $as = sprintf( '%u', crc32( $seed . '|' . $aid ) );
            $bs = sprintf( '%u', crc32( $seed . '|' . $bid ) );
            if ( $as === $bs ) { return strcmp( $aid, $bid ); }
            return $as <=> $bs;
        } );
        return $items;
    }

    private function fetch_autopilot_source_items( array $settings, $limit = 20 ) {
        $limit = max( 3, min( 30, absint( $limit ) ) );
        $pool = [];
        $google_items = $this->fetch_google_trends_rss_items( max( 10, (int) ceil( $limit / 2 ) ), $settings );
        foreach ( $google_items as $item ) {
            $item['autopilot_source'] = 'google_trends';
            $item['id'] = 'ap_google_' . md5( (string) ( $item['id'] ?? $item['link'] ?? $item['title'] ?? wp_json_encode( $item ) ) );
            $pool[] = $item;
        }
        $global_items = $this->fetch_global_trends_rss_items( max( 10, (int) ceil( $limit / 2 ) ), $settings );
        foreach ( $global_items as $item ) {
            $item['autopilot_source'] = 'global_trends';
            $item['id'] = 'ap_global_' . md5( (string) ( $item['id'] ?? $item['link'] ?? $item['title'] ?? wp_json_encode( $item ) ) );
            $pool[] = $item;
        }
        if ( empty( $pool ) ) {
            $this->add_auto_news_log( 'AutoPilot: tidak ada kandidat dari Google Trends atau Global Trends.', 'warning' );
            return [];
        }
        $keywords = $this->auto_article_keywords_from_settings( $settings['manual_keywords'] ?? '' );
        if ( ! empty( $keywords ) ) {
            $matched = [];
            foreach ( $pool as $item ) {
                $haystack = mb_strtolower( wp_strip_all_tags( ( $item['title'] ?? '' ) . ' ' . ( $item['summary'] ?? '' ) . ' ' . wp_json_encode( $item['news_items'] ?? [] ) ) );
                foreach ( $keywords as $kw ) {
                    if ( $kw !== '' && mb_stripos( $haystack, mb_strtolower( $kw ) ) !== false ) {
                        $matched[] = $item;
                        break;
                    }
                }
                if ( count( $matched ) >= $limit ) { break; }
            }
            if ( ! empty( $matched ) ) { $pool = $matched; }
        }
        $pool = $this->order_auto_news_feed_items_for_site( $pool, array_merge( $settings, [ 'feed_mode' => 'autopilot' ] ) );
        return array_slice( $pool, 0, $limit );
    }

    private function fetch_auto_source_items( array $settings, $limit = 20 ) {
        if ( ( $settings['feed_mode'] ?? 'autopilot' ) === 'autopilot' ) {
            return $this->fetch_autopilot_source_items( $settings, $limit );
        }
        if ( ( $settings['feed_mode'] ?? 'autopilot' ) === 'global_trends' ) {
            return $this->fetch_global_trends_rss_items( $limit, $settings );
        }
        if ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'google_news' ) {
            return $this->fetch_google_news_top_rss_items( $limit, 'Google News Indonesia' );
        }
        if ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'manual_keywords' ) {
            $keywords = $this->auto_article_keywords_from_settings( $settings['manual_keywords'] ?? '' );
            if ( empty( $keywords ) ) {
                $this->add_auto_news_log( 'Mode keyword manual aktif, tetapi keyword masih kosong.', 'warning' );
                return [];
            }
            $settings['keyword_pick_mode'] = 'sequential';
            $keywords = $this->select_auto_article_keywords( $keywords, $settings );
            if ( empty( $keywords ) ) {
                $this->add_auto_news_log( 'Semua keyword manual sudah digenerate. Auto Artikel dihentikan otomatis.', 'settings' );
                $this->disable_auto_news_after_keyword_complete();
                return [];
            }
            $items = [];
            foreach ( $keywords as $keyword ) {
                $keyword = trim( sanitize_text_field( $keyword ) );
                if ( $keyword === '' ) { continue; }
                $cycle = absint( get_option( 'he_journalist_auto_news_keyword_cycle', 0 ) );
                $id = md5( 'manual_keyword_direct|' . $cycle . '|' . mb_strtolower( $keyword ) );
                $items[] = [
                    'id'         => $id,
                    'title'      => $keyword,
                    'link'       => '',
                    'pub_date'   => current_time( 'mysql' ),
                    'traffic'    => 'Keyword Manual SEO',
                    'picture'    => '',
                    'summary'    => 'Keyword utama untuk artikel SEO: ' . $keyword,
                    'keyword'    => $keyword,
                    'keyword_direct' => '1',
                    'news_items' => [ [ 'title' => $keyword, 'url' => '', 'source' => 'Keyword Manual', 'summary' => 'Keyword utama untuk artikel SEO: ' . $keyword ] ],
                ];
                if ( count( $items ) >= $limit ) { break; }
            }
            return $items;
        }
        if ( ( $settings['feed_mode'] ?? 'google_trends' ) === 'manual_rss' ) {
            $rss_urls = $this->auto_article_rss_urls_from_settings( $settings['manual_rss_urls'] ?? '' );
            if ( empty( $rss_urls ) ) {
                $this->add_auto_news_log( 'Mode RSS manual aktif, tetapi URL RSS masih kosong.', 'warning' );
                return [];
            }
            $merged = [];
            foreach ( $rss_urls as $rss_url ) {
                foreach ( $this->fetch_generic_rss_items( $rss_url, max( 3, (int) ceil( $limit / max( 1, count( $rss_urls ) ) ) ) ) as $item ) {
                    $merged[] = $item;
                    if ( count( $merged ) >= $limit ) { break 2; }
                }
            }
            return $merged;
        }
        return $this->fetch_google_trends_rss_items( $limit, $settings );
    }

    private function auto_article_rss_urls_from_settings( $manual_rss_urls ) {
        $raw = preg_split( '/\r\n|\r|\n|,/', (string) $manual_rss_urls );
        $items = [];
        foreach ( $raw as $row ) {
            $url = esc_url_raw( trim( (string) $row ) );
            if ( $url && ! in_array( $url, $items, true ) ) { $items[] = $url; }
        }
        return array_slice( $items, 0, 20 );
    }

    private function auto_news_feed_proxy_urls_from_settings( $proxy_urls ) {
        $raw = preg_split( '/\r\n|\r|\n|,/', (string) $proxy_urls );
        $items = [];
        foreach ( $raw as $row ) {
            $url = esc_url_raw( trim( (string) $row ) );
            if ( $url && ! in_array( $url, $items, true ) ) { $items[] = $url; }
        }
        return array_slice( $items, 0, 5 );
    }

    private function fetch_auto_news_rss_body_via_proxy( $target_url, array $settings = [] ) {
        $target_url = esc_url_raw( $target_url );
        if ( ! $target_url ) { return ''; }
        $proxies = $this->auto_news_feed_proxy_urls_from_settings( $settings['feed_proxy_urls'] ?? '' );
        if ( empty( $proxies ) ) { return ''; }
        foreach ( $proxies as $proxy_url ) {
            $endpoint = false !== strpos( $proxy_url, '{url}' )
                ? str_replace( '{url}', rawurlencode( $target_url ), $proxy_url )
                : add_query_arg( 'url', $target_url, $proxy_url );
            $response = wp_remote_get( $endpoint, [
                'timeout'     => 35,
                'redirection' => 5,
                'headers'     => [
                    'User-Agent' => 'YZG-AI-Journalist-RSS-Proxy/' . self::VERSION,
                    'Accept'     => 'application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.5',
                ],
            ] );
            if ( is_wp_error( $response ) ) {
                $this->add_auto_news_log( 'Proxy RSS gagal: ' . $proxy_url . ' - ' . $response->get_error_message(), 'warning' );
                continue;
            }
            $code = (int) wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            if ( $code >= 200 && $code < 300 && is_string( $body ) && trim( $body ) !== '' ) {
                $decoded = json_decode( $body, true );
                if ( is_array( $decoded ) ) {
                    foreach ( [ 'body', 'rss', 'content' ] as $json_key ) {
                        if ( ! empty( $decoded[ $json_key ] ) && is_string( $decoded[ $json_key ] ) ) {
                            $candidate = $decoded[ $json_key ];
                            if ( stripos( $candidate, '<rss' ) !== false || stripos( $candidate, '<item' ) !== false || stripos( $candidate, '<feed' ) !== false ) {
                                return $candidate;
                            }
                        }
                    }
                }
                if ( stripos( $body, '<rss' ) !== false || stripos( $body, '<item' ) !== false || stripos( $body, '<feed' ) !== false ) {
                    return $body;
                }
            }
            $this->add_auto_news_log( 'Proxy RSS tidak mengembalikan RSS valid: ' . $proxy_url . ' HTTP ' . $code, 'warning' );
        }
        return '';
    }

    private function is_google_news_redirect_url( $url ) {
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        return $host === 'news.google.com' || substr( $host, -16 ) === '.news.google.com';
    }

    private function follow_redirect_url( $url, $max_hops = 6 ) {
        $current = esc_url_raw( $url );
        if ( ! $current ) { return ''; }
        for ( $i = 0; $i < $max_hops; $i++ ) {
            $response = wp_remote_head( $current, [
                'timeout'     => 12,
                'redirection' => 0,
                'headers'     => [
                    'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome Safari YZG-AI-Journalist/' . self::VERSION,
                    'Accept-Language' => 'id-ID,id;q=0.9,en-US;q=0.7,en;q=0.5',
                ],
            ] );
            if ( is_wp_error( $response ) ) { break; }
            $code = (int) wp_remote_retrieve_response_code( $response );
            $location = wp_remote_retrieve_header( $response, 'location' );
            if ( $code >= 300 && $code < 400 && $location ) {
                $next = $this->absolutize_url( is_array( $location ) ? reset( $location ) : $location, $current );
                if ( $next && $next !== $current ) { $current = esc_url_raw( $next ); continue; }
            }
            break;
        }
        return $current;
    }

    private function resolve_google_news_article_url( $url ) {
        $url = esc_url_raw( $url );
        if ( ! $url || ! $this->is_google_news_redirect_url( $url ) ) { return $url; }
        $cache_key = 'heaj_resolved_gnews_' . md5( $url );
        $cached = get_transient( $cache_key );
        if ( is_string( $cached ) && $cached ) { return $cached; }

        $resolved = $this->follow_redirect_url( $url, 6 );
        if ( $resolved && ! $this->is_google_news_redirect_url( $resolved ) ) {
            set_transient( $cache_key, $resolved, DAY_IN_SECONDS );
            return $resolved;
        }

        $response = wp_remote_get( $url, [
            'timeout'     => 15,
            'redirection' => 3,
            'headers'     => [
                'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome Safari YZG-AI-Journalist/' . self::VERSION,
                'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language' => 'id-ID,id;q=0.9,en-US;q=0.7,en;q=0.5',
            ],
        ] );
        if ( ! is_wp_error( $response ) ) {
            $body = wp_remote_retrieve_body( $response );
            if ( is_string( $body ) && $body !== '' ) {
                $patterns = [
                    '#<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']#i',
                    '#<meta[^>]+property=["\']og:url["\'][^>]+content=["\']([^"\']+)["\']#i',
                    '#<a[^>]+href=["\'](https?://(?!news\.google\.com)[^"\']+)["\']#i',
                ];
                foreach ( $patterns as $pattern ) {
                    if ( preg_match( $pattern, $body, $m ) ) {
                        $candidate = esc_url_raw( html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 ) );
                        if ( $candidate && ! $this->is_google_news_redirect_url( $candidate ) ) {
                            set_transient( $cache_key, $candidate, DAY_IN_SECONDS );
                            return $candidate;
                        }
                    }
                }
            }
        }
        set_transient( $cache_key, $url, HOUR_IN_SECONDS );
        return $url;
    }

    private function clean_source_image_caption( $caption ) {
        $caption = html_entity_decode( (string) $caption, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $caption = wp_strip_all_tags( $caption );
        $caption = preg_replace( '/\s+/u', ' ', $caption );
        $caption = trim( $caption );
        if ( $caption === '' ) { return ''; }
        return sanitize_text_field( mb_substr( $caption, 0, 280 ) );
    }

    private function img_tag_attr( $tag, $attr ) {
        $attr = preg_quote( $attr, '#' );
        if ( preg_match( '#\s' . $attr . '\s*=\s*(["\'])(.*?)\1#is', (string) $tag, $m ) ) {
            return $this->clean_source_image_caption( $m[2] );
        }
        return '';
    }

    private function caption_from_rss_node( $node ) {
        if ( ! $node instanceof SimpleXMLElement ) { return ''; }
        $namespaces = $node->getNameSpaces( true );
        if ( ! empty( $namespaces['media'] ) ) {
            $media = $node->children( $namespaces['media'] );
            foreach ( [ 'title', 'description', 'credit' ] as $tag ) {
                if ( isset( $media->{$tag} ) ) {
                    $cap = $this->clean_source_image_caption( (string) $media->{$tag} );
                    if ( $cap !== '' ) { return $cap; }
                }
            }
            foreach ( [ 'content', 'thumbnail' ] as $tag ) {
                if ( isset( $media->{$tag} ) ) {
                    foreach ( $media->{$tag} as $media_node ) {
                        foreach ( [ 'caption', 'title', 'description', 'alt' ] as $attr ) {
                            $attrs = $media_node->attributes();
                            if ( isset( $attrs[ $attr ] ) ) {
                                $cap = $this->clean_source_image_caption( (string) $attrs[ $attr ] );
                                if ( $cap !== '' ) { return $cap; }
                            }
                        }
                    }
                }
            }
        }
        $desc = (string) ( $node->description ?? $node->summary ?? $node->content ?? '' );
        if ( $desc && preg_match( '#<img\b[^>]*>#i', $desc, $m ) ) {
            foreach ( [ 'alt', 'title', 'data-caption', 'aria-label' ] as $attr ) {
                $cap = $this->img_tag_attr( $m[0], $attr );
                if ( $cap !== '' ) { return $cap; }
            }
        }
        return '';
    }

    private function extract_image_from_rss_node( $node, $base_url = '' ) {
        if ( ! $node instanceof SimpleXMLElement ) { return ''; }
        if ( isset( $node->enclosure ) ) {
            foreach ( $node->enclosure as $enc ) {
                $attrs = $enc->attributes();
                $type = isset( $attrs['type'] ) ? strtolower( (string) $attrs['type'] ) : '';
                $url = isset( $attrs['url'] ) ? esc_url_raw( (string) $attrs['url'] ) : '';
                if ( $url && ( ! $type || strpos( $type, 'image/' ) === 0 ) ) { return $this->absolutize_url( $url, $base_url ); }
            }
        }
        $namespaces = $node->getNameSpaces( true );
        foreach ( [ 'media', 'image' ] as $prefix ) {
            if ( empty( $namespaces[ $prefix ] ) ) { continue; }
            $media = $node->children( $namespaces[ $prefix ] );
            foreach ( [ 'content', 'thumbnail' ] as $tag ) {
                if ( isset( $media->{$tag} ) ) {
                    foreach ( $media->{$tag} as $media_node ) {
                        $attrs = $media_node->attributes();
                        $url = isset( $attrs['url'] ) ? esc_url_raw( (string) $attrs['url'] ) : '';
                        if ( $url ) { return $this->absolutize_url( $url, $base_url ); }
                    }
                }
            }
        }
        $desc = (string) ( $node->description ?? $node->summary ?? $node->content ?? '' );
        if ( $desc && preg_match( '#<img[^>]+src=["\']([^"\']+)["\']#i', $desc, $m ) ) {
            return $this->absolutize_url( html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 ), $base_url );
        }
        return '';
    }

    private function rss_node_summary_text( $node ) {
        $text = (string) ( $node->description ?? $node->summary ?? $node->content ?? '' );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5 );
        $text = trim( wp_strip_all_tags( $text ) );
        return sanitize_textarea_field( $text );
    }

    private function fetch_generic_rss_items( $rss_url, $limit = 10 ) {
        $rss_url = esc_url_raw( $rss_url );
        if ( ! $rss_url ) { return []; }
        $response = wp_remote_get( $rss_url, [
            'timeout'     => 20,
            'redirection' => 5,
            'headers'     => [
                'User-Agent' => 'Mozilla/5.0 (compatible; YZG-AI-Journalist-AutoArtikel/' . self::VERSION . ')',
                'Accept'     => 'application/rss+xml, application/atom+xml, application/xml;q=0.9, */*;q=0.8',
            ],
        ] );
        if ( is_wp_error( $response ) ) {
            $this->add_auto_news_log( 'Gagal mengambil RSS manual: ' . $response->get_error_message(), 'error', [ 'rss_url' => $rss_url ] );
            return [];
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        if ( $code < 200 || $code >= 300 || ! is_string( $body ) || trim( $body ) === '' ) {
            $this->add_auto_news_log( 'RSS manual tidak bisa dibaca. HTTP ' . $code, 'error', [ 'rss_url' => $rss_url ] );
            return [];
        }
        $xml = @simplexml_load_string( $body, 'SimpleXMLElement', LIBXML_NOCDATA );
        if ( ! $xml ) { return []; }
        $items = [];
        if ( isset( $xml->channel->item ) ) {
            foreach ( $xml->channel->item as $node ) {
                $title = sanitize_text_field( (string) $node->title );
                $link = esc_url_raw( (string) $node->link );
                $pub_date = sanitize_text_field( (string) $node->pubDate );
                if ( ! $link && isset( $node->guid ) ) { $link = esc_url_raw( (string) $node->guid ); }
                if ( ! $title || ! $link ) { continue; }
                $image = $this->extract_image_from_rss_node( $node, $rss_url );
                $image_caption = $this->caption_from_rss_node( $node );
                $summary = $this->rss_node_summary_text( $node );
                $id = md5( 'rss|' . strtolower( $rss_url . '|' . $title . '|' . $pub_date . '|' . $link ) );
                $items[] = [
                    'id'         => $id,
                    'title'      => $title,
                    'link'       => $link,
                    'pub_date'   => $pub_date,
                    'traffic'    => 'RSS Manual',
                    'picture'    => $image,
                    'picture_caption' => $image_caption,
                    'summary'    => $summary,
                    'rss_url'    => $rss_url,
                    'news_items' => [ [ 'title' => $title, 'url' => $link, 'source' => parse_url( $rss_url, PHP_URL_HOST ) ?: 'RSS Manual', 'image' => $image, 'image_caption' => $image_caption, 'summary' => $summary ] ],
                ];
                if ( count( $items ) >= $limit ) { break; }
            }
        } elseif ( isset( $xml->entry ) ) {
            foreach ( $xml->entry as $node ) {
                $title = sanitize_text_field( (string) $node->title );
                $link = '';
                foreach ( $node->link as $ln ) {
                    $attrs = $ln->attributes();
                    if ( ! empty( $attrs['href'] ) ) { $link = esc_url_raw( (string) $attrs['href'] ); break; }
                }
                $pub_date = sanitize_text_field( (string) ( $node->updated ?: $node->published ) );
                if ( ! $title || ! $link ) { continue; }
                $image = $this->extract_image_from_rss_node( $node, $rss_url );
                $image_caption = $this->caption_from_rss_node( $node );
                $summary = $this->rss_node_summary_text( $node );
                $id = md5( 'atom|' . strtolower( $rss_url . '|' . $title . '|' . $pub_date . '|' . $link ) );
                $items[] = [
                    'id'         => $id,
                    'title'      => $title,
                    'link'       => $link,
                    'pub_date'   => $pub_date,
                    'traffic'    => 'RSS Manual',
                    'picture'    => $image,
                    'picture_caption' => $image_caption,
                    'summary'    => $summary,
                    'rss_url'    => $rss_url,
                    'news_items' => [ [ 'title' => $title, 'url' => $link, 'source' => parse_url( $rss_url, PHP_URL_HOST ) ?: 'Atom Manual', 'image' => $image, 'image_caption' => $image_caption, 'summary' => $summary ] ],
                ];
                if ( count( $items ) >= $limit ) { break; }
            }
        }
        return $items;
    }

    private function normalize_global_trends_url( $url ) {
        $url = esc_url_raw( html_entity_decode( (string) $url, ENT_QUOTES | ENT_HTML5 ) );
        if ( ! $url ) { return ''; }
        $parts = wp_parse_url( $url );
        $host = strtolower( (string) ( $parts['host'] ?? '' ) );
        if ( $host === 'trendhunter.com' || $host === 'www.trendhunter.com' || $host === 'cdn.trendhunterstatic.com' ) {
            $path = isset( $parts['path'] ) ? $parts['path'] : '';
            $query = ! empty( $parts['query'] ) ? '?' . $parts['query'] : '';
            $host = $host === 'trendhunter.com' ? 'www.trendhunter.com' : $host;
            return esc_url_raw( 'https://' . $host . $path . $query );
        }
        return $url;
    }

    private function global_trends_rss_candidate_urls() {
        return [
            'https://www.trendhunter.com/rss',
            'http://www.trendhunter.com/rss',
            'https://trendhunter.com/rss',
            'http://trendhunter.com/rss',
        ];
    }

    private function decode_rss_text_fragment( $text ) {
        $text = (string) $text;
        $text = preg_replace( '/^\s*<!\[CDATA\[(.*)\]\]>\s*$/s', '$1', $text );
        return html_entity_decode( trim( $text ), ENT_QUOTES | ENT_HTML5 );
    }

    private function regex_rss_tag_value( $xml, $tag ) {
        $tag = preg_quote( $tag, '#' );
        if ( preg_match( '#<' . $tag . '\b[^>]*>(.*?)</' . $tag . '>#is', (string) $xml, $m ) ) {
            return $this->decode_rss_text_fragment( $m[1] );
        }
        return '';
    }

    private function parse_global_trends_items_from_rss_body_regex( $body, $limit = 20, $rss_url = 'https://www.trendhunter.com/rss' ) {
        $body = (string) $body;
        if ( ! preg_match_all( '#<item\b[^>]*>(.*?)</item>#is', $body, $matches ) ) { return []; }
        $items = [];
        foreach ( $matches[1] as $item_xml ) {
            $title = sanitize_text_field( $this->regex_rss_tag_value( $item_xml, 'title' ) );
            $link = $this->normalize_global_trends_url( $this->regex_rss_tag_value( $item_xml, 'link' ) );
            $pub_date = sanitize_text_field( $this->regex_rss_tag_value( $item_xml, 'pubDate' ) );
            if ( ! $link ) { $link = $this->normalize_global_trends_url( $this->regex_rss_tag_value( $item_xml, 'guid' ) ); }
            if ( ! $title || ! $link ) { continue; }
            $desc_html = $this->decode_rss_text_fragment( $this->regex_rss_tag_value( $item_xml, 'description' ) );
            $image = '';
            if ( preg_match( '#<enclosure\b[^>]+url=(?:"|\')([^"\']+)(?:"|\')#is', $item_xml, $em ) ) {
                $image = $this->normalize_global_trends_url( $em[1] );
            }
            if ( ! $image && preg_match( '#<img\b[^>]+src=(?:"|\')([^"\']+)(?:"|\')#is', $desc_html, $im ) ) {
                $image = $this->normalize_global_trends_url( $this->absolutize_url( html_entity_decode( $im[1], ENT_QUOTES | ENT_HTML5 ), $rss_url ) );
            }
            $caption = '';
            if ( $desc_html && preg_match( '#<a[^>]+title=(?:"|\')([^"\']+)(?:"|\')#i', $desc_html, $tm ) ) {
                $caption = $this->clean_source_image_caption( $tm[1] );
            }
            if ( ! $caption ) { $caption = $this->clean_source_image_caption( preg_replace( '/\s*\(TrendHunter\.com\)\s*$/i', '', $title ) ); }
            $summary = sanitize_textarea_field( trim( wp_strip_all_tags( html_entity_decode( $desc_html, ENT_QUOTES | ENT_HTML5 ) ) ) );
            $id = md5( 'global_trends|' . strtolower( $title . '|' . $pub_date . '|' . $link ) );
            $items[] = [
                'id'              => $id,
                'title'           => $title,
                'link'            => $link,
                'pub_date'        => $pub_date,
                'traffic'         => 'Global Trends',
                'picture'         => $image,
                'picture_caption' => $caption,
                'summary'         => $summary,
                'rss_url'         => $rss_url,
                'global_trends'   => '1',
                'news_items'      => [ [ 'title' => $title, 'url' => $link, 'source' => 'TrendHunter', 'image' => $image, 'image_caption' => $caption, 'summary' => $summary ] ],
            ];
            if ( count( $items ) >= $limit ) { break; }
        }
        return $items;
    }

    private function fetch_global_trends_body_direct( $rss_url ) {
        $rss_url = esc_url_raw( $rss_url );
        if ( ! $rss_url ) { return [ 'body' => '', 'error' => 'URL RSS kosong.' ]; }
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari YZG-AI-Journalist/' . self::VERSION;

        if ( function_exists( 'curl_init' ) ) {
            $ch = curl_init( $rss_url );
            if ( $ch ) {
                curl_setopt_array( $ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 8,
                    CURLOPT_CONNECTTIMEOUT => 12,
                    CURLOPT_TIMEOUT        => 30,
                    CURLOPT_USERAGENT      => $ua,
                    CURLOPT_HTTPHEADER     => [
                        'Accept: application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, text/html;q=0.7, */*;q=0.5',
                        'Accept-Language: en-US,en;q=0.9,id;q=0.8',
                        'Cache-Control: no-cache',
                    ],
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                ] );
                $body = curl_exec( $ch );
                $err  = curl_error( $ch );
                $code = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
                curl_close( $ch );
                if ( is_string( $body ) && trim( $body ) !== '' && $code >= 200 && $code < 400 ) {
                    return [ 'body' => $body, 'error' => '', 'code' => $code, 'method' => 'curl' ];
                }
                $last_error = $err ?: ( 'cURL HTTP ' . $code );
            }
        }

        $context = stream_context_create( [
            'http' => [
                'timeout' => 30,
                'header'  => "User-Agent: {$ua}\r\nAccept: application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.5\r\nAccept-Language: en-US,en;q=0.9,id;q=0.8\r\nCache-Control: no-cache\r\n",
            ],
            'ssl' => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ] );
        $body = @file_get_contents( $rss_url, false, $context );
        if ( is_string( $body ) && trim( $body ) !== '' ) {
            return [ 'body' => $body, 'error' => '', 'code' => 200, 'method' => 'file_get_contents' ];
        }
        return [ 'body' => '', 'error' => isset( $last_error ) ? $last_error : 'cURL/file_get_contents gagal atau dinonaktifkan.' ];
    }

    private function fetch_global_trends_rss_items( $limit = 20, array $settings = [] ) {
        $last_message = '';
        foreach ( $this->global_trends_rss_candidate_urls() as $rss_url ) {
            $response = wp_remote_get( $rss_url, [
                'timeout'     => 30,
                'redirection' => 8,
                'headers'     => [
                    'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari YZG-AI-Journalist/' . self::VERSION,
                    'Accept'          => 'application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, text/html;q=0.7, */*;q=0.5',
                    'Accept-Language' => 'en-US,en;q=0.9,id;q=0.8',
                    'Cache-Control'   => 'no-cache',
                ],
            ] );
            $body = '';
            $code = 0;
            if ( is_wp_error( $response ) ) {
                $last_message = $response->get_error_message();
            } else {
                $code = (int) wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                if ( $code < 200 || $code >= 300 || ! is_string( $body ) || trim( $body ) === '' ) {
                    $last_message = 'WP HTTP ' . $code . ' / body kosong dari ' . $rss_url;
                    $body = '';
                }
            }
            if ( ! is_string( $body ) || trim( $body ) === '' || ( stripos( $body, '<item' ) === false && stripos( $body, '<rss' ) === false ) ) {
                $direct = $this->fetch_global_trends_body_direct( $rss_url );
                if ( ! empty( $direct['body'] ) ) {
                    $body = $direct['body'];
                    $last_message = 'Global Trends RSS dibaca via fallback ' . ( $direct['method'] ?? 'direct' ) . ' dari ' . $rss_url;
                } else {
                    $proxy_body = $this->fetch_auto_news_rss_body_via_proxy( $rss_url, $settings );
                    if ( $proxy_body !== '' ) {
                        $body = $proxy_body;
                        $last_message = 'Global Trends RSS dibaca via proxy dari ' . $rss_url;
                        $this->add_auto_news_log( $last_message, 'proxy' );
                    } else {
                        $last_message = 'Response bukan RSS valid dari ' . $rss_url . '. WP: ' . $last_message . '. Direct: ' . ( $direct['error'] ?? '' ) . '. Proxy juga gagal.';
                        continue;
                    }
                }
            }
            if ( stripos( $body, '<item' ) === false && stripos( $body, '<rss' ) === false ) {
                $last_message = 'Response bukan RSS valid dari ' . $rss_url . ': ' . mb_substr( trim( wp_strip_all_tags( $body ) ), 0, 160 );
                continue;
            }
            $body = preg_replace( '/^\xEF\xBB\xBF/', '', $body );
            $xml = @simplexml_load_string( $body, 'SimpleXMLElement', LIBXML_NOCDATA );
            if ( $xml && ! empty( $xml->channel->item ) ) {
                $items = [];
                foreach ( $xml->channel->item as $node ) {
                    $title = sanitize_text_field( (string) $node->title );
                    $link = $this->normalize_global_trends_url( (string) $node->link );
                    $pub_date = sanitize_text_field( (string) $node->pubDate );
                    if ( ! $link && isset( $node->guid ) ) { $link = $this->normalize_global_trends_url( (string) $node->guid ); }
                    if ( ! $title || ! $link ) { continue; }
                    $image = $this->normalize_global_trends_url( $this->extract_image_from_rss_node( $node, $rss_url ) );
                    $summary = $this->rss_node_summary_text( $node );
                    $caption = $this->caption_from_rss_node( $node );
                    if ( ! $caption ) {
                        $desc = (string) ( $node->description ?? '' );
                        if ( $desc && preg_match( '#<a[^>]+title=["\']([^"\']+)["\']#i', $desc, $tm ) ) {
                            $caption = $this->clean_source_image_caption( $tm[1] );
                        }
                    }
                    if ( ! $caption ) { $caption = preg_replace( '/\s*\(TrendHunter\.com\)\s*$/i', '', $title ); }
                    $id = md5( 'global_trends|' . strtolower( $title . '|' . $pub_date . '|' . $link ) );
                    $items[] = [
                        'id'              => $id,
                        'title'           => $title,
                        'link'            => $link,
                        'pub_date'        => $pub_date,
                        'traffic'         => 'Global Trends',
                        'picture'         => $image,
                        'picture_caption' => $caption,
                        'summary'         => $summary,
                        'rss_url'         => $rss_url,
                        'global_trends'   => '1',
                        'news_items'      => [ [ 'title' => $title, 'url' => $link, 'source' => 'TrendHunter', 'image' => $image, 'image_caption' => $caption, 'summary' => $summary ] ],
                    ];
                    if ( count( $items ) >= $limit ) { break; }
                }
                if ( ! empty( $items ) ) { return $items; }
                $last_message = 'RSS terbaca dari ' . $rss_url . ' tetapi tidak ada item valid.';
            }
            $regex_items = $this->parse_global_trends_items_from_rss_body_regex( $body, $limit, $rss_url );
            if ( ! empty( $regex_items ) ) { return $regex_items; }
            $last_message = 'XML Global Trends gagal diparse dari ' . $rss_url . ', regex fallback juga kosong.';
        }
        $this->add_auto_news_log( 'Global Trends RSS kosong/gagal dibaca. ' . $last_message, 'error' );
        return [];
    }

    private function fetch_keyword_news_items( $keyword, $limit = 10 ) {
        $keyword = trim( sanitize_text_field( $keyword ) );
        if ( $keyword === '' ) { return []; }
        $url = add_query_arg( [
            'q'    => $keyword,
            'hl'   => 'id',
            'gl'   => 'ID',
            'ceid' => 'ID:id',
        ], 'https://news.google.com/rss/search' );
        $response = wp_remote_get( $url, [
            'timeout'     => 20,
            'redirection' => 5,
            'headers'     => [
                'User-Agent' => 'Mozilla/5.0 (compatible; YZG-AI-Journalist-AutoArtikel/' . self::VERSION . ')',
                'Accept'     => 'application/rss+xml, application/xml;q=0.9, */*;q=0.8',
            ],
        ] );
        if ( is_wp_error( $response ) ) {
            $this->add_auto_news_log( 'Gagal mengambil RSS keyword "' . $keyword . '": ' . $response->get_error_message(), 'error' );
            return [];
        }
        $body = wp_remote_retrieve_body( $response );
        $xml = @simplexml_load_string( $body, 'SimpleXMLElement', LIBXML_NOCDATA );
        if ( ! $xml || empty( $xml->channel->item ) ) { return []; }
        $items = [];
        foreach ( $xml->channel->item as $node ) {
            $title = sanitize_text_field( (string) $node->title );
            $link = esc_url_raw( (string) $node->link );
            $pub_date = sanitize_text_field( (string) $node->pubDate );
            if ( ! $title || ! $link ) { continue; }
            $image = $this->extract_image_from_rss_node( $node, $url );
            $image_caption = $this->caption_from_rss_node( $node );
            $summary = $this->rss_node_summary_text( $node );
            $id = md5( 'kw|' . strtolower( $keyword . '|' . $title . '|' . $pub_date . '|' . $link ) );
            $items[] = [
                'id'         => $id,
                'title'      => $title,
                'link'       => $link,
                'pub_date'   => $pub_date,
                'traffic'    => 'Keyword: ' . $keyword,
                'picture'    => $image,
                'picture_caption' => $image_caption,
                'summary'    => $summary,
                'keyword'    => $keyword,
                'news_items' => [ [ 'title' => $title, 'url' => $link, 'source' => 'Google News', 'image' => $image, 'image_caption' => $image_caption, 'summary' => $summary ] ],
            ];
            if ( count( $items ) >= $limit ) { break; }
        }
        return $items;
    }

    private function auto_news_queue() {
        $queue = get_option( self::OPTION_AUTO_NEWS_QUEUE, [] );
        return is_array( $queue ) ? $queue : [];
    }

    private function save_auto_news_queue( array $queue ) {
        usort( $queue, function( $a, $b ) {
            return (int) ( $b['created_at'] ?? 0 ) <=> (int) ( $a['created_at'] ?? 0 );
        } );
        $queue = array_slice( $queue, 0, 500 );
        update_option( self::OPTION_AUTO_NEWS_QUEUE, $queue, false );
    }

    private function auto_news_queue_has_pending( $mode_filter = null ) {
        if ( $mode_filter === null ) {
            $settings = $this->get_auto_news_settings();
            $mode_filter = sanitize_key( $settings['feed_mode'] ?? '' );
        } else {
            $mode_filter = sanitize_key( $mode_filter );
        }
        foreach ( $this->auto_news_queue() as $job ) {
            if ( ! in_array( (string) ( $job['status'] ?? '' ), [ 'queued', 'retry' ], true ) ) { continue; }
            if ( $mode_filter !== '' ) {
                $job_mode = sanitize_key( $job['settings']['feed_mode'] ?? '' );
                if ( $job_mode !== $mode_filter ) { continue; }
            }
            return true;
        }
        return false;
    }

    private function normalize_auto_news_duplicate_text( $text ) {
        $text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $text = strtolower( remove_accents( $text ) );
        $text = preg_replace( '/https?:\/\/\S+/i', ' ', $text );
        $text = preg_replace( '/[^a-z0-9\s]+/i', ' ', $text );
        $text = preg_replace( '/\s+/', ' ', trim( $text ) );
        return $text;
    }

    private function auto_news_url_signature( $url ) {
        $url = esc_url_raw( trim( (string) $url ) );
        if ( ! $url ) { return ''; }
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        $host = preg_replace( '/^www\./i', '', $host );
        $path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
        $path = trim( preg_replace( '#/+#', '/', $path ), '/' );
        if ( ! $host || ! $path ) { return ''; }
        return $host . '/' . untrailingslashit( $path );
    }

    private function auto_news_candidate_source_urls( array $item ) {
        $urls = [];
        $add_url = function( $url ) use ( &$urls ) {
            $url = esc_url_raw( trim( (string) $url ) );
            if ( ! $url ) { return; }
            $path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
            if ( preg_match( '/\.(jpe?g|png|webp|gif|svg)(\?.*)?$/i', $path ) ) { return; }
            $sig = $this->auto_news_url_signature( $url );
            $key = $sig ?: strtolower( untrailingslashit( $url ) );
            if ( isset( $urls[ $key ] ) ) { return; }
            $urls[ $key ] = $url;
        };
        foreach ( [ 'link', 'url', 'source_url' ] as $field ) { if ( ! empty( $item[ $field ] ) ) { $add_url( $item[ $field ] ); } }
        foreach ( [ 'multi_sources', 'news_items', 'sources', 'related_sources' ] as $field ) {
            if ( empty( $item[ $field ] ) || ! is_array( $item[ $field ] ) ) { continue; }
            foreach ( $item[ $field ] as $row ) {
                if ( is_array( $row ) ) {
                    foreach ( [ 'url', 'link', 'source_url' ] as $key ) { if ( ! empty( $row[ $key ] ) ) { $add_url( $row[ $key ] ); } }
                } elseif ( is_string( $row ) ) { $add_url( $row ); }
            }
        }
        return array_slice( array_values( $urls ), 0, 15 );
    }

    private function auto_news_candidate_title_for_duplicate( array $item ) {
        $parts = [];
        if ( ! empty( $item['title'] ) ) { $parts[] = $item['title']; }
        if ( ! empty( $item['keyword'] ) ) { $parts[] = $item['keyword']; }
        foreach ( [ 'multi_sources', 'news_items' ] as $field ) {
            if ( empty( $item[ $field ] ) || ! is_array( $item[ $field ] ) ) { continue; }
            foreach ( array_slice( $item[ $field ], 0, 3 ) as $row ) {
                if ( is_array( $row ) && ! empty( $row['title'] ) ) { $parts[] = $row['title']; }
            }
        }
        return $this->normalize_auto_news_duplicate_text( implode( ' ', array_unique( array_map( 'strval', $parts ) ) ) );
    }

    private function auto_news_text_is_similar( $a, $b, $threshold = 88 ) {
        $a = $this->normalize_auto_news_duplicate_text( $a );
        $b = $this->normalize_auto_news_duplicate_text( $b );
        if ( $a === '' || $b === '' ) { return false; }
        if ( $a === $b ) { return true; }
        if ( strlen( $a ) > 18 && strlen( $b ) > 18 && ( strpos( $a, $b ) !== false || strpos( $b, $a ) !== false ) ) { return true; }
        similar_text( $a, $b, $percent );
        return $percent >= $threshold;
    }

    private function detect_auto_news_duplicate_candidate( array $item ) {
        $urls = $this->auto_news_candidate_source_urls( $item );
        $url_sigs = [];
        foreach ( $urls as $url ) {
            $sig = $this->auto_news_url_signature( $url );
            if ( $sig ) { $url_sigs[ $sig ] = true; }
        }
        foreach ( $urls as $url ) {
            $found = get_posts( [
                'post_type'      => 'post',
                'post_status'    => [ 'publish', 'future', 'draft' ],
                'posts_per_page' => 1,
                'fields'         => 'ids',
                'meta_query'     => [
                    [ 'key' => '_he_source_url', 'value' => esc_url_raw( $url ), 'compare' => '=' ],
                ],
                'no_found_rows'  => true,
            ] );
            if ( ! empty( $found ) ) { return [ 'duplicate' => true, 'reason' => 'source_url_exact', 'post_id' => absint( $found[0] ) ]; }
        }
        $candidate_title = $this->auto_news_candidate_title_for_duplicate( $item );
        $recent_posts = get_posts( [
            'post_type'      => 'post',
            'post_status'    => [ 'publish', 'future', 'draft' ],
            'posts_per_page' => 160,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'meta_query'     => [ [ 'key' => '_he_auto_news', 'value' => '1', 'compare' => '=' ] ],
            'date_query'     => [ [ 'after' => '120 days ago' ] ],
            'no_found_rows'  => true,
        ] );
        foreach ( $recent_posts as $post_id ) {
            $post_id = absint( $post_id );
            $existing_urls = [];
            $primary = get_post_meta( $post_id, '_he_source_url', true );
            if ( $primary ) { $existing_urls[] = $primary; }
            $json_urls = get_post_meta( $post_id, '_he_auto_news_source_urls', true );
            $decoded = is_string( $json_urls ) ? json_decode( $json_urls, true ) : [];
            if ( is_array( $decoded ) ) { $existing_urls = array_merge( $existing_urls, $decoded ); }
            foreach ( $existing_urls as $existing_url ) {
                $sig = $this->auto_news_url_signature( $existing_url );
                if ( $sig && isset( $url_sigs[ $sig ] ) ) { return [ 'duplicate' => true, 'reason' => 'source_url_signature', 'post_id' => $post_id ]; }
            }
            $existing_title = get_the_title( $post_id );
            $existing_trend = get_post_meta( $post_id, '_he_auto_news_trend_title', true );
            if ( $candidate_title && ( $this->auto_news_text_is_similar( $candidate_title, $existing_title, 90 ) || $this->auto_news_text_is_similar( $candidate_title, $existing_trend, 88 ) ) ) {
                return [ 'duplicate' => true, 'reason' => 'title_similarity', 'post_id' => $post_id ];
            }
        }
        return [ 'duplicate' => false ];
    }

    private function auto_news_job_exists( $item_id ) {
        $item_id = (string) $item_id;
        foreach ( $this->auto_news_queue() as $job ) {
            if ( (string) ( $job['item_id'] ?? '' ) === $item_id && in_array( (string) ( $job['status'] ?? '' ), [ 'queued', 'processing', 'retry', 'failed' ], true ) ) { return true; }
        }
        return false;
    }

    private function cleanup_stale_auto_news_queue() {
        $changed = false;
        $queue = $this->auto_news_queue();
        $now = time();
        $runner_lock = (int) get_transient( 'heaj_auto_news_runner_lock' );
        if ( $runner_lock && ( $now - $runner_lock ) > 20 * MINUTE_IN_SECONDS ) {
            delete_transient( 'heaj_auto_news_runner_lock' );
        }
        $queue_lock = (int) get_transient( 'heaj_auto_news_queue_lock' );
        if ( $queue_lock && ( $now - $queue_lock ) > 20 * MINUTE_IN_SECONDS ) {
            delete_transient( 'heaj_auto_news_queue_lock' );
        }
        foreach ( $queue as &$job ) {
            if ( ( $job['status'] ?? '' ) === 'processing' && ! empty( $job['started_at'] ) && ( $now - absint( $job['started_at'] ) ) > 20 * MINUTE_IN_SECONDS ) {
                $job['status'] = 'retry';
                $job['last_error'] = 'Processing timeout/stale lock, dikembalikan ke retry.';
                $job['updated_at'] = $now;
                $changed = true;
            }
        }
        unset( $job );
        if ( $changed ) { $this->save_auto_news_queue( $queue ); }
    }

    private function enqueue_auto_news_candidates( $manual = false ) {
        $settings = $this->get_auto_news_settings();
        if ( ! $this->is_allowed_license_domain() ) { return [ 'checked' => 0, 'queued_now' => 0, 'message' => 'Auto Artikel tidak berjalan karena lisensi belum valid.', 'time' => time() ]; }
        if ( ! $manual && ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) ) {
            return [ 'checked' => 0, 'queued_now' => 0, 'message' => 'Auto posting nonaktif.', 'time' => time() ];
        }
        $this->cleanup_stale_auto_news_queue();
        $items = $this->fetch_auto_source_items( $settings, 20 );
        $items = $this->order_auto_news_feed_items_for_site( $items, $settings );
        if ( empty( $items ) ) {
            $msg = ( ( $settings['feed_mode'] ?? '' ) === 'global_trends' ) ? 'Global Trends RSS kosong/gagal dibaca oleh server. Cek log Auto Artikel untuk HTTP/body parser detail.' : 'RSS kosong.';
            return [ 'checked' => 0, 'queued_now' => 0, 'message' => $msg, 'time' => time() ];
        }
        $processed = $this->auto_news_processed_ids();
        $queue = $this->auto_news_queue();
        $candidates = [];
        $seen_candidate_ids = [];
        if ( $this->auto_news_interval_seconds( $settings ) > 5 * MINUTE_IN_SECONDS ) {
            $offset = min( max( 0, absint( $settings['item_offset'] ) ), max( 0, count( $items ) - 1 ) );
            if ( ! empty( $items[ $offset ] ) ) { $candidates[] = $items[ $offset ]; }
        }
        foreach ( $items as $item ) {
            $candidate_id = sanitize_key( $item['id'] ?? md5( wp_json_encode( $item ) ) );
            if ( ! $candidate_id || isset( $seen_candidate_ids[ $candidate_id ] ) ) { continue; }
            $seen_candidate_ids[ $candidate_id ] = true;
            $candidates[] = $item;
        }
        $candidates = array_slice( $candidates, 0, 30 );
        $checked = 0;
        $queued_now = 0;
        $duplicates = 0;
        $seen = [];
        foreach ( $candidates as $item ) {
            $checked++;
            $item_id = sanitize_key( $item['id'] ?? md5( wp_json_encode( $item ) ) );
            if ( ! $item_id || isset( $seen[ $item_id ] ) || ! empty( $processed[ $item_id ] ) || $this->auto_news_job_exists( $item_id ) ) { continue; }
            $seen[ $item_id ] = true;
            $duplicate = $this->detect_auto_news_duplicate_candidate( $item );
            if ( ! empty( $duplicate['duplicate'] ) ) {
                $duplicates++;
                $this->mark_auto_news_processed( $item_id );
                if ( $duplicates <= 5 ) {
                    $this->add_auto_news_log( 'Kandidat dilewati karena duplikat/mirip: ' . sanitize_text_field( $item['title'] ?? $item_id ) . ' (' . sanitize_text_field( $duplicate['reason'] ?? 'duplicate' ) . ')', 'duplicate' );
                }
                continue;
            }
            $queue[] = [
                'job_id'     => 'heaj_' . md5( $item_id . '|' . microtime( true ) ),
                'item_id'    => $item_id,
                'title'      => sanitize_text_field( $item['title'] ?? '' ),
                'keyword'    => sanitize_text_field( $item['keyword'] ?? '' ),
                'status'     => 'queued',
                'attempts'   => 0,
                'item'       => $item,
                'settings'   => $settings,
                'created_at' => time(),
                'updated_at' => time(),
                'last_error' => '',
            ];
            if ( ! empty( $item['keyword'] ) && ( $settings['feed_mode'] ?? '' ) !== 'manual_keywords' ) { $this->mark_auto_news_keyword_used( $item['keyword'] ); }
            $queued_now++;
            // AutoPilot hanya menyiapkan 1 kandidat valid per jadwal publish.
            break;
        }
        if ( $queued_now > 0 ) {
            $this->save_auto_news_queue( $queue );
            $this->add_auto_news_log( 'Auto Artikel enqueue: ' . $queued_now . ' item valid masuk antrean dari ' . $checked . ' item dicek. Duplikat dilewati: ' . $duplicates . '.', 'queue' );
        } else {
            $msg = $duplicates > 0 ? 'Semua kandidat valid sudah pernah dipublish atau terlalu mirip. Proses publish dilewati.' : 'Tidak ada item baru untuk antrean.';
            $this->add_auto_news_log( 'Auto Artikel enqueue selesai: ' . $msg, 'info' );
        }
        return [ 'checked' => $checked, 'queued_now' => $queued_now, 'duplicates' => $duplicates, 'queue_total' => count( $queue ), 'message' => $queued_now > 0 ? 'Kandidat valid ditemukan.' : ( $duplicates > 0 ? 'Semua kandidat duplikat/mirip.' : 'Tidak ada kandidat baru.' ), 'time' => time() ];
    }

    public function process_auto_news_queue( $limit = 1, $manual = false, $mode_filter = '' ) {
        @ignore_user_abort( true );
        @set_time_limit( 600 );
        @ini_set( 'max_execution_time', '600' );
        @ini_set( 'memory_limit', '512M' );
        $limit = max( 1, min( 5, absint( $limit ) ) );
        if ( ! $this->is_allowed_license_domain() ) { return [ 'processed' => 0, 'created' => 0, 'failed' => 0, 'skipped' => 0, 'last_error' => 'Lisensi belum valid.', 'time' => time() ]; }
        if ( $mode_filter === '' && ! $manual ) {
            $current_settings = $this->get_auto_news_settings();
            $mode_filter = sanitize_key( $current_settings['feed_mode'] ?? '' );
        } else {
            $current_settings = $this->get_auto_news_settings();
        }
        if ( ! $manual && ! $this->is_auto_news_due_by_last_run( $current_settings ) ) {
            return [ 'processed' => 0, 'created' => 0, 'failed' => 0, 'skipped' => 0, 'message' => 'Queue menunggu jadwal publish berikutnya.', 'time' => time() ];
        }
        $this->cleanup_stale_auto_news_queue();
        if ( get_transient( 'heaj_auto_news_queue_lock' ) ) {
            return [ 'processed' => 0, 'created' => 0, 'message' => 'Queue worker masih berjalan.', 'time' => time() ];
        }
        set_transient( 'heaj_auto_news_queue_lock', time(), 15 * MINUTE_IN_SECONDS );
        $queue = $this->auto_news_queue();
        $processed = 0;
        $created = 0;
        $failed = 0;
        $skipped = 0;
        $last_error = '';
        try {
            foreach ( $queue as &$job ) {
                if ( $processed >= $limit ) { break; }
                $status = (string) ( $job['status'] ?? '' );
                if ( ! in_array( $status, [ 'queued', 'retry' ], true ) ) { continue; }
                $job_mode = sanitize_key( $job['settings']['feed_mode'] ?? '' );
                $mode_filter = sanitize_key( $mode_filter );
                if ( $mode_filter !== '' && $job_mode !== $mode_filter ) { continue; }
                $job['status'] = 'processing';
                $job['started_at'] = time();
                $job['updated_at'] = time();
                $job['attempts'] = absint( $job['attempts'] ?? 0 ) + 1;
                $this->save_auto_news_queue( $queue );

                $result = $this->process_single_auto_news_item( (array) ( $job['item'] ?? [] ), (array) ( $job['settings'] ?? $this->get_auto_news_settings() ) );
                $processed++;
                if ( ! empty( $result['created'] ) ) {
                    $created++;
                    $job['status'] = ( ( $job['settings']['publish_mode'] ?? 'draft' ) === 'publish' ) ? 'published' : 'drafted';
                    $job['post_id'] = absint( $result['post_id'] ?? 0 );
                    $job['completed_at'] = time();
                    $this->mark_auto_news_processed( $job['item_id'] ?? '' );
                    if ( ! empty( $job['keyword'] ) && ( $job['settings']['feed_mode'] ?? '' ) === 'manual_keywords' ) { $this->mark_auto_news_keyword_used( $job['keyword'], absint( $result['post_id'] ?? 0 ) ); }
                } else {
                    $reason = (string) ( $result['reason'] ?? 'failed' );
                    if ( $reason === 'no_source_image' ) {
                        $skipped++;
                        $job['status'] = 'skipped_no_image';
                        $job['completed_at'] = time();
                        $job['last_error'] = 'Tidak ada image/konten valid.';
                        $last_error = $job['last_error'];
                        $this->mark_auto_news_processed( $job['item_id'] ?? '' );
                    } else {
                        $failed++;
                        $job['last_error'] = $reason ?: 'failed';
                        $last_error = $job['last_error'];
                        $job['status'] = ( absint( $job['attempts'] ?? 0 ) >= 3 ) ? 'failed' : 'retry';
                        if ( $job['status'] === 'failed' ) { $job['completed_at'] = time(); }
                    }
                }
                $job['updated_at'] = time();
            }
            unset( $job );
            $this->save_auto_news_queue( $queue );
        } catch ( Throwable $e ) {
            delete_transient( 'heaj_auto_news_queue_lock' );
            $this->add_auto_news_log( 'Fatal queue worker Auto Artikel: ' . $e->getMessage(), 'error' );
            throw $e;
        }
        delete_transient( 'heaj_auto_news_queue_lock' );
        $result = [ 'processed' => $processed, 'created' => $created, 'failed' => $failed, 'skipped' => $skipped, 'last_error' => $last_error, 'time' => time() ];
        update_option( self::OPTION_AUTO_NEWS_LAST_RESULT, [ 'queue_worker' => $result ], false );
        return $result;
    }

    private function auto_news_diagnostic() {
        $queue = $this->auto_news_queue();
        $counts = [];
        foreach ( $queue as $job ) {
            $st = (string) ( $job['status'] ?? 'unknown' );
            $counts[ $st ] = ( $counts[ $st ] ?? 0 ) + 1;
        }
        return [
            'next_cron'        => wp_next_scheduled( self::AUTO_NEWS_MASTER_HOOK ),
            'next_queue'       => wp_next_scheduled( self::AUTO_NEWS_QUEUE_HOOK ),
            'next_keepalive'   => wp_next_scheduled( self::AUTO_NEWS_KEEPALIVE_HOOK ),
            'queue_counts'     => $counts,
            'runner_lock'      => get_transient( 'heaj_auto_news_runner_lock' ),
            'queue_lock'       => get_transient( 'heaj_auto_news_queue_lock' ),
            'wp_cron_disabled' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
            'heartbeat_url'    => rest_url( 'heaj-auto-artikel/v1/heartbeat' ),
        ];
    }

    private function auto_news_processed_ids() {
        $ids = get_option( 'he_journalist_auto_news_processed_ids', [] );
        return is_array( $ids ) ? $ids : [];
    }

    private function mark_auto_news_processed( $id ) {
        $ids = $this->auto_news_processed_ids();
        $ids[ sanitize_key( $id ) ] = time();
        arsort( $ids );
        $ids = array_slice( $ids, 0, 300, true );
        update_option( 'he_journalist_auto_news_processed_ids', $ids, false );
    }

    private function process_auto_news( $manual = false ) {
        $settings = $this->get_auto_news_settings();
        if ( ! $manual && ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) ) {
            return [ 'checked' => 0, 'created' => 0, 'message' => 'Auto posting nonaktif.' ];
        }
        $items = $this->fetch_auto_source_items( $settings, 20 );
        $items = $this->order_auto_news_feed_items_for_site( $items, $settings );
        if ( empty( $items ) ) {
            $msg = ( ( $settings['feed_mode'] ?? '' ) === 'global_trends' ) ? 'Global Trends RSS kosong/gagal dibaca oleh server. Cek log Auto Artikel untuk HTTP/body parser detail.' : 'RSS kosong.';
            return [ 'checked' => 0, 'created' => 0, 'message' => $msg ];
        }
        $processed = $this->auto_news_processed_ids();
        $candidates = [];
        if ( $this->auto_news_interval_seconds( $settings ) > 5 * MINUTE_IN_SECONDS ) {
            $offset = min( max( 0, absint( $settings['item_offset'] ) ), max( 0, count( $items ) - 1 ) );
            $candidates[] = $items[ $offset ];
            foreach ( $items as $item ) {
                if ( empty( $processed[ $item['id'] ] ) ) { $candidates[] = $item; }
                if ( count( $candidates ) >= 3 ) { break; }
            }
        } else {
            foreach ( $items as $item ) {
                if ( empty( $processed[ $item['id'] ] ) ) { $candidates[] = $item; }
                if ( count( $candidates ) >= absint( $settings['max_per_run'] ) ) { break; }
            }
        }
        $created = 0;
        $checked = 0;
        $skipped = 0;
        $failed = 0;
        foreach ( $candidates as $item ) {
            $checked++;
            if ( ! empty( $processed[ $item['id'] ] ) ) { continue; }
            $result = $this->process_single_auto_news_item( $item, $settings );
            $reason = isset( $result['reason'] ) ? (string) $result['reason'] : '';
            if ( ! empty( $result['created'] ) ) {
                $created++;
                $this->mark_auto_news_processed( $item['id'] );
            } elseif ( $reason === 'no_source_image' ) {
                $skipped++;
                $this->mark_auto_news_processed( $item['id'] );
            } else {
                $failed++;
            }
            if ( $created > 0 && $this->auto_news_interval_seconds( $settings ) > 5 * MINUTE_IN_SECONDS ) { break; }
        }
        if ( $created === 0 ) { $this->add_auto_news_log( 'Auto Artikel selesai dicek: ' . $checked . ' item diperiksa, ' . $skipped . ' dilewati, ' . $failed . ' gagal sementara, belum ada artikel baru.', 'info' ); }
        return [ 'checked' => $checked, 'created' => $created, 'skipped' => $skipped, 'failed' => $failed, 'time' => time() ];
    }

    private function build_auto_news_feed_fallback_context( array $item, array $news, $candidate_url = '' ) {
        $parts = [];
        $title = sanitize_text_field( $item['title'] ?? $news['title'] ?? '' );
        $news_title = sanitize_text_field( $news['title'] ?? '' );
        $source = sanitize_text_field( $news['source'] ?? '' );
        $traffic = sanitize_text_field( $item['traffic'] ?? '' );
        $pub_date = sanitize_text_field( $item['pub_date'] ?? '' );
        $summary = trim( (string) ( $news['summary'] ?? $item['summary'] ?? '' ) );
        if ( $title ) { $parts[] = 'Topik feed: ' . $title; }
        if ( $news_title && $news_title !== $title ) { $parts[] = 'Judul sumber terkait: ' . $news_title; }
        if ( $source ) { $parts[] = 'Sumber terkait: ' . $source; }
        if ( $traffic ) { $parts[] = 'Indikator traffic/feed: ' . $traffic; }
        if ( $pub_date ) { $parts[] = 'Tanggal feed: ' . $pub_date; }
        if ( $candidate_url ) { $parts[] = 'URL sumber: ' . esc_url_raw( $candidate_url ); }
        if ( $summary ) { $parts[] = 'Ringkasan RSS: ' . wp_strip_all_tags( $summary ); }
        $related = [];
        foreach ( array_slice( (array) ( $item['news_items'] ?? [] ), 0, 5 ) as $rel ) {
            $rt = sanitize_text_field( $rel['title'] ?? '' );
            $rs = sanitize_text_field( $rel['source'] ?? '' );
            if ( $rt ) { $related[] = trim( $rt . ( $rs ? ' - ' . $rs : '' ) ); }
        }
        if ( $related ) { $parts[] = 'Daftar sumber/topik terkait dari feed: ' . implode( '; ', array_unique( $related ) ); }
        $text = trim( implode( "\n", array_filter( $parts ) ) );
        return sanitize_textarea_field( $text );
    }

    private function process_single_auto_news_item( array $item, array $settings ) {
        $feed_mode = sanitize_key( $settings['feed_mode'] ?? 'google_trends' );
        if ( $feed_mode === 'manual_keywords' ) {
            return $this->process_manual_keyword_auto_news_item( $item, $settings );
        }

        $sources = [];
        $source_images = [];
        $news_list = array_slice( (array) ( $item['news_items'] ?? [] ), 0, 8 );
        foreach ( $news_list as $idx => $news ) {
            $raw_candidate_url = esc_url_raw( $news['url'] ?? '' );
            if ( ! $raw_candidate_url ) { continue; }
            $is_global_source = ! empty( $item['global_trends'] ) || stripos( $raw_candidate_url, 'trendhunter.com' ) !== false;
            $raw_candidate_url = $is_global_source ? $this->normalize_global_trends_url( $raw_candidate_url ) : $raw_candidate_url;
            $candidate_url = $is_global_source ? $raw_candidate_url : $this->resolve_google_news_article_url( $raw_candidate_url );
            $candidate_url = esc_url_raw( $candidate_url );
            if ( ! $candidate_url ) { continue; }
            if ( ! $is_global_source && $this->is_google_news_redirect_url( $candidate_url ) ) {
                $this->add_auto_news_log( 'Lewati sumber Google Trends karena URL publisher tidak berhasil di-resolve: ' . $raw_candidate_url, 'skip' );
                continue;
            }
            if ( $candidate_url !== $raw_candidate_url && ! get_transient( 'heaj_gnews_resolve_log_' . md5( $raw_candidate_url ) ) ) {
                $this->add_auto_news_log( 'Google News URL berhasil diarahkan ke publisher: ' . $candidate_url, 'info' );
                set_transient( 'heaj_gnews_resolve_log_' . md5( $raw_candidate_url ), 1, DAY_IN_SECONDS );
            }

            // Aturan strict: Google Trends/Global Trends hanya boleh memakai sumber yang benar-benar bisa diakses.
            $context = $this->fetch_source_text_context( $candidate_url );
            if ( mb_strlen( wp_strip_all_tags( $context ) ) < 180 ) {
                $this->add_auto_news_log( 'Lewati sumber: konten tidak dapat diakses/terlalu pendek untuk Auto Artikel: ' . $candidate_url, 'skip' );
                continue;
            }

            $source_title = sanitize_text_field( $news['title'] ?? $item['title'] ?? '' );
            $images = [];
            if ( ! empty( $news['image'] ) ) {
                $img_url = $is_global_source ? $this->normalize_global_trends_url( $news['image'] ) : esc_url_raw( $news['image'] );
                if ( $img_url ) {
                    $images[] = [ 'url' => $img_url, 'source' => $candidate_url, 'width' => 0, 'scope' => 'rss-image', 'caption' => $this->clean_source_image_caption( $news['image_caption'] ?? '' ), 'credit' => '' ];
                }
            }
            if ( ! empty( $item['picture'] ) ) {
                $img_url = $is_global_source ? $this->normalize_global_trends_url( $item['picture'] ) : esc_url_raw( $item['picture'] );
                if ( $img_url ) {
                    $images[] = [ 'url' => $img_url, 'source' => $candidate_url, 'width' => 0, 'scope' => 'feed-picture', 'caption' => $this->clean_source_image_caption( $item['picture_caption'] ?? '' ), 'credit' => '' ];
                }
            }
            foreach ( $this->extract_source_images_from_url( $candidate_url, 5 ) as $page_image ) {
                $images[] = $page_image;
            }

            $valid_images = [];
            $seen_images = [];
            foreach ( $images as $image ) {
                $img_url = esc_url_raw( $image['url'] ?? '' );
                if ( ! $img_url || isset( $seen_images[ md5( $img_url ) ] ) ) { continue; }
                $seen_images[ md5( $img_url ) ] = true;
                $readable = $this->auto_news_remote_image_is_readable( $img_url );
                if ( empty( $readable['ok'] ) ) {
                    $this->add_auto_news_log( 'Lewati image sumber tidak terbaca: ' . $img_url . ' (' . sanitize_text_field( $readable['error'] ?? 'unknown' ) . ')', 'skip' );
                    continue;
                }
                $image['url'] = $readable['url'] ?: $img_url;
                $image['width'] = absint( $readable['width'] ?? ( $image['width'] ?? 0 ) );
                $valid_images[] = $image;
            }
            if ( empty( $valid_images ) ) {
                $this->add_auto_news_log( 'Lewati sumber: tidak ada image terbaca untuk ' . $candidate_url, 'skip' );
                continue;
            }

            $source_index = count( $sources ) + 1;
            $sources[] = [
                'index'   => $source_index,
                'title'   => $source_title,
                'url'     => $candidate_url,
                'source'  => sanitize_text_field( $news['source'] ?? wp_parse_url( $candidate_url, PHP_URL_HOST ) ),
                'context' => $context,
            ];
            $first = $valid_images[0];
            $first['source_url'] = $candidate_url;
            $first['source_title'] = $source_title;
            $first['source_name'] = sanitize_text_field( $news['source'] ?? wp_parse_url( $candidate_url, PHP_URL_HOST ) );
            $first['source_index'] = $source_index;
            $source_images[] = $first;

            if ( count( $sources ) >= 3 ) { break; }
        }
        if ( empty( $sources ) || empty( $source_images ) ) {
            $this->add_auto_news_log( 'Lewati tren: tidak ditemukan sumber yang sekaligus bisa diakses dan memiliki image terbaca untuk "' . ( $item['title'] ?? '' ) . '".', 'skip', [ 'trend' => $item ] );
            return [ 'created' => false, 'reason' => 'no_source_image' ];
        }

        $source_context_parts = [];
        foreach ( $sources as $src ) {
            $source_context_parts[] = "\n\n=== SUMBER " . absint( $src['index'] ) . ": " . sanitize_text_field( $src['title'] ) . " ===\nURL: " . esc_url_raw( $src['url'] ) . "\nMedia/Sumber: " . sanitize_text_field( $src['source'] ) . "\n" . wp_strip_all_tags( $src['context'] );
        }
        $source_context = implode( "\n", $source_context_parts );
        $primary = $sources[0];
        $item['multi_sources'] = array_map( function( $src ) {
            return [ 'title' => $src['title'], 'url' => $src['url'], 'source' => $src['source'] ];
        }, $sources );
        $ai = $this->generate_auto_news_article( $primary['url'], $primary['title'] ?: ( $item['title'] ?? '' ), $source_context, $item, $settings );
        if ( is_wp_error( $ai ) ) {
            $this->add_auto_news_log( 'AI gagal untuk "' . ( $item['title'] ?? '' ) . '": ' . $ai->get_error_message(), 'error' );
            return [ 'created' => false, 'reason' => 'AI gagal: ' . $ai->get_error_message() ];
        }
        $status = $settings['publish_mode'] === 'publish' ? 'publish' : 'draft';
        $post_id = $this->create_auto_news_post( $ai, $status, $primary['url'], $source_images, $item, $settings );
        if ( is_wp_error( $post_id ) ) {
            $this->add_auto_news_log( 'Gagal membuat post Auto News: ' . $post_id->get_error_message(), 'error' );
            return [ 'created' => false, 'reason' => 'Gagal membuat post: ' . $post_id->get_error_message() ];
        }
        $this->add_auto_news_log( 'Auto News dibuat dari ' . count( $sources ) . ' sumber valid: #' . $post_id . ' - ' . get_the_title( $post_id ), $status === 'publish' ? 'publish' : 'draft', [ 'post_id' => $post_id, 'source_url' => $primary['url'] ] );
        return [ 'created' => true, 'post_id' => $post_id ];
    }

    private function process_manual_keyword_auto_news_item( array $item, array $settings ) {
        $keyword = trim( sanitize_text_field( $item['keyword'] ?? $item['title'] ?? '' ) );
        if ( $keyword === '' ) {
            return [ 'created' => false, 'reason' => 'Keyword kosong' ];
        }
        $pexels_image = $this->fetch_pexels_image_for_auto_news( $keyword );
        if ( is_wp_error( $pexels_image ) ) {
            $this->add_auto_news_log( 'Lewati keyword "' . $keyword . '": ' . $pexels_image->get_error_message(), 'skip' );
            return [ 'created' => false, 'reason' => 'Pexels image gagal: ' . $pexels_image->get_error_message() ];
        }
        $source_context = "\n\n=== KEYWORD SEO PAGE 1 ===\nKeyword utama: " . $keyword . "\nMode: Artikel dibuat dari keyword manual, bukan dari RSS/Google News.\nInstruksi: bangun artikel evergreen yang menjawab search intent keyword, memakai struktur SEO, dan tidak mengarang klaim berita spesifik yang membutuhkan sumber eksternal.";
        $item['keyword_direct'] = '1';
        $item['multi_sources'] = [ [ 'title' => $keyword, 'url' => '', 'source' => 'Keyword Manual' ] ];
        $ai = $this->generate_auto_news_article( '', $keyword, $source_context, $item, $settings );
        if ( is_wp_error( $ai ) ) {
            $this->add_auto_news_log( 'AI gagal untuk keyword "' . $keyword . '": ' . $ai->get_error_message(), 'error' );
            return [ 'created' => false, 'reason' => 'AI gagal: ' . $ai->get_error_message() ];
        }
        $status = $settings['publish_mode'] === 'publish' ? 'publish' : 'draft';
        $post_id = $this->create_auto_news_post( $ai, $status, '', [ $pexels_image ], $item, $settings );
        if ( is_wp_error( $post_id ) ) {
            $this->add_auto_news_log( 'Gagal membuat post keyword manual: ' . $post_id->get_error_message(), 'error' );
            return [ 'created' => false, 'reason' => 'Gagal membuat post: ' . $post_id->get_error_message() ];
        }
        $this->add_auto_news_log( 'Auto Artikel Keyword SEO dibuat: #' . $post_id . ' - ' . get_the_title( $post_id ), $status === 'publish' ? 'publish' : 'draft', [ 'post_id' => $post_id, 'keyword' => $keyword ] );
        return [ 'created' => true, 'post_id' => $post_id ];
    }

    private function extract_source_images_from_url( $url, $limit = 8 ) {
        $url = esc_url_raw( $url );
        $limit = max( 1, min( 24, absint( $limit ) ) );
        if ( ! $url ) { return []; }
        $response = wp_remote_get( $url, [
            'timeout'     => 20,
            'redirection' => 5,
            'headers'     => [
                'User-Agent' => 'YZGAIJournalist/3.4',
                'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            ],
        ] );
        if ( is_wp_error( $response ) ) { return []; }
        $html = wp_remote_retrieve_body( $response );
        if ( ! is_string( $html ) || trim( $html ) === '' ) { return []; }

        $article = $this->extract_article_like_html( $html );
        $scan_html = $article['html'];
        // Samakan metode dengan Tools Generate Artikel: caption diambil dari area dekat image, figcaption, class caption, alt/title/data-caption, dan credit dekat image.
        if ( preg_match_all( '#<(?:div|figure|picture)\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>.*?</(?:div|figure|picture)>#is', $html, $cover_blocks ) ) {
            $scan_html .= "\n" . implode( "\n", $cover_blocks[0] );
        }
        if ( preg_match_all( '#<img\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>#is', $html, $cover_imgs ) ) {
            $scan_html .= "\n" . implode( "\n", $cover_imgs[0] );
        }
        $strict_article = ! empty( $article['strict_article'] );
        $images = [];
        $seen_names = [];
        $min_width = 320;

        if ( preg_match_all( '#<img\b[^>]*>#i', $scan_html, $tags ) ) {
            foreach ( $tags[0] as $tag ) {
                $tag_width = $this->parse_img_tag_width( $tag );
                foreach ( $this->parse_img_tag_srcs( $tag ) as $src ) {
                    $img = $this->absolutize_url( $src, $url );
                    if ( ! $img || ! preg_match( '#\.(jpe?g|png|webp|gif)(\?.*)?$#i', $img ) ) { continue; }
                    $width = $tag_width;
                    if ( $width < $min_width ) { $width = $this->remote_image_width( $img ); }
                    if ( $width < $min_width ) { continue; }
                    $name_key = $this->normalize_source_image_name_key( $img );
                    if ( isset( $seen_names[ $name_key ] ) ) { continue; }
                    $seen_names[ $name_key ] = true;
                    $images[ md5( $img ) ] = [
                        'url'     => $img,
                        'source'  => $url,
                        'width'   => $width,
                        'scope'   => $strict_article ? 'article' : 'page-filtered',
                        'caption' => $this->extract_caption_near_image( $scan_html, $tag ),
                        'credit'  => $this->extract_credit_near_image( $scan_html, $tag ),
                    ];
                    if ( count( $images ) >= $limit ) { break 2; }
                }
            }
        }

        if ( count( $images ) < $limit ) {
            $meta_caption = '';
            foreach ( [ 'og:image:alt', 'twitter:image:alt', 'og:title', 'twitter:title' ] as $caption_prop ) {
                if ( preg_match( '#<meta[^>]+(?:property|name)=["\']' . preg_quote( $caption_prop, '#' ) . '["\'][^>]+content=["\']([^"\']+)["\']#i', $html, $cm ) || preg_match( '#<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']' . preg_quote( $caption_prop, '#' ) . '["\']#i', $html, $cm ) ) {
                    $meta_caption = $this->clean_source_image_caption( $cm[1] );
                    if ( $meta_caption !== '' ) { break; }
                }
            }
            foreach ( [ 'og:image', 'og:image:url', 'twitter:image', 'twitter:image:src' ] as $prop ) {
                if ( preg_match( '#<meta[^>]+(?:property|name)=["\']' . preg_quote( $prop, '#' ) . '["\'][^>]+content=["\']([^"\']+)["\']#i', $html, $m ) || preg_match( '#<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']' . preg_quote( $prop, '#' ) . '["\']#i', $html, $m ) ) {
                    $img = $this->absolutize_url( $m[1], $url );
                    if ( $img && preg_match( '#\.(jpe?g|png|webp)(\?.*)?$#i', $img ) ) {
                        $name_key = $this->normalize_source_image_name_key( $img );
                        if ( ! isset( $seen_names[ $name_key ] ) ) {
                            $width = $this->remote_image_width( $img );
                            if ( $width >= $min_width ) {
                                $seen_names[ $name_key ] = true;
                                $images[ md5( $img ) ] = [ 'url' => $img, 'source' => $url, 'width' => $width, 'scope' => 'meta-image', 'caption' => $meta_caption, 'credit' => '' ];
                            }
                        }
                    }
                }
                if ( count( $images ) >= $limit ) { break; }
            }
        }
        return array_values( $images );
    }

    private function auto_news_remote_image_is_readable( $url ) {
        $url = esc_url_raw( (string) $url );
        if ( ! $url ) { return [ 'ok' => false, 'error' => 'URL kosong', 'url' => '', 'width' => 0 ]; }
        $cache_key = 'heaj_img_ok_' . md5( $url );
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) { return $cached; }
        $attempts = [ $url ];
        if ( stripos( $url, 'trendhunterstatic.com' ) !== false || stripos( $url, 'trendhunter.com' ) !== false ) {
            $attempts[] = str_replace( 'http://', 'https://', $url );
            $attempts[] = str_replace( 'https://', 'http://', $url );
            $attempts[] = preg_replace( '/_(?:120|300|468|600|800)(\.(?:jpe?g|png|webp))(\?.*)?$/i', '_468$1$2', $url );
            $attempts[] = preg_replace( '/_(?:120|300|468|600|800)(\.(?:jpe?g|png|webp))(\?.*)?$/i', '_120$1$2', $url );
        }
        $attempts = array_values( array_unique( array_filter( array_map( 'esc_url_raw', $attempts ) ) ) );
        $last_error = 'image tidak terbaca';
        foreach ( $attempts as $attempt_url ) {
            $width = $this->remote_image_width( $attempt_url );
            if ( $width >= 320 ) {
                $result = [ 'ok' => true, 'error' => '', 'url' => $attempt_url, 'width' => $width ];
                set_transient( $cache_key, $result, DAY_IN_SECONDS );
                return $result;
            }
            if ( $width > 0 && $width < 320 ) {
                $last_error = 'image terlalu kecil (' . $width . 'px)';
                continue;
            }
            $last_error = 'getimagesize gagal';
        }
        $result = [ 'ok' => false, 'error' => $last_error, 'url' => $url, 'width' => 0 ];
        set_transient( $cache_key, $result, HOUR_IN_SECONDS );
        return $result;
    }

    private function fetch_pexels_image_for_auto_news( $keyword ) {
        $api_key = trim( (string) get_option( self::OPTION_PEXELS_API_KEY, '' ) );
        if ( $api_key === '' ) {
            return new WP_Error( 'heaj_pexels_no_key', 'API key Pexels belum diisi.' );
        }
        $query = $this->build_pexels_query( $keyword );
        if ( $query === '' ) {
            $query = 'news article illustration';
        }
        $response = wp_remote_get( add_query_arg( [
            'query' => $query,
            'per_page' => 8,
            'orientation' => 'landscape',
            'size' => 'large',
            'locale' => 'en-US',
        ], 'https://api.pexels.com/v1/search' ), [
            'timeout' => 20,
            'headers' => [
                'Authorization' => $api_key,
                'Accept' => 'application/json',
            ],
        ] );
        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'heaj_pexels_http_error', $response->get_error_message() );
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
            return new WP_Error( 'heaj_pexels_bad_response', 'Gagal mengambil gambar Pexels. HTTP ' . $code );
        }
        $photos = (array) ( $data['photos'] ?? [] );
        if ( empty( $photos ) && $query !== 'news article illustration' ) {
            return $this->fetch_pexels_image_for_auto_news( 'news article illustration' );
        }
        if ( empty( $photos ) ) {
            return new WP_Error( 'heaj_pexels_empty', 'Pexels tidak mengembalikan gambar untuk keyword ini.' );
        }
        foreach ( $photos as $photo ) {
            $src = is_array( $photo['src'] ?? null ) ? $photo['src'] : [];
            $url = $src['large2x'] ?? $src['large'] ?? $src['original'] ?? '';
            if ( ! $url ) { continue; }
            $photographer = sanitize_text_field( $photo['photographer'] ?? 'Pexels' );
            return [
                'url' => esc_url_raw( $url ),
                'source' => esc_url_raw( $photo['url'] ?? 'https://www.pexels.com' ),
                'width' => absint( $photo['width'] ?? 0 ),
                'scope' => 'pexels',
                'caption' => 'Ilustrasi foto',
                'credit' => 'Foto: ' . $photographer . ' / Pexels',
                'label' => 'ilustrasi foto',
                'source_type' => 'pexels',
                'source_url' => esc_url_raw( $photo['url'] ?? 'https://www.pexels.com' ),
                'source_title' => 'Pexels',
                'source_name' => 'Pexels',
                'pexels_id' => absint( $photo['id'] ?? 0 ),
            ];
        }
        return new WP_Error( 'heaj_pexels_no_usable_image', 'Tidak ada URL gambar Pexels yang dapat dipakai.' );
    }

    private function auto_news_response_schema() {
        return [
            'type' => 'OBJECT',
            'properties' => [
                'titleOptions' => [ 'type' => 'ARRAY', 'items' => [ 'type' => 'STRING' ] ],
                'slugOptions' => [ 'type' => 'ARRAY', 'items' => [ 'type' => 'STRING' ] ],
                'metaDescriptions' => [ 'type' => 'ARRAY', 'items' => [ 'type' => 'STRING' ] ],
                'category' => [ 'type' => 'STRING' ],
                'tags' => [ 'type' => 'ARRAY', 'items' => [ 'type' => 'STRING' ] ],
                'imageKeywords' => [ 'type' => 'STRING' ],
                'articleBody' => [ 'type' => 'STRING' ],
                'references' => [ 'type' => 'ARRAY', 'items' => [ 'type' => 'STRING' ] ],
            ],
            'required' => [ 'titleOptions', 'slugOptions', 'metaDescriptions', 'category', 'tags', 'articleBody', 'references' ],
        ];
    }

    private function auto_article_prompt_text( $prompt_key ) {
        $prompt_key = sanitize_key( $prompt_key ?: 'straight_news' );
        $settings = $this->get_custom_settings();
        foreach ( (array) ( $settings['prompts'] ?? [] ) as $row ) {
            if ( sanitize_key( $row['key'] ?? '' ) === $prompt_key && trim( (string) ( $row['prompt'] ?? '' ) ) !== '' ) {
                return (string) $row['prompt'];
            }
        }
        $builtin = self::builtin_prompt( $prompt_key );
        return $builtin ?: self::builtin_prompt( 'straight_news' );
    }

    private function generate_auto_news_article( $source_url, $source_title, $source_context, array $rss_item, array $settings = [] ) {
        $settings = array_merge( self::default_auto_news_settings(), is_array( $settings ) ? $settings : [] );
        $schema = $this->auto_news_response_schema();
        $language = sanitize_key( $settings['language'] ?? 'id' );
        $language_rule = $language === 'en'
            ? 'ABSOLUTE LANGUAGE RULE: Write all generated output in English except proper nouns and direct quotes.'
            : 'ATURAN BAHASA MUTLAK: Gunakan Bahasa Indonesia untuk semua field output kecuali nama diri dan kutipan langsung.';
        $feed_mode = sanitize_key( $settings['feed_mode'] ?? 'google_trends' );
        $auto_prompt_key = $feed_mode === 'manual_keywords' ? 'seo_artikel' : 'jurnalis_heading';
        $system_prompt = $language_rule . "\n\n" . $this->auto_article_prompt_text( $auto_prompt_key );
        if ( $feed_mode === 'manual_keywords' ) {
            $system_prompt .= "\n\nMODE KEYWORD MANUAL / SEO PAGE 1: Artikel dibuat dari keyword input pengguna, bukan dari Google News RSS. Gunakan keyword sebagai bahan utama, petakan search intent, buat struktur SEO yang kuat, dan tulis artikel evergreen/informasional. DILARANG berpura-pura memiliki sumber berita, kutipan narasumber, tanggal kejadian, angka statistik, atau peristiwa aktual spesifik jika tidak diberikan dalam input. Gunakan gaya edukatif-komersial yang natural, bukan hard selling.";
            $system_prompt .= "\n\nOUTPUT SEO: titleOptions harus mengandung keyword atau variasi sangat dekat. metaDescriptions harus menarik klik dan relevan dengan intent. articleBody wajib HTML rapi dengan <p>, <h2>, <h3>, dan <ul><li> bila relevan. Setiap paragraf maksimal 2 kalimat. Jangan gunakan markdown **teks**; jika perlu bold, gunakan tag HTML <strong>teks</strong>. Output wajib JSON sesuai schema.";
            $keyword_label = sanitize_text_field( $rss_item['keyword'] ?? $source_title );
            $user_text = $language_rule . "\n\nTUGAS: Buat artikel SEO Page 1 Google dari keyword berikut.\n\nKeyword utama: " . $keyword_label . $source_context;
        } else {
            $system_prompt .= "\n\nMODE GOOGLE/GLOBAL TRENDS STRICT: Gunakan model rewrite default jurnalis. Tulis ulang berita secara faktual, netral, lugas, memakai gaya jurnalistik dan piramida terbalik. Artikel hanya boleh dibuat dari sumber yang berhasil diakses server dan memiliki image terbaca. DILARANG membuat fakta di luar teks sumber hasil ekstraksi server.";
            $system_prompt .= "\n\nMODE MULTI-SUMBER: Jika tersedia beberapa SUMBER 1, SUMBER 2, dan SUMBER 3, gunakan semuanya sebagai rujukan artikel agar isi lebih lengkap, unik, dan tidak hanya menyalin satu sumber. Buat subheading sesuai angle bahasan dari masing-masing sumber bila relevan. articleBody wajib HTML rapi dengan <p>, <h2>, <h3>, <blockquote>, dan <ul><li> bila relevan. Setiap paragraf maksimal 2 kalimat. Jangan gunakan markdown **teks**; jika perlu bold, gunakan tag HTML <strong>teks</strong>. Output wajib JSON sesuai schema.";
            $topic_label = 'Topik Feed: ' . sanitize_text_field( $rss_item['title'] ?? '' );
            $user_text = $language_rule . "\n\nTUGAS: Buat artikel berita SEO-ready dari sumber yang VALID berikut. Jangan memakai sumber/feed yang tidak tercantum di teks ekstraksi.\n\n" . $topic_label . "\nJudul berita sumber: " . sanitize_text_field( $source_title ) . "\nURL sumber utama: " . esc_url_raw( $source_url ) . $source_context;
        }

        $preferred = sanitize_key( $settings['ai_provider'] ?? 'gemini' );
        $provider_order = $preferred === 'gemini'
            ? [ 'gemini', 'openrouter', 'grok', 'groqcloud', 'zai' ]
            : array_values( array_unique( array_merge( [ $preferred ], [ 'openrouter', 'grok', 'groqcloud', 'zai', 'gemini' ] ) ) );
        foreach ( $provider_order as $provider ) {
            if ( $provider === 'gemini' ) {
                $result = $this->call_gemini_json_internal( $system_prompt, $user_text, $schema, false );
                if ( ! is_wp_error( $result ) ) { return $result; }
                continue;
            }
            $config = $this->openai_provider_config( $provider );
            if ( empty( $config['keys'] ) ) { continue; }
            $result = $this->call_openai_compatible_json( $provider, $system_prompt, $user_text, $schema );
            if ( ! is_wp_error( $result ) ) {
                return $this->sanitize_ai_json_result( $result['result'], $schema );
            }
        }
        return new WP_Error( 'heaj_auto_all_ai_failed', 'Semua provider AI yang tersedia gagal membuat Auto Artikel.' );
    }

    private function call_gemini_json_internal( $system_prompt, $user_text, $schema, $use_search = false ) {
        $api_key_pool = $this->get_api_key_pool( false );
        if ( empty( $api_key_pool ) ) { return new WP_Error( 'heaj_auto_no_api', 'Tidak ada Gemini API Key aktif dan provider OpenAI-compatible juga tidak tersedia.' ); }
        $model_chain = $this->get_gemini_model_chain( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        $last_error = 'Request Gemini gagal.';
        foreach ( $model_chain as $try_model ) {
            $payload = $this->build_gemini_payload( $try_model, $system_prompt, $user_text, $schema, $use_search );
            foreach ( $api_key_pool as $api_item ) {
                $api_key = $api_item['key'] ?? '';
                if ( ! $api_key || $this->is_api_key_blocked( $api_key ) ) { continue; }
                $endpoint = sprintf( 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', rawurlencode( $try_model ), rawurlencode( $api_key ) );
                $response = wp_remote_post( $endpoint, [ 'headers' => [ 'Content-Type' => 'application/json' ], 'timeout' => 120, 'body' => wp_json_encode( $payload ) ] );
                if ( is_wp_error( $response ) ) { $last_error = $response->get_error_message(); continue; }
                $code = (int) wp_remote_retrieve_response_code( $response );
                $decoded = json_decode( wp_remote_retrieve_body( $response ), true );
                if ( $code < 200 || $code >= 300 ) {
                    $last_error = $decoded['error']['message'] ?? 'Request Gemini gagal. HTTP ' . $code;
                    if ( $this->is_blockable_gemini_api_key_error( $code, $last_error ) ) { $this->block_api_key( $api_key, $last_error ); }
                    continue;
                }
                $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( is_array( $result ) ) { return $this->sanitize_ai_json_result( $result, $schema ); }
                $last_error = 'Respons Gemini bukan JSON valid.';
            }
        }
        return new WP_Error( 'heaj_auto_gemini_failed', $last_error );
    }

    private function auto_news_author_id( array $settings ) {
        $author_id = absint( $settings['author_user_id'] ?? 0 );
        if ( $author_id && get_userdata( $author_id ) ) { return $author_id; }
        $current = get_current_user_id();
        if ( $current && get_userdata( $current ) ) { return $current; }
        return 1;
    }

    private function auto_news_source_image_figure_html( $attachment_id, array $image ) {
        $img_html = wp_get_attachment_image( $attachment_id, 'large', false, [ 'loading' => 'lazy', 'class' => 'heaj-auto-source-image' ] );
        if ( ! $img_html ) { return ''; }
        $caption = $this->clean_source_image_caption( $image['caption'] ?? '' );
        $source_name = sanitize_text_field( $image['source_name'] ?? ( $image['source_title'] ?? 'Sumber' ) );
        $source_url = esc_url_raw( $image['source_url'] ?? ( $image['source'] ?? '' ) );
        $caption_parts = [];
        if ( $caption !== '' ) { $caption_parts[] = esc_html( $caption ); }
        if ( $source_url ) {
            $caption_parts[] = 'Sumber: <a href="' . esc_url( $source_url ) . '" target="_blank" rel="nofollow noopener noreferrer">' . esc_html( $source_name ?: wp_parse_url( $source_url, PHP_URL_HOST ) ) . '</a>';
        } elseif ( $source_name ) {
            $caption_parts[] = 'Sumber: ' . esc_html( $source_name );
        }
        $figcaption = $caption_parts ? '<figcaption>' . implode( ' — ', $caption_parts ) . '</figcaption>' : '';
        return '<figure class="heaj-auto-source-figure">' . $img_html . $figcaption . '</figure>';
    }

    private function inject_auto_news_source_figures( $content, array $figure_blocks ) {
        $content = (string) $content;
        $figure_blocks = array_values( array_filter( $figure_blocks ) );
        if ( empty( $figure_blocks ) ) { return $content; }
        if ( preg_match_all( '#</h[23]>#i', $content, $matches, PREG_OFFSET_CAPTURE ) && ! empty( $matches[0] ) ) {
            $insertions = [];
            foreach ( $figure_blocks as $i => $block ) {
                if ( empty( $matches[0][ $i ] ) ) { break; }
                $insertions[] = [ 'pos' => $matches[0][ $i ][1] + strlen( $matches[0][ $i ][0] ), 'html' => "\n" . $block . "\n" ];
            }
            foreach ( array_reverse( $insertions ) as $ins ) {
                $content = substr( $content, 0, $ins['pos'] ) . $ins['html'] . substr( $content, $ins['pos'] );
            }
            if ( count( $figure_blocks ) > count( $insertions ) ) {
                $content .= "\n" . implode( "\n", array_slice( $figure_blocks, count( $insertions ) ) );
            }
            return $content;
        }
        if ( preg_match( '#</p>#i', $content, $m, PREG_OFFSET_CAPTURE ) ) {
            $pos = $m[0][1] + strlen( $m[0][0] );
            return substr( $content, 0, $pos ) . "\n" . implode( "\n", $figure_blocks ) . "\n" . substr( $content, $pos );
        }
        return implode( "\n", $figure_blocks ) . "\n" . $content;
    }

    private function he_network_integration_is_available() {
        if ( class_exists( 'HE_NP_Settings' ) || class_exists( 'HE_NP_Source' ) || class_exists( 'HE_NP_Aggregator' ) ) { return true; }
        $settings = get_option( 'he_np_settings', null );
        $legacy = get_option( 'he_nla_settings', null );
        return is_array( $settings ) || is_array( $legacy );
    }

    private function he_network_sites_from_raw_settings( array $settings ) {
        if ( class_exists( 'HE_NP_Settings' ) && method_exists( 'HE_NP_Settings', 'sites' ) ) {
            $sites = HE_NP_Settings::sites();
            if ( is_array( $sites ) && ! empty( $sites ) ) { return $sites; }
        }
        $raw = isset( $settings['sites'] ) ? (string) $settings['sites'] : '';
        $items = preg_split( '/\r\n|\r|\n|,/', $raw );
        $sites = [];
        foreach ( (array) $items as $item ) {
            $url = trim( (string) $item );
            if ( $url === '' ) { continue; }
            if ( ! preg_match( '#^https?://#i', $url ) ) { $url = 'https://' . $url; }
            $url = esc_url_raw( $url );
            if ( $url ) { $sites[] = trailingslashit( $url ); }
        }
        return array_values( array_unique( $sites ) );
    }

    private function notify_he_network_aggregators_after_auto_publish( $post_id ) {
        $post_id = absint( $post_id );
        if ( ! $post_id || get_post_status( $post_id ) !== 'publish' ) { return false; }
        if ( ! $this->he_network_integration_is_available() ) {
            update_post_meta( $post_id, '_he_np_auto_ping_status', 'network_plugin_not_installed' );
            return false;
        }

        $settings = [];
        if ( class_exists( 'HE_NP_Settings' ) && method_exists( 'HE_NP_Settings', 'get' ) ) {
            $settings = HE_NP_Settings::get();
        } else {
            $settings = get_option( 'he_np_settings', [] );
        }
        $settings = is_array( $settings ) ? $settings : [];
        $mode = isset( $settings['mode'] ) ? sanitize_key( $settings['mode'] ) : '';

        // Website aggregator boleh memakai Auto Artikel, tetapi tidak boleh ping keluar karena ia sendiri aggregator.
        // Yang dibutuhkan adalah refresh index lokal setelah featured image/figure selesai dipasang.
        if ( $mode === 'aggregator' ) {
            $indexed = false;
            $message = 'HE Network mode Aggregator: ping keluar dilewati untuk post #' . $post_id . '.';
            if ( class_exists( 'HE_NP_Aggregator' ) ) {
                try {
                    $aggregator = new HE_NP_Aggregator();
                    if ( method_exists( $aggregator, 'upsert_local_post' ) ) {
                        $indexed = (bool) $aggregator->upsert_local_post( $post_id );
                    }
                    if ( method_exists( $aggregator, 'flush_cache' ) ) { $aggregator->flush_cache(); }
                    $message = $indexed
                        ? 'HE Network mode Aggregator: artikel auto lokal diindex ulang tanpa ping keluar untuk post #' . $post_id . '.'
                        : 'HE Network mode Aggregator: ping keluar dilewati; upsert lokal tidak menambah data baru untuk post #' . $post_id . '.';
                } catch ( Throwable $e ) {
                    $message = 'HE Network mode Aggregator: ping keluar dilewati, tetapi upsert lokal gagal: ' . $e->getMessage();
                } catch ( Exception $e ) {
                    $message = 'HE Network mode Aggregator: ping keluar dilewati, tetapi upsert lokal gagal: ' . $e->getMessage();
                }
            }
            update_post_meta( $post_id, '_he_np_auto_ping_status', 'skipped_aggregator_mode' );
            update_post_meta( $post_id, '_he_np_auto_ping_time', time() );
            update_post_meta( $post_id, '_he_np_auto_local_indexed', $indexed ? '1' : '0' );
            $this->add_auto_news_log( $message, $indexed ? 'index' : 'info', [ 'post_id' => $post_id ] );
            return false;
        }

        $sent = false;
        $message = '';

        // HE Network may ping on transition_post_status before featured image is attached.
        // Clear its short lock so this post-image ping can refresh aggregator with the final thumbnail.
        delete_transient( 'he_np_ping_lock_' . $post_id );

        if ( $mode === 'source' && class_exists( 'HE_NP_Source' ) ) {
            try {
                $source = new HE_NP_Source();
                if ( method_exists( $source, 'notify_aggregators' ) ) {
                    $source->notify_aggregators( $post_id, 'auto_published' );
                    $sent = true;
                    $message = 'Ping HE Network dikirim via HE_NP_Source untuk post #' . $post_id . '.';
                }
            } catch ( Throwable $e ) {
                $message = 'Ping HE Network via class gagal: ' . $e->getMessage();
            } catch ( Exception $e ) {
                $message = 'Ping HE Network via class gagal: ' . $e->getMessage();
            }
        }

        if ( ! $sent ) {
            $sites = $mode === 'source' ? $this->he_network_sites_from_raw_settings( $settings ) : [];
            if ( $mode !== 'source' || empty( $sites ) ) {
                update_post_meta( $post_id, '_he_np_auto_ping_status', 'skipped_no_source_settings' );
                $this->add_auto_news_log( 'HE Network ping dilewati: situs bukan mode Source atau daftar aggregator kosong.', 'warning', [ 'post_id' => $post_id, 'mode' => $mode ] );
                return false;
            }
            $secret = isset( $settings['secret_key'] ) ? (string) $settings['secret_key'] : '';
            $namespace = defined( 'HE_NP_REST_NAMESPACE' ) ? HE_NP_REST_NAMESPACE : 'he-network/v1';
            foreach ( $sites as $site_url ) {
                $endpoint = trailingslashit( $site_url ) . 'wp-json/' . $namespace . '/ping';
                $args = array_filter( [
                    'source'       => home_url( '/' ),
                    'post_id'      => $post_id,
                    'event'        => 'auto_published',
                    'modified_gmt' => get_post_modified_time( DATE_W3C, true, $post_id ),
                    'key'          => $secret,
                ], static function( $value ) { return (string) $value !== '' && $value !== 0; } );
                $url = add_query_arg( $args, $endpoint );
                $http_args = [
                    'timeout'   => 1,
                    'blocking'  => false,
                    'sslverify' => true,
                    'headers'   => [ 'User-Agent' => 'YZG-AI-Journalist/' . self::VERSION . ' HE-Network-Ping; ' . home_url( '/' ) ],
                ];
                wp_remote_post( $url, $http_args );
                $http_args['sslverify'] = false;
                wp_remote_get( $url, $http_args );
            }
            $sent = true;
            $message = 'Ping HE Network fallback dikirim ke ' . count( $sites ) . ' aggregator untuk post #' . $post_id . '.';
        }

        update_post_meta( $post_id, '_he_np_auto_ping_status', $sent ? 'sent' : 'failed' );
        update_post_meta( $post_id, '_he_np_auto_ping_time', time() );
        if ( $message ) { $this->add_auto_news_log( $message, $sent ? 'ping' : 'warning', [ 'post_id' => $post_id ] ); }
        return $sent;
    }

    private function normalize_auto_article_body_html( $content ) {
        $content = (string) $content;
        if ( $content === '' ) { return ''; }
        // AI kadang mengeluarkan markdown **teks** pada field HTML. Ubah menjadi <strong> agar tidak tampil mentah di artikel.
        $content = preg_replace_callback( '/\*\*([^\n*][^*]*?)\*\*/u', function( $m ) {
            return '<strong>' . trim( $m[1] ) . '</strong>';
        }, $content );
        $content = preg_replace_callback( '/__([^\n_][^_]*?)__/u', function( $m ) {
            return '<strong>' . trim( $m[1] ) . '</strong>';
        }, $content );
        return $content;
    }

    private function collect_auto_news_source_urls( $source_url, array $rss_item ) {
        $urls = [];
        $add_url = function( $url ) use ( &$urls ) {
            $url = esc_url_raw( trim( (string) $url ) );
            if ( ! $url ) { return; }
            $path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
            if ( preg_match( '/\.(jpe?g|png|webp|gif|svg)(\?.*)?$/i', $path ) ) { return; }
            $key = strtolower( untrailingslashit( $url ) );
            if ( isset( $urls[ $key ] ) ) { return; }
            $urls[ $key ] = $url;
        };
        $add_url( $source_url );
        $add_url( $rss_item['link'] ?? '' );
        $add_url( $rss_item['url'] ?? '' );
        if ( ! empty( $rss_item['source_url'] ) ) { $add_url( $rss_item['source_url'] ); }
        foreach ( [ 'multi_sources', 'news_items', 'sources', 'related_sources' ] as $field ) {
            if ( empty( $rss_item[ $field ] ) || ! is_array( $rss_item[ $field ] ) ) { continue; }
            foreach ( $rss_item[ $field ] as $row ) {
                if ( is_array( $row ) ) {
                    $add_url( $row['url'] ?? '' );
                    $add_url( $row['link'] ?? '' );
                    $add_url( $row['source_url'] ?? '' );
                } elseif ( is_string( $row ) ) {
                    $add_url( $row );
                }
            }
        }
        return array_slice( array_values( $urls ), 0, 12 );
    }

    private function auto_news_source_footer_html( $source_url, array $rss_item ) {
        $urls = $this->collect_auto_news_source_urls( $source_url, $rss_item );
        if ( empty( $urls ) ) { return ''; }
        $items = [];
        foreach ( $urls as $url ) {
            $items[] = '<li>' . esc_html( $url ) . '</li>';
        }
        return '<details class="heaj-auto-sources"><summary>sumber:</summary><ol style="font-size:x-small;margin:.5em 0 0 1.25em;padding-left:1.25em;">' . implode( '', $items ) . '</ol></details>';
    }

    private function create_auto_news_post( array $ai, $status, $source_url, array $source_images, array $rss_item, array $settings = [] ) {
        $title = sanitize_text_field( is_array( $ai['titleOptions'] ?? null ) ? ( $ai['titleOptions'][0] ?? '' ) : '' );
        $slug = sanitize_title( is_array( $ai['slugOptions'] ?? null ) ? ( $ai['slugOptions'][0] ?? '' ) : $title );
        $meta = sanitize_textarea_field( is_array( $ai['metaDescriptions'] ?? null ) ? ( $ai['metaDescriptions'][0] ?? '' ) : '' );
        $content = wp_kses_post( $this->normalize_auto_article_body_html( $ai['articleBody'] ?? '' ) );
        if ( ! $title || ! $content ) { return new WP_Error( 'heaj_auto_empty_article', 'AI tidak menghasilkan judul/konten valid.' ); }
        if ( get_transient( 'heaj_auto_publish_slot_lock' ) ) {
            return new WP_Error( 'heaj_auto_publish_slot_locked', 'Publish slot masih terkunci. AutoPilot hanya boleh membuat 1 artikel dalam satu slot jadwal.' );
        }
        set_transient( 'heaj_auto_publish_slot_lock', time(), 10 * MINUTE_IN_SECONDS );
        $source_footer = $this->auto_news_source_footer_html( $source_url, $rss_item );
        if ( $source_footer ) {
            $content .= "\n\n" . $source_footer;
        }
        $category = sanitize_text_field( $ai['category'] ?? 'Berita' );
        $cat_id = 0;
        if ( $category ) {
            $term = get_term_by( 'name', $category, 'category' );
            if ( $term && ! is_wp_error( $term ) ) { $cat_id = (int) $term->term_id; }
            else {
                $new_term = wp_insert_term( $category, 'category' );
                if ( ! is_wp_error( $new_term ) && ! empty( $new_term['term_id'] ) ) { $cat_id = (int) $new_term['term_id']; }
            }
        }
        $post_data = [
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_status'  => $status === 'publish' ? 'publish' : 'draft',
            'post_type'    => 'post',
            'post_author'  => $this->auto_news_author_id( $settings ),
        ];
        if ( $meta ) { $post_data['post_excerpt'] = $meta; }
        if ( $cat_id ) { $post_data['post_category'] = [ $cat_id ]; }
        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) { delete_transient( 'heaj_auto_publish_slot_lock' ); return $post_id; }
        $tags = is_array( $ai['tags'] ?? null ) ? array_filter( array_map( 'sanitize_text_field', $ai['tags'] ) ) : [];
        if ( $tags ) { wp_set_post_tags( $post_id, $tags, false ); }
        if ( $meta ) {
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta );
            update_post_meta( $post_id, 'rank_math_description', $meta );
            update_post_meta( $post_id, '_seopress_titles_desc', $meta );
            update_post_meta( $post_id, '_he_meta_description', $meta );
            update_post_meta( $post_id, 'newspress_meta_description', $meta );
            update_post_meta( $post_id, '_newspress_meta_description', $meta );
            update_post_meta( $post_id, 'single_post_subtitle', $meta );
            update_post_meta( $post_id, '_single_post_subtitle', $meta );
        }
        update_post_meta( $post_id, '_he_source_url', esc_url_raw( $source_url ) );
        $all_source_urls = $this->collect_auto_news_source_urls( $source_url, $rss_item );
        if ( ! empty( $all_source_urls ) ) { update_post_meta( $post_id, '_he_auto_news_source_urls', wp_json_encode( array_values( $all_source_urls ) ) ); }
        update_post_meta( $post_id, '_he_auto_news', '1' );
        update_post_meta( $post_id, '_he_auto_news_trend_title', sanitize_text_field( $rss_item['title'] ?? '' ) );
        update_post_meta( $post_id, '_he_generated_by', 'YZG AI Journalist Auto News ' . self::VERSION );
        if ( empty( $source_images[0]['url'] ) ) {
            wp_delete_post( $post_id, true );
            delete_transient( 'heaj_auto_publish_slot_lock' );
            return new WP_Error( 'heaj_auto_image_missing', 'Featured image wajib tersedia untuk Auto Artikel.' );
        }
        $featured_set = false;
        $image_errors = [];
        foreach ( array_slice( $source_images, 0, 5 ) as $image ) {
            if ( empty( $image['url'] ) ) { continue; }
            $img_caption = sanitize_text_field( $image['caption'] ?? '' );
            $att_id = $this->sideload_featured_image( $image['url'], $post_id, $title, $img_caption );
            if ( is_wp_error( $att_id ) || ! $att_id ) {
                $image_errors[] = is_wp_error( $att_id ) ? $att_id->get_error_message() : 'Gagal memasang image sumber.';
                continue;
            }
            set_post_thumbnail( $post_id, $att_id );
            update_post_meta( $post_id, '_he_featured_image_source_url', esc_url_raw( $image['url'] ) );
            if ( $img_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $img_caption ); }
            if ( ! empty( $image['credit'] ) ) { update_post_meta( $post_id, '_he_featured_image_credit', sanitize_text_field( $image['credit'] ) ); }
            if ( ! empty( $image['source_type'] ) ) { update_post_meta( $post_id, '_he_featured_image_source_type', sanitize_key( $image['source_type'] ) ); }
            update_post_meta( $post_id, '_he_auto_news_body_images', 'disabled_featured_only' );
            $featured_set = true;
            break;
        }
        if ( ! $featured_set ) {
            wp_delete_post( $post_id, true );
            delete_transient( 'heaj_auto_publish_slot_lock' );
            return new WP_Error( 'heaj_auto_image_failed', 'Semua featured image gagal dipasang: ' . sanitize_textarea_field( implode( ' | ', array_slice( $image_errors, 0, 3 ) ) ) );
        }
        if ( get_post_status( $post_id ) === 'publish' ) {
            $this->notify_he_network_aggregators_after_auto_publish( $post_id );
        }
        return $post_id;
    }

    private function default_api_keys() {
        return [];
    }



    private function default_grok_api_keys() {
        return [];
    }

    private function default_groqcloud_api_keys() {
        return [];
    }

    private function default_zai_api_keys() {
        return [];
    }

    private function default_openrouter_api_keys() {
        return [];
    }

    private function parse_api_keys_option( $option_name ) {
        $raw = get_option( $option_name, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_unique( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) ) );
    }

    private function filter_unblocked_api_keys( array $keys, $include_blocked = false ) {
        $keys = array_values( array_unique( array_filter( array_map( 'trim', $keys ) ) ) );
        if ( $include_blocked ) { return $keys; }
        return array_values( array_filter( $keys, function( $key ) {
            return ! $this->is_api_key_blocked( $key );
        } ) );
    }

    private function get_grok_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_grok_api_keys(), $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ) ), $include_blocked );
    }

    private function get_groqcloud_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_groqcloud_api_keys(), $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ) ), $include_blocked );
    }

    private function get_zai_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_zai_api_keys(), $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ) ), $include_blocked );
    }

    private function get_openrouter_api_keys( $include_blocked = false ) {
        return $this->filter_unblocked_api_keys( array_merge( $this->default_openrouter_api_keys(), $this->parse_api_keys_option( self::OPTION_OPENROUTER_API_KEYS ) ), $include_blocked );
    }

    private function get_provider_key_status_rows() {
        $groups = [
            'Gemini' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_api_keys(), array_keys( $this->default_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->get_extra_api_keys(), array_keys( $this->get_extra_api_keys() ) )
            ),
            'Grok / xAI' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_grok_api_keys(), array_keys( $this->default_grok_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_GROK_API_KEYS ) ) )
            ),
            'Groq' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_groqcloud_api_keys(), array_keys( $this->default_groqcloud_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_GROQ_API_KEYS ) ) )
            ),
            'Z.AI' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_zai_api_keys(), array_keys( $this->default_zai_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_ZAI_API_KEYS ) ) )
            ),
            'OpenRouter' => array_merge(
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Default #' . ( $i + 1 ), 'source' => 'default' ]; }, $this->default_openrouter_api_keys(), array_keys( $this->default_openrouter_api_keys() ) ),
                array_map( function( $key, $i ) { return [ 'key' => $key, 'label' => 'Tambahan #' . ( $i + 1 ), 'source' => 'extra' ]; }, $this->parse_api_keys_option( self::OPTION_OPENROUTER_API_KEYS ), array_keys( $this->parse_api_keys_option( self::OPTION_OPENROUTER_API_KEYS ) ) )
            ),
        ];

        $rows = [];
        $blocked = $this->get_blocked_api_keys();
        foreach ( $groups as $provider => $items ) {
            $seen = [];
            $order = 1;
            foreach ( $items as $item ) {
                $key = trim( (string) ( $item['key'] ?? '' ) );
                if ( $key === '' ) { continue; }
                $hash = $this->api_key_hash( $key );
                if ( isset( $seen[ $hash ] ) ) { continue; }
                $seen[ $hash ] = true;
                $rows[] = [
                    'provider'   => $provider,
                    'order'      => $order++,
                    'label'      => $item['label'],
                    'masked'     => $this->mask_api_key( $key ),
                    'blocked'    => isset( $blocked[ $hash ] ),
                    'block_info' => $blocked[ $hash ] ?? null,
                ];
            }
        }
        return $rows;
    }

    private function get_available_ai_providers() {
        return [
            'gemini' => count( $this->get_api_key_pool( false ) ),
            'grok'      => count( $this->get_grok_api_keys() ),
            'groqcloud' => count( $this->get_groqcloud_api_keys() ),
            'zai'       => count( $this->get_zai_api_keys() ),
            'openrouter'=> count( $this->get_openrouter_api_keys() ),
        ];
    }

    public static function supported_models() {
        return [
            'gemini-2.5-flash' => 'Gemini 2.5 Flash — default stabil, cepat, cocok untuk artikel harian',
            'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash-Lite — lebih ringan dan ekonomis',
            'gemini-2.5-pro' => 'Gemini 2.5 Pro — reasoning lebih kuat untuk artikel panjang/kompleks',
            'gemini-3.1-flash-lite-preview' => 'Gemini 3.1 Flash-Lite Preview — preview, cepat dan ringan',
        ];
    }





    public function sanitize_fallback_models_textarea( $value ) {
        $value = is_string( $value ) ? wp_unslash( $value ) : '';
        $rows = preg_split( '/\r\n|\r|\n|,/', $value );
        $supported = array_keys( self::supported_models() );
        $clean = [];
        foreach ( $rows as $row ) {
            $model = $this->normalize_model_name( $row );
            if ( in_array( $model, $supported, true ) && ! in_array( $model, $clean, true ) ) {
                $clean[] = $model;
            }
        }
        return implode( "\n", $clean );
    }

    private function get_gemini_model_chain( $primary_model = '' ) {
        $primary = $this->normalize_model_name( $primary_model ?: get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        $raw = get_option( self::OPTION_GEMINI_FALLBACK_MODELS, "gemini-2.5-flash-lite\ngemini-2.5-pro" );
        $rows = preg_split( '/\r\n|\r|\n|,/', (string) $raw );
        $chain = [ $primary ];
        foreach ( $rows as $row ) {
            $model = $this->normalize_model_name( $row );
            if ( $model && ! in_array( $model, $chain, true ) ) { $chain[] = $model; }
        }
        return $chain;
    }

    private function build_gemini_payload( $model, $system_prompt, $user_text, $schema, $use_search ) {
        if ( $use_search ) {
            $json_contract = "\n\nFORMAT OUTPUT WAJIB:\n" .
                "Balas HANYA dengan JSON object valid tanpa markdown, tanpa ```json, tanpa teks tambahan. " .
                "JSON harus mengikuti schema ini secara ketat:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            return [
                'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt . $json_contract ] ] ],
                'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
                'tools'             => [ [ 'google_search' => new stdClass() ] ],
            ];
        }
        return [
            'systemInstruction' => [ 'parts' => [ [ 'text' => $system_prompt ] ] ],
            'contents'          => [ [ 'parts' => [ [ 'text' => $user_text ] ] ] ],
            'generationConfig'  => [
                'responseMimeType' => 'application/json',
                'responseSchema'   => $schema,
            ],
        ];
    }

    public static function builtin_prompt( $key ) {
        $prompts = [
            'default' => <<<'HEAJ_PROMPT_DEFAULT'
{
  "role": "Asisten Jurnalistik Profesional untuk media/website pengguna",
  "task": "Menulis ulang artikel berita secara SANGAT AKURAT berdasarkan sumber (link atau teks) yang diberikan pengguna dengan menerapkan prinsip Piramida Terbalik.",
  
  "input": { 
    "source": "[Diberikan pengguna: URL, teks, atau transkrip video]" 
  },
  
  "strict_accuracy_rules": {
    "rule_1": "Bila berupa URL, WAJIB gunakan alat pencari untuk MEMBACA ISI TAUTAN tersebut secara langsung.",
    "rule_2": "DILARANG KERAS berhalusinasi, menambahkan opini, cerita, nama tokoh, atau kejadian yang tidak terdapat dalam sumber asli. Fokus pada parafrase fakta.",
    "rule_3": "Tulis ulang HANYA berdasarkan data mutlak dari input."
  },

  "journalistic_structure": {
    "principle": "Piramida Terbalik (Inverted Pyramid)",
    "description": "Susun berita dari informasi paling penting di bagian atas hingga informasi paling tidak penting di bagian bawah.",
    "structure_order": [
      {
        "section": "Headline",
        "position": "Paling atas",
        "rules": [
          "Singkat (maksimal 60 karakter)",
          "Padat, jelas, dan menarik",
          "Mengandung unsur utama (biasanya What + Who)",
          "Gunakan kata kerja aktif dan kuat"
        ]
      },
      {
        "section": "Lead (Teras Berita)",
        "position": "Paragraf pertama",
        "rules": [
          "Langsung menyampaikan inti berita (What, Who, Where, When)",
          "Maksimal 35 kata",
          "Format: [NAMA MEDIA], [KOTA] - [Inti berita]. [Hari,] (DD/MM/YYYY)",
          "Harus bisa berdiri sendiri sebagai ringkasan utama"
        ]
      },
      {
        "section": "Body",
        "position": "Isi utama",
        "inverted_pyramid_rule": "Susun dari yang paling penting ke yang kurang penting",
        "paragraph_order": [
          "Paragraf 2: Detail utama (kondisi, jumlah, dampak langsung, penanganan)",
          "Paragraf 3: Kronologi kejadian secara urut",
          "Paragraf 4: Kutipan narasumber resmi",
          "Paragraf 5 dst: Data pendukung, latar belakang, informasi tambahan"
        ]
      },
      {
        "section": "Tail (Penutup)",
        "position": "Paling bawah",
        "rules": [
          "Berisi informasi pelengkap yang tidak krusial",
          "Bisa berupa imbauan, rencana tindak lanjut, atau fakta tambahan",
          "Boleh dipotong oleh editor tanpa merusak inti berita"
        ]
      }
    ]
  },

  "writing_goals": {
    "language": "Bahasa Indonesia",
    "style": "Jurnalistik profesional, lugas, jelas, dan to the point",
    "tone": "Netral, profesional, tanpa clickbait atau sensasionalisme",
    "uniqueness": "Parafrase narasi dengan susunan kalimat baru dan gaya sendiri agar tidak duplikasi konten. HANYA menggunakan informasi dari referensi, 100% bebas halusinasi.",
    "voice": "Aktif; hindari kalimat pasif",
    "length_rule": "Ikuti kelengkapan fakta sumber, tetapi tulis ulang narasi dengan struktur dan kalimat baru"
  },

  "article_structure": {
    "headline": { 
      "max_length": 60, 
      "requirement": "SEO-friendly, informatif, sangat relevan dengan inti sumber" 
    },
    "lead": {
      "max_words": 35,
      "format": "[NAMA MEDIA], [KOTA ASAL KEJADIAN DARI SUMBER] - [kalimat SPOK]. (DD/MM/YYYY)",
      "note": "KOTA dan TANGGAL wajib diambil tepat seperti di sumber"
    },
    "body": {
      "use_headings": "Gunakan heading (H2, H3) jika sesuai untuk memecah teks",
      "quotes": {
        "format": "\"[KUTIPAN AKURAT SAMA PERSIS DENGAN SUMBER MENTAH]\" ujar [NAMA LENGKAP] ([JABATAN]) di [LOKASI], [HARI/TANGGAL]."
      },
      "dates_times": "Pertahankan waktu dan tanggal persis seperti di sumber, JANGAN MENGARANG."
    },
    "footer": { 
      "references": "Sertakan link sumber referensi asli" 
    }
  },

  "seo_requirements": {
    "slug": "Buat 3 opsi slug SEO-friendly singkat",
    "meta_description": "Buat 3-5 opsi meta deskripsi (maks 160 karakter)",
    "tags": "Minimal 10 tag relevan (tanpa tanda #) huruf kecil semua",
    "category": "Tentukan kategori / label yang relevan"
  },

  "final_instruction": "Selalu terapkan prinsip Piramida Terbalik secara ketat: letakkan informasi paling penting di Lead dan awal Body, kemudian susun secara menurun pentingnya hingga Tail."
}
HEAJ_PROMPT_DEFAULT,
            'straight_news' => <<<'HEAJ_PROMPT_STRAIGHT'
{
  "role": "Professional Journalist & SEO Content Writer",
  "task": "Tulis ulang artikel berita menjadi Straight News yang SANGAT AKURAT berdasarkan tautan/sumber.",
  "strict_accuracy_rules": { 
    "rule_1": "DILARANG KERAS menambahkan fakta, cerita, tokoh, atau spekulasi baru. Hanya gunakan informasi murni yang ada di dalam referensi.",
    "rule_2": "Gunakan alat pencarian HANYA untuk mengekstrak isi teks sebenarnya dari URL yang diberikan pengguna."
  },
  "writing_goals": {
    "language_style": "Jurnalistik + Santai",
    "tone": "Netral, Objektif, Seimbang",
    "plagiarism": "100% unik dengan parafrase, tetapi TANPA mengubah esensi fakta",
    "fact_policy": "Fakta 100% WAJIB HANYA berasal dari sumber."
  },
  "journalistic_standards": {
    "mandatory_elements_lead": "lead [3W+1H maks 160 word]",
    "mandatory_elements_content": "content [5W+1H]",
    "structure": "Piramida Terbalik",
    "accuracy": "Semua fakta harus sesuai dengan sumbernya."
  },
  "article_structure": {
    "title": { "rules": ["Menarik dan informatif", "Mencerminkan isi nyata berita"] },
    "meta_description": { "max_length": 160, "rules": ["Standar jurnalistik", "Berisi intisari berita"] },
    "content": {
      "min_word_count": 350,
      "sections": ["Lead (ringkasan inti berita standar jurnalistik)", "Detail peristiwa murni dari sumber", "Kronologi peristiwa jika ada di sumber", "Dampak pihak terkait", "Gunakan <h2>/<h3> untuk subtopik penting", "Gunakan <ul><li> jika ada poin penting", "Gunakan <blockquote> untuk kutipan", "<strong> untuk kata penting"],
      "writing_style_rules": ["Gunakan bahasa santai namun profesional.", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan", "Transisi halus"]
    }
  },
  "output_format": [
    "TITLE:", 
    "SLUG: Buat 3 opsi slug",
    "META DESCRIPTION: Buat 3-5 opsi meta",
    "ARTICLE CONTENT:",
    "BUAT 10 TAG SESUAI DENGAN ARTIKEL (koma, tanpa #, huruf kecil)",
    "category: Tentukan kategori"
  ]
}
HEAJ_PROMPT_STRAIGHT,
            'jurnalis_heading' => <<<'HEAJ_PROMPT_REWRITE'
{ "role": "Jurnalis Profesional & SEO Content Writer", "task": "Menulis ulang artikel berita dengan SANGAT AKURAT sesuai link sumber yang diberikan", "strict_accuracy_rules": { "rule_1": "Bila berupa URL, gunakan tool untuk ekstraksi teks halaman tersebut", "rule_2": "JANGAN PERNAH menyertakan data, kejadian, opini, atau waktu yang tidak tercantum di dalam teks sumber" }, "writing_goals": { "language_style": "Santai", "tone": "Netral, Objektif", "fact_policy": "100% FAKTA DARI SUMBER ASLI, DILARANG MENGARANG" }, "journalistic_standards": { "mandatory_elements_lead": "lead [3W+1H maks 160 word]", "mandatory_elements_content": "content [5W+1H]", "structure": "Piramida Terbalik", "accuracy": "Semua fakta wajib sama persis dengan sumber" }, "article_structure": { "title": { "rules": ["Menarik", "Tidak clickbait", "Sesuai sumber"] }, "meta_description": { "max_length": 160, "rules": ["Intisari berita"] }, "content": { "min_word_count": 800, "sections": ["H2: Topik utama", "H3: Penjelasan detail", "Lead", "Detail peristiwa", "Kronologi (jika ada di sumber)", "Buat blockquote Pernyataan narasumber", "Bold keyword", "Bullet list bila relevan"], "writing_style_rules": ["Bahasa santai profesional", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan"] } } }
HEAJ_PROMPT_REWRITE,
            'seo_artikel' => <<<'HEAJ_PROMPT_SEO'
{ "role": "SEO Content Writer Professional", "goal": "Membuat artikel SEO SANGAT AKURAT dari referensi pengguna", "strict_accuracy_rules": { "rule_1": "Wajib mendasarkan seluruh konten murni pada fakta di teks/URL referensi", "rule_2": "Dilarang keras berhalusinasi atau menambahkan konteks luar" }, "general_criteria": { "minimum_word_count": 1000, "language": "Bahasa Indonesia", "writing_style": "Casual / Santai", "tone": "Informatif + Solutif", "readability": "Mudah dipahami", "seo_requirements": ["SEO-friendly", "Gunakan active voice"] }, "article_structure": { "title": { "format": "H1", "requirements": ["Mengandung keyword", "SEO optimized"] }, "meta_description": { "max_length": 160, "requirements": ["Mengandung keyword", "Relevan"] }, "introduction": { "paragraphs": "2-3 paragraphs", "requirements": ["Gaya santai", "Menarik"] }, "main_content": { "heading_structure": { "H2": "Topik utama", "H3": "Penjelasan detail" }, "mandatory_elements": ["Penjelasan mendalam murni dari sumber", "Gunakan heading H2/H3", "Gunakan bullet point", "Gunakan bold/blockquote bila relevan", "Bahas sesuai fakta referensi semata"] }, "faq_section": { "minimum_questions": 5, "format": "Tanya jawab", "requirements": ["Pertanyaan relevan dengan konten", "Jawaban akurat"] }, "conclusion": { "requirements": ["Ringkas isi artikel"] } } }
HEAJ_PROMPT_SEO,
        ];
        return isset( $prompts[ $key ] ) ? $prompts[ $key ] : '';
    }

    public static function default_brand_settings() {
        return [
            'brand_name'       => 'YZG AI Journalist',
            'media_name'       => '',
            'organization'     => '',
            'logo_url'         => '',
            'primary_color'    => '#0f172a',
            'developer_name'   => 'YanuarZG',
            'developer_url'    => 'https://yanuarzg.github.io/',
            'copyright_text'   => 'Hak Cipta © 2026 YanuarZG',
            'warning_text'     => '',
            'brand_voice'      => 'Jurnalistik profesional, netral, faktual, dan mudah dipahami.',
            'forbidden_words'  => '',
            'default_city'     => '',
            'footer_style'     => 'media',
            'seo_style'        => 'news',
            'license_type'     => 'auto',
            'authors_source'   => 'manual',
            'social_image_engine'              => 'gemini',
            'social_image_model'               => 'gemini-3.1-flash-image',
            'social_image_size'                => '2K',
            'social_template_instagram_url'    => '',
            'social_template_pinterest_url'    => '',
            'social_template_linkedin_url'     => '',
            'social_image_prompt_extra'        => '',
        ];
    }

    private function get_brand_settings() {
        $settings = $this->get_custom_settings();
        $brand = isset( $settings['branding'] ) && is_array( $settings['branding'] ) ? $settings['branding'] : [];
        return array_merge( self::default_brand_settings(), $brand );
    }

    private function get_media_name() {
        $brand = $this->get_brand_settings();
        $name = trim( (string) ( $brand['media_name'] ?: $brand['organization'] ?: get_bloginfo( 'name' ) ) );
        return $name !== '' ? $name : ( wp_parse_url( home_url(), PHP_URL_HOST ) ?: 'Website' );
    }

    private function get_plugin_brand_name() {
        $brand = $this->get_brand_settings();
        return trim( (string) ( $brand['brand_name'] ?: 'YZG AI Journalist' ) );
    }

    private function get_brand_instruction() {
        $brand = $this->get_brand_settings();
        $parts = [];
        $parts[] = 'Nama media/website: ' . $this->get_media_name();
        if ( ! empty( $brand['organization'] ) ) { $parts[] = 'Organisasi/redaksi: ' . $brand['organization']; }
        if ( ! empty( $brand['brand_voice'] ) ) { $parts[] = 'Brand voice: ' . $brand['brand_voice']; }
        if ( ! empty( $brand['default_city'] ) ) { $parts[] = 'Kota default jika relevan dan ada di sumber: ' . $brand['default_city']; }
        if ( ! empty( $brand['seo_style'] ) ) { $parts[] = 'Gaya SEO: ' . $brand['seo_style']; }
        if ( ! empty( $brand['footer_style'] ) ) { $parts[] = 'Gaya penutup/footer artikel: ' . $brand['footer_style']; }
        if ( ! empty( $brand['forbidden_words'] ) ) { $parts[] = 'Hindari kata/frasa: ' . $brand['forbidden_words']; }
        return implode( "\n", $parts );
    }

    private function get_author_editor_names( $type = 'authors' ) {
        $settings = $this->get_custom_settings();
        $brand = $this->get_brand_settings();
        $manual = isset( $settings[ $type ] ) && is_array( $settings[ $type ] ) ? $settings[ $type ] : [];
        $source = $brand['authors_source'] ?? 'manual';
        $wp_names = [];
        if ( in_array( $source, [ 'wp_users', 'both' ], true ) ) {
            $wp_names = $this->get_author_editor_names_from_wp( $type );
        }
        if ( $source === 'wp_users' ) { return array_values( array_unique( $wp_names ) ); }
        if ( $source === 'both' ) { return array_values( array_unique( array_merge( $manual, $wp_names ) ) ); }
        return array_values( array_unique( $manual ) );
    }

    private function is_network_directory_enabled() {
        $brand = $this->get_brand_settings();
        $mode = $brand['license_type'] ?? 'auto';
        if ( $mode === 'harianexpress_network' || $mode === 'agency' ) { return true; }
        if ( $mode === 'single_site' ) { return false; }
        return $this->is_harianexpress_com_domain();
    }

    public static function default_custom_settings() {
        return [
            'prompts' => [
                [ 'key' => 'default', 'label' => 'Standar Jurnalistik', 'prompt' => self::builtin_prompt( 'default' ) ],
                [ 'key' => 'straight_news', 'label' => 'Straight News', 'prompt' => self::builtin_prompt( 'straight_news' ) ],
                [ 'key' => 'jurnalis_heading', 'label' => 'Rewrite Artikel', 'prompt' => self::builtin_prompt( 'jurnalis_heading' ) ],
                [ 'key' => 'seo_artikel', 'label' => 'Target SEO Page 1', 'prompt' => self::builtin_prompt( 'seo_artikel' ) ],
            ],
            'lengths' => [
                [ 'label' => 'Sesuai prompt', 'value' => '' ],
                [ 'label' => 'Pendek (300-500)', 'value' => 'minimal 300 kata - maksimal 500 kata' ],
                [ 'label' => 'Sedang (500-1000)', 'value' => 'minimal 500 kata - maksimal 1000 kata' ],
                [ 'label' => 'Panjang (1000+)', 'value' => 'minimal 1000 kata' ],
            ],
            'languages' => [
                [ 'code' => 'id', 'label' => 'Indonesia', 'instruction' => 'Tulis output dalam Bahasa Indonesia.' ],
                [ 'code' => 'en', 'label' => 'English', 'instruction' => 'Write the output in English.' ],
            ],
            'branding' => self::default_brand_settings(),
            'global_prompt' => '',
            'authors' => [ 'Achmad Fauzan', 'Ajeng Mietaswary Annisa', 'Cavin Juliansyah', 'Findy Alfiansyah', 'Heri Purwadyo', 'Ipnu Subroto', 'Muklis Purwanto', 'Ridwan Habibie', 'Yanuar Zhaldy G' ],
            'editors' => [ 'Achmad Fauzan', 'Findy Alfiansyah', 'Ipnu Subroto', 'Muklis Purwanto', 'Ridwan Habibie', 'Yanuar Zhaldy G' ],
        ];
    }

    private function normalize_default_article_lengths( $lengths ) {
        if ( ! is_array( $lengths ) || empty( $lengths ) ) {
            return self::default_custom_settings()['lengths'];
        }

        $labels = array_map(
            static function( $row ) {
                return is_array( $row ) ? sanitize_text_field( $row['label'] ?? '' ) : '';
            },
            $lengths
        );

        $joined = implode( '|', $labels );

        // Migrate the old built-in length set:
        // Sesuai prompt, Pendek (300-500), Sedang (1000+), Panjang (1500+)
        // into the new requested set, without overriding truly custom length lists.
        if (
            in_array( 'Sesuai prompt', $labels, true )
            && in_array( 'Pendek (300-500)', $labels, true )
            && in_array( 'Sedang (1000+)', $labels, true )
            && in_array( 'Panjang (1500+)', $labels, true )
            && count( $labels ) === 4
        ) {
            return self::default_custom_settings()['lengths'];
        }

        return $lengths;
    }

    public function sanitize_custom_settings( $value ) {
        if ( is_string( $value ) ) {
            $decoded = json_decode( wp_unslash( $value ), true );
            $value = is_array( $decoded ) ? $decoded : [];
        }
        if ( ! is_array( $value ) ) { $value = []; }
        $defaults = self::default_custom_settings();
        $clean = [ 'prompts' => [], 'lengths' => [], 'languages' => [], 'authors' => [], 'editors' => [], 'branding' => self::default_brand_settings(), 'global_prompt' => '' ];

        if ( isset( $value['prompts'] ) && is_array( $value['prompts'] ) ) {
            foreach ( $value['prompts'] as $row ) {
                if ( ! is_array( $row ) ) { continue; }
                $label = sanitize_text_field( $row['label'] ?? '' );
                $key = sanitize_key( $row['key'] ?? '' );
                $prompt = sanitize_textarea_field( $row['prompt'] ?? '' );
                if ( $label === '' ) { continue; }
                if ( $key === '' ) { $key = 'custom_' . substr( md5( $label ), 0, 10 ); }
                // Backward compatibility: exported JSON from v3.3.11 stored built-in prompts as blank.
                // Refill built-in prompts so import/export never makes default generators empty.
                if ( $prompt === '' && in_array( $key, [ 'default', 'straight_news', 'jurnalis_heading', 'seo_artikel' ], true ) ) {
                    $prompt = self::builtin_prompt( $key );
                }
                $clean['prompts'][] = [ 'key' => $key, 'label' => $label, 'prompt' => $prompt ];
            }
        }
        if ( isset( $value['lengths'] ) && is_array( $value['lengths'] ) ) {
            foreach ( $value['lengths'] as $row ) {
                if ( ! is_array( $row ) ) { continue; }
                $label = sanitize_text_field( $row['label'] ?? '' );
                $val = sanitize_text_field( $row['value'] ?? '' );
                if ( $label !== '' ) { $clean['lengths'][] = [ 'label' => $label, 'value' => $val ]; }
            }
        }
        $clean['lengths'] = $this->normalize_default_article_lengths( $clean['lengths'] );
        if ( isset( $value['languages'] ) && is_array( $value['languages'] ) ) {
            foreach ( $value['languages'] as $row ) {
                if ( ! is_array( $row ) ) { continue; }
                $code = sanitize_key( $row['code'] ?? '' );
                $label = sanitize_text_field( $row['label'] ?? '' );
                $instruction = sanitize_text_field( $row['instruction'] ?? '' );
                if ( $code !== '' && $label !== '' ) { $clean['languages'][] = [ 'code' => $code, 'label' => $label, 'instruction' => $instruction ]; }
            }
        }
        if ( isset( $value['branding'] ) && is_array( $value['branding'] ) ) {
            $bd = array_merge( self::default_brand_settings(), $value['branding'] );
            $clean['branding'] = [
                'brand_name'       => sanitize_text_field( $bd['brand_name'] ?? '' ),
                'media_name'       => sanitize_text_field( $bd['media_name'] ?? '' ),
                'organization'     => sanitize_text_field( $bd['organization'] ?? '' ),
                'logo_url'         => esc_url_raw( $bd['logo_url'] ?? '' ),
                'primary_color'    => sanitize_hex_color( $bd['primary_color'] ?? '#0f172a' ) ?: '#0f172a',
                'developer_name'   => sanitize_text_field( $bd['developer_name'] ?? '' ),
                'developer_url'    => esc_url_raw( $bd['developer_url'] ?? '' ),
                'copyright_text'   => sanitize_text_field( $bd['copyright_text'] ?? '' ),
                'warning_text'     => sanitize_textarea_field( $bd['warning_text'] ?? '' ),
                'brand_voice'      => sanitize_textarea_field( $bd['brand_voice'] ?? '' ),
                'forbidden_words'  => sanitize_textarea_field( $bd['forbidden_words'] ?? '' ),
                'default_city'     => sanitize_text_field( $bd['default_city'] ?? '' ),
                'footer_style'     => sanitize_key( $bd['footer_style'] ?? 'media' ),
                'seo_style'        => sanitize_key( $bd['seo_style'] ?? 'news' ),
                'license_type'     => sanitize_key( $bd['license_type'] ?? 'auto' ),
                'authors_source'   => sanitize_key( $bd['authors_source'] ?? 'manual' ),
                'social_image_engine'           => sanitize_key( $bd['social_image_engine'] ?? 'gemini' ),
                'social_image_model'            => sanitize_text_field( $bd['social_image_model'] ?? 'gemini-3.1-flash-image' ),
                'social_image_size'             => sanitize_text_field( $bd['social_image_size'] ?? '2K' ),
                'social_template_instagram_url' => esc_url_raw( $bd['social_template_instagram_url'] ?? '' ),
                'social_template_pinterest_url' => esc_url_raw( $bd['social_template_pinterest_url'] ?? '' ),
                'social_template_linkedin_url'  => esc_url_raw( $bd['social_template_linkedin_url'] ?? '' ),
                'social_image_prompt_extra'     => sanitize_textarea_field( $bd['social_image_prompt_extra'] ?? '' ),
            ];
        }
        $clean['global_prompt'] = sanitize_textarea_field( $value['global_prompt'] ?? '' );

        foreach ( [ 'authors', 'editors' ] as $key ) {
            $names_source = $value[ $key ] ?? [];
            if ( is_string( $names_source ) ) {
                $names_source = preg_split( '/\r?\n/', wp_unslash( $names_source ) );
            }
            if ( is_array( $names_source ) ) {
                foreach ( $names_source as $name ) {
                    $name = sanitize_text_field( $name );
                    if ( $name !== '' && ! in_array( $name, $clean[ $key ], true ) ) { $clean[ $key ][] = $name; }
                }
            }
        }
        foreach ( $clean as $key => $rows ) {
            if ( empty( $rows ) && isset( $defaults[ $key ] ) ) { $clean[ $key ] = $defaults[ $key ]; }
        }
        return $clean;
    }

    private function get_custom_settings() {
        $settings = get_option( self::OPTION_CUSTOM_SETTINGS, self::default_custom_settings() );
        return $this->sanitize_custom_settings( is_array( $settings ) ? $settings : [] );
    }

    public function sanitize_pexels_api_key( $value ) {
        return sanitize_text_field( trim( (string) $value ) );
    }


    public static function maybe_schedule_cleanup_history() {
        if ( ! wp_next_scheduled( 'he_journalist_cleanup_history' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'he_journalist_cleanup_history' );
        }
    }

    public static function cleanup_history() {
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { return; }
        $cutoff = time() - ( 30 * DAY_IN_SECONDS );
        $clean = [];
        foreach ( $history as $item ) {
            if ( ! is_array( $item ) ) { continue; }
            $time = isset( $item['time'] ) ? strtotime( (string) $item['time'] ) : 0;
            if ( ! $time || $time >= $cutoff ) { $clean[] = $item; }
        }
        $clean = array_slice( $clean, 0, 150 );
        update_option( self::OPTION_HISTORY, $clean, false );
    }

    private function sanitize_ai_json_value( $value, $key = '' ) {
        if ( is_array( $value ) ) {
            $clean = [];
            foreach ( $value as $k => $v ) {
                $clean_key = is_string( $k ) ? sanitize_key( $k ) : $k;
                $clean[ $clean_key ] = $this->sanitize_ai_json_value( $v, is_string( $k ) ? $k : $key );
            }
            return $clean;
        }
        if ( is_string( $value ) ) {
            $key = strtolower( (string) $key );
            if ( in_array( $key, [ 'references', 'source_url', 'source_urls', 'url', 'image', 'imageurl' ], true ) ) {
                return esc_url_raw( $value );
            }
            if ( in_array( $key, [ 'articlebody', 'article_body', 'content', 'html' ], true ) ) {
                return wp_kses_post( $value );
            }
            return sanitize_text_field( $value );
        }
        if ( is_bool( $value ) || is_numeric( $value ) || null === $value ) { return $value; }
        return '';
    }

    private function sanitize_ai_json_result( $result, $schema = [] ) {
        if ( ! is_array( $result ) ) { return []; }
        $clean = [];
        foreach ( $result as $key => $value ) {
            $clean_key = sanitize_key( (string) $key );
            if ( $clean_key === '' ) { continue; }
            $clean[ $clean_key ] = $this->sanitize_ai_json_value( $value, $key );
        }
        // Preserve expected camelCase keys used by the frontend while still sanitizing values.
        $expected = [ 'titleOptions', 'slugOptions', 'metaDescriptions', 'category', 'tags', 'articleBody', 'references', 'twitterThread', 'igFbCaption', 'takeaways', 'visualCues', 'hook', 'body', 'cta', 'imageKeywords' ];
        foreach ( $expected as $key ) {
            if ( array_key_exists( $key, $result ) ) {
                $clean[ $key ] = $this->sanitize_ai_json_value( $result[ $key ], $key );
            }
        }
        return $clean;
    }

    private function gemini_cache_key( $model, $system_prompt, $user_text, $schema, $use_search ) {
        return 'heaj_gem_' . md5( wp_json_encode( [ $model, $system_prompt, $user_text, $schema, (bool) $use_search ] ) );
    }

    public function handle_reset_custom_settings() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_reset_custom_settings' );
        update_option( self::OPTION_CUSTOM_SETTINGS, self::default_custom_settings(), false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-custom-settings', 'heaj-custom-reset' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_clear_generate_history() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_clear_generate_history' );
        update_option( self::OPTION_HISTORY, [], false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-custom-settings', 'heaj-history-cleared' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    public function handle_delete_generate_history() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        $id = isset( $_GET['id'] ) ? sanitize_key( wp_unslash( $_GET['id'] ) ) : '';
        check_admin_referer( 'heaj_delete_generate_history_' . $id );
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( is_array( $history ) && $id !== '' ) {
            $history = array_values( array_filter( $history, function( $item ) use ( $id ) {
                return ! ( is_array( $item ) && isset( $item['id'] ) && $item['id'] === $id );
            } ) );
            update_option( self::OPTION_HISTORY, $history, false );
        }
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-history', 'heaj-deleted' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    public static function editor_admin_capability() {
        return 'edit_others_posts';
    }

    public function allow_editor_admin_option_page( $capability ) {
        return self::editor_admin_capability();
    }

    public function allow_auto_news_source_footer_html( $tags, $context ) {
        if ( $context === 'post' ) {
            $tags['details'] = [
                'class' => true,
                'open'  => true,
            ];
            $tags['summary'] = [
                'class' => true,
            ];
            if ( empty( $tags['ol'] ) || ! is_array( $tags['ol'] ) ) { $tags['ol'] = []; }
            if ( empty( $tags['li'] ) || ! is_array( $tags['li'] ) ) { $tags['li'] = []; }
            $tags['ol']['class'] = true;
            $tags['ol']['style'] = true;
            $tags['li']['class'] = true;
            $tags['li']['style'] = true;
        }
        return $tags;
    }

    public function sanitize_api_keys_textarea( $value ) {
        $value = is_string( $value ) ? wp_unslash( $value ) : '';
        $lines = preg_split( '/\r\n|\r|\n/', $value );
        $keys = [];
        $seen = [];
        foreach ( $lines as $line ) {
            $key = trim( $line );
            if ( $key === '' ) { continue; }
            $key = sanitize_text_field( $key );
            $hash = hash_hmac( 'sha256', $key, wp_salt( 'auth' ) );
            if ( isset( $seen[ $hash ] ) ) { continue; }
            $seen[ $hash ] = true;
            $keys[] = $key;
        }
        return implode( "\n", $keys );
    }



    public function sanitize_prompt_overrides( $value ) {
        $value = is_array( $value ) ? $value : [];
        $allowed = [ 'default', 'straight_news', 'jurnalis_heading', 'seo_artikel', 'global' ];
        $clean = [];
        foreach ( $allowed as $key ) {
            $raw = isset( $value[ $key ] ) ? wp_unslash( $value[ $key ] ) : '';
            $raw = is_string( $raw ) ? trim( $raw ) : '';
            if ( $raw !== '' ) {
                $clean[ $key ] = sanitize_textarea_field( $raw );
            }
        }
        return $clean;
    }

    private function get_prompt_overrides() {
        $value = get_option( self::OPTION_PROMPT_OVERRIDES, [] );
        return is_array( $value ) ? $value : [];
    }

    private function add_history_event( array $event ) {
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { $history = []; }
        $defaults = [
            'time'       => current_time( 'mysql' ),
            'user_id'    => get_current_user_id(),
            'user'       => wp_get_current_user()->display_name ?: wp_get_current_user()->user_login,
            'domain'     => wp_parse_url( home_url(), PHP_URL_HOST ),
            'id'         => 'heh_' . wp_generate_uuid4(),
            'title'      => '',
            'source_url' => '',
            'source_urls'=> [],
            'draft_status' => 'not_sent',
            'provider'   => '',
            'status'     => 'generated',
            'post_id'    => 0,
            'edit_url'   => '',
            'title_index' => 0,
            'slug_index' => 0,
            'meta_index' => 0,
            'image_source' => '',
            'selected_image_url' => '',
        ];
        $event = array_merge( $defaults, $event );
        $event['id'] = sanitize_key( $event['id'] );
        $event['title'] = sanitize_text_field( $event['title'] );
        $event['source_url'] = esc_url_raw( $event['source_url'] );
        $event['source_urls'] = isset( $event['source_urls'] ) && is_array( $event['source_urls'] ) ? array_values( array_unique( array_filter( array_map( 'esc_url_raw', $event['source_urls'] ) ) ) ) : [];
        $event['draft_status'] = sanitize_key( $event['draft_status'] );
        $event['provider'] = sanitize_text_field( $event['provider'] );
        $event['status'] = sanitize_text_field( $event['status'] );
        $event['post_id'] = absint( $event['post_id'] );
        $event['edit_url'] = esc_url_raw( $event['edit_url'] );
        $event['title_index'] = absint( $event['title_index'] ?? 0 );
        $event['slug_index'] = absint( $event['slug_index'] ?? 0 );
        $event['meta_index'] = absint( $event['meta_index'] ?? 0 );
        $event['image_source'] = sanitize_text_field( $event['image_source'] ?? '' );
        $event['selected_image_url'] = esc_url_raw( $event['selected_image_url'] ?? '' );
        foreach ( [ 'source_input', 'prompt_style', 'prompt_label', 'language', 'image_source', 'model_used' ] as $field ) {
            if ( isset( $event[ $field ] ) ) { $event[ $field ] = sanitize_text_field( $event[ $field ] ); }
        }
        if ( isset( $event['cached'] ) ) { $event['cached'] = (bool) $event['cached']; }
        array_unshift( $history, $event );
        $history = array_slice( $history, 0, 150 );
        update_option( self::OPTION_HISTORY, $history, false );
        return $event['id'];
    }

    private function update_history_generated_to_draft( $history_id, $post_id, $edit_url ) {
        $history_id = sanitize_key( $history_id );
        if ( ! $history_id ) { return; }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { return; }
        foreach ( $history as &$item ) {
            if ( isset( $item['id'] ) && $item['id'] === $history_id ) {
                $item['draft_status'] = 'sent';
                $item['linked_post_id'] = absint( $post_id );
                $item['linked_edit_url'] = esc_url_raw( $edit_url );
                break;
            }
        }
        unset( $item );
        update_option( self::OPTION_HISTORY, $history, false );
    }

    public function handle_check_updates_now() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_check_updates_now' );
        delete_site_transient( 'update_plugins' );
        wp_clean_plugins_cache( true );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-settings', 'heaj-update-check' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    private function get_extra_api_keys() {
        $raw = get_option( self::OPTION_EXTRA_API_KEYS, '' );
        if ( ! is_string( $raw ) || trim( $raw ) === '' ) { return []; }
        return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) );
    }

    private function api_key_hash( $key ) {
        return hash_hmac( 'sha256', (string) $key, wp_salt( 'auth' ) );
    }

    private function get_blocked_api_keys() {
        $blocked = get_option( self::OPTION_BLOCKED_API_KEYS, [] );
        return is_array( $blocked ) ? $blocked : [];
    }

    private function is_api_key_blocked( $key ) {
        $hash = $this->api_key_hash( $key );
        $blocked = $this->get_blocked_api_keys();
        return isset( $blocked[ $hash ] );
    }

    private function block_api_key( $key, $reason = '' ) {
        $key = trim( (string) $key );
        if ( $key === '' ) { return; }
        $hash = $this->api_key_hash( $key );
        $blocked = $this->get_blocked_api_keys();
        $blocked[ $hash ] = [
            'masked'     => $this->mask_api_key( $key ),
            'reason'     => sanitize_text_field( $reason ?: 'API key ditolak permanen oleh provider AI.' ),
            'blocked_at' => current_time( 'mysql' ),
        ];
        update_option( self::OPTION_BLOCKED_API_KEYS, $blocked, false );
    }

    private function rotate_api_key_pool( $provider, array $pool, $include_blocked = false ) {
        if ( $include_blocked || count( $pool ) <= 1 ) { return $pool; }
        $provider = sanitize_key( $provider ?: 'gemini' );
        $rotors = get_option( 'he_journalist_api_key_rotors', [] );
        if ( ! is_array( $rotors ) ) { $rotors = []; }
        $idx = isset( $rotors[ $provider ] ) ? absint( $rotors[ $provider ] ) : 0;
        $idx = $idx % count( $pool );
        $rotated = array_merge( array_slice( $pool, $idx ), array_slice( $pool, 0, $idx ) );
        $rotors[ $provider ] = ( $idx + 1 ) % count( $pool );
        update_option( 'he_journalist_api_key_rotors', $rotors, false );
        return $rotated;
    }

    private function get_api_key_pool( $include_blocked = false ) {
        $manager = new HEAJ_API_Key_Manager( 'gemini', $this->get_blocked_api_keys() );
        return $this->rotate_api_key_pool( 'gemini', $manager->get_pool( $include_blocked ), $include_blocked );
    }

    private function get_provider_key_pool( $provider, $include_blocked = false ) {
        $manager = new HEAJ_API_Key_Manager( $provider, $this->get_blocked_api_keys() );
        return $this->rotate_api_key_pool( $provider, $manager->get_pool( $include_blocked ), $include_blocked );
    }

    private function get_all_api_keys() {
        return array_values( array_map( function( $item ) { return $item['key']; }, $this->get_api_key_pool( false ) ) );
    }

    public function handle_reset_blocked_api_keys() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'heaj_reset_blocked_api_keys' );
        update_option( self::OPTION_BLOCKED_API_KEYS, [], false );
        wp_safe_redirect( add_query_arg( [ 'page' => 'he-journalist-settings', 'heaj-blocked-reset' => '1' ], admin_url( 'admin.php' ) ) );
        exit;
    }


    private function extract_json_from_text( $text ) {
        $text = trim( (string) $text );
        if ( $text === '' ) { return null; }

        $direct = json_decode( $text, true );
        if ( is_array( $direct ) ) { return $direct; }

        if ( preg_match( '/```(?:json)?\s*(\{.*?\})\s*```/s', $text, $matches ) ) {
            $decoded = json_decode( trim( $matches[1] ), true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        $start = strpos( $text, '{' );
        $end   = strrpos( $text, '}' );
        if ( $start !== false && $end !== false && $end > $start ) {
            $candidate = substr( $text, $start, $end - $start + 1 );
            $decoded = json_decode( $candidate, true );
            if ( is_array( $decoded ) ) { return $decoded; }
        }

        return null;
    }


    private function normalize_model_name( $model ) {
        $model = trim( (string) $model );
        $deprecated = [
            '',
            'gemini-2.5-flash-preview-09-2025',
            'models/gemini-2.5-flash-preview-09-2025',
            'gemini-2.0-flash',
            'models/gemini-2.0-flash',
        ];
        if ( in_array( $model, $deprecated, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        $model = preg_replace( '#^models/#', '', $model );
        $model = sanitize_text_field( $model );
        $supported = array_keys( self::supported_models() );
        if ( ! in_array( $model, $supported, true ) ) {
            $model = 'gemini-2.5-flash';
        }
        return $model;
    }


    private function is_retryable_gemini_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) {
            return true;
        }

        $retryable_phrases = [
            'high demand',
            'overloaded',
            'temporarily unavailable',
            'try again later',
            'resource exhausted',
            'quota',
            'rate limit',
            'deadline',
            'timeout',
            'timed out',
            'internal error',
            'service unavailable',
        ];

        foreach ( $retryable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return false;
    }


    private function is_blockable_gemini_api_key_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );

        $blockable_phrases = [
            'api key was reported as leaked',
            'reported as leaked',
            'please use another api key',
            'api key not valid',
            'api_key_invalid',
            'invalid api key',
            'permission_denied',
            'api key expired',
            'api key has expired',
            'api key disabled',
            'key disabled',
        ];

        foreach ( $blockable_phrases as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) {
                return true;
            }
        }

        return in_array( $status, [ 400, 401, 403 ], true ) && false !== strpos( $message, 'api key' );
    }

    private function retry_delay_seconds( $round ) {
        $round = max( 1, (int) $round );
        return min( 8, 2 ** $round );
    }

    private function mask_api_key( $key ) {
        $key = (string) $key;
        if ( strlen( $key ) <= 12 ) { return str_repeat( '•', strlen( $key ) ); }
        return substr( $key, 0, 7 ) . str_repeat( '•', max( 6, strlen( $key ) - 14 ) ) . substr( $key, -7 );
    }


    public function sanitize_model_name( $value ) {
        return $this->normalize_model_name( wp_unslash( $value ) );
    }

    public static function openrouter_model_choices() {
        return [
            'openai/gpt-4o-mini' => 'OpenAI GPT-4o Mini',
            'openai/gpt-4o' => 'OpenAI GPT-4o',
            'google/gemini-2.5-flash' => 'Google Gemini 2.5 Flash',
            'google/gemini-2.5-pro' => 'Google Gemini 2.5 Pro',
            'anthropic/claude-sonnet-4.5' => 'Anthropic Claude Sonnet 4.5',
            'meta-llama/llama-3.3-70b-instruct' => 'Meta Llama 3.3 70B Instruct',
            'qwen/qwen-2.5-72b-instruct' => 'Qwen 2.5 72B Instruct',
            'deepseek/deepseek-chat-v3.1' => 'DeepSeek Chat v3.1',
            'x-ai/grok-4' => 'xAI Grok 4',
        ];
    }

    public function sanitize_openrouter_model( $value ) {
        $value = trim( (string) wp_unslash( $value ) );
        $value = preg_replace( '/[^a-zA-Z0-9_\-\.\/:~]/', '', $value );
        $choices = array_keys( self::openrouter_model_choices() );
        return in_array( $value, $choices, true ) ? $value : 'openai/gpt-4o-mini';
    }

    public function register_settings() {
        register_setting( 'he_journalist_options', self::OPTION_EXTRA_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GROK_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GROQ_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_ZAI_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_OPENROUTER_API_KEYS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_api_keys_textarea' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_OPENROUTER_MODEL, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_openrouter_model' ],
            'default'           => 'openai/gpt-4o-mini',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_PROMPT_OVERRIDES, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_prompt_overrides' ],
            'default'           => [],
        ] );
        register_setting( 'he_journalist_options', self::OPTION_PEXELS_API_KEY, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_pexels_api_key' ],
            'default'           => '',
        ] );
        register_setting( 'he_journalist_custom_options', self::OPTION_CUSTOM_SETTINGS, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_custom_settings' ],
            'default'           => self::default_custom_settings(),
        ] );
        register_setting( 'he_journalist_options', self::OPTION_MODEL, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_model_name' ],
            'default'           => 'gemini-2.5-flash',
        ] );
        register_setting( 'he_journalist_options', self::OPTION_GEMINI_FALLBACK_MODELS, [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_fallback_models_textarea' ],
            'default'           => "gemini-2.5-flash-lite\ngemini-2.5-pro",
        ] );

        $stored_model = get_option( self::OPTION_MODEL, 'gemini-2.5-flash' );
        $fixed_model  = $this->normalize_model_name( $stored_model );
        if ( $stored_model !== $fixed_model ) {
            update_option( self::OPTION_MODEL, $fixed_model );
        }
    }

    public function add_menu() {
        add_menu_page(
            $this->get_plugin_brand_name(),
            $this->get_plugin_brand_name(),
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ],
            'dashicons-edit-large',
            30
        );
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Generator Artikel' ),
            $this->tr_ui( 'Generator Artikel' ),
            'edit_posts',
            'he-journalist',
            [ $this, 'render_generator_page' ]
        );
        add_submenu_page(
            'he-journalist',
            'Auto Artikel',
            'Auto Artikel',
            'edit_posts',
            'he-journalist-auto-news',
            [ $this, 'render_auto_news_page' ]
        );
        if ( $this->is_network_directory_enabled() ) {
            add_submenu_page(
                'he-journalist',
                $this->tr_ui( 'Network Sites' ),
                $this->tr_ui( 'Network Sites' ),
                'edit_posts',
                'he-journalist-subdomains',
                [ $this, 'render_subdomains_page' ]
            );
        }
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Riwayat Generate' ),
            $this->tr_ui( 'Riwayat Generate' ),
            self::editor_admin_capability(),
            'he-journalist-history',
            [ $this, 'render_history_page' ]
        );
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Custom Settings' ),
            $this->tr_ui( 'Custom Settings' ),
            self::editor_admin_capability(),
            'he-journalist-custom-settings',
            [ $this, 'render_custom_settings_page' ]
        );
        add_submenu_page(
            'he-journalist',
            'Lisensi',
            'Lisensi',
            self::editor_admin_capability(),
            'he-journalist-license',
            [ $this, 'render_license_page' ]
        );
        add_submenu_page(
            'he-journalist',
            $this->tr_ui( 'Pengaturan API' ),
            $this->tr_ui( 'Pengaturan API' ),
            self::editor_admin_capability(),
            'he-journalist-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    public function admin_enqueue_assets( $hook ) {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( strpos( $hook, 'he-journalist' ) === false && strpos( $page, 'he-journalist' ) === false ) { return; }

        $this->enqueue_common_assets();

        if ( $page === 'he-journalist' ) {
            $this->enqueue_generator_assets();
        } elseif ( $page === 'he-journalist-subdomains' ) {
            $this->enqueue_subdomains_assets();
        }
    }

    private function enqueue_common_assets() {
        wp_enqueue_script( 'tailwindcss-cdn', 'https://cdn.tailwindcss.com', [], null, false );
        wp_enqueue_style( 'heaj-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Merriweather:wght@400;700&display=swap', [], null );
        wp_enqueue_script( 'lucide-cdn', 'https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js', [], null, true );
        wp_add_inline_script( 'lucide-cdn', $this->admin_language_bridge_script() . "\n" . $this->admin_notice_relocator_script() . "\n" . $this->lucide_icon_bootstrap_script(), 'after' );
        wp_enqueue_style( 'he-journalist-app', $this->plugin_url() . 'assets/css/app.css', [], self::VERSION );
        $brand = $this->get_brand_settings();
        $primary = sanitize_hex_color( $brand['primary_color'] ?? '#0f172a' ) ?: '#0f172a';
        wp_add_inline_style( 'he-journalist-app', ':root{--heaj-primary:' . esc_html( $primary ) . ';}.he-generator-header,.he-settings-hero,.he-history-hero,.he-directory-hero{background:var(--heaj-primary)!important}.he-card-icon,.he-settings-card .he-card-icon{background:color-mix(in srgb,var(--heaj-primary) 12%,#fff)!important;color:var(--heaj-primary)!important}.he-save-button,.button-primary{background:var(--heaj-primary)!important;border-color:var(--heaj-primary)!important}' );
    }

    private function admin_notice_relocator_script() {
        return <<<'JS'
(function(){
  function moveHEAdminNotices(){
    var app = document.querySelector('#heaj-app, #he-subdomains-app, #he-settings-app, #he-history-app, .heaj-settings-page');
    if (!app || !app.parentNode) { return; }

    var wrap = app.closest('.wrap') || app.parentNode;
    var tray = document.getElementById('heaj-admin-notice-tray');
    if (!tray) {
      tray = document.createElement('div');
      tray.id = 'heaj-admin-notice-tray';
      tray.className = 'heaj-admin-notice-tray';
      app.parentNode.insertBefore(tray, app);
    }

    var found = [];
    [app, wrap].forEach(function(root){
      if (!root || !root.querySelectorAll) { return; }
      root.querySelectorAll('.notice, .updated, .error, .update-nag').forEach(function(el){
        if (!el || el === tray || tray.contains(el)) { return; }
        if (el.closest('#heaj-admin-notice-tray')) { return; }
        if (el.id === 'heSubdomainStatus' || el.id === 'toast') { return; }
        if (el.closest('#toast')) { return; }
        found.push(el);
      });
    });

    found.forEach(function(el){
      el.classList.add('heaj-relocated-notice');
      tray.appendChild(el);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', moveHEAdminNotices);
  } else {
    moveHEAdminNotices();
  }
  setTimeout(moveHEAdminNotices, 120);
  setTimeout(moveHEAdminNotices, 700);
  setTimeout(moveHEAdminNotices, 1600);
})();
JS;
    }



    private function lucide_icon_bootstrap_script() {
        return <<<'JS'
(function(){
  function fallbackIcon(el){
    if (!el || el.dataset.heIconFallback === '1') return;
    var name = el.getAttribute('data-lucide') || 'circle';
    var cls = el.getAttribute('class') || '';
    var color = 'currentColor';
    var paths = {
      'shield-check':'<path d="M12 3l7 3v5c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-3z"/><path d="M9 12l2 2 4-5"/>',
      'key-round':'<circle cx="7.5" cy="14.5" r="3.5"/><path d="M10 12l7-7 3 3-2 2 2 2-2 2-2-2-3 3"/>',
      'cpu':'<rect x="7" y="7" width="10" height="10" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M4 9h3M4 15h3M17 9h3M17 15h3M9 4v3M15 4v3M9 17v3M15 17v3"/>',
      'activity':'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
      'key':'<circle cx="7.5" cy="14.5" r="3.5"/><path d="M10 12l8-8 3 3-8 8"/>',
      'external-link':'<path d="M14 3h7v7"/><path d="M10 14L21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/>',
      'network':'<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="3" y="16" width="6" height="6" rx="1"/><rect x="15" y="16" width="6" height="6" rx="1"/><path d="M12 8v4M6 16v-2h12v2"/>',
      'search':'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
      'refresh-cw':'<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/>',
      'plus-circle':'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
      'newspaper':'<path d="M4 5h13a3 3 0 0 1 3 3v11H6a2 2 0 0 1-2-2V5z"/><path d="M8 9h6M8 13h8M8 17h5"/>',
      'clock-3':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
      'tag':'<path d="M20 10l-8 8-8-8V4h6l10 10z"/><circle cx="8" cy="8" r="1"/>',
      'star':'<path d="M12 3l2.7 5.5 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1-4.4-4.3 6.1-.9L12 3z"/>',
      'log-in':'<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/>',
      'layout-dashboard':'<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
      'wand-sparkles':'<path d="M15 4l5 5-11 11-5-5L15 4z"/><path d="M14 5l5 5"/><path d="M5 3v4M3 5h4M19 15v4M17 17h4"/>'
    };
    var svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('xmlns','http://www.w3.org/2000/svg');
    svg.setAttribute('viewBox','0 0 24 24');
    svg.setAttribute('fill','none');
    svg.setAttribute('stroke', color);
    svg.setAttribute('stroke-width','2');
    svg.setAttribute('stroke-linecap','round');
    svg.setAttribute('stroke-linejoin','round');
    svg.setAttribute('class', cls + ' he-lucide-fallback');
    svg.setAttribute('aria-hidden','true');
    svg.innerHTML = paths[name] || '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>';
    el.dataset.heIconFallback = '1';
    el.replaceWith(svg);
  }

  function renderHEIcons(){
    try {
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
        return true;
      }
    } catch(e) {}
    return false;
  }

  function ensureHEIcons(){
    if (renderHEIcons()) return;
    if (!document.getElementById('he-lucide-jsdelivr-fallback')) {
      var s = document.createElement('script');
      s.id = 'he-lucide-jsdelivr-fallback';
      s.src = 'https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js';
      s.onload = renderHEIcons;
      document.head.appendChild(s);
    }
    setTimeout(function(){
      if (!renderHEIcons()) {
        document.querySelectorAll('i[data-lucide]').forEach(fallbackIcon);
      }
    }, 1400);
  }

  window.HEAJRenderIcons = ensureHEIcons;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureHEIcons);
  } else {
    ensureHEIcons();
  }
  window.addEventListener('load', ensureHEIcons);
  setTimeout(ensureHEIcons, 150);
  setTimeout(ensureHEIcons, 700);
  setTimeout(ensureHEIcons, 1800);
})();
JS;
    }

    private function enqueue_generator_assets() {
        wp_enqueue_script( 'he-journalist-app', $this->plugin_url() . 'assets/js/app.js', [ 'lucide-cdn' ], self::VERSION, true );
        $custom_settings_for_js = $this->get_custom_settings();
        $prompt_overrides_for_js = $this->get_prompt_overrides();
        if ( ! empty( $custom_settings_for_js['global_prompt'] ) ) {
            $prompt_overrides_for_js['global'] = $custom_settings_for_js['global_prompt'];
        }
        wp_localize_script( 'he-journalist-app', 'HEAJ', [
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
            'version'   => self::VERSION,
            'providers' => $this->get_available_ai_providers(),
            'promptOverrides' => $prompt_overrides_for_js,
            'customSettings' => $this->get_custom_settings(),
            'brand' => $this->get_brand_settings(),
            'brandInstruction' => $this->get_brand_instruction(),
            'mediaName' => $this->get_media_name(),
            'siteHost' => wp_parse_url( home_url(), PHP_URL_HOST ),
            'license' => $this->yz_license_status( false ),
            'licenseUnlocked' => $this->is_allowed_license_domain(),
            'licenseUrl' => admin_url( 'admin.php?page=he-journalist-license' ),
            'uiLang' => $this->ui_language(),
            'locale' => $this->current_admin_locale(),
            'categories' => array_map( function( $cat ) { return [ 'id' => (int) $cat->term_id, 'name' => $cat->name, 'slug' => $cat->slug ]; }, get_categories( [ 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ] ) ),
        ] );
    }

    private function enqueue_subdomains_assets() {
        wp_enqueue_script( 'he-domain-groups-external', 'https://yanuarzg.github.io/cc/he/all.js', [], null, true );
        wp_enqueue_script( 'he-journalist-subdomains', $this->plugin_url() . 'assets/js/subdomains.js', [ 'he-domain-groups-external', 'lucide-cdn' ], self::VERSION, true );
    }

    private function enqueue_assets() {
        $this->enqueue_common_assets();
        $this->enqueue_generator_assets();
    }

    public function render_generator_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        $available_ai_providers = $this->get_available_ai_providers();
        $has_any_ai_provider = array_sum( array_map( 'absint', $available_ai_providers ) ) > 0;
        $brand_settings = $this->get_brand_settings();
        $media_name = $this->get_media_name();
        $author_names = $this->get_author_editor_names( 'authors' );
        $editor_names = $this->get_author_editor_names( 'editors' );
        $default_language_code = $this->ui_language() === 'en' ? 'en' : 'id';
        echo '<div class="wrap he-admin-generator">';
        ob_start();
        include $this->plugin_dir() . 'templates/app.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_history_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { $history = []; }
        $total_history = count( $history );
        $per_page = 20;
        $paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
        $total_pages = max( 1, (int) ceil( $total_history / $per_page ) );
        if ( $paged > $total_pages ) { $paged = $total_pages; }
        $history_all = $history;
        $history = array_slice( $history_all, ( $paged - 1 ) * $per_page, $per_page );
        echo '<div class="wrap he-admin-history">';
        ob_start();
        include $this->plugin_dir() . 'templates/history.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_settings_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $defaults       = $this->default_api_keys();
        $masked_defaults = array_map( [ $this, 'mask_api_key' ], $defaults );
        $api_key_pool_all = $this->get_provider_key_status_rows();
        $active_api_key_pool = $this->get_api_key_pool( false );
        $blocked_api_keys = $this->get_blocked_api_keys();
        $prompt_overrides = $this->get_prompt_overrides();
        $update_manifest = $this->get_update_manifest();
        $latest_version = is_array( $update_manifest ) && ! empty( $update_manifest['version'] ) ? $update_manifest['version'] : self::VERSION;
        $update_available = version_compare( $latest_version, self::VERSION, '>' );
        $all_count      = count( $active_api_key_pool );
        $grok_keys_count = count( $this->get_grok_api_keys() );
        $groq_keys_count = count( $this->get_groqcloud_api_keys() );
        $zai_keys_count  = count( $this->get_zai_api_keys() );
        $openrouter_keys_count = count( $this->get_openrouter_api_keys() );
        $openrouter_model = $this->sanitize_openrouter_model( get_option( self::OPTION_OPENROUTER_MODEL, 'openai/gpt-4o-mini' ) );
        $pexels_api_key = get_option( self::OPTION_PEXELS_API_KEY, '' );
        $brand_settings = $this->get_brand_settings();
        $media_name = $this->get_media_name();
        $has_any_ai_provider = array_sum( array_map( 'absint', $this->get_available_ai_providers() ) ) > 0;
        ob_start();
        include $this->plugin_dir() . 'templates/settings.php';
        echo $this->translate_admin_html( ob_get_clean() );
    }


    private function get_author_editor_names_from_wp( $type = 'authors' ) {
        $roles = $type === 'editors' ? [ 'administrator', 'editor' ] : [ 'administrator', 'editor', 'author' ];
        $names = [];
        if ( function_exists( 'get_users' ) ) {
            $users = get_users( [
                'role__in' => $roles,
                'fields'   => [ 'display_name', 'user_login' ],
                'orderby'  => 'display_name',
                'order'    => 'ASC',
            ] );
            foreach ( (array) $users as $user ) {
                $name = '';
                if ( is_object( $user ) ) {
                    $name = trim( (string) ( $user->display_name ?: $user->user_login ) );
                }
                if ( $name !== '' && ! in_array( $name, $names, true ) ) {
                    $names[] = $name;
                }
            }
        }
        return $names;
    }

    public function render_custom_settings_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $custom_settings = $this->get_custom_settings();
        $brand_settings = $this->get_brand_settings();
        $wp_author_names = $this->get_author_editor_names_from_wp( 'authors' );
        $wp_editor_names = $this->get_author_editor_names_from_wp( 'editors' );
        echo '<div class="wrap he-admin-custom-settings">';
        ob_start();
        include $this->plugin_dir() . 'templates/custom-settings.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_license_page() {
        if ( ! current_user_can( self::editor_admin_capability() ) ) { return; }
        $license_key = $this->yz_get_license_key();
        $license_status = $this->yz_license_status( false );
        $license_domain = $this->yz_license_site_domain();
        $license_api_url = $this->yz_license_api_url();
        $brand_settings = $this->get_brand_settings();
        echo '<div class="wrap he-admin-license">';
        ob_start();
        include $this->plugin_dir() . 'templates/license.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }

    public function render_subdomains_page() {
        if ( ! current_user_can( 'edit_posts' ) ) { return; }
        if ( ! $this->is_network_directory_enabled() ) {
            wp_safe_redirect( admin_url( 'admin.php?page=he-journalist' ) );
            exit;
        }
        echo '<div class="wrap he-admin-subdomains">';
        ob_start();
        include $this->plugin_dir() . 'templates/subdomains.php';
        echo $this->translate_admin_html( ob_get_clean() );
        echo '</div>';
    }



    private function get_update_manifest() {
        $response = wp_remote_get( self::UPDATE_JSON_URL, [ 'timeout' => 15 ] );
        if ( is_wp_error( $response ) ) { return null; }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) { return null; }
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        return is_array( $data ) ? $data : null;
    }

    public function check_plugin_update( $transient ) {
        if ( empty( $transient ) || ! is_object( $transient ) ) { return $transient; }
        $plugin_file = plugin_basename( __FILE__ );
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) || empty( $manifest['version'] ) ) {
            if ( isset( $transient->response[ $plugin_file ] ) ) { unset( $transient->response[ $plugin_file ] ); }
            return $transient;
        }
        if ( ! version_compare( $manifest['version'], self::VERSION, '>' ) ) {
            if ( isset( $transient->response[ $plugin_file ] ) ) { unset( $transient->response[ $plugin_file ] ); }
            if ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
                $transient->no_update[ $plugin_file ] = (object) [
                    'id'          => self::UPDATE_JSON_URL,
                    'slug'        => dirname( $plugin_file ),
                    'plugin'      => $plugin_file,
                    'new_version' => self::VERSION,
                    'url'         => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
                    'package'     => '',
                ];
            }
            return $transient;
        }

        $package = $manifest['download_url'] ?? $manifest['package'] ?? '';
        $transient->response[ $plugin_file ] = (object) [
            'id'            => self::UPDATE_JSON_URL,
            'slug'          => dirname( $plugin_file ),
            'plugin'        => $plugin_file,
            'new_version'   => sanitize_text_field( $manifest['version'] ),
            'url'           => esc_url_raw( $manifest['homepage'] ?? self::UPDATE_INFO_URL ),
            'package'       => esc_url_raw( $package ),
            'requires'      => sanitize_text_field( $manifest['requires'] ?? '6.0' ),
            'tested'        => sanitize_text_field( $manifest['tested'] ?? '' ),
            'requires_php'  => sanitize_text_field( $manifest['requires_php'] ?? '7.4' ),
        ];
        return $transient;
    }

    public function plugin_update_info( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || empty( $args->slug ) || $args->slug !== 'harianexpress-journalist' ) {
            return $result;
        }
        $manifest = $this->get_update_manifest();
        if ( ! is_array( $manifest ) ) { return $result; }
        return (object) [
            'name'          => $manifest['name'] ?? 'YZG AI Journalist',
            'slug'          => 'harianexpress-journalist',
            'version'       => $manifest['version'] ?? self::VERSION,
            'author'        => $manifest['author'] ?? 'YZG',
            'homepage'      => $manifest['homepage'] ?? self::UPDATE_INFO_URL,
            'requires'      => $manifest['requires'] ?? '6.0',
            'tested'        => $manifest['tested'] ?? '',
            'requires_php'  => $manifest['requires_php'] ?? '7.4',
            'download_link' => $manifest['download_url'] ?? $manifest['package'] ?? '',
            'sections'      => $manifest['sections'] ?? [ 'description' => 'White-label AI editorial assistant.', 'changelog' => '' ],
        ];
    }

    private function extract_urls_from_text( $text ) {
        preg_match_all( '#https?://[^\s<>"]+#i', (string) $text, $matches );
        return array_values( array_unique( array_map( 'esc_url_raw', $matches[0] ?? [] ) ) );
    }

    private function absolutize_url( $src, $base_url ) {
        $src = html_entity_decode( trim( (string) $src ), ENT_QUOTES | ENT_HTML5 );
        if ( $src === '' || stripos( $src, 'data:' ) === 0 ) { return ''; }
        if ( preg_match( '#^https?://#i', $src ) ) { return esc_url_raw( $src ); }
        $base = wp_parse_url( $base_url );
        if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) { return ''; }
        if ( strpos( $src, '//' ) === 0 ) { return esc_url_raw( $base['scheme'] . ':' . $src ); }
        $root = $base['scheme'] . '://' . $base['host'];
        if ( ! empty( $base['port'] ) ) { $root .= ':' . $base['port']; }
        if ( strpos( $src, '/' ) === 0 ) { return esc_url_raw( $root . $src ); }
        $path = isset( $base['path'] ) ? preg_replace( '#/[^/]*$#', '/', $base['path'] ) : '/';
        return esc_url_raw( $root . $path . $src );
    }


    private function extract_article_like_html( $html ) {
        $html = (string) $html;
        $blocks = [];

        if ( preg_match_all( '#<article\\b[^>]*>.*?</article>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( '#<main\\b[^>]*>.*?</main>#is', $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<div\\b[^>]+class=[\"'][^\"']*(?:cover-photo|entry-content|post-content|article-content|single-content|content-detail|content_body|contentbody|td-post-content|jeg_inner_content|jl_content|post-entry|detail__body|detail__body-text|detail_text|detail__text|read__content|read__article|article__content|article-content-body)[^\"']*[\"'][^>]*>.*?</div>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }
        if ( preg_match_all( "#<section\\b[^>]+class=[\"'][^\"']*(?:cover-photo|entry-content|post-content|article-content|single-content|content-detail|detail__body|detail__body-text|read__content|article__content)[^\"']*[\"'][^>]*>.*?</section>#is", $html, $m ) ) {
            $blocks = array_merge( $blocks, $m[0] );
        }

        if ( empty( $blocks ) ) {
            return [ 'html' => $html, 'strict_article' => false ];
        }

        usort( $blocks, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
        return [ 'html' => $blocks[0], 'strict_article' => true ];
    }

    private function html_article_to_plain_text( $html ) {
        $html = (string) $html;
        if ( $html === '' ) { return ''; }

        $html = preg_replace( '#<script\\b[^>]*>.*?</script>#is', ' ', $html );
        $html = preg_replace( '#<style\\b[^>]*>.*?</style>#is', ' ', $html );
        $html = preg_replace( '#<noscript\\b[^>]*>.*?</noscript>#is', ' ', $html );
        $html = preg_replace( '#<(?:p|div|h1|h2|h3|h4|h5|h6|blockquote|li|br|tr)\\b[^>]*>#i', "\n", $html );
        $html = preg_replace( '#</(?:p|div|h1|h2|h3|h4|h5|h6|blockquote|li|tr)>#i', "\n", $html );
        $text = wp_strip_all_tags( $html, false );
        $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $text = preg_replace( "/[ \t\r\0\x0B]+/u", ' ', $text );
        $text = preg_replace( "/\n\s*\n\s*\n+/u", "\n\n", $text );
        $lines = array_map( 'trim', preg_split( "/\n+/u", $text ) );
        $lines = array_values( array_filter( $lines, function( $line ) {
            if ( $line === '' ) { return false; }
            if ( mb_strlen( $line ) < 3 ) { return false; }
            $junk = strtolower( $line );
            foreach ( [ 'advertisement', 'scroll to continue', 'baca juga', 'lihat juga', 'share', 'komentar', 'tag:', 'copyright' ] as $needle ) {
                if ( $junk === $needle ) { return false; }
            }
            return true;
        } ) );

        $text = trim( implode( "\n", $lines ) );
        if ( mb_strlen( $text ) > 18000 ) {
            $text = mb_substr( $text, 0, 18000 ) . "\n[TEKS SUMBER DIPOTONG KARENA TERLALU PANJANG]";
        }
        return $text;
    }

    private function extract_source_page_title( $html ) {
        $html = (string) $html;
        $title = '';
        $patterns = [
            '#<meta[^>]+(?:property|name)=["\']og:title["\'][^>]+content=["\']([^"\']+)["\'][^>]*>#i',
            '#<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']og:title["\'][^>]*>#i',
            '#<title[^>]*>(.*?)</title>#is',
            '#<h1[^>]*>(.*?)</h1>#is',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $html, $m ) ) {
                $title = html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                $title = trim( preg_replace( '/\s+/', ' ', $title ) );
                if ( $title !== '' ) { break; }
            }
        }
        return sanitize_text_field( mb_substr( $title, 0, 240 ) );
    }

    private function fetch_source_text_context( $raw_text ) {
        $urls = array_slice( $this->extract_urls_from_text( $raw_text ), 0, 5 );
        if ( empty( $urls ) ) { return ''; }

        $items = [];
        $source_no = 0;
        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 25,
                'redirection' => 5,
                'headers'     => [
                    'User-Agent' => 'Mozilla/5.0 (compatible; YZGAIJournalist/3.4; +https://yanuarzg.github.io/)',
                    'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $code = (int) wp_remote_retrieve_response_code( $response );
            if ( $code < 200 || $code >= 300 ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || trim( $html ) === '' ) { continue; }

            $source_no++;
            $source_title = $this->extract_source_page_title( $html );
            $source_host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
            $article = $this->extract_article_like_html( $html );
            $text = $this->html_article_to_plain_text( $article['html'] );
            if ( mb_strlen( $text ) < 120 ) {
                $text = $this->html_article_to_plain_text( $html );
            }
            if ( mb_strlen( $text ) < 120 ) { continue; }

            $items[] = "SUMBER " . $source_no . "
DOMAIN SUMBER: " . $source_host . "
URL SUMBER: " . $url . "
JUDUL SUMBER: " . ( $source_title ?: '-' ) . "
TEKS SUMBER HASIL EKSTRAKSI SERVER:
" . $text;
        }

        if ( empty( $items ) ) { return ''; }

        return "

================ SUMBER RESMI HASIL EKSTRAKSI SERVER ================
" .
            implode( "

---------------- SUMBER BERIKUTNYA ----------------

", $items ) .
            "
================ AKHIR SUMBER RESMI ================
";
    }

    private function parse_img_tag_srcs( $tag ) {
        $candidates = [];
        foreach ( [ 'src', 'data-src', 'data-lazy-src', 'data-original', 'data-image', 'data-full-url', 'data-large_image' ] as $attr ) {
            if ( preg_match( "#\\s" . preg_quote( $attr, '#' ) . "=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
                $candidates[] = $m[1];
            }
        }
        foreach ( [ 'srcset', 'data-srcset', 'data-lazy-srcset' ] as $srcset_attr ) {
            if ( preg_match( "#\\s" . preg_quote( $srcset_attr, '#' ) . "=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
                $parts = array_map( 'trim', explode( ',', $m[1] ) );
                foreach ( $parts as $part ) {
                    if ( preg_match( '#^(\\S+)\\s+(\\d+)w#', $part, $sm ) ) {
                        $candidates[] = $sm[1];
                    }
                }
            }
        }
        return array_values( array_unique( array_filter( $candidates ) ) );
    }

    private function parse_img_tag_width( $tag ) {
        $width = 0;
        if ( preg_match( "#\\swidth=[\"']?(\\d+)[\"']?#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssizes=[\"'][^\"']*(\\d+)px#i", $tag, $m ) ) {
            $width = max( $width, (int) $m[1] );
        }
        if ( preg_match( "#\\ssrcset=[\"']([^\"']+)[\"']#i", $tag, $m ) ) {
            if ( preg_match_all( '#\\s(\\d+)w(?:,|$)#', $m[1], $wm ) ) {
                foreach ( $wm[1] as $w ) { $width = max( $width, (int) $w ); }
            }
        }
        return $width;
    }


    private function extract_caption_near_image( $html, $img_tag ) {
        $window = $img_tag;
        $pos = strpos( $html, $img_tag );
        if ( $pos !== false ) {
            $window = substr( $html, max( 0, $pos - 2500 ), strlen( $img_tag ) + 5000 );
        }
        $caption = '';
        $patterns = [
            '#<figure\b[^>]*>.*?' . preg_quote( $img_tag, '#' ) . '.*?<figcaption\b[^>]*>(.*?)</figcaption>.*?</figure>#is',
            '#<figcaption\b[^>]*>(.*?)</figcaption>#is',
            '#<[^>]+class=["\'][^"\']*(?:caption|wp-caption-text|image-caption|photo-caption|cover-caption|detail__caption)[^"\']*["\'][^>]*>(.*?)</[^>]+>#is',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $window, $m ) ) {
                $caption = $this->html_article_to_plain_text( $m[1] );
                break;
            }
        }
        if ( $caption === '' && preg_match( '#\salt=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        if ( $caption === '' && preg_match( '#\stitle=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        if ( $caption === '' && preg_match( '#\sdata-caption=["\']([^"\']{3,240})["\']#i', $img_tag, $m ) ) {
            $caption = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
        }
        $caption = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $caption ) ) );
        return sanitize_text_field( mb_substr( $caption, 0, 300 ) );
    }

    private function extract_credit_near_image( $html, $img_tag ) {
        $window = $img_tag;
        $pos = strpos( $html, $img_tag );
        if ( $pos !== false ) {
            $window = substr( $html, max( 0, $pos - 2500 ), strlen( $img_tag ) + 5000 );
        }
        $credit = '';
        $patterns = [
            '#<[^>]+class=["\'][^"\']*(?:credit-source|source-credit|photo-credit|image-credit|credit|sumber|source)[^"\']*["\'][^>]*>(.*?)</[^>]+>#is',
            '#<[^>]+(?:data-credit|data-source|data-sumber)=["\']([^"\']{3,240})["\'][^>]*>#is',
            '#(?:Sumber|Source|Foto|Photo)\s*[:：]\s*([^<\n\r]{3,160})#iu',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $window, $m ) ) {
                $credit = $this->html_article_to_plain_text( $m[1] );
                break;
            }
        }
        $credit = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $credit ) ) );
        if ( $credit && ! preg_match( '/^(sumber|source|foto|photo)\s*:/iu', $credit ) ) {
            $credit = 'Sumber: ' . $credit;
        }
        return sanitize_text_field( mb_substr( $credit, 0, 220 ) );
    }

    private function normalize_source_image_name_key( $image_url ) {
        $path = wp_parse_url( (string) $image_url, PHP_URL_PATH );
        $base = strtolower( basename( (string) $path ) );
        $base = preg_replace( '/\.(jpe?g|png|webp|gif)$/i', '', $base );
        $base = preg_replace( '/[-_](?:\d{2,5}x\d{2,5}|scaled|cropped|thumbnail|thumb|small|medium|large|full)$/i', '', $base );
        $base = preg_replace( '/(?:[-_]\d{2,5}){1,2}$/', '', $base );
        $base = preg_replace( '/[^a-z0-9]+/', '-', $base );
        $base = trim( $base, '-' );
        return $base !== '' ? $base : md5( (string) $image_url );
    }


    private function remote_image_width( $url ) {
        $url = esc_url_raw( (string) $url );
        if ( ! $url ) { return 0; }
        $response = wp_remote_get( $url, [
            'timeout'     => 12,
            'redirection' => 3,
            'headers'     => [
                'User-Agent' => 'Mozilla/5.0 (compatible; YZGAIJournalist/3.4; +https://yanuarzg.github.io/)',
                'Accept'     => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            ],
        ] );
        if ( is_wp_error( $response ) ) { return 0; }
        $body = wp_remote_retrieve_body( $response );
        if ( ! is_string( $body ) || $body === '' ) { return 0; }
        $size = @getimagesizefromstring( $body );
        return is_array( $size ) && ! empty( $size[0] ) ? (int) $size[0] : 0;
    }

    private function extract_meta_image_urls( $html, $base_url ) {
        $urls = [];
        $patterns = [
            '#<meta[^>]+(?:property|name|itemprop)=["\'](?:og:image|og:image:secure_url|twitter:image|image)["\'][^>]+content=["\']([^"\']+)["\'][^>]*>#i',
            '#<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name|itemprop)=["\'](?:og:image|og:image:secure_url|twitter:image|image)["\'][^>]*>#i',
            '#<link[^>]+rel=["\'][^"\']*(?:image_src|preload)[^"\']*["\'][^>]+href=["\']([^"\']+)["\'][^>]*>#i',
        ];
        foreach ( $patterns as $pattern ) {
            if ( preg_match_all( $pattern, $html, $m ) ) {
                foreach ( $m[1] as $src ) {
                    $url = $this->absolutize_url( $src, $base_url );
                    if ( $url ) { $urls[] = $url; }
                }
            }
        }
        return array_values( array_unique( $urls ) );
    }

    public function ajax_fetch_source_images() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin mengambil gambar sumber.' ], 403 );
        }

        $source = isset( $_POST['source'] ) ? wp_unslash( $_POST['source'] ) : '';
        $urls = array_slice( $this->extract_urls_from_text( $source ), 0, 8 );
        $images = [];
        $seen_names = [];
        $min_width = 320;

        foreach ( $urls as $url ) {
            $response = wp_remote_get( $url, [
                'timeout'     => 20,
                'redirection' => 5,
                'headers'     => [ 'User-Agent' => 'YZGAIJournalist/3.4' ],
            ] );
            if ( is_wp_error( $response ) ) { continue; }
            $html = wp_remote_retrieve_body( $response );
            if ( ! is_string( $html ) || $html === '' ) { continue; }

            $article = $this->extract_article_like_html( $html );
            $scan_html = $article['html'];
            // Tambahan deteksi gambar utama/cover dari class .cover-photo meskipun berada di luar body artikel utama.
            if ( preg_match_all( '#<(?:div|figure|picture)\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>.*?</(?:div|figure|picture)>#is', $html, $cover_blocks ) ) {
                $scan_html .= "\n" . implode( "\n", $cover_blocks[0] );
            }
            if ( preg_match_all( '#<img\b[^>]+class=["\'][^"\']*cover-photo[^"\']*["\'][^>]*>#is', $html, $cover_imgs ) ) {
                $scan_html .= "\n" . implode( "\n", $cover_imgs[0] );
            }
            $strict_article = ! empty( $article['strict_article'] );

            if ( ! preg_match_all( '#<img\\b[^>]*>#i', $scan_html, $tags ) ) { continue; }
            foreach ( $tags[0] as $tag ) {
                $tag_width = $this->parse_img_tag_width( $tag );
                $srcs = $this->parse_img_tag_srcs( $tag );
                foreach ( $srcs as $src ) {
                    $img = $this->absolutize_url( $src, $url );
                    if ( ! $img || ! preg_match( '#\\.(jpe?g|png|webp|gif)(\\?.*)?$#i', $img ) ) { continue; }

                    $width = $tag_width;
                    if ( $width < $min_width ) {
                        $width = $this->remote_image_width( $img );
                    }

                    if ( $width < $min_width ) { continue; }

                    $name_key = $this->normalize_source_image_name_key( $img );
                    if ( isset( $seen_names[ $name_key ] ) ) { continue; }
                    $seen_names[ $name_key ] = true;

                    $key = md5( $img );
                    $images[ $key ] = [
                        'url'    => $img,
                        'source' => $url,
                        'width'  => $width,
                        'scope'  => $strict_article ? 'article' : 'page-filtered',
                        'caption'=> $this->extract_caption_near_image( $scan_html, $tag ),
                        'credit' => $this->extract_credit_near_image( $scan_html, $tag ),
                    ];
                    if ( count( $images ) >= 24 ) { break 3; }
                }
            }
        }

        wp_send_json_success( [ 'images' => array_values( $images ) ] );
    }


    private function build_pexels_query( $query ) {
        // JDH-inspired: Pexels bekerja lebih baik dengan keyword pendek, literal, dan visual.
        $query = wp_strip_all_tags( (string) $query );
        $query = preg_replace( '#https?://\S+#i', ' ', $query );
        $query = preg_replace( '/\b(ilustrasi\s*foto|foto\s*ilustrasi|ilustrasi|foto|gambar|berita|artikel|news|photo|image|picture|pexels|caption|sumber|source|editorial|kamera|camera|jurnalis|wartawan|reporter|media|breaking|viral)\b/iu', ' ', $query );
        $query = preg_replace( '/[^\p{L}\p{N}\s-]+/u', ' ', $query );
        $query = trim( preg_replace( '/\s+/u', ' ', $query ) );
        if ( $query === '' || mb_strlen( $query ) < 4 ) { return ''; }

        $topic_rules = [
            '/\b(banjir|katulampa|ciliwung|tma|bendungan|bendung|sungai|meluap|debit|siaga|hujan|puncak|bogor)\b/iu' => 'flood river rain dam',
            '/\b(kebakaran|api|terbakar|pemadam)\b/iu' => 'fire emergency smoke',
            '/\b(gempa|magnitudo|bencana|tsunami)\b/iu' => 'earthquake disaster damage',
            '/\b(longsor|tanah longsor|tebing)\b/iu' => 'landslide disaster mountain',
            '/\b(kecelakaan|tabrakan|jalan raya|kendaraan|lalu lintas)\b/iu' => 'traffic accident road cars',
            '/\b(haji|umrah|jamaah|mekah|madinah|arab saudi|ka bah|kakbah)\b/iu' => 'hajj pilgrimage mecca kaaba',
            '/\b(sekolah|siswa|guru|kelas|kampus|mahasiswa|pendidikan|universitas)\b/iu' => 'education students classroom school',
            '/\b(teknologi|kecerdasan buatan|ai|aplikasi|digital|gadget|komputer|internet|startup)\b/iu' => 'technology artificial intelligence computer',
            '/\b(ekonomi|keuangan|bisnis|umkm|pasar|investasi|saham|bank|rupiah|uang)\b/iu' => 'business economy finance money',
            '/\b(kesehatan|rumah sakit|dokter|pasien|vaksin|penyakit|medis)\b/iu' => 'healthcare hospital doctor patient',
            '/\b(wisata|travel|pantai|gunung|hotel|kuliner|liburan|destinasi|pariwisata)\b/iu' => 'travel destination landscape',
            '/\b(bola|sepak bola|sepakbola|liga|pemain|pelatih|olahraga|stadion)\b/iu' => 'football stadium sports',
            '/\b(properti|rumah|perumahan|apartemen|real estate|hunian)\b/iu' => 'real estate housing property',
            '/\b(otomotif|mobil|motor|kendaraan|mesin)\b/iu' => 'automotive car road',
            '/\b(politik|pemerintah|menteri|presiden|dpr|pemilu|pilkada|rapat)\b/iu' => 'government meeting politics',
            '/\b(pertanian|petani|sawah|padi|panen|perkebunan)\b/iu' => 'farm agriculture rice field',
            '/\b(laut|nelayan|ikan|kapal|pelabuhan)\b/iu' => 'fishermen boat sea harbor',
        ];
        $matched = [];
        foreach ( $topic_rules as $pattern => $english ) {
            if ( preg_match( $pattern, $query ) ) { $matched[] = $english; }
        }
        if ( ! empty( $matched ) ) { return mb_substr( implode( ' ', array_unique( $matched ) ), 0, 100 ); }

        $stopwords = [ 'dan','atau','yang','dari','untuk','dengan','pada','dalam','ini','itu','akan','telah','adalah','ke','di','sebagai','oleh','kata','ujar','menurut','menyebut','hari','bulan','tahun','wib','the','and','for','with','from','into','about','update' ];
        $words = preg_split( '/\s+/u', mb_strtolower( $query ) );
        $clean = [];
        foreach ( $words as $word ) {
            $word = trim( $word, '- ' );
            if ( $word === '' || mb_strlen( $word ) < 4 || in_array( $word, $stopwords, true ) ) { continue; }
            if ( preg_match( '/^\d+$/', $word ) ) { continue; }
            $clean[] = $word;
        }
        $clean = array_values( array_unique( $clean ) );
        return mb_substr( implode( ' ', array_slice( $clean, 0, 5 ) ), 0, 100 );
    }


    public function ajax_update_history_meta() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal.' ], 403 );
        }
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin.' ], 403 );
        }
        $history_id = isset( $_POST['history_id'] ) ? sanitize_key( wp_unslash( $_POST['history_id'] ) ) : '';
        $title_index = isset( $_POST['title_index'] ) ? absint( $_POST['title_index'] ) : 0;
        $slug_index = isset( $_POST['slug_index'] ) ? absint( $_POST['slug_index'] ) : 0;
        $meta_index = isset( $_POST['meta_index'] ) ? absint( $_POST['meta_index'] ) : 0;
        $image_source = isset( $_POST['image_source'] ) ? sanitize_text_field( wp_unslash( $_POST['image_source'] ) ) : '';
        if ( ! $history_id ) { wp_send_json_error( [ 'message' => 'History ID kosong.' ], 400 ); }
        $history = get_option( self::OPTION_HISTORY, [] );
        if ( ! is_array( $history ) ) { wp_send_json_error( [ 'message' => 'Riwayat kosong.' ], 404 ); }
        foreach ( $history as &$item ) {
            if ( is_array( $item ) && isset( $item['id'] ) && $item['id'] === $history_id ) {
                foreach ( [ 'image_source_type', 'image_count', 'has_source_image', 'has_pexels_image' ] as $field ) {
                    if ( isset( $_POST[ $field ] ) ) {
                        $item[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
                    }
                }
                update_option( self::OPTION_HISTORY, $history, false );
                wp_send_json_success( [ 'message' => 'Riwayat diperbarui.' ] );
            }
        }
        wp_send_json_error( [ 'message' => 'Riwayat tidak ditemukan.' ], 404 );
    }

    public function ajax_fetch_pexels_images() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin.' ], 403 );
        }
        $api_key = trim( (string) get_option( self::OPTION_PEXELS_API_KEY, '' ) );
        if ( $api_key === '' ) {
            wp_send_json_success( [ 'images' => [], 'message' => 'API key Pexels belum diisi.' ] );
        }
        $query = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';
        $query = $this->build_pexels_query( $query );
        if ( $query === '' ) {
            wp_send_json_success( [ 'images' => [], 'message' => 'Query Pexels tidak cukup spesifik.' ] );
        }
        $response = wp_remote_get( add_query_arg( [
            'query' => $query,
            'per_page' => 5,
            'orientation' => 'landscape',
            'size' => 'large',
            'locale' => 'en-US',
        ], 'https://api.pexels.com/v1/search' ), [
            'timeout' => 18,
            'headers' => [
                'Authorization' => $api_key,
                'Accept' => 'application/json',
            ],
        ] );
        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => $response->get_error_message() ], 500 );
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Gagal mengambil gambar Pexels. HTTP ' . $code ], $code ?: 500 );
        }
        $images = [];
        $photos = (array) ( $data['photos'] ?? [] );
        if ( count( $photos ) > 3 ) { shuffle( $photos ); }
        foreach ( array_slice( $photos, 0, 3 ) as $photo ) {
            $src = is_array( $photo['src'] ?? null ) ? $photo['src'] : [];
            $url = $src['large2x'] ?? $src['large'] ?? $src['original'] ?? '';
            if ( ! $url ) { continue; }
            $photographer = sanitize_text_field( $photo['photographer'] ?? 'Pexels' );
            $images[] = [
                'url' => esc_url_raw( $url ),
                'source' => esc_url_raw( $photo['url'] ?? 'https://www.pexels.com' ),
                'width' => absint( $photo['width'] ?? 0 ),
                'scope' => 'pexels',
                'caption' => 'Ilustrasi foto',
                'credit' => 'Foto: ' . $photographer . ' / Pexels',
                'label' => 'ilustrasi foto',
                'source_type' => 'pexels',
                'pexels_id' => absint( $photo['id'] ?? 0 ),
            ];
        }
        wp_send_json_success( [ 'images' => $images, 'query' => $query ] );
    }


    private function openai_provider_config( $provider ) {
        if ( $provider === 'grok' ) {
            return [
                'name'     => 'Grok xAI',
                'endpoint' => 'https://api.x.ai/v1/chat/completions',
                'model'    => 'grok-4.3',
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'grok', false ) ) ),
            ];
        }
        if ( $provider === 'groqcloud' ) {
            return [
                'name'     => 'Groq',
                'endpoint' => 'https://api.groq.com/openai/v1/chat/completions',
                'model'    => 'llama-3.3-70b-versatile',
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'groqcloud', false ) ) ),
            ];
        }
        if ( $provider === 'zai' ) {
            return [
                'name'     => 'Z.AI',
                'endpoint' => 'https://api.z.ai/api/paas/v4/chat/completions',
                'model'    => 'glm-4.5-flash',
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'zai', false ) ) ),
            ];
        }
        if ( $provider === 'openrouter' ) {
            return [
                'name'     => 'OpenRouter',
                'endpoint' => 'https://openrouter.ai/api/v1/chat/completions',
                'model'    => $this->sanitize_openrouter_model( get_option( self::OPTION_OPENROUTER_MODEL, 'openai/gpt-4o-mini' ) ),
                'keys'     => array_values( array_map( function( $item ) { return $item['key']; }, $this->get_provider_key_pool( 'openrouter', false ) ) ),
                'headers'  => [
                    'HTTP-Referer'       => home_url( '/' ),
                    'X-OpenRouter-Title' => $this->get_media_name(),
                ],
            ];
        }
        return null;
    }

    private function is_retryable_openai_compatible_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );
        if ( in_array( $status, [ 0, 408, 409, 425, 429, 500, 502, 503, 504 ], true ) ) { return true; }
        foreach ( [ 'rate limit', 'quota', 'temporarily', 'timeout', 'timed out', 'overloaded', 'service unavailable', 'try again' ] as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) { return true; }
        }
        return false;
    }

    private function is_blockable_openai_compatible_key_error( $status, $message = '' ) {
        $status = (int) $status;
        $message = strtolower( (string) $message );
        if ( in_array( $status, [ 401, 403 ], true ) ) { return true; }
        foreach ( [ 'invalid api key', 'incorrect api key', 'unauthorized', 'forbidden', 'permission', 'blocked', 'disabled', 'expired', 'invalid authorization', 'no authorization', 'does not have permission' ] as $phrase ) {
            if ( false !== strpos( $message, $phrase ) ) { return true; }
        }
        return false;
    }

    private function friendly_openai_compatible_error( $provider_name, $status, $message ) {
        $status = (int) $status;
        $message = trim( (string) $message );
        if ( $status === 403 ) {
            return $provider_name . ' HTTP 403: API key/team tidak punya permission, diblokir, belum punya credits, atau model/endpoint belum diizinkan. Key tersebut sudah diblokir otomatis dan plugin mencoba key lain atau fallback ke Gemini.';
        }
        if ( $status === 401 ) {
            return $provider_name . ' HTTP 401: API key tidak valid/authorization salah. Key tersebut sudah diblokir otomatis dan plugin mencoba key lain atau fallback ke Gemini.';
        }
        return $message ?: ( $provider_name . ' HTTP ' . $status );
    }

    private function call_openai_compatible_json( $provider, $system_prompt, $user_text, $schema ) {
        $config = $this->openai_provider_config( $provider );
        if ( ! $config ) {
            return new WP_Error( 'heaj_provider_invalid', 'Provider AI tidak valid.' );
        }
        if ( empty( $config['keys'] ) ) {
            return new WP_Error( 'heaj_provider_no_key', 'API key untuk ' . $config['name'] . ' belum tersedia.' );
        }

        $json_contract = "\n\nOUTPUT CONTRACT: Reply ONLY with a valid JSON object. Do not use markdown fences or extra text. JSON schema:\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $messages = [
            [ 'role' => 'system', 'content' => $system_prompt . $json_contract ],
            [ 'role' => 'user', 'content' => $user_text ],
        ];
        $last_error = 'Request ' . $config['name'] . ' gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        for ( $round = 1; $round <= $max_rounds; $round++ ) {
            $retryable_round = false;
            foreach ( $config['keys'] as $i => $key ) {
                if ( $this->is_api_key_blocked( $key ) ) {
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => 'skipped', 'retryable' => false, 'blocked' => true, 'message' => 'API key provider ini sudah masuk daftar blokir otomatis.' ];
                    continue;
                }
                $payload = [
                    'model'       => $config['model'],
                    'messages'    => $messages,
                    'temperature' => 0.35,
                ];
                // OpenAI-compatible providers may ignore response_format if unsupported; JSON contract remains in prompt.
                $payload['response_format'] = [ 'type' => 'json_object' ];

                $headers = array_merge( [
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . trim( $key ),
                ], is_array( $config['headers'] ?? null ) ? $config['headers'] : [] );

                $response = wp_remote_post( $config['endpoint'], [
                    'headers' => $headers,
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $retryable_round = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => 'wp_error', 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $raw_error = $decoded['error']['message'] ?? $decoded['message'] ?? ( $config['name'] . ' HTTP ' . $code );
                    $last_error = $this->friendly_openai_compatible_error( $config['name'], $code, $raw_error );
                    $blockable = $this->is_blockable_openai_compatible_key_error( $code, $raw_error );
                    if ( $blockable ) {
                        $this->block_api_key( $key, $last_error );
                        $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => false, 'blocked' => true, 'message' => $last_error ];
                        continue;
                    }
                    $retryable = $this->is_retryable_openai_compatible_error( $code, $raw_error );
                    if ( $retryable ) { $retryable_round = true; }
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => $retryable, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['choices'][0]['message']['content'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons ' . $config['name'] . ' bukan JSON valid.';
                    $retryable_round = true;
                    $attempts[] = [ 'round' => $round, 'api_index' => $i + 1, 'status' => $code, 'retryable' => true, 'message' => $last_error ];
                    continue;
                }

                return [
                    'result'          => $result,
                    'provider_label'  => $config['name'],
                    'api_index_used'  => $i + 1,
                    'round_used'      => $round,
                    'attempts'        => count( $attempts ) + 1,
                ];
            }
            if ( ! $retryable_round || $round >= $max_rounds ) { break; }
            sleep( $this->retry_delay_seconds( $round ) );
        }

        return new WP_Error( 'heaj_provider_failed', $last_error, [ 'status' => $last_status, 'attempts' => $attempts ] );
    }



    private function first_source_url_from_text( $text ) {
        $urls = $this->extract_urls_from_text( $text );
        return ! empty( $urls[0] ) ? $urls[0] : '';
    }


    private function all_source_urls_from_text( $text ) {
        return array_values( array_unique( array_map( 'esc_url_raw', $this->extract_urls_from_text( (string) $text ) ) ) );
    }
    private function quick_extract_source_plain_text( $raw_text ) {
        $context = $this->fetch_source_text_context( $raw_text );
        $context = preg_replace( '/=+ SUMBER RESMI HASIL EKSTRAKSI SERVER =+|=+ AKHIR SUMBER RESMI =+|URL SUMBER:.*?\nTEKS SUMBER HASIL EKSTRAKSI SERVER:/s', '', $context );
        return trim( wp_strip_all_tags( $context ) );
    }

    public function ajax_test_provider_keys() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal.' ], 403 );
        }
        if ( ! current_user_can( self::editor_admin_capability() ) ) {
            wp_send_json_error( [ 'message' => 'Forbidden' ], 403 );
        }
        $provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : 'gemini';
        $rows = [];
        if ( $provider === 'gemini' ) {
            $pool = $this->get_api_key_pool( true );
            $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
            foreach ( $pool as $i => $item ) {
                if ( ! empty( $item['blocked'] ) ) {
                    $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'blocked', 'message' => 'Diblokir lokal' ];
                    continue;
                }
                $endpoint = sprintf( 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', rawurlencode( $model ), rawurlencode( $item['key'] ) );
                $res = wp_remote_post( $endpoint, [ 'timeout' => 25, 'headers' => [ 'Content-Type' => 'application/json' ], 'body' => wp_json_encode( [ 'contents' => [ [ 'parts' => [ [ 'text' => 'Reply OK only.' ] ] ] ] ] ) ] );
                if ( is_wp_error( $res ) ) { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'error', 'message' => $res->get_error_message() ]; continue; }
                $code = wp_remote_retrieve_response_code( $res );
                $body = json_decode( wp_remote_retrieve_body( $res ), true );
                $msg = $body['error']['message'] ?? 'Aktif';
                if ( $code >= 200 && $code < 300 ) { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'active', 'message' => 'Aktif' ]; }
                else { $rows[] = [ 'label' => $item['label'], 'masked' => $item['masked'], 'status' => 'error', 'message' => wp_trim_words( $msg, 18 ) ]; }
            }
        } else {
            $config = $this->openai_provider_config( $provider );
            if ( ! $config ) { wp_send_json_error( [ 'message' => 'Provider tidak valid.' ], 400 ); }
            foreach ( $config['keys'] as $i => $key ) {
                $masked = $this->mask_api_key( $key );
                if ( $this->is_api_key_blocked( $key ) ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'blocked', 'message' => 'Diblokir lokal' ]; continue; }
                $payload = [ 'model' => $config['model'], 'messages' => [ [ 'role' => 'user', 'content' => 'Reply OK only.' ] ], 'temperature' => 0 ];
                $headers = array_merge( [ 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . trim( $key ) ], is_array( $config['headers'] ?? null ) ? $config['headers'] : [] );
                $res = wp_remote_post( $config['endpoint'], [ 'timeout' => 30, 'headers' => $headers, 'body' => wp_json_encode( $payload ) ] );
                if ( is_wp_error( $res ) ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'error', 'message' => $res->get_error_message() ]; continue; }
                $code = wp_remote_retrieve_response_code( $res );
                $body = json_decode( wp_remote_retrieve_body( $res ), true );
                $msg = $body['error']['message'] ?? $body['message'] ?? 'Aktif';
                if ( $code >= 200 && $code < 300 ) { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'active', 'message' => 'Aktif' ]; }
                else { $rows[] = [ 'label' => 'API #' . ( $i + 1 ), 'masked' => $masked, 'status' => 'error', 'message' => wp_trim_words( $msg, 18 ) ]; }
            }
        }
        wp_send_json_success( [ 'provider' => $provider, 'rows' => $rows ] );
    }

    public function ajax_generate_content() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin memakai generator.' ], 403 );
        }

        $system_prompt = isset( $_POST['systemPrompt'] ) ? wp_unslash( $_POST['systemPrompt'] ) : '';
        $user_text     = isset( $_POST['userText'] ) ? wp_unslash( $_POST['userText'] ) : '';
        $schema_raw    = isset( $_POST['schema'] ) ? wp_unslash( $_POST['schema'] ) : '';
        $use_search    = ! empty( $_POST['useSearch'] ) && $_POST['useSearch'] === '1';
        $schema        = json_decode( $schema_raw, true );
        $ai_provider   = isset( $_POST['aiProvider'] ) ? sanitize_key( wp_unslash( $_POST['aiProvider'] ) ) : 'gemini';
        $prompt_style  = isset( $_POST['promptStyle'] ) ? sanitize_text_field( wp_unslash( $_POST['promptStyle'] ) ) : '';
        $prompt_label  = isset( $_POST['promptLabel'] ) ? sanitize_text_field( wp_unslash( $_POST['promptLabel'] ) ) : '';
        $language_code = isset( $_POST['language'] ) ? sanitize_key( wp_unslash( $_POST['language'] ) ) : '';
        $source_input_raw = isset( $_POST['sourceInput'] ) ? sanitize_textarea_field( wp_unslash( $_POST['sourceInput'] ) ) : '';
        if ( ! in_array( $ai_provider, [ 'gemini', 'grok', 'groqcloud', 'zai', 'openrouter' ], true ) ) { $ai_provider = 'gemini'; }

        if ( empty( $system_prompt ) || empty( $user_text ) || ! is_array( $schema ) ) {
            wp_send_json_error( [ 'message' => 'Payload tidak lengkap atau schema JSON tidak valid.' ], 400 );
        }

        $source_context = $this->fetch_source_text_context( $user_text );
        if ( $source_context !== '' ) {
            $system_prompt .= "

MODE SUMBER URL TERKUNCI (WAJIB DIIKUTI): Server WordPress sudah mengambil teks artikel sumber dan melampirkannya di input. Gunakan HANYA teks sumber hasil ekstraksi server sebagai dasar fakta. Jangan mengandalkan memori model, hasil pencarian lain, atau asumsi. Semua tanggal, waktu, angka, nama narasumber, jabatan, lokasi, dan kutipan langsung wajib sama persis dengan teks sumber. Jika sebuah data tidak ada di teks sumber, jangan tulis data tersebut. DILARANG membuat tanggal default, tanggal hari ini, atau tanggal acak. Kutipan langsung di dalam tanda petik harus disalin verbatim dari sumber, bukan diparafrase. Untuk menghindari duplikasi konten, paragraf narasi di luar kutipan WAJIB ditulis ulang secara unik: ubah struktur kalimat, urutan penjelasan, dan pilihan kata tanpa mengubah fakta. Jangan menyalin paragraf sumber secara utuh atau berurutan sama persis. Parafrase hanya boleh untuk narasi, bukan untuk kutipan, angka, tanggal, nama, lokasi, atau jabatan.

MODE KORELASI MULTI-SUMBER CERDAS: Jika ada lebih dari satu SUMBER, jangan mengikuti urutan URL sebagai penentu utama. Anggap semua sumber sebagai bahan sejajar. Sebelum menulis, buat analisis internal: (1) fakta yang muncul di lebih dari satu sumber, (2) fakta unik tiap sumber, (3) perbedaan atau konflik informasi, (4) sudut pandang paling layak diberitakan berdasarkan nilai berita, dampak publik, kebaruan, kejelasan bukti, dan kekuatan irisan fakta antarsumber. Pilih angle artikel dari hasil korelasi tersebut, bukan dari sumber pertama. Jika satu sumber hanya memberi konteks pendukung, tempatkan sebagai latar. Jika sumber berbeda fokus, satukan menjadi artikel sintesis yang koheren tanpa memaksakan semua detail. Jika ada konflik, tulis secara hati-hati sebagai perbedaan informasi, jangan membuat kesimpulan yang tidak didukung sumber. References wajib memuat semua URL sumber yang benar-benar dipakai.";
            $user_text .= $source_context;
            $use_search = false;
        }

        $provider_fallback_error = null;
        $provider_fallback_attempts = [];
        $fallback_from_provider = '';
        if ( $ai_provider !== 'gemini' ) {
            $provider_result = $this->call_openai_compatible_json( $ai_provider, $system_prompt, $user_text, $schema );
            if ( ! is_wp_error( $provider_result ) ) {
                $result_clean = $this->sanitize_ai_json_result( $provider_result['result'], $schema );
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result_clean['titleOptions'] ?? null ) ? ( $result_clean['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => $ai_provider,
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                    'source_input' => $source_input_raw ?: $user_text,
                    'prompt_style' => $prompt_style,
                    'prompt_label' => $prompt_label,
                    'language' => $language_code,
                ] );
                wp_send_json_success( [
                    'result'          => $result_clean,
                    'provider_used'   => $ai_provider,
                    'provider_label'  => $provider_result['provider_label'],
                    'api_index_used'  => $provider_result['api_index_used'],
                    'round_used'      => $provider_result['round_used'],
                    'attempts'        => $provider_result['attempts'],
                    'source_context'  => $source_context ? sanitize_textarea_field( $this->quick_extract_source_plain_text( $user_text ) ) : '',
                    'source_url'      => $this->first_source_url_from_text( $user_text ),
                    'source_urls'     => $this->all_source_urls_from_text( $user_text ),
                    'history_id'      => $history_id,
                ] );
            }

            $data = $provider_result->get_error_data();
            $provider_fallback_error = $provider_result->get_error_message();
            $provider_fallback_attempts = is_array( $data ) && isset( $data['attempts'] ) ? $data['attempts'] : [];
            $fallback_from_provider = $ai_provider;
            // Jangan hentikan proses ketika Grok/Z.AI 401/403/limit. Fallback otomatis ke Gemini jika tersedia.
        }

        $api_key_pool = $this->get_api_key_pool( false );
        if ( empty( $api_key_pool ) ) {
            $msg = 'Tidak ada Gemini API Key aktif. Semua API key mungkin kosong atau sudah diblokir otomatis karena leaked/invalid.';
            if ( $provider_fallback_error ) { $msg = $provider_fallback_error . ' Fallback ke Gemini tidak bisa dilakukan karena tidak ada Gemini API aktif.'; }
            wp_send_json_error( [ 'message' => $msg, 'provider_attempts' => $provider_fallback_attempts ], 400 );
        }

        $model = $this->normalize_model_name( get_option( self::OPTION_MODEL, 'gemini-2.5-flash' ) );
        $model_chain = $this->get_gemini_model_chain( $model );

        foreach ( $model_chain as $cache_model ) {
            $cache_key = $this->gemini_cache_key( $cache_model, $system_prompt, $user_text, $schema, $use_search );
            $cached_result = get_transient( $cache_key );
            if ( is_array( $cached_result ) && ! empty( $cached_result['result'] ) && is_array( $cached_result['result'] ) ) {
                $result = $this->sanitize_ai_json_result( $cached_result['result'], $schema );
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result['titleOptions'] ?? null ) ? ( $result['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => 'gemini',
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                    'source_input' => $source_input_raw ?: $user_text,
                    'prompt_style' => $prompt_style,
                    'prompt_label' => $prompt_label,
                    'language' => $language_code,
                    'cached' => true,
                    'model_used' => $cache_model,
                ] );
                wp_send_json_success( [
                    'result'         => $result,
                    'provider_used'  => 'gemini',
                    'cached'         => true,
                    'model_used'     => $cache_model,
                    'model_chain'    => $model_chain,
                    'source_context' => $source_context ? sanitize_textarea_field( $this->quick_extract_source_plain_text( $user_text ) ) : '',
                    'source_url'     => $this->first_source_url_from_text( $user_text ),
                    'source_urls'    => $this->all_source_urls_from_text( $user_text ),
                    'history_id'     => $history_id,
                ] );
            }
        }

        $last_error = 'Request Gemini gagal.';
        $last_status = 500;
        $attempts = [];
        $max_rounds = 3;

        foreach ( $model_chain as $try_model ) {
            $payload = $this->build_gemini_payload( $try_model, $system_prompt, $user_text, $schema, $use_search );
            $cache_key = $this->gemini_cache_key( $try_model, $system_prompt, $user_text, $schema, $use_search );
            for ( $round = 1; $round <= $max_rounds; $round++ ) {
                $round_has_retryable_error = false;

                foreach ( $api_key_pool as $index => $api_item ) {
                $api_key = $api_item['key'];
                $api_label = $api_item['label'] ?? ( 'API #' . ( $index + 1 ) );
                if ( $this->is_api_key_blocked( $api_key ) ) {
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => 'skipped', 'retryable' => false, 'blocked' => true, 'message' => 'API key sudah masuk daftar blokir otomatis.' ];
                    continue;
                }
                $endpoint = sprintf(
                    'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
                    rawurlencode( $try_model ),
                    rawurlencode( $api_key )
                );

                $response = wp_remote_post( $endpoint, [
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'timeout' => 120,
                    'body'    => wp_json_encode( $payload ),
                ] );

                if ( is_wp_error( $response ) ) {
                    $last_error = $response->get_error_message();
                    $last_status = 500;
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => 'wp_error', 'retryable' => true, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $code = wp_remote_retrieve_response_code( $response );
                $body = wp_remote_retrieve_body( $response );
                $decoded = json_decode( $body, true );
                $last_status = $code ?: 500;

                if ( $code < 200 || $code >= 300 ) {
                    $last_error = $decoded['error']['message'] ?? 'Request Gemini gagal.';
                    $blockable = $this->is_blockable_gemini_api_key_error( $code, $last_error );
                    if ( $blockable ) {
                        $this->block_api_key( $api_key, $last_error );
                        $attempts[] = [
                            'round' => $round,
                            'api_index' => $index + 1,
                            'api_label' => $api_label,
                            'status' => $code,
                            'retryable' => false,
                            'blocked' => true,
                            'message' => $last_error,
                        ];
                        continue;
                    }
                    $retryable = $this->is_retryable_gemini_error( $code, $last_error );
                    if ( $retryable ) {
                        $round_has_retryable_error = true;
                    }
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => $code, 'retryable' => $retryable, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $result = $this->extract_json_from_text( $text );
                if ( ! is_array( $result ) ) {
                    $last_error = 'Respons Gemini bukan JSON valid.';
                    $round_has_retryable_error = true;
                    $attempts[] = [ 'model' => $try_model, 'round' => $round, 'api_index' => $index + 1, 'api_label' => $api_label, 'status' => $code, 'retryable' => true, 'blocked' => false, 'message' => $last_error ];
                    continue;
                }

                $result = $this->sanitize_ai_json_result( $result, $schema );
                set_transient( $cache_key, [ 'result' => $result, 'timestamp' => time(), 'model' => $try_model ], HOUR_IN_SECONDS );
                $history_id = $this->add_history_event( [
                    'title'      => is_array( $result['titleOptions'] ?? null ) ? ( $result['titleOptions'][0] ?? '' ) : '',
                    'source_url' => $this->first_source_url_from_text( $user_text ),
                    'source_urls'=> $this->all_source_urls_from_text( $user_text ),
                    'provider'   => 'gemini',
                    'status'     => 'generated',
                    'draft_status' => 'not_sent',
                    'source_input' => $source_input_raw ?: $user_text,
                    'prompt_style' => $prompt_style,
                    'prompt_label' => $prompt_label,
                    'language' => $language_code,
                    'cached' => false,
                    'model_used' => $try_model,
                ] );
                wp_send_json_success( [
                    'result'         => $result,
                    'provider_used'  => 'gemini',
                    'fallback_from'  => $fallback_from_provider,
                    'fallback_error' => $provider_fallback_error,
                    'provider_attempts' => $provider_fallback_attempts,
                    'api_index_used' => $index + 1,
                    'api_label_used' => $api_label,
                    'round_used'     => $round,
                    'attempts'       => count( $attempts ) + 1,
                    'cached'        => false,
                    'model_used'    => $try_model,
                    'source_context' => $source_context ? sanitize_textarea_field( $this->quick_extract_source_plain_text( $user_text ) ) : '',
                    'source_url'     => $this->first_source_url_from_text( $user_text ),
                    'source_urls'    => $this->all_source_urls_from_text( $user_text ),
                    'history_id'     => $history_id,
                ] );
            }

            if ( ! $round_has_retryable_error || $round >= $max_rounds ) {
                break;
            }

            sleep( $this->retry_delay_seconds( $round ) );
            }
            // If this model failed because of retryable overload/limit, try the next fallback model.
        }

        $friendly_message = $last_error;
        if ( $provider_fallback_error ) {
            $friendly_message = $provider_fallback_error . ' Fallback ke Gemini juga belum berhasil: ' . $last_error;
        }
        if ( $this->is_blockable_gemini_api_key_error( $last_status, $last_error ) ) {
            $friendly_message = 'API key terakhir ditolak permanen oleh Gemini dan sudah diblokir otomatis. Plugin akan memakai API aktif lain pada request berikutnya. Tambahkan API key baru jika semua key sudah terblokir.';
        } elseif ( $this->is_retryable_gemini_error( $last_status, $last_error ) ) {
            $friendly_message = 'Gemini sedang sibuk/limit sementara. Plugin sudah mencoba ulang dan merotasi API key, tapi belum berhasil. Silakan klik Generate Ulang beberapa saat lagi.';
        }
        if ( $provider_fallback_error ) {
            $friendly_message = $provider_fallback_error . ' Fallback ke Gemini juga belum berhasil: ' . $friendly_message;
        }

        wp_send_json_error( [
            'message'  => $friendly_message,
            'raw_message' => $last_error,
            'status'   => $last_status,
            'attempts' => $attempts,
            'provider_attempts' => $provider_fallback_attempts,
            'model_chain' => isset( $model_chain ) ? $model_chain : [],
        ], $last_status );
    }



    private function optimize_downloaded_source_image( $tmp, $filename ) {
        if ( ! $tmp || ! file_exists( $tmp ) ) {
            return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
        }

        if ( ! function_exists( 'wp_get_image_editor' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $dir = dirname( $tmp );
        $base = pathinfo( $filename, PATHINFO_FILENAME );
        $base = sanitize_file_name( $base ? $base : 'he-source-image' );
        $target_width = 1200;
        $target_bytes = 102400; // 100KB.
        $supports_webp = function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( [ 'mime_type' => 'image/webp' ] );

        $best_path = '';
        $best_bytes = 0;
        $best_width = 0;
        $best_quality = 0;
        $try_widths = [ 1200, 1100, 1000, 900, 800, 720, 640 ];
        $try_qualities = [ 82, 76, 70, 64, 58, 52, 46, 40, 34 ];

        if ( $supports_webp ) {
            foreach ( $try_widths as $width_limit ) {
                foreach ( $try_qualities as $quality ) {
                    $editor = wp_get_image_editor( $tmp );
                    if ( is_wp_error( $editor ) ) { continue; }
                    $size = $editor->get_size();
                    if ( ! empty( $size['width'] ) && (int) $size['width'] > $width_limit ) {
                        $editor->resize( $width_limit, null, false );
                    }
                    if ( method_exists( $editor, 'set_quality' ) ) {
                        $editor->set_quality( $quality );
                    }
                    $candidate_filename = wp_unique_filename( $dir, $base . '-w' . $width_limit . '-q' . $quality . '.webp' );
                    $candidate_path = trailingslashit( $dir ) . $candidate_filename;
                    $saved = $editor->save( $candidate_path, 'image/webp' );
                    if ( is_wp_error( $saved ) || empty( $saved['path'] ) || ! file_exists( $saved['path'] ) ) { continue; }

                    $bytes = (int) filesize( $saved['path'] );
                    $saved_size = @getimagesize( $saved['path'] );
                    $saved_width = isset( $saved_size[0] ) ? (int) $saved_size[0] : $width_limit;
                    if ( $saved_width > $target_width ) {
                        @unlink( $saved['path'] );
                        continue;
                    }

                    if ( $best_path === '' || $bytes < $best_bytes || ( $best_bytes > $target_bytes && $bytes < $best_bytes ) ) {
                        if ( $best_path && file_exists( $best_path ) ) { @unlink( $best_path ); }
                        $best_path = $saved['path'];
                        $best_bytes = $bytes;
                        $best_width = $saved_width;
                        $best_quality = $quality;
                    } else {
                        @unlink( $saved['path'] );
                    }

                    if ( $bytes > 0 && $bytes <= $target_bytes ) {
                        @unlink( $tmp );
                        return [
                            'tmp'       => $best_path,
                            'filename'  => basename( $best_path ),
                            'optimized' => true,
                            'format'    => 'webp',
                            'bytes'     => $best_bytes,
                            'width'     => $best_width,
                            'quality'   => $best_quality,
                        ];
                    }
                }
            }

            if ( $best_path && file_exists( $best_path ) ) {
                @unlink( $tmp );
                return [
                    'tmp'       => $best_path,
                    'filename'  => basename( $best_path ),
                    'optimized' => true,
                    'format'    => 'webp',
                    'bytes'     => $best_bytes,
                    'width'     => $best_width,
                    'quality'   => $best_quality,
                    'warning'   => $best_bytes > $target_bytes ? 'WebP sudah dikompres maksimal, tetapi masih di atas 100KB.' : '',
                ];
            }
        }

        // Fallback jika server belum mendukung WebP: tetap batasi lebar dan kompres format asli.
        $editor = wp_get_image_editor( $tmp );
        if ( is_wp_error( $editor ) ) {
            return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
        }
        $size = $editor->get_size();
        if ( ! empty( $size['width'] ) && (int) $size['width'] > $target_width ) {
            $editor->resize( $target_width, null, false );
        }
        if ( method_exists( $editor, 'set_quality' ) ) {
            $editor->set_quality( 72 );
        }
        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        if ( ! $ext ) { $ext = 'jpg'; }
        $fallback_filename = wp_unique_filename( $dir, $base . '-optimized.' . $ext );
        $fallback_path = trailingslashit( $dir ) . $fallback_filename;
        $saved = $editor->save( $fallback_path );
        if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && file_exists( $saved['path'] ) ) {
            @unlink( $tmp );
            return [ 'tmp' => $saved['path'], 'filename' => basename( $saved['path'] ), 'optimized' => true, 'format' => 'fallback', 'warning' => 'Server belum mendukung WebP.' ];
        }

        return [ 'tmp' => $tmp, 'filename' => $filename, 'optimized' => false, 'format' => 'original' ];
    }

    private function source_image_download_attempt_urls( $image_url ) {
        $image_url = esc_url_raw( $image_url );
        if ( ! $image_url ) { return []; }
        $urls = [ $image_url ];
        $parts = wp_parse_url( $image_url );
        $scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
        if ( $scheme === 'https' ) { $urls[] = preg_replace( '#^https://#i', 'http://', $image_url ); }
        if ( $scheme === 'http' ) { $urls[] = preg_replace( '#^http://#i', 'https://', $image_url ); }
        if ( stripos( $image_url, 'cdn.trendhunterstatic.com/' ) !== false ) {
            foreach ( [ '_468.', '_120.' ] as $from ) {
                foreach ( [ '_468.', '_120.' ] as $to ) {
                    if ( $from !== $to && strpos( $image_url, $from ) !== false ) { $urls[] = str_replace( $from, $to, $image_url ); }
                }
            }
            $more = [];
            foreach ( $urls as $u ) {
                if ( stripos( $u, 'https://' ) === 0 ) { $more[] = preg_replace( '#^https://#i', 'http://', $u ); }
                if ( stripos( $u, 'http://' ) === 0 ) { $more[] = preg_replace( '#^http://#i', 'https://', $u ); }
            }
            $urls = array_merge( $urls, $more );
        }
        return array_values( array_unique( array_filter( array_map( 'esc_url_raw', $urls ) ) ) );
    }

    private function download_source_image_to_temp( $image_url, $referer = '' ) {
        $attempt_urls = $this->source_image_download_attempt_urls( $image_url );
        if ( empty( $attempt_urls ) ) { return new WP_Error( 'heaj_image_bad_url', 'URL gambar sumber tidak valid.' ); }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $last_error = '';
        foreach ( $attempt_urls as $attempt_url ) {
            $tmp = download_url( $attempt_url, 30 );
            if ( ! is_wp_error( $tmp ) && $tmp && file_exists( $tmp ) && filesize( $tmp ) > 0 ) {
                return [ 'tmp' => $tmp, 'url' => $attempt_url ];
            }
            if ( is_wp_error( $tmp ) ) { $last_error = $tmp->get_error_message(); }

            $headers = [
                'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari YZG-AI-Journalist/' . self::VERSION,
                'Accept'          => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.9,id;q=0.8',
            ];
            if ( $referer ) { $headers['Referer'] = esc_url_raw( $referer ); }
            $response = wp_remote_get( $attempt_url, [
                'timeout'     => 30,
                'redirection' => 5,
                'headers'     => $headers,
            ] );
            if ( is_wp_error( $response ) ) { $last_error = $response->get_error_message(); continue; }
            $code = (int) wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            $content_type = strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) );
            if ( $code < 200 || $code >= 300 || ! is_string( $body ) || strlen( $body ) < 500 ) {
                $last_error = 'HTTP ' . $code . ' saat mengambil gambar sumber.';
                continue;
            }
            if ( $content_type && strpos( $content_type, 'image/' ) === false && @getimagesizefromstring( $body ) === false ) {
                $last_error = 'Response gambar bukan image valid.';
                continue;
            }
            $tmp_name = wp_tempnam( $attempt_url );
            if ( ! $tmp_name ) { $last_error = 'Gagal membuat file temporary untuk gambar.'; continue; }
            if ( file_put_contents( $tmp_name, $body ) === false ) {
                @unlink( $tmp_name );
                $last_error = 'Gagal menyimpan file temporary gambar.';
                continue;
            }
            return [ 'tmp' => $tmp_name, 'url' => $attempt_url ];
        }
        return new WP_Error( 'heaj_image_download_failed', $last_error ?: 'Gagal download gambar sumber dari semua URL percobaan.' );
    }

    private function sideload_featured_image( $image_url, $post_id, $title = '', $caption = '' ) {
        $image_url = esc_url_raw( $image_url );
        if ( ! $image_url || ! $post_id ) {
            return new WP_Error( 'heaj_featured_image_invalid', 'URL featured image tidak valid.' );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $downloaded = $this->download_source_image_to_temp( $image_url );
        if ( is_wp_error( $downloaded ) ) { return $downloaded; }
        $tmp = $downloaded['tmp'];
        $image_url = esc_url_raw( $downloaded['url'] );

        $path = wp_parse_url( $image_url, PHP_URL_PATH );
        $filename = sanitize_file_name( basename( (string) $path ) );
        if ( ! $filename || strpos( $filename, '.' ) === false ) {
            $filename = 'he-source-image-' . time() . '.jpg';
        }

        $optimized = $this->optimize_downloaded_source_image( $tmp, $filename );
        $tmp = $optimized['tmp'];
        $filename = $optimized['filename'];

        $file_array = [
            'name'     => $filename,
            'tmp_name' => $tmp,
        ];

        $attachment_id = media_handle_sideload( $file_array, $post_id, $caption ?: $title );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            return $attachment_id;
        }
        $alt_text = $caption ? $caption : $title;
        if ( $alt_text ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt_text ) );
        }
        if ( $caption ) {
            wp_update_post( [
                'ID' => $attachment_id,
                'post_excerpt' => $caption,
            ] );
        }
        update_post_meta( $attachment_id, '_he_source_image_original_url', $image_url );
        update_post_meta( $attachment_id, '_he_source_image_optimized', ! empty( $optimized['optimized'] ) ? '1' : '0' );
        update_post_meta( $attachment_id, '_he_source_image_format', sanitize_text_field( $optimized['format'] ) );
        return $attachment_id;
    }


    private function heaj_social_tmp_image_from_url( $url ) {
        $url = esc_url_raw( $url );
        if ( ! $url ) { return new WP_Error( 'heaj_social_bad_url', 'URL gambar tidak valid.' ); }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $tmp = download_url( $url, 30 );
        if ( is_wp_error( $tmp ) ) { return $tmp; }
        $raw = @file_get_contents( $tmp );
        if ( ! $raw ) {
            @unlink( $tmp );
            return new WP_Error( 'heaj_social_empty_image', 'Gambar tidak bisa dibaca.' );
        }
        $img = @imagecreatefromstring( $raw );
        @unlink( $tmp );
        if ( ! $img ) {
            return new WP_Error( 'heaj_social_unsupported_image', 'Format gambar tidak didukung server. Gunakan JPG/PNG/WebP, bukan SVG.' );
        }
        imagepalettetotruecolor( $img );
        imagesavealpha( $img, true );
        return $img;
    }


    private function heaj_social_tmp_image_from_local_file( $file ) {
        $path = '';
        if ( is_array( $file ) ) {
            $path = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
        } else {
            $path = (string) $file;
        }
        if ( ! $path || ! file_exists( $path ) ) {
            return new WP_Error( 'heaj_social_manual_missing', 'File gambar manual untuk Social Image tidak ditemukan.' );
        }
        $raw = @file_get_contents( $path );
        if ( ! $raw ) {
            return new WP_Error( 'heaj_social_empty_image', 'Gambar manual tidak bisa dibaca.' );
        }
        $img = @imagecreatefromstring( $raw );
        if ( ! $img ) {
            return new WP_Error( 'heaj_social_unsupported_image', 'Format gambar manual tidak didukung server. Gunakan JPG/PNG/WebP, bukan SVG.' );
        }
        if ( function_exists( 'imagepalettetotruecolor' ) ) { @imagepalettetotruecolor( $img ); }
        if ( function_exists( 'imagesavealpha' ) ) { @imagesavealpha( $img, true ); }
        return $img;
    }

    private function heaj_social_ensure_runtime_fonts() {
        static $runtime_dir = null;
        if ( $runtime_dir !== null ) { return $runtime_dir; }
        $runtime_dir = '';
        if ( ! function_exists( 'wp_upload_dir' ) ) { return ''; }
        $upload = wp_upload_dir();
        if ( ! empty( $upload['error'] ) || empty( $upload['basedir'] ) ) { return ''; }
        $dir = trailingslashit( $upload['basedir'] ) . 'heaj-fonts';
        if ( ! wp_mkdir_p( $dir ) || ! is_writable( $dir ) ) { return ''; }

        $fonts = [
            'HEAJ-Oswald.ttf' => [
                'https://raw.githubusercontent.com/google/fonts/main/ofl/oswald/Oswald%5Bwght%5D.ttf',
                'https://github.com/google/fonts/raw/main/ofl/oswald/Oswald%5Bwght%5D.ttf',
            ],
            'HEAJ-BebasNeue-Regular.ttf' => [
                'https://raw.githubusercontent.com/google/fonts/main/ofl/bebasneue/BebasNeue-Regular.ttf',
                'https://github.com/google/fonts/raw/main/ofl/bebasneue/BebasNeue-Regular.ttf',
            ],
        ];
        $all_ready = true;
        foreach ( $fonts as $filename => $urls ) {
            $target = trailingslashit( $dir ) . sanitize_file_name( $filename );
            if ( file_exists( $target ) && filesize( $target ) > 10000 ) { continue; }
            $all_ready = false;
            require_once ABSPATH . 'wp-admin/includes/file.php';
            foreach ( $urls as $url ) {
                $tmp = download_url( esc_url_raw( $url ), 30 );
                if ( is_wp_error( $tmp ) || ! $tmp || ! file_exists( $tmp ) ) { continue; }
                $bytes = (int) filesize( $tmp );
                $raw_head = @file_get_contents( $tmp, false, null, 0, 4 );
                $looks_like_font = ( $raw_head === "\x00\x01\x00\x00" || $raw_head === 'OTTO' || $raw_head === 'ttcf' );
                if ( $bytes > 10000 && $looks_like_font ) {
                    @copy( $tmp, $target );
                    @unlink( $tmp );
                    break;
                }
                @unlink( $tmp );
            }
        }
        $runtime_dir = trailingslashit( $dir );
        return $runtime_dir;
    }

    private function heaj_social_font( $bold = false, $italic = false ) {
        $upload = function_exists( 'wp_upload_dir' ) ? wp_upload_dir() : [];
        $runtime_font_dir = $this->heaj_social_ensure_runtime_fonts();
        $base_dirs = [
            plugin_dir_path( __FILE__ ) . 'assets/fonts/',
            $runtime_font_dir,
            ! empty( $upload['basedir'] ) ? trailingslashit( $upload['basedir'] ) . 'heaj-fonts/' : '',
            defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/fonts/' : '',
            function_exists( 'get_stylesheet_directory' ) ? trailingslashit( get_stylesheet_directory() ) . 'assets/fonts/' : '',
            function_exists( 'get_template_directory' ) ? trailingslashit( get_template_directory() ) . 'assets/fonts/' : '',
            ABSPATH . 'wp-includes/fonts/',
            '/usr/share/fonts/truetype/dejavu/',
            '/usr/share/fonts/truetype/liberation/',
            '/usr/share/fonts/truetype/liberation2/',
            '/usr/share/fonts/dejavu/',
            '/usr/local/share/fonts/',
            '/usr/share/fonts/TTF/',
            '/usr/share/fonts/',
        ];
        $base_dirs = array_values( array_unique( array_filter( array_map( 'trailingslashit', $base_dirs ) ) ) );

        if ( $bold && $italic ) {
            $names = [
                'DejaVuSansCondensed-BoldOblique.ttf', 'DejaVuSans-BoldOblique.ttf',
                'LiberationSans-BoldItalic.ttf', 'LiberationSans-BoldOblique.ttf',
                'Arial Bold Italic.ttf', 'Arial_Bold_Italic.ttf', 'NotoSans-BoldItalic.ttf',
                'Roboto-BoldItalic.ttf', 'OpenSans-BoldItalic.ttf', 'Inter-BoldItalic.ttf',
                'HEAJ-BebasNeue-Regular.ttf', 'HEAJ-Oswald.ttf', 'NotoSans-Bold.ttf', 'DejaVuSansCondensed-Bold.ttf', 'DejaVuSans-Bold.ttf',
            ];
            $regex = '/(bold|black|heavy).*(italic|oblique)|(italic|oblique).*(bold|black|heavy)/i';
        } elseif ( $bold ) {
            $names = [
                'DejaVuSansCondensed-Bold.ttf', 'DejaVuSans-Bold.ttf',
                'LiberationSans-Bold.ttf', 'Arial Bold.ttf', 'Arial_Bold.ttf',
                'NotoSans-Bold.ttf', 'NotoSansDisplay-Bold.ttf', 'Roboto-Bold.ttf',
                'OpenSans-Bold.ttf', 'Inter-Bold.ttf', 'HEAJ-Oswald.ttf', 'HEAJ-BebasNeue-Regular.ttf',
            ];
            $regex = '/(bold|black|heavy|semibold|demibold)/i';
        } else {
            $names = [
                'DejaVuSansCondensed.ttf', 'DejaVuSans.ttf',
                'LiberationSans-Regular.ttf', 'Arial.ttf', 'NotoSans-Regular.ttf',
                'NotoSansDisplay-Regular.ttf', 'Roboto-Regular.ttf', 'OpenSans-Regular.ttf',
                'Inter-Regular.ttf', 'HEAJ-Oswald.ttf',
            ];
            $regex = '/(regular|book|normal|roman|sans).*\.(ttf|otf)$/i';
        }

        foreach ( $base_dirs as $dir ) {
            foreach ( $names as $name ) {
                $font = $dir . $name;
                if ( $font && file_exists( $font ) && is_readable( $font ) ) { return $font; }
            }
        }

        foreach ( $base_dirs as $dir ) {
            if ( ! is_dir( $dir ) || ! is_readable( $dir ) ) { continue; }
            $checked = 0;
            try {
                $it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
                foreach ( $it as $file ) {
                    if ( $checked++ > 500 ) { break; }
                    if ( ! $file->isFile() ) { continue; }
                    $path = $file->getPathname();
                    if ( ! preg_match( '/\.(ttf|otf)$/i', $path ) || ! is_readable( $path ) ) { continue; }
                    $basename = basename( $path );
                    if ( preg_match( $regex, $basename ) ) { return $path; }
                }
            } catch ( Exception $e ) {
                continue;
            }
        }
        return '';
    }

    private function heaj_social_text_box_width( $font, $size, $text ) {
        if ( $font && function_exists( 'imagettfbbox' ) ) {
            $box = imagettfbbox( $size, 0, $font, $text );
            if ( is_array( $box ) ) { return abs( $box[2] - $box[0] ); }
        }
        // GD bitmap fallback must be scaled to requested pseudo-TTF size, otherwise headline becomes tiny.
        return (int) ceil( strlen( $text ) * imagefontwidth( 5 ) * max( 1, $size / 12 ) );
    }

    private function heaj_social_wrap_text( $text, $font, $size, $max_width, $max_lines = 4, $ellipsis = true ) {
        $text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $text ) ) );
        if ( $text === '' ) { return []; }
        $words = preg_split( '/\s+/', $text );
        $lines = [];
        $line = '';
        foreach ( $words as $word ) {
            $test = $line === '' ? $word : $line . ' ' . $word;
            if ( $this->heaj_social_text_box_width( $font, $size, $test ) <= $max_width || $line === '' ) {
                $line = $test;
            } else {
                $lines[] = $line;
                $line = $word;
            }
        }
        if ( $line !== '' ) { $lines[] = $line; }
        if ( count( $lines ) <= $max_lines ) { return $lines; }
        if ( ! $ellipsis ) { return $lines; }
        $lines = array_slice( $lines, 0, $max_lines );
        $last = $lines[ $max_lines - 1 ];
        while ( $this->heaj_social_text_box_width( $font, $size, $last . '…' ) > $max_width && strlen( $last ) > 8 ) {
            $last = preg_replace( '/\s+?\S+$/', '', $last );
            if ( ! $last ) { break; }
        }
        $lines[ $max_lines - 1 ] = rtrim( $last, '.,;:- ' ) . '…';
        return $lines;
    }

    private function heaj_social_fit_text_layout( $text, $font, $start_size, $min_size, $max_width, $max_lines = 4, $line_height = 1.16, $ellipsis = true ) {
        $start_size = (int) $start_size;
        $min_size = (int) $min_size;
        if ( $start_size < $min_size ) { $start_size = $min_size; }
        for ( $size = $start_size; $size >= $min_size; $size -= 2 ) {
            $lines = $this->heaj_social_wrap_text( $text, $font, $size, $max_width, $max_lines, false );
            if ( count( $lines ) <= $max_lines ) {
                $line_px = (int) round( $size * $line_height );
                return [
                    'size' => $size,
                    'lines' => $lines,
                    'line_px' => $line_px,
                    'height' => count( $lines ) * $line_px,
                ];
            }
        }
        $size = $min_size;
        $lines = $this->heaj_social_wrap_text( $text, $font, $size, $max_width, $max_lines, $ellipsis );
        $line_px = (int) round( $size * $line_height );
        return [
            'size' => $size,
            'lines' => $lines,
            'line_px' => $line_px,
            'height' => count( $lines ) * $line_px,
        ];
    }

    private function heaj_social_draw_lines( $canvas, $lines, $x, $y, $size, $color, $font = '', $line_height = 1.16, $shadow = false ) {
        $line_px = (int) round( $size * $line_height );
        foreach ( (array) $lines as $i => $line ) {
            $yy = $y + ( $i * $line_px );
            if ( $font && function_exists( 'imagettftext' ) ) {
                if ( $shadow ) {
                    $shadow_col = imagecolorallocatealpha( $canvas, 0, 0, 0, 42 );
                    imagettftext( $canvas, $size, 0, $x + 3, $yy + 4, $shadow_col, $font, $line );
                }
                imagettftext( $canvas, $size, 0, $x, $yy, $color, $font, $line );
                if ( $size >= 38 ) { imagettftext( $canvas, $size, 0, $x + 1, $yy, $color, $font, $line ); }
            } else {
                $scale = max( 2, (int) round( $size / 10 ) );
                $tw = max( 1, strlen( $line ) * imagefontwidth( 5 ) + 6 );
                $th = imagefontheight( 5 ) + 6;
                $tmp = imagecreatetruecolor( $tw, $th );
                imagesavealpha( $tmp, true );
                $transparent = imagecolorallocatealpha( $tmp, 0, 0, 0, 127 );
                imagefill( $tmp, 0, 0, $transparent );
                imagestring( $tmp, 5, 3, 3, $line, $color );
                imagecopyresampled( $canvas, $tmp, $x, $yy - $size, 0, 0, $tw * $scale, $th * $scale, $tw, $th );
                imagedestroy( $tmp );
            }
        }
        return count( $lines ) ? $y + ( count( $lines ) * $line_px ) : $y;
    }

    private function heaj_social_draw_text( $canvas, $text, $x, $y, $size, $color, $font = '', $line_height = 1.16, $max_width = 800, $max_lines = 4, $shadow = false, $min_size = 0 ) {
        $fit = $this->heaj_social_fit_text_layout( $text, $font, $size, $min_size > 0 ? $min_size : max( 10, (int) round( $size * 0.65 ) ), $max_width, $max_lines, $line_height, true );
        return $this->heaj_social_draw_lines( $canvas, $fit['lines'], $x, $y, $fit['size'], $color, $font, $line_height, $shadow );
    }

    private function heaj_social_overlay_rect( $canvas, $x1, $y1, $x2, $y2, $r, $g, $b, $alpha ) {
        imagefilledrectangle( $canvas, (int) $x1, (int) $y1, (int) $x2, (int) $y2, imagecolorallocatealpha( $canvas, $r, $g, $b, max( 0, min( 127, (int) $alpha ) ) ) );
    }

    private function heaj_social_cover_image( $canvas, $src, $dst_x, $dst_y, $dst_w, $dst_h ) {
        $sw = imagesx( $src ); $sh = imagesy( $src );
        if ( ! $sw || ! $sh ) { return; }
        $scale = max( $dst_w / $sw, $dst_h / $sh );
        $cw = (int) round( $dst_w / $scale );
        $ch = (int) round( $dst_h / $scale );
        $sx = max( 0, (int) floor( ( $sw - $cw ) / 2 ) );
        $sy = max( 0, (int) floor( ( $sh - $ch ) / 2 ) );
        imagecopyresampled( $canvas, $src, $dst_x, $dst_y, $sx, $sy, $dst_w, $dst_h, $cw, $ch );
    }

    private function heaj_social_hex_color( $hex, $fallback = '#e30613' ) {
        $hex = trim( (string) $hex );
        if ( ! preg_match( '/^#?[0-9a-fA-F]{6}$/', $hex ) ) { $hex = $fallback; }
        $hex = ltrim( $hex, '#' );
        return [ hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) ];
    }


    private function heaj_social_site_host() {
        $host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
        $host = preg_replace( '/^www\./i', '', $host );
        return $host ?: 'website.com';
    }

    private function heaj_social_reference_template_url( $platform, $brand = [] ) {
        if ( empty( $brand ) ) {
            $brand = $this->get_brand_settings();
        }
        $map = [
            'instagram' => $brand['social_template_instagram_url'] ?? '',
            'pinterest' => $brand['social_template_pinterest_url'] ?? '',
            'linkedin'  => $brand['social_template_linkedin_url'] ?? '',
        ];
        $url = esc_url_raw( $map[ $platform ] ?? '' );
        if ( ! $url ) {
            $fallbacks = [
                $brand['social_template_instagram_url'] ?? '',
                $brand['social_template_pinterest_url'] ?? '',
                $brand['social_template_linkedin_url'] ?? '',
            ];
            foreach ( $fallbacks as $candidate ) {
                $candidate = esc_url_raw( $candidate );
                if ( $candidate ) { $url = $candidate; break; }
            }
        }
        return $url;
    }

    private function heaj_social_fetch_media_part( $url ) {
        $url = esc_url_raw( $url );
        if ( ! $url ) {
            return new WP_Error( 'heaj_social_bad_url', 'URL gambar tidak valid.' );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $tmp = download_url( $url, 30 );
        if ( is_wp_error( $tmp ) ) { return $tmp; }
        $bytes = @file_get_contents( $tmp );
        if ( ! $bytes ) {
            @unlink( $tmp );
            return new WP_Error( 'heaj_social_empty_image', 'Gambar tidak bisa dibaca.' );
        }
        $mime = '';
        if ( function_exists( 'mime_content_type' ) ) {
            $mime = (string) @mime_content_type( $tmp );
        }
        if ( ! $mime && function_exists( 'finfo_open' ) ) {
            $finfo = @finfo_open( FILEINFO_MIME_TYPE );
            if ( $finfo ) {
                $mime = (string) @finfo_file( $finfo, $tmp );
                @finfo_close( $finfo );
            }
        }
        if ( ! $mime ) {
            $path = (string) wp_parse_url( $url, PHP_URL_PATH );
            $ft = wp_check_filetype( basename( $path ) );
            $mime = (string) ( $ft['type'] ?? '' );
        }
        @unlink( $tmp );
        $mime = strtolower( trim( $mime ) );
        $allowed = [ 'image/jpeg', 'image/jpg', 'image/png', 'image/webp' ];
        if ( ! in_array( $mime, $allowed, true ) ) {
            return new WP_Error( 'heaj_social_unsupported_image', 'Format gambar referensi belum didukung untuk Gemini. Gunakan JPG/PNG/WebP, bukan SVG.' );
        }
        if ( $mime === 'image/jpg' ) { $mime = 'image/jpeg'; }
        return [
            'mime_type' => $mime,
            'data'      => base64_encode( $bytes ),
        ];
    }


    private function heaj_social_fetch_media_part_from_local_file( $file ) {
        $path = '';
        $mime = '';
        if ( is_array( $file ) ) {
            $path = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
            $mime = isset( $file['type'] ) ? (string) $file['type'] : '';
        } else {
            $path = (string) $file;
        }
        if ( ! $path || ! file_exists( $path ) ) {
            return new WP_Error( 'heaj_social_manual_missing', 'File gambar manual untuk Social Image tidak ditemukan.' );
        }
        $bytes = @file_get_contents( $path );
        if ( ! $bytes ) {
            return new WP_Error( 'heaj_social_empty_image', 'Gambar manual tidak bisa dibaca.' );
        }
        if ( ! $mime && function_exists( 'mime_content_type' ) ) {
            $mime = (string) @mime_content_type( $path );
        }
        if ( ! $mime && function_exists( 'finfo_open' ) ) {
            $finfo = @finfo_open( FILEINFO_MIME_TYPE );
            if ( $finfo ) {
                $mime = (string) @finfo_file( $finfo, $path );
                @finfo_close( $finfo );
            }
        }
        if ( ! $mime ) {
            $ft = wp_check_filetype( basename( $path ) );
            $mime = (string) ( $ft['type'] ?? '' );
        }
        $mime = strtolower( trim( $mime ) );
        $allowed = [ 'image/jpeg', 'image/jpg', 'image/png', 'image/webp' ];
        if ( ! in_array( $mime, $allowed, true ) ) {
            return new WP_Error( 'heaj_social_unsupported_image', 'Format gambar manual untuk Social Image harus JPG, PNG, atau WebP.' );
        }
        if ( $mime === 'image/jpg' ) { $mime = 'image/jpeg'; }
        return [
            'mime_type' => $mime,
            'data'      => base64_encode( $bytes ),
        ];
    }

    private function heaj_social_generate_ai_prompt( $platform, $args, $brand, $site_host ) {
        $category = trim( (string) ( $args['category'] ?? 'BERITA' ) );
        $sub = trim( (string) ( $args['sub_category'] ?? '' ) );
        $title = trim( (string) ( $args['title'] ?? '' ) );
        $desc = trim( preg_replace( '/\s+/', ' ', (string) ( $args['description'] ?? '' ) ) );
        $media_name = trim( (string) $this->get_media_name() );
        $layout_map = [
            'instagram' => 'Vertical 4:5 sports/editorial news poster. Main image dominates upper half. Category label at top-left. Huge stacked headline in lower-middle. Short description below. Footer black with thin angular red line, brand logo bottom-left, website bottom-right.',
            'pinterest' => 'Tall 2:3 premium editorial poster. Main image occupies upper portion. Category label at top-left. Big stacked headline in lower-middle. Short description below. Footer black with thin angular red line, brand logo bottom-left, website bottom-right.',
            'linkedin'  => 'Wide horizontal editorial banner close to LinkedIn proportion. Right or center-right main image, dark left panel, category label at top-left, headline max 3 lines, short description below, footer with brand logo left and website right.',
        ];
        $ratio_map = [ 'instagram' => '4:5', 'pinterest' => '2:3', 'linkedin' => '16:9 (crop-safe for LinkedIn 1.91:1)' ];
        $extra = trim( (string) ( $brand['social_image_prompt_extra'] ?? '' ) );
        $prompt = [];
        $prompt[] = 'Create a polished social media news poster for ' . $media_name . '.';
        $prompt[] = 'If image 1 is provided, use it as the style/layout reference. Match its overall design language closely: black background, white typography, strong red accents, halftone red dots on the left, gritty editorial sports-news mood, sharp readable headline, and angular footer line.';
        $prompt[] = 'If image 2 is provided, use it as the main article image / hero subject. Preserve the subject identity and make it the dominant visual.';
        $prompt[] = 'If image 3 is provided, use it as the exact brand logo. Keep the logo unchanged: do not redesign, recolor, stretch, simplify, or alter the text, icon, or proportions.';
        $prompt[] = 'Required layout: ' . ( $layout_map[ $platform ] ?? $layout_map['instagram'] );
        $prompt[] = 'Target aspect ratio: ' . ( $ratio_map[ $platform ] ?? '4:5' ) . '.';
        $prompt[] = 'Render all text cleanly and correctly. Do not invent extra text. Do not corrupt words. Keep all text inside safe margins and keep the face/main subject visible.';
        $prompt[] = 'Use these exact content values:';
        $prompt[] = 'Category label: "' . $category . '"';
        if ( $sub !== '' ) {
            $prompt[] = 'Sub-category text: "' . $sub . '"';
        }
        $prompt[] = 'Headline exact text: "' . $title . '"';
        $prompt[] = 'Description exact text: "' . $desc . '"';
        $prompt[] = 'Website exact text in footer: "' . $site_host . '"';
        $prompt[] = 'Brand name: "' . $media_name . '"';
        if ( $extra !== '' ) {
            $prompt[] = 'Additional mandatory instructions: ' . $extra;
        }
        $prompt[] = 'Avoid cartoon styling, avoid random extra logos, avoid incorrect website text, and avoid placeholder lorem ipsum.';
        return implode( "
", $prompt );
    }

    private function heaj_social_maybe_resize_output( $path, $target_w, $target_h ) {
        $path = (string) $path;
        if ( ! file_exists( $path ) ) { return false; }
        if ( ! function_exists( 'wp_get_image_editor' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $editor = wp_get_image_editor( $path );
        if ( is_wp_error( $editor ) ) {
            return false;
        }
        $result = $editor->resize( (int) $target_w, (int) $target_h, true );
        if ( is_wp_error( $result ) ) {
            return false;
        }
        $saved = $editor->save( $path, 'image/png' );
        return ! is_wp_error( $saved );
    }

    private function heaj_social_is_quota_error( $status, $message = '' ) {
        $message = strtolower( (string) $message );
        return (int) $status === 429
            || strpos( $message, 'quota exceeded' ) !== false
            || strpos( $message, 'current quota' ) !== false
            || strpos( $message, 'free_tier' ) !== false
            || strpos( $message, 'rate-limit' ) !== false
            || strpos( $message, 'rate limits' ) !== false;
    }

    private function heaj_social_filename_slug( $args ) {
        $slug = '';
        if ( isset( $args['slug'] ) ) {
            $slug = sanitize_title( (string) $args['slug'] );
        }
        if ( $slug === '' && ! empty( $args['title'] ) ) {
            $slug = sanitize_title( wp_strip_all_tags( (string) $args['title'] ) );
        }
        if ( $slug === '' ) {
            $slug = 'social-image';
        }
        return $slug;
    }

    private function heaj_social_unique_filename( $dir, $slug, $platform, $ext = 'png' ) {
        $dir = untrailingslashit( (string) $dir );
        $slug = sanitize_title( (string) $slug );
        $platform = sanitize_key( (string) $platform );
        $ext = preg_replace( '/[^a-z0-9]/i', '', strtolower( (string) $ext ) );
        if ( $slug === '' ) { $slug = 'social-image'; }
        if ( $platform === '' ) { $platform = 'image'; }
        if ( $ext === '' ) { $ext = 'png'; }

        // File name follows article slug so it is SEO-friendly and easy to identify:
        // article-slug-instagram.png, article-slug-pinterest.png, article-slug-linkedin.png
        $base = sanitize_file_name( $slug . '-' . $platform . '.' . $ext );
        $candidate = $base;
        $i = 2;
        while ( file_exists( trailingslashit( $dir ) . $candidate ) ) {
            $candidate = sanitize_file_name( $slug . '-' . $platform . '-' . $i . '.' . $ext );
            $i++;
        }
        return $candidate;
    }

    private function heaj_social_compress_png_under_limit( $path, $max_bytes = 204800 ) {
        $path = (string) $path;
        $max_bytes = max( 50000, (int) $max_bytes );

        if ( ! file_exists( $path ) || ! function_exists( 'imagecreatefromstring' ) || ! function_exists( 'imagepng' ) ) {
            return [
                'compressed' => false,
                'bytes'      => file_exists( $path ) ? (int) filesize( $path ) : 0,
                'message'    => 'Kompresi PNG dilewati karena GD tidak lengkap.',
            ];
        }

        clearstatcache( true, $path );
        $raw = @file_get_contents( $path );
        $img = $raw ? @imagecreatefromstring( $raw ) : false;
        if ( ! $img ) {
            return [
                'compressed' => false,
                'bytes'      => (int) filesize( $path ),
                'message'    => 'Gambar tidak bisa dibaca untuk kompresi.',
            ];
        }

        if ( function_exists( 'imagepalettetotruecolor' ) ) { @imagepalettetotruecolor( $img ); }
        if ( function_exists( 'imagesavealpha' ) ) { @imagesavealpha( $img, true ); }

        @imagepng( $img, $path, 9 );
        clearstatcache( true, $path );
        if ( (int) filesize( $path ) <= $max_bytes ) {
            $bytes = (int) filesize( $path );
            imagedestroy( $img );
            return [ 'compressed' => true, 'bytes' => $bytes, 'message' => 'PNG dikompres level 9.' ];
        }

        $w = imagesx( $img );
        $h = imagesy( $img );
        $best_tmp = '';
        $best_bytes = (int) filesize( $path );
        $best_w = $w;
        $best_h = $h;

        foreach ( [ 0.92, 0.84, 0.76, 0.68, 0.60, 0.52, 0.46 ] as $scale ) {
            $nw = max( 420, (int) floor( $w * $scale ) );
            $nh = max( 300, (int) floor( $h * $scale ) );
            if ( $nw >= $w || $nh >= $h ) { continue; }

            $resized = imagecreatetruecolor( $nw, $nh );
            if ( ! $resized ) { continue; }
            if ( function_exists( 'imagesavealpha' ) ) { @imagesavealpha( $resized, true ); }
            $transparent = imagecolorallocatealpha( $resized, 0, 0, 0, 127 );
            imagefill( $resized, 0, 0, $transparent );
            imagecopyresampled( $resized, $img, 0, 0, 0, 0, $nw, $nh, $w, $h );

            if ( function_exists( 'imagetruecolortopalette' ) ) {
                @imagetruecolortopalette( $resized, false, 192 );
            }

            $tmp = $path . '.heajtmp';
            @imagepng( $resized, $tmp, 9 );
            imagedestroy( $resized );

            if ( ! file_exists( $tmp ) ) { continue; }
            $bytes = (int) filesize( $tmp );

            if ( $bytes > 0 && $bytes < $best_bytes ) {
                if ( $best_tmp && file_exists( $best_tmp ) ) { @unlink( $best_tmp ); }
                $best_tmp = $tmp;
                $best_bytes = $bytes;
                $best_w = $nw;
                $best_h = $nh;
            } else {
                @unlink( $tmp );
            }

            if ( $bytes > 0 && $bytes <= $max_bytes ) {
                @unlink( $path );
                @rename( $tmp, $path );
                imagedestroy( $img );
                return [
                    'compressed' => true,
                    'bytes'      => $bytes,
                    'width'      => $nw,
                    'height'     => $nh,
                    'message'    => 'PNG dikompres maksimal 200KB.',
                ];
            }
        }

        if ( $best_tmp && file_exists( $best_tmp ) ) {
            @unlink( $path );
            @rename( $best_tmp, $path );
        }

        imagedestroy( $img );
        clearstatcache( true, $path );
        $final_bytes = file_exists( $path ) ? (int) filesize( $path ) : $best_bytes;

        return [
            'compressed' => $final_bytes <= $max_bytes,
            'bytes'      => $final_bytes,
            'width'      => $best_w,
            'height'     => $best_h,
            'message'    => $final_bytes <= $max_bytes ? 'PNG dikompres maksimal 200KB.' : 'PNG sudah dikompres, tetapi masih di atas 200KB.',
        ];
    }

    private function heaj_social_generate_one_ai( $platform, $args, $provider = 'gemini' ) {
        $provider = sanitize_key( $provider ?: 'gemini' );
        if ( $provider !== 'gemini' ) {
            return $this->heaj_social_generate_one_provider_assisted_gd( $platform, $args, $provider );
        }
        $map = [
            'instagram' => [ 'label' => 'Instagram 4:5', 'w' => 1080, 'h' => 1350, 'aspect' => '4:5' ],
            'pinterest' => [ 'label' => 'Pinterest 2:3', 'w' => 1000, 'h' => 1500, 'aspect' => '2:3' ],
            'linkedin'  => [ 'label' => 'LinkedIn 1.91:1', 'w' => 1200, 'h' => 627, 'aspect' => '16:9' ],
        ];
        if ( empty( $map[ $platform ] ) ) {
            return new WP_Error( 'heaj_social_bad_platform', 'Platform tidak valid.' );
        }
        $brand = $this->get_brand_settings();
        $api_key_pool = $this->get_api_key_pool( false );
        if ( empty( $api_key_pool ) ) {
            return new WP_Error( 'heaj_social_no_gemini_key', 'API key Gemini belum diatur. Isi API key Gemini terlebih dahulu agar Social Image bisa dibuat dengan AI.' );
        }
        $cfg = $map[ $platform ];
        $site_host = $this->heaj_social_site_host();
        $prompt = $this->heaj_social_generate_ai_prompt( $platform, $args, $brand, $site_host );
        $parts = [ [ 'text' => $prompt ] ];

        $template_url = $this->heaj_social_reference_template_url( $platform, $brand );
        if ( $template_url ) {
            $template_part = $this->heaj_social_fetch_media_part( $template_url );
            if ( ! is_wp_error( $template_part ) ) {
                $parts[] = [ 'inline_data' => [ 'mime_type' => $template_part['mime_type'], 'data' => $template_part['data'] ] ];
            }
        }

        if ( ! empty( $args['image_is_manual'] ) && ! empty( $args['image_upload'] ) ) {
            $main_part = $this->heaj_social_fetch_media_part_from_local_file( $args['image_upload'] );
        } else {
            $main_part = $this->heaj_social_fetch_media_part( $args['image_url'] ?? '' );
        }
        if ( is_wp_error( $main_part ) ) {
            return $main_part;
        }
        $parts[] = [ 'inline_data' => [ 'mime_type' => $main_part['mime_type'], 'data' => $main_part['data'] ] ];

        $logo_url = ! empty( $args['logo_url'] ) ? esc_url_raw( $args['logo_url'] ) : esc_url_raw( $brand['logo_url'] ?? '' );
        if ( $logo_url && ! preg_match( '/\.svg(\?.*)?$/i', $logo_url ) ) {
            $logo_part = $this->heaj_social_fetch_media_part( $logo_url );
            if ( ! is_wp_error( $logo_part ) ) {
                $parts[] = [ 'inline_data' => [ 'mime_type' => $logo_part['mime_type'], 'data' => $logo_part['data'] ] ];
            }
        }

        $model = sanitize_text_field( $brand['social_image_model'] ?? 'gemini-3.1-flash-image' );
        if ( $model === '' ) { $model = 'gemini-3.1-flash-image'; }
        $image_size = strtoupper( sanitize_text_field( $brand['social_image_size'] ?? '2K' ) );
        if ( ! in_array( $image_size, [ '1K', '2K', '4K', '0.5K' ], true ) ) { $image_size = '2K'; }

        $payload = [
            'contents' => [ [ 'role' => 'user', 'parts' => $parts ] ],
            'generationConfig' => [
                // Gemini image generation REST currently expects responseModalities + imageConfig.
                // Do not use responseFormat.image here; some API versions reject it as an unknown field.
                'responseModalities' => [ 'TEXT', 'IMAGE' ],
                'imageConfig' => [
                    'aspectRatio' => $cfg['aspect'],
                    'imageSize'   => $image_size,
                ],
            ],
        ];

        $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent';
        $last_error = 'Gagal membuat image sosial media via Gemini.';
        $last_status = 0;
        foreach ( $api_key_pool as $api_item ) {
            $api_key = $api_item['key'] ?? '';
            if ( ! $api_key ) { continue; }
            $response = wp_remote_post( $endpoint, [
                'timeout' => 180,
                'headers' => [
                    'x-goog-api-key' => $api_key,
                    'Content-Type'   => 'application/json',
                ],
                'body' => wp_json_encode( $payload ),
            ] );
            if ( is_wp_error( $response ) ) {
                $last_error = $response->get_error_message();
                continue;
            }
            $last_status = (int) wp_remote_retrieve_response_code( $response );
            $body = (string) wp_remote_retrieve_body( $response );
            $json = json_decode( $body, true );
            $message = '';
            if ( isset( $json['error']['message'] ) ) {
                $message = sanitize_text_field( (string) $json['error']['message'] );
            }
            if ( $last_status < 200 || $last_status >= 300 ) {
                $last_error = $message ?: ( 'HTTP ' . $last_status . ' dari Gemini.' );
                if ( $this->heaj_social_is_quota_error( $last_status, $last_error ) ) {
                    return new WP_Error(
                        'heaj_social_gemini_quota',
                        'Gemini Image tidak tersedia. Sistem memakai GD Fallback Lokal.'
                    );
                }
                if ( $this->is_blockable_gemini_api_key_error( $last_status, $last_error ) ) {
                    $this->block_api_key( $api_key, $last_error );
                }
                continue;
            }
            $parts_out = $json['candidates'][0]['content']['parts'] ?? [];
            $image_binary = '';
            $mime = 'image/png';
            foreach ( $parts_out as $part ) {
                if ( ! empty( $part['inlineData']['data'] ) ) {
                    $image_binary = base64_decode( (string) $part['inlineData']['data'] );
                    $mime = sanitize_text_field( (string) ( $part['inlineData']['mimeType'] ?? 'image/png' ) );
                    break;
                }
                if ( ! empty( $part['inline_data']['data'] ) ) {
                    $image_binary = base64_decode( (string) $part['inline_data']['data'] );
                    $mime = sanitize_text_field( (string) ( $part['inline_data']['mime_type'] ?? 'image/png' ) );
                    break;
                }
            }
            if ( ! $image_binary ) {
                $last_error = $message ?: 'Gemini tidak mengembalikan image output.';
                continue;
            }

            $upload = wp_upload_dir();
            if ( ! empty( $upload['error'] ) ) {
                return new WP_Error( 'heaj_social_upload_dir', $upload['error'] );
            }
            $dir = trailingslashit( $upload['basedir'] ) . 'heaj-social-images';
            $url = trailingslashit( $upload['baseurl'] ) . 'heaj-social-images';
            if ( ! wp_mkdir_p( $dir ) ) {
                return new WP_Error( 'heaj_social_mkdir', 'Folder upload social image tidak bisa dibuat.' );
            }
            $slug = $this->heaj_social_filename_slug( $args );
            $filename = $this->heaj_social_unique_filename( $dir, $slug, $platform, 'png' );
            $path = trailingslashit( $dir ) . $filename;

            $source_image = @imagecreatefromstring( $image_binary );
            if ( $source_image ) {
                if ( function_exists( 'imagepalettetotruecolor' ) ) { @imagepalettetotruecolor( $source_image ); }
                if ( function_exists( 'imagesavealpha' ) ) { @imagesavealpha( $source_image, true ); }
                @imagepng( $source_image, $path, 9 );
                imagedestroy( $source_image );
            } elseif ( ! @file_put_contents( $path, $image_binary ) ) {
                return new WP_Error( 'heaj_social_save_failed', 'Gagal menyimpan file hasil Gemini.' );
            }

            $this->heaj_social_maybe_resize_output( $path, $cfg['w'], $cfg['h'] );
            $compress_info = $this->heaj_social_compress_png_under_limit( $path, 204800 );
            $actual = @getimagesize( $path );
            return [
                'platform'         => $platform,
                'label'            => $cfg['label'],
                'width'            => isset( $actual[0] ) ? (int) $actual[0] : $cfg['w'],
                'height'           => isset( $actual[1] ) ? (int) $actual[1] : $cfg['h'],
                'url'              => trailingslashit( $url ) . basename( $path ),
                'filename'         => basename( $path ),
                'slug'             => $slug,
                'engine'           => 'gemini',
                'model'            => $model,
                'website'          => $site_host,
                'reference'        => (bool) $template_url,
                'compressed'       => ! empty( $compress_info['compressed'] ),
                'compressed_bytes' => isset( $compress_info['bytes'] ) ? (int) $compress_info['bytes'] : 0,
                'compress_message' => isset( $compress_info['message'] ) ? $compress_info['message'] : '',
            ];
        }
        if ( $this->is_blockable_gemini_api_key_error( $last_status, $last_error ) ) {
            $last_error .= ' API key diblokir lokal. Silakan cek Pengaturan API.';
        }
        return new WP_Error( 'heaj_social_gemini_failed', $last_error ?: 'Gagal membuat image sosial media via Gemini.' );
    }

    private function heaj_social_generate_one_provider_assisted_gd( $platform, $args, $provider ) {
        $schema = [
            'type' => 'OBJECT',
            'properties' => [
                'title' => [ 'type' => 'STRING' ],
                'description' => [ 'type' => 'STRING' ],
                'category' => [ 'type' => 'STRING' ],
                'sub_category' => [ 'type' => 'STRING' ],
            ],
            'required' => [ 'title', 'description', 'category' ],
        ];
        $system = 'You are a senior social media news art director. Return short Indonesian editorial poster copy only as JSON. Do not invent facts. Keep headline very punchy and readable.';
        $user = "Platform: {$platform}\nOriginal category: " . ( $args['category'] ?? '' ) . "\nOriginal sub-category: " . ( $args['sub_category'] ?? '' ) . "\nOriginal headline: " . ( $args['title'] ?? '' ) . "\nOriginal description: " . ( $args['description'] ?? '' ) . "\nRules: title max 10 words, description max 18 words. Keep factual meaning. No hashtags.";
        $res = $this->call_openai_compatible_json( $provider, $system, $user, $schema );
        if ( is_wp_error( $res ) ) { return $res; }
        $r = is_array( $res['result'] ?? null ) ? $res['result'] : [];
        $next = $args;
        foreach ( [ 'title', 'description', 'category', 'sub_category' ] as $k ) {
            if ( isset( $r[ $k ] ) && trim( (string) $r[ $k ] ) !== '' ) {
                $next[ $k ] = sanitize_text_field( $r[ $k ] );
            }
        }
        $next['_skip_ai'] = true;
        $next['_ai_assisted'] = true;
        $next['_ai_provider_used'] = $provider;
        return $this->heaj_social_generate_one( $platform, $next );
    }

    private function heaj_social_generate_one( $platform, $args ) {
        $brand = $this->get_brand_settings();
        $engine = sanitize_key( $brand['social_image_engine'] ?? 'gemini' );
        $selected_provider = sanitize_key( $args['ai_provider'] ?? 'gemini' );
        if ( empty( $args['_skip_ai'] ) && $engine !== 'gd' ) {
            $ai_result = $this->heaj_social_generate_one_ai( $platform, $args, $selected_provider );
            if ( ! is_wp_error( $ai_result ) ) {
                return $ai_result;
            }
            // Any selected-AI failure falls back to local GD so the workflow keeps producing images.
            $args['_ai_fallback_reason'] = $ai_result->get_error_message();
        }
        if ( ! function_exists( 'imagecreatetruecolor' ) ) {
            return new WP_Error( 'heaj_social_gd_missing', 'PHP GD belum aktif di server. Aktifkan ekstensi GD agar plugin bisa membuat PNG otomatis.' );
        }
        if ( ! function_exists( 'imagettftext' ) || ! function_exists( 'imagettfbbox' ) ) {
            return new WP_Error( 'heaj_social_freetype_missing', 'Server belum mendukung font TTF/Freetype untuk GD. Fitur Social Image butuh imagettftext agar layout headline tidak rusak.' );
        }
        $map = [
            'instagram' => [ 'label' => 'Instagram 4:5', 'w' => 1080, 'h' => 1350 ],
            'pinterest' => [ 'label' => 'Pinterest 2:3', 'w' => 1000, 'h' => 1500 ],
            'linkedin'  => [ 'label' => 'LinkedIn 1.91:1', 'w' => 1200, 'h' => 627 ],
        ];
        if ( empty( $map[ $platform ] ) ) { return new WP_Error( 'heaj_social_bad_platform', 'Platform tidak valid.' ); }
        $cfg = $map[ $platform ];
        $w = $cfg['w']; $h = $cfg['h'];
        $brand = $this->get_brand_settings();
        $rgb = $this->heaj_social_hex_color( $brand['primary_color'] ?: '#e30613', '#e30613' );
        $accent = [ max( 160, $rgb[0] ), min( 60, $rgb[1] ), min( 60, $rgb[2] ) ];
        if ( ! empty( $args['image_is_manual'] ) && ! empty( $args['image_upload'] ) ) {
            $bg_img = $this->heaj_social_tmp_image_from_local_file( $args['image_upload'] );
        } else {
            $bg_img = $this->heaj_social_tmp_image_from_url( $args['image_url'] );
        }
        if ( is_wp_error( $bg_img ) ) { return $bg_img; }

        $canvas = imagecreatetruecolor( $w, $h );
        imagesavealpha( $canvas, true );
        $black = imagecolorallocate( $canvas, 5, 5, 5 );
        $white = imagecolorallocate( $canvas, 248, 250, 252 );
        $muted = imagecolorallocate( $canvas, 226, 232, 240 );
        $red = imagecolorallocate( $canvas, $accent[0], $accent[1], $accent[2] );
        imagefilledrectangle( $canvas, 0, 0, $w, $h, $black );

        if ( $platform === 'linkedin' ) {
            $image_w = (int) round( $w * 0.58 );
            $this->heaj_social_cover_image( $canvas, $bg_img, $w - $image_w, 0, $image_w, $h );
            // Left dark panel for text, but keep the image clearly visible.
            $split_x = (int) round( $w * 0.42 );
            $fade_w = (int) round( $w * 0.16 );
            $this->heaj_social_overlay_rect( $canvas, 0, 0, $split_x, $h, 0, 0, 0, 60 );
            for ( $i = 0; $i < $fade_w; $i++ ) {
                $alpha = min( 98, 60 + (int) round( ( $i / max( 1, $fade_w ) ) * 38 ) );
                $this->heaj_social_overlay_rect( $canvas, $split_x + $i, 0, $split_x + $i + 1, $h, 0, 0, 0, $alpha );
            }
        } else {
            // Reference style: image dominates the upper half, text sits on a deep black lower editorial field.
            $photo_h = (int) round( $h * ( $platform === 'pinterest' ? 0.57 : 0.56 ) );
            $this->heaj_social_cover_image( $canvas, $bg_img, 0, 0, $w, $photo_h );
            // Keep the subject visible. Use a very soft darkening only near the bottom.
            $grad_start = (int) round( $photo_h * 0.66 );
            for ( $y = $grad_start; $y < $photo_h; $y++ ) {
                $pct = ( $y - $grad_start ) / max( 1, ( $photo_h - $grad_start ) );
                $alpha = 112 - (int) round( $pct * 24 );
                $this->heaj_social_overlay_rect( $canvas, 0, $y, $w, $y + 1, 0, 0, 0, $alpha );
            }
            $this->heaj_social_overlay_rect( $canvas, 0, $photo_h, $w, $h, 0, 0, 0, 0 );
        }
        imagedestroy( $bg_img );

        // Subtle red halftone dots on left side.
        for ( $yy = 18; $yy < (int) ( $h * 0.48 ); $yy += 18 ) {
            for ( $xx = 18; $xx < (int) ( $w * 0.28 ); $xx += 18 ) {
                if ( ( $xx + $yy ) % 36 === 0 ) {
                    imagefilledellipse( $canvas, $xx, $yy, 3, 3, imagecolorallocatealpha( $canvas, $accent[0], $accent[1], $accent[2], 70 ) );
                }
            }
        }

        $font_head = $this->heaj_social_font( true, true );
        $font_bold = $this->heaj_social_font( true, false );
        $font_reg  = $this->heaj_social_font( false, false );
        if ( ! $font_bold || ! $font_reg ) {
            imagedestroy( $canvas );
            imagedestroy( $bg_img );
            return new WP_Error( 'heaj_social_font_missing', 'Font TTF untuk GD fallback tidak terbaca dan auto-download font gagal. Pastikan server bisa menulis ke wp-content/uploads/heaj-fonts/ dan outbound HTTPS aktif.' );
        }
        if ( ! $font_head ) { $font_head = $font_bold; }

        $pad = $platform === 'linkedin' ? 56 : 72;
        $top_y = $platform === 'linkedin' ? 44 : 48;
        $cat = strtoupper( sanitize_text_field( $args['category'] ?: 'BERITA' ) );
        $sub = strtoupper( sanitize_text_field( $args['sub_category'] ?: '' ) );
        $cat_font_size = $platform === 'linkedin' ? 20 : 26;
        $cat_w = $this->heaj_social_text_box_width( $font_bold, $cat_font_size, $cat ) + 34;
        imagefilledrectangle( $canvas, $pad, $top_y, $pad + $cat_w, $top_y + 48, $red );
        if ( $font_bold ) { imagettftext( $canvas, $cat_font_size, 0, $pad + 17, $top_y + 33, $white, $font_bold, $cat ); }
        else { imagestring( $canvas, 5, $pad + 12, $top_y + 16, $cat, $white ); }

        $sub_w = 0;
        if ( $sub ) {
            $sub_x = $pad + $cat_w + 22;
            $sub_w = $this->heaj_social_text_box_width( $font_bold, $cat_font_size, $sub );
            if ( $font_bold ) { imagettftext( $canvas, $cat_font_size, 0, $sub_x, $top_y + 33, $white, $font_bold, $sub ); }
            else { imagestring( $canvas, 5, $pad + $cat_w + 18, $top_y + 16, $sub, $white ); }
        }

        // Garis miring setelah kategori dihapus agar header lebih bersih.

        $title_raw = wp_strip_all_tags( (string) $args['title'] );
        $title = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $title_raw, 'UTF-8' ) : strtoupper( $title_raw );
        $desc = wp_strip_all_tags( (string) $args['description'] );
        $footer_h = $platform === 'linkedin' ? 84 : 120;
        if ( $platform === 'linkedin' ) {
            $hx = $pad + 34;
            $hy = 170;
            $maxw = (int) round( $w * 0.43 );
            $hs = 40;
            $title_max_lines = 4;
            $title_min_size = 28;
            $desc_size = 17;
            $desc_max_lines = 4;
            $desc_min_size = 14;
            $title_gap = -10;
            $desc_bottom_pad = 18;
            $title_line_height = 1.12;
            $desc_line_height = 1.16;
        } else {
            $hx = $pad + 56;
            $hy = (int) round( $h * ( $platform === 'pinterest' ? 0.54 : 0.53 ) );
            $maxw = $w - ( $pad * 2 ) - 68;
            $hs = $platform === 'pinterest' ? 61 : 66;
            $title_max_lines = 5;
            $title_min_size = 46;
            $desc_size = 27;
            $desc_max_lines = 5;
            $desc_min_size = 21;
            $title_gap = -16;
            $desc_bottom_pad = 34;
            $title_line_height = 1.15;
            $desc_line_height = 1.18;
        }
        $bottom_limit = $h - $footer_h - $desc_bottom_pad;
        $title_fit = $this->heaj_social_fit_text_layout( $title, $font_head ?: $font_bold, $hs, $title_min_size, $maxw, $title_max_lines, $title_line_height, true );
        $after_title_y = $this->heaj_social_draw_lines( $canvas, $title_fit['lines'], $hx, $hy + $title_fit['size'], $title_fit['size'], $white, $font_head ?: $font_bold, $title_line_height, true );
        $desc_start = $after_title_y + $title_gap;
        $desc_fit = $this->heaj_social_fit_text_layout( $desc, $font_reg, $desc_size, $desc_min_size, $maxw, $desc_max_lines, $desc_line_height, true );
        while ( $desc_fit['height'] > max( 40, $bottom_limit - $desc_start ) && $desc_fit['size'] > $desc_min_size ) {
            $desc_fit = $this->heaj_social_fit_text_layout( $desc, $font_reg, $desc_fit['size'] - 1, $desc_min_size, $maxw, $desc_max_lines, $desc_line_height, true );
        }
        $after_desc_y = $this->heaj_social_draw_lines( $canvas, $desc_fit['lines'], $hx, $desc_start + $desc_fit['size'], $desc_fit['size'], $muted, $font_reg, $desc_line_height, true );
        $bar_bottom = min( $bottom_limit, $after_desc_y + 14 );
        imagefilledrectangle( $canvas, $pad, $hy - 10, $pad + 17, $bar_bottom, $red );
        imagefilledrectangle( $canvas, 0, $h - $footer_h, $w, $h, imagecolorallocatealpha( $canvas, 0, 0, 0, 0 ) );
        imageline( $canvas, 0, $h - $footer_h + 1, (int) ( $w * 0.42 ), $h - $footer_h + 1, $red );
        imageline( $canvas, (int) ( $w * 0.42 ), $h - $footer_h + 1, (int) ( $w * 0.47 ), $h - $footer_h + 54, $red );
        imageline( $canvas, (int) ( $w * 0.47 ), $h - $footer_h + 54, (int) ( $w * 0.53 ), $h - $footer_h + 54, $red );
        imageline( $canvas, (int) ( $w * 0.53 ), $h - $footer_h + 54, (int) ( $w * 0.58 ), $h - $footer_h + 1, $red );
        imageline( $canvas, (int) ( $w * 0.58 ), $h - $footer_h + 1, $w, $h - $footer_h + 1, $red );

        $logo_url = ! empty( $args['logo_url'] ) ? esc_url_raw( $args['logo_url'] ) : esc_url_raw( $brand['logo_url'] ?? '' );
        $logo_drawn = false;
        if ( $logo_url && ! preg_match( '/\.svg(\?.*)?$/i', $logo_url ) ) {
            $logo = $this->heaj_social_tmp_image_from_url( $logo_url );
            if ( ! is_wp_error( $logo ) ) {
                $lw = imagesx( $logo ); $lh = imagesy( $logo );
                $max_lw = (int) round( $w * ( $platform === 'linkedin' ? 0.22 : 0.30 ) );
                $max_lh = $footer_h - 34;
                $scale = min( $max_lw / max( 1, $lw ), $max_lh / max( 1, $lh ), 1 );
                $dw = (int) round( $lw * $scale ); $dh = (int) round( $lh * $scale );
                imagecopyresampled( $canvas, $logo, $pad, $h - $footer_h + (int) ( ( $footer_h - $dh ) / 2 ) + 7, 0, 0, $dw, $dh, $lw, $lh );
                imagedestroy( $logo );
                $logo_drawn = true;
            }
        }
        if ( ! $logo_drawn ) {
            $media = strtoupper( $this->get_media_name() );
            if ( $font_bold ) { imagettftext( $canvas, $platform === 'linkedin' ? 24 : 32, 0, $pad, $h - 44, $white, $font_bold, $media ); }
            else { imagestring( $canvas, 5, $pad, $h - 54, $media, $white ); }
        }

        $website = sanitize_text_field( $args['website'] ?: wp_parse_url( home_url(), PHP_URL_HOST ) );
        $site_size = $platform === 'linkedin' ? 20 : 26;
        $site_w = $this->heaj_social_text_box_width( $font_reg, $site_size, $website );
        $site_x = max( $pad, $w - $pad - $site_w );
        imagefilledellipse( $canvas, $site_x - 32, $h - (int) round( $footer_h / 2 ) + 6, 24, 24, $red );
        if ( $font_reg ) { imagettftext( $canvas, $site_size, 0, $site_x, $h - (int) round( $footer_h / 2 ) + 15, $white, $font_reg, $website ); }
        else { imagestring( $canvas, 5, $site_x, $h - (int) round( $footer_h / 2 ), $website, $white ); }

        $upload = wp_upload_dir();
        if ( ! empty( $upload['error'] ) ) { imagedestroy( $canvas ); return new WP_Error( 'heaj_social_upload_dir', $upload['error'] ); }
        $dir = trailingslashit( $upload['basedir'] ) . 'heaj-social-images';
        $url = trailingslashit( $upload['baseurl'] ) . 'heaj-social-images';
        if ( ! wp_mkdir_p( $dir ) ) { imagedestroy( $canvas ); return new WP_Error( 'heaj_social_mkdir', 'Folder upload social image tidak bisa dibuat.' ); }
        $slug = $this->heaj_social_filename_slug( $args );
        $filename = $this->heaj_social_unique_filename( $dir, $slug, $platform, 'png' );
        $path = trailingslashit( $dir ) . $filename;
        $saved = imagepng( $canvas, $path, 9 );
        imagedestroy( $canvas );
        if ( ! $saved || ! file_exists( $path ) ) { return new WP_Error( 'heaj_social_save_failed', 'Gagal menyimpan file PNG.' ); }

        $compress_info = $this->heaj_social_compress_png_under_limit( $path, 204800 );
        $actual = @getimagesize( $path );
        return [
            'platform'         => $platform,
            'label'            => $cfg['label'],
            'width'            => isset( $actual[0] ) ? (int) $actual[0] : $w,
            'height'           => isset( $actual[1] ) ? (int) $actual[1] : $h,
            'url'              => trailingslashit( $url ) . $filename,
            'filename'         => $filename,
            'logo_used'        => $logo_drawn,
            'engine'           => ! empty( $args['_ai_provider_used'] ) ? sanitize_key( $args['_ai_provider_used'] ) . '_gd' : ( ! empty( $args['_ai_fallback_reason'] ) ? 'gd_fallback' : 'gd' ),
            'website'          => $this->heaj_social_site_host(),
            'warning'          => '',
            'compressed'       => ! empty( $compress_info['compressed'] ),
            'compressed_bytes' => isset( $compress_info['bytes'] ) ? (int) $compress_info['bytes'] : 0,
            'compress_message' => isset( $compress_info['message'] ) ? $compress_info['message'] : '',
        ];
    }


    private function normalize_single_uploaded_image_file( $field_name ) {
        if ( empty( $_FILES[ $field_name ] ) || ! is_array( $_FILES[ $field_name ] ) ) {
            return null;
        }
        $file = $_FILES[ $field_name ];
        $name = isset( $file['name'] ) ? sanitize_file_name( wp_unslash( $file['name'] ) ) : '';
        $tmp_name = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
        $error = isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
        if ( $error !== UPLOAD_ERR_OK ) {
            return new WP_Error( 'heaj_social_manual_upload_error', 'Upload gambar manual untuk Social Image gagal. Kode error: ' . $error );
        }
        if ( ! $tmp_name || ! file_exists( $tmp_name ) ) {
            return new WP_Error( 'heaj_social_manual_missing', 'File gambar manual untuk Social Image tidak ditemukan.' );
        }
        $type = isset( $file['type'] ) ? sanitize_mime_type( (string) $file['type'] ) : '';
        if ( ! $type ) {
            $ft = wp_check_filetype( $name );
            $type = (string) ( $ft['type'] ?? '' );
        }
        $allowed = [ 'image/jpeg', 'image/jpg', 'image/png', 'image/webp' ];
        if ( ! in_array( strtolower( $type ), $allowed, true ) ) {
            return new WP_Error( 'heaj_social_unsupported_image', 'Format gambar manual untuk Social Image harus JPG, PNG, atau WebP.' );
        }
        return [
            'name'     => $name ?: 'manual-social-image',
            'tmp_name' => $tmp_name,
            'type'     => $type,
            'size'     => isset( $file['size'] ) ? (int) $file['size'] : 0,
            'error'    => $error,
        ];
    }

    public function ajax_generate_social_images() {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );
        if ( ! current_user_can( self::editor_admin_capability() ) ) {
            wp_send_json_error( [ 'message' => 'Akses ditolak.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();

        $args = [
            'title'          => isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '',
            'description'    => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
            'category'       => isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : 'BERITA',
            'sub_category'   => isset( $_POST['sub_category'] ) ? sanitize_text_field( wp_unslash( $_POST['sub_category'] ) ) : '',
            'website'        => wp_parse_url( home_url(), PHP_URL_HOST ),
            'image_url'      => isset( $_POST['image_url'] ) ? esc_url_raw( wp_unslash( $_POST['image_url'] ) ) : '',
            'image_is_manual'=> ! empty( $_POST['image_is_manual'] ),
            'image_caption'  => isset( $_POST['image_caption'] ) ? sanitize_text_field( wp_unslash( $_POST['image_caption'] ) ) : '',
            'manual_image_id'=> isset( $_POST['manual_image_id'] ) ? sanitize_key( wp_unslash( $_POST['manual_image_id'] ) ) : '',
            'logo_url'       => isset( $_POST['logo_url'] ) ? esc_url_raw( wp_unslash( $_POST['logo_url'] ) ) : '',
            'slug'           => isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '',
            'ai_provider'    => isset( $_POST['ai_provider'] ) ? sanitize_key( wp_unslash( $_POST['ai_provider'] ) ) : 'gemini',
        ];
        if ( ! empty( $args['image_is_manual'] ) ) {
            $manual_upload = $this->normalize_single_uploaded_image_file( 'manual_social_image' );
            if ( is_wp_error( $manual_upload ) ) {
                wp_send_json_error( [ 'message' => $manual_upload->get_error_message() ], 400 );
            }
            if ( empty( $manual_upload ) ) {
                wp_send_json_error( [ 'message' => 'File gambar manual untuk Social Image belum dikirim.' ], 400 );
            }
            $args['image_upload'] = $manual_upload;
            $args['image_url'] = 'manual-upload';
        }
        if ( empty( $args['image_url'] ) && empty( $args['image_upload'] ) ) {
            wp_send_json_error( [ 'message' => 'Pilih/gunakan gambar sumber terlebih dahulu agar Social Image AI bisa dibuat.' ], 400 );
        }
        $args['website'] = $this->heaj_social_site_host();
        if ( empty( $args['title'] ) ) { $args['title'] = 'Judul Artikel'; }
        if ( empty( $args['description'] ) ) { $args['description'] = 'Deskripsi singkat artikel.'; }

        $platforms = [ 'instagram', 'pinterest', 'linkedin' ];
        $items = [];
        foreach ( $platforms as $platform ) {
            $item = $this->heaj_social_generate_one( $platform, $args );
            if ( is_wp_error( $item ) ) {
                wp_send_json_error( [ 'message' => $item->get_error_message(), 'platform' => $platform ], 500 );
            }
            $items[] = $item;
        }
        wp_send_json_success( [
            'message' => 'Image sosial media berhasil dibuat.',
            'items'   => $items,
        ] );
    }

    private function parse_selected_source_images_from_request() {
        $raw = isset( $_POST['source_images'] ) ? wp_unslash( $_POST['source_images'] ) : '';
        if ( ! is_string( $raw ) || $raw === '' ) {
            return [];
        }
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            return [];
        }
        $items = [];
        foreach ( $decoded as $item ) {
            if ( ! is_array( $item ) ) { continue; }
            $caption = isset( $item['caption'] ) ? sanitize_text_field( $item['caption'] ) : '';
            $credit = isset( $item['credit'] ) ? sanitize_text_field( $item['credit'] ) : '';
            if ( $credit && stripos( $caption, $credit ) === false ) {
                $caption = trim( $caption ? $caption . ' | ' . $credit : $credit );
            }
            if ( ! empty( $item['is_manual'] ) ) {
                $manual_id = isset( $item['manual_id'] ) ? sanitize_key( $item['manual_id'] ) : '';
                if ( $manual_id === '' ) { continue; }
                $items[] = [
                    'is_manual' => true,
                    'manual_id' => $manual_id,
                    'caption'   => $caption,
                    'source'    => 'manual-upload',
                ];
                continue;
            }
            if ( empty( $item['url'] ) ) { continue; }
            $url = esc_url_raw( $item['url'] );
            if ( ! $url ) { continue; }
            $items[] = [
                'url'     => $url,
                'caption' => $caption,
                'source'  => isset( $item['source'] ) ? esc_url_raw( $item['source'] ) : '',
            ];
        }
        return array_slice( $items, 0, 12 );
    }

    private function normalize_manual_source_image_files() {
        if ( empty( $_FILES['manual_source_images'] ) || ! is_array( $_FILES['manual_source_images'] ) ) {
            return [];
        }
        $files = $_FILES['manual_source_images'];
        $ids = isset( $_POST['manual_image_ids'] ) ? (array) wp_unslash( $_POST['manual_image_ids'] ) : [];
        $captions = isset( $_POST['manual_image_captions'] ) ? (array) wp_unslash( $_POST['manual_image_captions'] ) : [];
        $normalized = [];
        $names = isset( $files['name'] ) && is_array( $files['name'] ) ? $files['name'] : [];
        foreach ( $names as $i => $name ) {
            $error = isset( $files['error'][ $i ] ) ? (int) $files['error'][ $i ] : UPLOAD_ERR_NO_FILE;
            if ( $error === UPLOAD_ERR_NO_FILE ) { continue; }
            $manual_id = isset( $ids[ $i ] ) ? sanitize_key( $ids[ $i ] ) : ( 'manual_' . $i );
            if ( $manual_id === '' ) { $manual_id = 'manual_' . $i; }
            $normalized[ $manual_id ] = [
                'name'     => sanitize_file_name( (string) $name ),
                'type'     => isset( $files['type'][ $i ] ) ? sanitize_mime_type( $files['type'][ $i ] ) : '',
                'tmp_name' => isset( $files['tmp_name'][ $i ] ) ? (string) $files['tmp_name'][ $i ] : '',
                'error'    => $error,
                'size'     => isset( $files['size'][ $i ] ) ? (int) $files['size'][ $i ] : 0,
                'caption'  => isset( $captions[ $i ] ) ? sanitize_text_field( $captions[ $i ] ) : '',
            ];
        }
        return $normalized;
    }

    private function sideload_manual_source_image( array $file, $post_id, $title = '', $caption = '' ) {
        if ( empty( $file['tmp_name'] ) || ! file_exists( $file['tmp_name'] ) ) {
            return new WP_Error( 'heaj_manual_image_missing', 'File upload manual tidak ditemukan.' );
        }
        if ( ! empty( $file['error'] ) ) {
            return new WP_Error( 'heaj_manual_image_upload_error', 'Upload gambar manual gagal. Kode error: ' . (int) $file['error'] );
        }
        if ( empty( $file['name'] ) ) {
            $file['name'] = 'he-manual-image-' . time() . '.jpg';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $allowed = [ 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ];
        $check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $allowed );
        if ( empty( $check['type'] ) || ! in_array( $check['type'], $allowed, true ) ) {
            return new WP_Error( 'heaj_manual_image_type', 'Format gambar manual harus JPG, PNG, atau WebP.' );
        }

        $tmp = $file['tmp_name'];
        $filename = sanitize_file_name( $file['name'] );
        $optimized = $this->optimize_downloaded_source_image( $tmp, $filename );
        $file_array = [
            'name'     => $optimized['filename'],
            'tmp_name' => $optimized['tmp'],
        ];

        $attachment_id = media_handle_sideload( $file_array, $post_id, $caption ?: $title );
        if ( is_wp_error( $attachment_id ) ) {
            if ( ! empty( $file_array['tmp_name'] ) && file_exists( $file_array['tmp_name'] ) ) { @unlink( $file_array['tmp_name'] ); }
            return $attachment_id;
        }
        $alt_text = $caption ? $caption : $title;
        if ( $alt_text ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt_text ) );
        }
        if ( $caption ) {
            wp_update_post( [ 'ID' => $attachment_id, 'post_excerpt' => $caption, 'post_title' => $caption ] );
        }
        update_post_meta( $attachment_id, '_he_source_image_original_url', 'manual-upload' );
        update_post_meta( $attachment_id, '_he_source_image_optimized', ! empty( $optimized['optimized'] ) ? '1' : '0' );
        update_post_meta( $attachment_id, '_he_source_image_format', sanitize_text_field( $optimized['format'] ) );
        update_post_meta( $attachment_id, '_he_source_image_manual_upload', '1' );
        return $attachment_id;
    }

    private function build_inserted_image_html( $attachment_id, $caption = '' ) {
        $src = wp_get_attachment_url( $attachment_id );
        if ( ! $src ) { return ''; }
        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $html = '<figure class="wp-caption aligncenter">';
        $html .= '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" />';
        if ( $caption ) {
            $html .= '<figcaption class="wp-caption-text">' . esc_html( $caption ) . '</figcaption>';
        }
        $html .= '</figure>';
        return $html;
    }

    public function ajax_create_draft() {
        if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Verifikasi gagal. Refresh halaman dan coba lagi.' ], 403 );
        }
        $this->reject_if_unlicensed_ajax();
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Anda tidak memiliki izin membuat draft.' ], 403 );
        }

        $title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
        $slug     = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';
        $meta     = isset( $_POST['meta'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta'] ) ) : '';
        $content  = isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '';
        $category = isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
        $tags_raw = isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '';
        $source_url = isset( $_POST['source_url'] ) ? esc_url_raw( wp_unslash( $_POST['source_url'] ) ) : '';
        $source_urls_raw = isset( $_POST['source_urls'] ) ? wp_unslash( $_POST['source_urls'] ) : '';
        $source_urls = [];
        if ( is_string( $source_urls_raw ) && $source_urls_raw !== '' ) {
            $decoded_source_urls = json_decode( $source_urls_raw, true );
            if ( is_array( $decoded_source_urls ) ) {
                $source_urls = array_values( array_unique( array_filter( array_map( 'esc_url_raw', $decoded_source_urls ) ) ) );
            }
        }
        $history_id = isset( $_POST['history_id'] ) ? sanitize_key( wp_unslash( $_POST['history_id'] ) ) : '';
        $title_index = isset( $_POST['title_index'] ) ? absint( $_POST['title_index'] ) : 0;
        $slug_index = isset( $_POST['slug_index'] ) ? absint( $_POST['slug_index'] ) : 0;
        $meta_index = isset( $_POST['meta_index'] ) ? absint( $_POST['meta_index'] ) : 0;
        $image_source = isset( $_POST['image_source'] ) ? sanitize_text_field( wp_unslash( $_POST['image_source'] ) ) : '';
        $ai_provider = isset( $_POST['ai_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['ai_provider'] ) ) : '';
        $excerpt = isset( $_POST['excerpt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['excerpt'] ) ) : '';
        $featured_image_url = isset( $_POST['featured_image_url'] ) ? esc_url_raw( wp_unslash( $_POST['featured_image_url'] ) ) : '';
        $featured_image_caption = isset( $_POST['featured_image_caption'] ) ? sanitize_text_field( wp_unslash( $_POST['featured_image_caption'] ) ) : '';
        $selected_source_images = $this->parse_selected_source_images_from_request();

        if ( empty( $title ) || empty( $content ) ) {
            wp_send_json_error( [ 'message' => 'Judul dan isi artikel tidak boleh kosong.' ], 400 );
        }

        $cat_id = 0;
        if ( $category ) {
            $term = get_term_by( 'name', $category, 'category' );
            if ( $term && ! is_wp_error( $term ) ) {
                $cat_id = (int) $term->term_id;
            } else {
                $new_term = wp_insert_term( $category, 'category' );
                if ( ! is_wp_error( $new_term ) && ! empty( $new_term['term_id'] ) ) {
                    $cat_id = (int) $new_term['term_id'];
                }
            }
        }

        $post_data = [
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => get_current_user_id(),
        ];
        if ( $excerpt ) { $post_data['post_excerpt'] = $excerpt; }
        if ( $cat_id ) { $post_data['post_category'] = [ $cat_id ]; }

        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Gagal membuat draft: ' . $post_id->get_error_message() ], 500 );
        }

        if ( $tags_raw ) {
            $tags = array_filter( array_map( 'trim', explode( ',', $tags_raw ) ) );
            wp_set_post_tags( $post_id, $tags, false );
        }

        if ( $source_url ) { update_post_meta( $post_id, '_he_source_url', $source_url ); }
        if ( ! empty( $source_urls ) ) { update_post_meta( $post_id, '_he_source_urls', $source_urls ); }
        if ( $ai_provider ) { update_post_meta( $post_id, '_he_ai_provider', $ai_provider ); }
        update_post_meta( $post_id, '_he_generated_by', 'YZG AI Journalist ' . self::VERSION );

        if ( $meta ) {
            update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta );
            update_post_meta( $post_id, 'rank_math_description', $meta );
            update_post_meta( $post_id, '_seopress_titles_desc', $meta );
            update_post_meta( $post_id, '_he_meta_description', $meta );

            // Support theme NewsPress meta description field:
            // <input id="newspress_meta_description" name="newspress_meta_description">
            update_post_meta( $post_id, 'newspress_meta_description', $meta );
            update_post_meta( $post_id, '_newspress_meta_description', $meta );

            // Tema/editor tertentu memakai custom field ini untuk input:
            // <input type="text" name="single_post_subtitle" id="input-single_post_subtitle">
            // Isi dengan meta deskripsi yang dipilih agar langsung muncul di Post Subtitle.
            update_post_meta( $post_id, 'single_post_subtitle', $meta );
            update_post_meta( $post_id, '_single_post_subtitle', $meta );
        }



        $inserted_image_html = [];
        $manual_files = $this->normalize_manual_source_image_files();
        if ( empty( $selected_source_images ) && ! empty( $manual_files ) ) {
            foreach ( array_keys( $manual_files ) as $manual_id ) {
                $selected_source_images[] = [
                    'is_manual' => true,
                    'manual_id' => $manual_id,
                    'caption'   => $manual_files[ $manual_id ]['caption'] ?? '',
                    'source'    => 'manual-upload',
                ];
            }
        }

        if ( ! empty( $selected_source_images ) ) {
            foreach ( $selected_source_images as $idx => $img ) {
                $img_caption = isset( $img['caption'] ) ? $img['caption'] : '';
                $is_manual = ! empty( $img['is_manual'] );
                $img_url = $is_manual ? 'manual-upload' : ( isset( $img['url'] ) ? $img['url'] : '' );
                if ( $is_manual ) {
                    $manual_id = isset( $img['manual_id'] ) ? sanitize_key( $img['manual_id'] ) : '';
                    if ( empty( $manual_files[ $manual_id ] ) ) {
                        update_post_meta( $post_id, '_he_source_image_error_' . $idx, 'File upload manual tidak ditemukan.' );
                        continue;
                    }
                    if ( empty( $img_caption ) && ! empty( $manual_files[ $manual_id ]['caption'] ) ) {
                        $img_caption = $manual_files[ $manual_id ]['caption'];
                    }
                    $attachment_id = $this->sideload_manual_source_image( $manual_files[ $manual_id ], $post_id, $title, $img_caption );
                } else {
                    if ( empty( $img_url ) ) { continue; }
                    $attachment_id = $this->sideload_featured_image( $img_url, $post_id, $title, $img_caption );
                }

                if ( ! is_wp_error( $attachment_id ) && $attachment_id ) {
                    if ( $idx === 0 ) {
                        set_post_thumbnail( $post_id, $attachment_id );
                        update_post_meta( $post_id, '_he_featured_image_source_url', $img_url );
                        if ( $img_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $img_caption ); }
                    } else {
                        $inserted = $this->build_inserted_image_html( $attachment_id, $img_caption );
                        if ( $inserted ) { $inserted_image_html[] = $inserted; }
                    }
                } else {
                    update_post_meta( $post_id, '_he_source_image_error_' . $idx, is_wp_error( $attachment_id ) ? $attachment_id->get_error_message() : 'Gagal mengunggah gambar sumber.' );
                }
            }
        } elseif ( $featured_image_url ) {
            $attachment_id = $this->sideload_featured_image( $featured_image_url, $post_id, $title, $featured_image_caption );
            if ( ! is_wp_error( $attachment_id ) && $attachment_id ) {
                set_post_thumbnail( $post_id, $attachment_id );
                update_post_meta( $post_id, '_he_featured_image_source_url', $featured_image_url );
                if ( $featured_image_caption ) { update_post_meta( $post_id, '_he_featured_image_caption', $featured_image_caption ); }
            } else {
                update_post_meta( $post_id, '_he_featured_image_error', is_wp_error( $attachment_id ) ? $attachment_id->get_error_message() : 'Gagal mengunggah featured image.' );
            }
        }

        if ( ! empty( $inserted_image_html ) ) {
            $content_with_images = $content . "\n\n" . implode( "\n\n", $inserted_image_html );
            wp_update_post( [
                'ID'           => $post_id,
                'post_content' => $content_with_images,
            ] );
            update_post_meta( $post_id, '_he_inserted_source_images_count', count( $inserted_image_html ) );
        }

        $this->add_history_event( [
            'title'      => $title,
            'source_url' => $source_url,
            'source_urls'=> ! empty( $source_urls ) ? $source_urls : ( $source_url ? [ $source_url ] : [] ),
            'provider'   => $ai_provider,
            'status'     => 'draft_created',
            'post_id'    => $post_id,
            'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
            'title_index' => $title_index,
            'slug_index' => $slug_index,
            'meta_index' => $meta_index,
            'image_source' => $image_source,
            'selected_image_url' => $featured_image_url,
        ] );

        $this->update_history_generated_to_draft( $history_id, $post_id, get_edit_post_link( $post_id, 'raw' ) );

        wp_send_json_success( [
            'message'  => 'Draft berhasil dibuat!',
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link( $post_id, 'raw' ),
        ] );
    }
}

new HE_Journalist_Pro_Tools();

=== YZG AI Journalist ===
Contributors: yanuarzg
Tags: ai, journalist, gemini, grok, zai, seo, harianexpress
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 5.0.7
License: GPLv2 or later

White-label AI editorial assistant dengan rotasi API, output SEO, audit fakta, gambar sumber/Pexels, draft sosial media, skrip video, dan kirim ke Draft WordPress.

== Changelog ==

= 5.0.7 =
* Article Generator labels multiple extracted URLs as SUMBER 1/2/3 with domain and title metadata.
* Added multi-source correlation rules so the angle is chosen by news value, overlap, and evidence rather than URL order.
* Improved synthesis rules for conflicting or complementary sources.

= 5.0.6 =
* Added publish slot lock to prevent concurrent Google Trends and Global Trends posts in the same schedule slot.
* Save AutoPilot clears publish slot lock with old queue/locks.

= 5.0.5 =
* Saving AutoPilot now resets old queue to zero and restarts the publish schedule from save time.
* Removed standalone queue cron hook from AutoPilot flow.
* Queue processing is blocked outside the configured publish schedule unless triggered manually by Mulai Sekarang.

= 5.0.4 =
* Added AutoPilot duplicate detection by source URL, URL signature, and title similarity.
* AutoPilot scans more feed items to find another non-duplicate candidate before skipping.
* Stores all article source URLs for future duplicate checks.

= 5.0.3 =
* AutoPilot now creates at most one article per publish schedule.
* Pending queue no longer triggers continuous publishing between schedules.
* Queue worker is controlled by the master scheduler only.

= 5.0.2 =
* Source footer now uses details + ordered list with x-small source URLs.
* AutoPilot scheduler adds admin-ajax async runner and direct fallback for overdue master cron.

= 5.0.1 =
* AutoPilot article footer now includes naked source URLs in details block.
* Cleaned AutoPilot admin UI copy.
* Scheduler remains master-cron based with no single-event conflict.

= 5.0.0 =
* Auto Artikel diubah menjadi AutoPilot Posting: pengguna tidak lagi perlu memilih metode Google Trends, Global Trends, atau Manual Keyword.
* AutoPilot mencampur kandidat dari beberapa sumber tren, memprioritaskan topik fokus opsional, lalu hanya membuat artikel dari sumber yang valid dan punya featured image terbaca.
* UI Auto Artikel disederhanakan total: jadwal publish, topik fokus opsional, proxy cadangan, bahasa, dan penulis.
* Master Scheduler v4.2 tetap menjadi mesin utama; cron checker berjalan setiap 5 menit sementara publish tetap mengikuti interval aman pengguna.
* Manual keyword lama tidak lagi menjadi mode utama; field keyword dipakai sebagai filter fokus AutoPilot.

= 4.2.0 =
* Auto Artikel dirombak menjadi master scheduler runner: satu master cron permanen setiap 5 menit mengecek jadwal publish dan queue pending.
* Sistem tidak lagi bergantung pada single event yang terus dijadwalkan ulang sehingga lebih tahan terhadap WP-Cron yang terlambat/hilang.
* Runner lama tetap menjadi wrapper kompatibilitas, tetapi alur utama sekarang memakai he_journalist_auto_news_master_cron.
* Auto-heal admin/frontend/login/shutdown/REST kini memastikan master cron aktif, bukan membuat jadwal publish baru yang redundant.
* Status Auto Artikel menampilkan master cron sebagai indikator utama.

= 4.1.8 =
* Menambahkan input custom jadwal aman untuk Google Trends, Global Trends, dan Keyword Manual.
* Jadwal menit kini dikunci minimal 15 menit agar tidak terlalu agresif terhadap API AI, RSS feed, image fetch, dan hosting.
* Opsi jadwal disederhanakan menjadi setiap xx menit, setiap xx jam, atau setiap xx hari dengan validasi min/max di server dan UI.
* Default jadwal Google Trends/Global Trends diarahkan ke interval jam agar lebih stabil untuk penggunaan produksi.

= 4.1.7 =
* Auto Artikel dibuat lebih turnkey: cron auto-heal aktif dari request admin, frontend, login, shutdown heartbeat, REST heartbeat, loopback, keepalive, dan queue worker.
* Pengguna umum tidak wajib mengisi cron eksternal; plugin otomatis membangunkan jadwal jika WP-Cron overdue saat ada request ke website/admin.
* URL Cron Eksternal tetap disediakan sebagai cadangan terakhir untuk hosting yang benar-benar memblokir loopback/WP-Cron atau website tanpa traffic sama sekali.
* Dashboard menyesuaikan keterangan trigger agar lebih jelas: jadwal tetap dihormati, tetapi auto-heal otomatis memperbaiki cron yang terlambat.

= 4.1.6 =
* Menambahkan endpoint URL Cron Eksternal untuk menjalankan Auto Artikel secara andal ketika WP-Cron/loopback hosting terlambat atau tidak berjalan.
* Status Singkat menampilkan peringatan jika Next cron sudah lewat dari waktu saat ini.
* Dashboard Auto Artikel menampilkan URL cron eksternal yang bisa dipasang di cron-job.org/EasyCron/cron hosting.
* External runner hanya berjalan jika jadwal sudah jatuh tempo atau ada queue pending, sehingga membuka halaman admin tetap tidak memicu publish otomatis.

= 4.1.5 =
* Auto Artikel menambahkan dropdown Profil Penulis agar author post dapat dipilih langsung dari daftar user administrator/editor/author.
* Mode Keyword Manual menampilkan status keyword: sudah berhasil dibuat atau belum, beserta link artikel dan waktu generate.
* Jika semua keyword manual sudah berhasil dibuat, jadwal Auto Artikel dihentikan otomatis dan queue/lock dibersihkan.
* Google Trends/Global Trends mendukung RSS proxy fallback untuk server yang IP/DNS/cURL-nya gagal membaca feed. Plugin juga menyediakan endpoint proxy terbatas untuk RSS Google Trends dan TrendHunter.
* Fitur Auto Artikel dikunci sampai lisensi domain valid, termasuk save setting, Mulai Sekarang, cron, queue worker, dan endpoint proxy.

= 4.1.4 =
* Membuka halaman Auto Artikel tidak lagi menjalankan runner otomatis.
* Dispatcher/heartbeat admin dimatikan agar membuka halaman pengaturan Auto Artikel tidak memicu publish baru.
* Eksekusi Auto Artikel dibatasi ke jadwal cron/heartbeat non-admin dan tombol Mulai Sekarang.

= 4.1.3 =
* Perubahan metode Auto Artikel sekarang membatalkan antrean metode sebelumnya agar Google Trends/Global Trends tidak tetap berjalan setelah pindah ke Keyword Manual, atau sebaliknya.
* Queue worker/heartbeat hanya memproses antrean yang sesuai dengan metode aktif saat ini.
* Saat Mulai Sekarang menyimpan mode baru, antrean lama dibersihkan sebelum item metode baru dimasukkan.

= 4.1.2 =
* Mulai Sekarang pada mode Keyword Manual kini hanya memproses satu keyword per klik/siklus, bukan seluruh daftar keyword sekaligus.
* Prompt SEO Page 1 dan normalisasi output diperbaiki agar markdown **teks** berubah menjadi <strong>teks</strong>, bukan tampil mentah di artikel.
* Caption featured image Auto Artikel disamakan dengan metode Tools Generate Artikel: membaca figcaption, caption di sekitar gambar, alt/title/data-caption, cover-photo, dan credit dekat image.

= 4.1.1 =
* Google Trends/Global Trends kembali strict: artikel hanya dibuat dari sumber yang bisa diakses server dan memiliki image terbaca. Jika sumber/image tidak valid, plugin mencoba sumber/item berikutnya.
* Mode Keyword Manual tidak lagi mengambil Google News RSS; artikel dibuat dari keyword input dengan prompt SEO Page 1 Google.
* Multiple-line keyword diproses berurutan mulai dari baris pertama, lalu lanjut ke keyword berikutnya pada siklus berikutnya.
* Mode Keyword Manual mengambil featured image dari Pexels API. Artikel tidak dibuat jika Pexels image gagal tersedia.
* Auto Artikel tetap featured-image-only; tidak ada gambar tambahan di dalam body artikel.

= 4.1.0 =
* Google Trends/Global Trends tidak lagi berhenti total jika halaman sumber atau image remote gagal dibaca pada server tertentu.
* Menambahkan fallback konteks dari data RSS/feed: judul topik, sumber terkait, traffic feed, tanggal, URL, dan summary RSS.
* Artikel tetap dibuat walaupun featured image gagal dipasang; error image disimpan sebagai meta dan log, bukan menyebabkan skip.

= 4.0.9 =
* Google Trends dan Global Trends kini memakai site-based rotation untuk mencegah beberapa website source mengambil item RSS yang sama pada waktu yang sama.
* Urutan item feed dibuat berbeda per website, per mode feed, dan per periode jadwal tanpa mengganggu processed-id lokal.

= 4.0.8 =
* Global Trends RSS fetch diperkuat untuk server tertentu: fallback cURL dan file_get_contents dengan browser user-agent jika WP HTTP gagal/body kosong.
* Auto Artikel sekarang hanya memakai satu featured image sumber; gambar sumber tidak lagi disisipkan ke dalam body artikel.

= 4.0.7 =
* HE Network integration dibuat benar-benar opsional: AI Journalist tetap berjalan tanpa error saat plugin network tidak dipasang.
* Jika HE Network tidak tersedia, Auto Artikel hanya menyimpan status meta network_plugin_not_installed tanpa warning berulang.

= 4.0.6 =
* HE Network mode Aggregator: Auto Artikel tetap boleh publish, tetapi ping keluar dilewati.
* Jika situs adalah Aggregator, artikel auto lokal di-upsert ulang ke index lokal dan cache aggregator di-flush setelah featured image selesai dipasang.
* HE Network mode Source tetap mengirim ping ke aggregator seperti v4.0.5.

= 4.0.5 =
* Integrasi HE Network for NewsPress: setelah Auto Artikel berhasil publish, plugin mengirim ping ke aggregator.
* Ping dilakukan setelah featured image/figure selesai dipasang agar aggregator mengambil thumbnail final, bukan thumbnail kosong.
* Jika HE Network aktif, ping memakai HE_NP_Source; jika tidak tersedia tetapi option he_np_settings ada, plugin memakai fallback REST ping ke /wp-json/he-network/v1/ping.

= 4.0.4 =
* Global Trends RSS dibuat lebih tahan terhadap hosting/server yang menerima response non-XML atau body kosong.
* Menambahkan beberapa kandidat URL TrendHunter RSS: https/http dan www/non-www.
* Menambahkan parser fallback berbasis regex untuk item TrendHunter jika SimpleXML gagal.
* Pesan RSS kosong kini lebih spesifik dan mengarahkan pengguna melihat log HTTP/parser detail.

= 4.0.3 =
* Global Trends direct RSS mode diperkuat: link dan image TrendHunter dinormalisasi ke HTTPS.
* Download image sumber dibuat lebih tangguh dengan user-agent browser, fallback http/https, dan fallback ukuran 468/120 khusus TrendHunter CDN.
* Featured image tidak langsung gagal pada image pertama; plugin mencoba image sumber berikutnya sebelum membatalkan post.
* Feedback UI sekarang menampilkan error worker terakhir agar penyebab gagal terlihat jelas.

= 4.0.2 =
* Global Trends parser dibuat khusus untuk struktur RSS TrendHunter: membaca link item, description, enclosure image 468px, dan caption dari title/description.
* Global Trends kini memprioritaskan image + summary dari RSS jika halaman TrendHunter sulit di-scrape.
* Proses Global Trends lebih stabil untuk membuat artikel karena tidak bergantung penuh pada scraping halaman sumber.

= 4.0.1 =
* Fix Global Trends: mengganti pemanggilan method fetch_manual_rss_items_from_url yang tidak tersedia menjadi fetch_generic_rss_items.
* Global Trends kini dapat membaca https://www.trendhunter.com/rss tanpa fatal error undefined method.

= 4.0.0 =
* Tambah metode utama Auto Artikel: Global Trends dari https://www.trendhunter.com/rss.
* Auto Artikel sekarang memiliki tiga metode: Google Trends, Global Trends, dan Manual Keyword.
* Tambah tombol secondary Mulai Sekarang di samping Simpan & Aktifkan untuk menjalankan auto post saat itu juga.
* Tambah feedback UI saat Mulai Sekarang berjalan: menyimpan settings, enqueue, worker, created/skipped/failed.

= 3.9.9 =
* Google Trends Auto Artikel kini memakai hingga 3 ht:news_item URL sebagai sumber artikel multi-sumber.
* AI diberi konteks SUMBER 1, SUMBER 2, dan SUMBER 3 agar artikel lebih lengkap dan unik.
* Jika masing-masing sumber memiliki gambar, gambar ikut dimasukkan ke konten sebagai figure lengkap dengan caption dan link sumber.

= 3.9.8 =
* Image sumber Auto Artikel sekarang ikut mengambil caption dari figcaption, alt/title image, og:image:alt, media:title/description RSS, dan image description jika tersedia.
* Caption image sumber disimpan sebagai caption attachment, alt text, dan meta caption featured image.

= 3.9.7 =
* Perbaikan Auto Artikel realtime: setelah enqueue, cron mencoba memproses 1 item queue langsung sebagai fallback jika queue worker/loopback hosting gagal.
* Status Singkat kini menampilkan queued, processed, created, skipped, failed, dan ringkasan queue.

= 3.9.6 =
* Tambah jadwal Auto Posting terpisah untuk mode Google Trends dan Keyword Manual.
* Google Trends: realtime, setiap xx jam, atau setiap xx hari.
* Keyword Manual: setiap xx menit, setiap xx jam, atau setiap xx hari.
* Input keyword manual kini hanya tampil ketika mode Keyword Manual dipilih.

= 3.9.5 =
* Rombak ulang UI Auto Artikel menjadi dua fungsi utama: Feeds Google Trends dan Keyword Manual.
* Auto Artikel Google Trends otomatis memakai prompt Rewrite Default Jurnalis; Keyword Manual otomatis memakai prompt Target SEO Page 1.
* Pengaturan visible disederhanakan: hanya bahasa artikel, sumber fungsi, dan keyword manual.
* Profil penulis post otomatis memakai user yang terakhir menyimpan pengaturan Auto Artikel.

= 3.9.4 =
* Adaptasi random multiple keyword: mode keyword manual kini mendukung pilihan random/berurutan, jumlah keyword per run, tracking keyword terpakai, auto reset siklus, dan tombol reset siklus keyword.
* Queue Auto Artikel sekarang menyimpan keyword asal setiap item.

= 3.9.3 =
* Adaptasi tambahan dari JDH: Auto Artikel sekarang memakai queue worker terpisah. Cron utama hanya enqueue item, worker memproses scraping/AI/publish satu per satu.
* Tambah status queue per item, retry hingga 3x, stale lock cleanup, tombol Force Enqueue Background, dan Run Queue Sync Debug.
* Tambah panel Diagnostik dan Queue Auto Artikel di halaman Auto Artikel.

= 3.9.2 =
* Auto Artikel cron diadaptasi dengan pola multi-layer seperti JDH Auto Publisher: single-event cron, loopback wp-cron, REST heartbeat, frontend heartbeat, shutdown heartbeat, dan keepalive shadow event.
* Cron utama sekarang self-reschedule setelah selesai, sehingga tidak bergantung pada recurring cron yang sering macet di shared hosting.
* Tambah diagnostik last heartbeat dan last keepalive pada halaman Auto Artikel.

= 3.9.1 =
* Perbaikan Auto Artikel Google News: coba resolve URL news.google.com/rss/articles ke URL publisher asli sebelum scrape gambar dan konten.
* Tambah fallback RSS image dari media:content, media:thumbnail, enclosure, dan img pada description.
* Jika jadwal cron overdue saat halaman Auto Artikel dibuka, runner dijalankan langsung dari admin page agar tidak diam karena loopback/admin-ajax hosting gagal.

= 3.9.0 =
* Perbaikan Google Trends HTTP 429: tambah cache, backoff 45 menit, dan fallback otomatis ke Google News Indonesia.
* Tambah pilihan feed Google News Indonesia yang lebih stabil untuk Auto Artikel.

= 3.8.9 =
* Perbaikan Auto Artikel cron: tambah fallback runner internal via admin-ajax ketika jadwal sudah lewat tetapi WP-Cron tidak terpanggil.
* Tambah pencatatan last run, last started, dan hasil terakhir di halaman Auto Artikel.
* Item yang gagal AI/post sementara tidak langsung ditandai processed agar bisa dicoba ulang.

= 3.8.8 =
* Tambah mode Input RSS Manual di Auto Artikel, support multi URL RSS/Atom.
* Feed Auto Artikel sekarang bisa memilih Google Trends, keyword manual, atau RSS manual.

= 3.8.7 =
* Auto News Article diubah menjadi Auto Artikel.
* Tambah Content Settings lengkap pada Auto Artikel: pilih AI, gaya penulisan, panjang artikel, bahasa, dan mode parafrase.
* Tambah pilihan sumber Auto Artikel: Google Trends Feed atau keyword manual multi-keyword via Google News RSS Search.

= 3.8.6 =
* Social Media Image memprioritaskan provider AI yang dipilih di generator; jika gagal otomatis fallback ke GD lokal.
* Tampilan GD Social Image dirapikan: headline lebih besar, jarak headline-deskripsi lebih rapat, dan slash setelah kategori dihapus.
* Model OpenRouter diganti menjadi dropdown pilihan.
* Rotasi multi API diterapkan ke Gemini, Grok, Groq, Z.AI, dan OpenRouter.

= 3.8.5 =
* Fix: submenu Auto News Article dipastikan muncul langsung di bawah menu utama plugin.

= 3.8.4 =
* Tambah halaman Auto News Article untuk mengambil Google Trends Indonesia RSS, generate artikel AI, dan publish/draft otomatis jika sumber berita memiliki image.
* Tambah pengaturan auto posting on/off, mode realtime, interval per jam, pilihan item RSS terbaru, dan mode publish/draft.

= 3.8.3 =
* Full install sekarang bisa menyiapkan font TTF runtime otomatis ke wp-content/uploads/heaj-fonts/ saat GD fallback dipakai.
* GD fallback tidak perlu patch-only selama server mengizinkan outbound HTTPS dan folder uploads writable.

= 3.8.2 =
* Perbaikan GD fallback: pencarian font TTF diperluas dan output bitmap/pixelated dicegah bila font tidak terbaca.
* Disarankan memakai patch-only di atas instalasi lama agar aset font v3.7.8 tetap dipakai.

= 3.8.1 =
* Optimasi gambar draft dipaksa WebP jika server mendukung, max width 1200px dan target max 100KB.
* Upload manual mendapat tombol pensil untuk edit alt + caption sebelum dikirim ke Draft.
* GD fallback dipertahankan memakai style lokal v3.7.8.

= 3.8.0 =
* Social Media Image sekarang juga bisa memakai gambar dari upload manual sebagai sumber AI/GD.

= 3.7.9 =
* Tambah support provider OpenRouter.ai dengan input API key dan model OpenRouter.
* Tambah upload gambar manual di panel Gambar dari Sumber; gambar diproses resize/compress saat dikirim ke Draft.
* Tambah dropdown kategori WordPress eksisting di samping saran kategori.
* Rapikan Social Media Image: tombol pilih dihapus dan warning quota Gemini Image panjang disembunyikan dari UI.
* Tambah tombol sumber MSN Indonesia di tools sumber berita.


= 3.3.12 =
* Revisi header generator, settings, filter gambar mirip, threshold kemiripan narasi, dan visibilitas halaman subdomain.

= 3.3.3 =
* Hapus indikator API aktif dari halaman Generator Artikel.
* Perbaiki error JavaScript Cannot access lastSourceText before initialization.
* Perbaiki heading Riwayat Generate agar terlihat jelas.
* Prompt Custom di Pengaturan API disederhanakan hanya menjadi Instruksi Global Tambahan.

= 3.2.5 =
* Halaman Semua Subdomain: tombol di dalam card dihapus, icon buka website dipindahkan setelah nama domain, dan icon login ditempatkan di pojok kanan atas card.
* Sortir baru berdasarkan jumlah total artikel terbanyak/tersedikit.
* CSS dibuat lebih netral tanpa gradient dan tanpa warna terlalu colorfull.

= 3.1.7 =
* Perbaikan error Grok/xAI HTTP 403.
* API key Grok/Z.AI yang ditolak 401/403 otomatis diblokir dan dilewati.
* Fallback otomatis ke Gemini jika Grok/Z.AI gagal.

= 3.1.6 =
* Tambah dukungan provider AI Grok/xAI dan Z.AI pada Generator Artikel.
* Tambah input API Grok/xAI dan Z.AI di Pengaturan API.
* Hapus block info Lisensi Domain via GitHub dari halaman Pengaturan API.
* Tambah tautan Ambil API Key Gemini sebelum input API Key Tambahan.

= 3.1.5 =
* Auto-block API key bocor/invalid/expired/disabled dari respons Gemini.
* Status API key aktif/terblokir di Pengaturan API.
* Perbaikan update checker agar notifikasi update tidak muncul saat versi remote sama.

= 3.1.4 =
* Lisensi domain dibaca dari GitHub licenses.json.
* Tambah contoh licenses.json untuk menambah domain pembeli lisensi tanpa rilis ulang plugin.

= 3.1.3 =
* Filter gambar sumber: hanya dari area artikel atau image minimal 320px agar ikon/gambar kecil tidak tampil.
* Tambah pembatasan lisensi domain untuk harianexpress.com, subdomain harianexpress.com, harianexpress.id, subdomain harianexpress.id, dan geky.page.gd.
* Redirect domain tidak terdaftar ke https://yanuarzg.github.io/.
* Tambah tombol Beli Lisensi di footer sebelum Dibangun oleh YZG.

= 3.1 =
* Mobile responsive.

= 3.3.12 =
* Revisi header generator, settings, filter gambar mirip, threshold kemiripan narasi, dan visibilitas halaman subdomain.

= 3.3.3 =
* Tambah Quality Score artikel dan deteksi kemiripan narasi.
* Revisi label tombol HTML dan Draft.

= 3.4.7 =
* Fixed Custom Settings persistence by using native WordPress option array fields.
* Branding, prompt, language, author, and editor settings now apply reliably after save.

= 3.5.5 =
* Tambah fitur Social Media Image: generate PNG otomatis untuk Instagram, Pinterest, dan LinkedIn dari gambar sumber/featured image, judul, deskripsi, kategori, website, dan logo brand.

= 3.5.2 =
* Plugin UI now follows WordPress admin/user locale: Indonesian for id_ID, English for other locales.

= 3.5.4 =
* Tambah fitur Social Media Image: generate PNG otomatis untuk Instagram, Pinterest, dan LinkedIn dari gambar sumber/featured image, judul, deskripsi, kategori, website, dan logo brand.

= 3.5.2 =
* Performance & Architecture Update: API Key Manager, Gemini fallback model chain, and richer history tracking.

= 3.5.6 =
* Fix Social Media Image agar selalu memakai hostname situs tempat plugin dipasang, bukan hostname sumber artikel.
* Bundle font DejaVu Sans Condensed ke dalam plugin agar headline Social Media Image lebih konsisten lintas server.
* Tambah validasi imagettftext/FreeType. Jika server tidak mendukung TTF GD, plugin akan menolak generate agar hasil tidak rusak.

= 3.5.7 =
* Social Image sekarang default memakai Gemini AI agar hasil jauh lebih mirip template referensi, bukan hanya renderer GD lokal.
* Footer website social image kini selalu memakai domain WordPress tempat plugin dipasang, bukan domain sumber artikel.
* Tambah pengaturan template referensi Instagram/Pinterest/LinkedIn, model Gemini, ukuran image, dan prompt tambahan khusus social image.
* GD tetap tersedia sebagai fallback manual jika dibutuhkan.

= 3.5.8 =
* Fix payload Gemini Social Image: endpoint dipindah ke v1beta dan konfigurasi image memakai imageConfig, bukan responseFormat.image, agar tidak muncul error Unknown name responseModalities/responseFormat pada generation_config.

= 3.5.9 =
* Perbaiki handling quota Gemini Image: error quota kini ditampilkan lebih jelas.
* Jika Gemini Image quota habis/tidak tersedia, Social Image otomatis fallback ke GD lokal agar workflow tidak berhenti total.
* Output fallback diberi indikator engine gd_fallback dan warning quota.

= 3.6.0 =
* Nama file Social Image sekarang mengikuti slug artikel: slug-instagram.png, slug-pinterest.png, slug-linkedin.png.
* Payload Social Image sekarang mengirim slug terpilih dari SEO metadata.
* Preview Social Image menampilkan nama file hasil generate.

= 3.6.1 =
* Perbaiki fallback GD Social Image: baseline teks kini lurus horizontal, ukuran headline/deskripsi otomatis diperkecil agar tidak mudah terpotong.
* Gradient/shadow area foto dibuat lebih halus dengan transisi 1px dan tanpa kontras berlebihan.
* Tambah tombol Copy Prompt di panel Social Media Image untuk menyalin prompt bundle dan memakainya di tool AI lain.

= 3.6.2 =
* Rapikan spacing Social Image fallback GD: jarak kategori ke headline, headline ke deskripsi, dan deskripsi ke footer dibuat lebih lega dan lebih konsisten.
* Layout LinkedIn diperbaiki agar teks tidak terlalu mepet kiri/atas dan area teks-foto terasa lebih seimbang.

= 3.6.3 =
* Jarak headline ke deskripsi dipersempit pada Social Image fallback GD.
* Line-height headline dan deskripsi dinaikkan agar blok teks lebih lega dan enak dibaca.

= 3.6.4 =
* Jarak headline ke deskripsi disetel 1rem pada Social Image fallback GD.
* Line-height headline dan deskripsi disetel 1.25rem/1.25 pada blok teks agar lebih lapang dan konsisten.

= 3.6.5 =
* Fine-tune fallback GD Social Image: headline diperkecil ke sekitar 80%, gap headline-deskripsi dihilangkan, dan padding kiri blok teks diperbesar 2x.
* Gradient/shadow diperingan agar tidak menutupi foto utama, khususnya layout LinkedIn dan poster vertikal.
* UX mobile panel Social Media Image dibuat lebih responsif dengan toolbar/card/action yang lebih mudah dipakai di layar kecil.
* Tombol Copy Prompt kini menyalin prompt untuk image terpilih dan otomatis mengunduh image yang dipilih.
* CSS Social Media Image dirapikan agar tidak redundant dan mengurangi risiko konflik selector.

= 3.6.6 =
* Perbaiki layout LinkedIn 1.91:1 agar headline dan deskripsi tidak mudah terpotong: area teks diperlebar, ukuran headline/deskripsi diperkecil otomatis, batas minimum size diturunkan, dan jumlah baris maksimum ditambah.

= 3.6.7 =
* Perbaiki posisi garis merah miring/slash pada label kategori Social Image agar tidak terlalu jauh ke kanan saat sub-kategori kosong.
* Slash kini mengikuti lebar kategori dan sub-kategori secara dinamis.

= 3.6.9 =
* Hotfix fatal error dari kompresi PNG: menghapus penggunaan konstanta GD opsional dan membuat kompresi lebih aman di berbagai server.
* Download Social Image PNG tetap dikompres otomatis dengan target maksimal 200KB.
* Preview Social Image menampilkan ukuran file hasil kompresi dalam KB.

= 3.7.0 =
* Tambah Batch Continue untuk artikel panjang minimal 1000 kata agar hasil tidak berhenti di tengah.
* Jika output awal belum mencapai target kata atau terlihat terpotong, plugin otomatis meminta AI melanjutkan articleBody dalam beberapa batch.
* Batch continuation menjaga metadata tetap sama dan hanya menambahkan isi artikel tanpa mengulang paragraf sebelumnya.

= 3.7.1 =
* Ubah default pilihan Panjang Artikel menjadi: Sesuai prompt, Pendek (300-500), Sedang (500-1000), dan Panjang (1000+).
* Tambah migrasi ringan untuk mengganti set panjang artikel bawaan lama jika belum dikustom manual.

= 3.7.2 =
* Tambah sistem lisensi YZTheme untuk product ID yzg-ai-journalist dengan mode encrypted_json_annual.
* Tambah menu Lisensi di dashboard plugin.
* Tambah verifikasi remote ke Apps Script License API via action verify_license_public.
* Generator dan AJAX penting dikunci jika lisensi belum aktif.

= 3.7.3 =
* Lisensi: sembunyikan pengaturan API lisensi dari halaman Lisensi dan hapus catatan warning.
* Generator artikel dasar tetap bisa dipakai walau lisensi belum aktif; fitur premium seperti content settings, author/editor, image source, fact audit, quality score, extra features, copy HTML, dan kirim draft dikunci.
* Tambah tombol WA Support dan link Member Area YZTheme di halaman Lisensi.
* Pesan invalid_response License API dibuat lebih jelas jika Apps Script belum mengembalikan JSON.

= 3.7.4 =
* License verifier dibuat lebih robust untuk Google Apps Script: manual follow redirect script.googleusercontent.com, redirection 10, User-Agent eksplisit, dan fallback form POST.
* Tambah Debug API di halaman Lisensi agar respons HTML/non-JSON bisa dilacak tanpa menebak.
* Tidak menambah decrypt lokal dan tidak mengubah secret flow productSecrets.

= 3.7.5 =
* License verifier ditambah fallback lokal CryptoJS AES untuk encrypted_json_annual ketika Google Apps Script/Web App mengembalikan HTML/400.
* Validasi lokal mencocokkan product, license_mode, annual type, domain, dan expired date.
* Remote API tetap dicoba lebih dulu; fallback lokal hanya dipakai saat response remote bukan JSON/error transport.

= 3.7.6 =
* License fallback diselaraskan dengan pola NewsPress: secret lokal memakai fragment obfuscated, bukan plain string.
* Menghapus konstanta password plain dari plugin ZIP.
* Menambahkan integrity token ringan untuk validasi lokal.

= 3.7.8 =
* Fix local license integrity token untuk fallback NewsPress-style encrypted_json_annual.
* Hapus komentar fragment secret agar tidak terlalu terbaca di source.
* Validasi lokal tetap mengecek product, mode, annual type, domain, dan expired date.

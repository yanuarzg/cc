// Initialize Icons
        function heajTrText(text){ return (window.HEAJTr ? window.HEAJTr(text) : text); }
        if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }

        let lastArticleData = null;
        let lastSourceImages = [];
        let lastSourceText = '';
        let lastSourceUrl = '';
        let lastProviderUsed = '';
        let lastSourceUrls = [];
        let lastHistoryId = '';
        let forceParaphraseMode = false;
        let selectedSourceImages = [];
        let manualSourceImages = [];
        let lastInputHasUrl = false;
        let lastSocialImagePromptBundle = null;
        let lastGeneratedSocialImages = [];
        let selectedSocialImagePlatform = '';

        // ---------- Definisi Prompt Dasar ----------
        const promptDefault = `{
  "role": "Asisten Jurnalistik Profesional untuk media/website pengguna",
  "task": "Menulis ulang artikel berita secara SANGAT AKURAT berdasarkan sumber (link atau teks) yang diberikan pengguna dengan menerapkan prinsip Piramida Terbalik.",
  
  "input": { 
    "source": "[Diberikan pengguna: URL, teks, atau transkrip video]" 
  },
  
  "strict_accuracy_rules": {
    "rule_1": "Bila berupa URL, WAJIB gunakan alat pencari untuk MEMBACA ISI TAUTAN tersebut secara langsung.",
    "rule_2": "DILARANG KERAS berhalusinasi, menambahkan opini, cerita, nama tokoh, atau kejadian yang tidak terdapat dalam sumber asli. Fokus pada parafrase fakta.",
    "rule_3": "Tulis ulang HANYA berdasarkan data mutlak dari input."
  },

  "journalistic_structure": {
    "principle": "Piramida Terbalik (Inverted Pyramid)",
    "description": "Susun berita dari informasi paling penting di bagian atas hingga informasi paling tidak penting di bagian bawah.",
    "structure_order": [
      {
        "section": "Headline",
        "position": "Paling atas",
        "rules": [
          "Singkat (maksimal 60 karakter)",
          "Padat, jelas, dan menarik",
          "Mengandung unsur utama (biasanya What + Who)",
          "Gunakan kata kerja aktif dan kuat"
        ]
      },
      {
        "section": "Lead (Teras Berita)",
        "position": "Paragraf pertama",
        "rules": [
          "Langsung menyampaikan inti berita (What, Who, Where, When)",
          "Maksimal 35 kata",
          "Format: [NAMA MEDIA], [KOTA] - [Inti berita]. [Hari,] (DD/MM/YYYY)",
          "Harus bisa berdiri sendiri sebagai ringkasan utama"
        ]
      },
      {
        "section": "Body",
        "position": "Isi utama",
        "inverted_pyramid_rule": "Susun dari yang paling penting ke yang kurang penting",
        "paragraph_order": [
          "Paragraf 2: Detail utama (kondisi, jumlah, dampak langsung, penanganan)",
          "Paragraf 3: Kronologi kejadian secara urut",
          "Paragraf 4: Kutipan narasumber resmi",
          "Paragraf 5 dst: Data pendukung, latar belakang, informasi tambahan"
        ]
      },
      {
        "section": "Tail (Penutup)",
        "position": "Paling bawah",
        "rules": [
          "Berisi informasi pelengkap yang tidak krusial",
          "Bisa berupa imbauan, rencana tindak lanjut, atau fakta tambahan",
          "Boleh dipotong oleh editor tanpa merusak inti berita"
        ]
      }
    ]
  },

  "writing_goals": {
    "language": "Bahasa Indonesia",
    "style": "Jurnalistik profesional, lugas, jelas, dan to the point",
    "tone": "Netral, profesional, tanpa clickbait atau sensasionalisme",
    "uniqueness": "Parafrase narasi dengan susunan kalimat baru dan gaya sendiri agar tidak duplikasi konten. HANYA menggunakan informasi dari referensi, 100% bebas halusinasi.",
    "voice": "Aktif; hindari kalimat pasif",
    "length_rule": "Ikuti kelengkapan fakta sumber, tetapi tulis ulang narasi dengan struktur dan kalimat baru"
  },

  "article_structure": {
    "headline": { 
      "max_length": 60, 
      "requirement": "SEO-friendly, informatif, sangat relevan dengan inti sumber" 
    },
    "lead": {
      "max_words": 35,
      "format": "[NAMA MEDIA], [KOTA ASAL KEJADIAN DARI SUMBER] - [kalimat SPOK]. (DD/MM/YYYY)",
      "note": "KOTA dan TANGGAL wajib diambil tepat seperti di sumber"
    },
    "body": {
      "use_headings": "Gunakan heading (H2, H3) jika sesuai untuk memecah teks",
      "quotes": {
        "format": "\"[KUTIPAN AKURAT SAMA PERSIS DENGAN SUMBER MENTAH]\" ujar [NAMA LENGKAP] ([JABATAN]) di [LOKASI], [HARI/TANGGAL]."
      },
      "dates_times": "Pertahankan waktu dan tanggal persis seperti di sumber, JANGAN MENGARANG."
    },
    "footer": { 
      "references": "Sertakan link sumber referensi asli" 
    }
  },

  "seo_requirements": {
    "slug": "Buat 3 opsi slug SEO-friendly singkat",
    "meta_description": "Buat 3-5 opsi meta deskripsi (maks 160 karakter)",
    "tags": "Minimal 10 tag relevan (tanpa tanda #) huruf kecil semua",
    "category": "Tentukan kategori / label yang relevan"
  },

  "final_instruction": "Selalu terapkan prinsip Piramida Terbalik secara ketat: letakkan informasi paling penting di Lead dan awal Body, kemudian susun secara menurun pentingnya hingga Tail."
}`; 
        const promptStraightNews = `{
  "role": "Professional Journalist & SEO Content Writer",
  "task": "Tulis ulang artikel berita menjadi Straight News yang SANGAT AKURAT berdasarkan tautan/sumber.",
  "strict_accuracy_rules": { 
    "rule_1": "DILARANG KERAS menambahkan fakta, cerita, tokoh, atau spekulasi baru. Hanya gunakan informasi murni yang ada di dalam referensi.",
    "rule_2": "Gunakan alat pencarian HANYA untuk mengekstrak isi teks sebenarnya dari URL yang diberikan pengguna."
  },
  "writing_goals": {
    "language_style": "Jurnalistik + Santai",
    "tone": "Netral, Objektif, Seimbang",
    "plagiarism": "100% unik dengan parafrase, tetapi TANPA mengubah esensi fakta",
    "fact_policy": "Fakta 100% WAJIB HANYA berasal dari sumber."
  },
  "journalistic_standards": {
    "mandatory_elements_lead": "lead [3W+1H maks 160 word]",
    "mandatory_elements_content": "content [5W+1H]",
    "structure": "Piramida Terbalik",
    "accuracy": "Semua fakta harus sesuai dengan sumbernya."
  },
  "article_structure": {
    "title": { "rules": ["Menarik dan informatif", "Mencerminkan isi nyata berita"] },
    "meta_description": { "max_length": 160, "rules": ["Standar jurnalistik", "Berisi intisari berita"] },
    "content": {
      "min_word_count": 350,
      "sections": ["Lead (ringkasan inti berita standar jurnalistik)", "Detail peristiwa murni dari sumber", "Kronologi peristiwa jika ada di sumber", "Dampak pihak terkait", "Gunakan <h2>/<h3> untuk subtopik penting", "Gunakan <ul><li> jika ada poin penting", "Gunakan <blockquote> untuk kutipan", "<strong> untuk kata penting"],
      "writing_style_rules": ["Gunakan bahasa santai namun profesional.", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan", "Transisi halus"]
    }
  },
  "output_format": [
    "TITLE:", 
    "SLUG: Buat 3 opsi slug",
    "META DESCRIPTION: Buat 3-5 opsi meta",
    "ARTICLE CONTENT:",
    "BUAT 10 TAG SESUAI DENGAN ARTIKEL (koma, tanpa #, huruf kecil)",
    "category: Tentukan kategori"
  ]
}`;
        const promptJurnalisHeading = `{ "role": "Jurnalis Profesional & SEO Content Writer", "task": "Menulis ulang artikel berita dengan SANGAT AKURAT sesuai link sumber yang diberikan", "strict_accuracy_rules": { "rule_1": "Bila berupa URL, gunakan tool untuk ekstraksi teks halaman tersebut", "rule_2": "JANGAN PERNAH menyertakan data, kejadian, opini, atau waktu yang tidak tercantum di dalam teks sumber" }, "writing_goals": { "language_style": "Santai", "tone": "Netral, Objektif", "fact_policy": "100% FAKTA DARI SUMBER ASLI, DILARANG MENGARANG" }, "journalistic_standards": { "mandatory_elements_lead": "lead [3W+1H maks 160 word]", "mandatory_elements_content": "content [5W+1H]", "structure": "Piramida Terbalik", "accuracy": "Semua fakta wajib sama persis dengan sumber" }, "article_structure": { "title": { "rules": ["Menarik", "Tidak clickbait", "Sesuai sumber"] }, "meta_description": { "max_length": 160, "rules": ["Intisari berita"] }, "content": { "min_word_count": 800, "sections": ["H2: Topik utama", "H3: Penjelasan detail", "Lead", "Detail peristiwa", "Kronologi (jika ada di sumber)", "Buat blockquote Pernyataan narasumber", "Bold keyword", "Bullet list bila relevan"], "writing_style_rules": ["Bahasa santai profesional", "Kalimat aktif", "Paragraf pendek", "Gunakan struktur markup/markdown artikel yang rapi: heading, bold, blockquote, dan bullet list jika relevan"] } } }`;
        const promptSeoArtikel = `{ "role": "SEO Content Writer Professional", "goal": "Membuat artikel SEO SANGAT AKURAT dari referensi pengguna", "strict_accuracy_rules": { "rule_1": "Wajib mendasarkan seluruh konten murni pada fakta di teks/URL referensi", "rule_2": "Dilarang keras berhalusinasi atau menambahkan konteks luar" }, "general_criteria": { "minimum_word_count": 1000, "language": "Bahasa Indonesia", "writing_style": "Casual / Santai", "tone": "Informatif + Solutif", "readability": "Mudah dipahami", "seo_requirements": ["SEO-friendly", "Gunakan active voice"] }, "article_structure": { "title": { "format": "H1", "requirements": ["Mengandung keyword", "SEO optimized"] }, "meta_description": { "max_length": 160, "requirements": ["Mengandung keyword", "Relevan"] }, "introduction": { "paragraphs": "2-3 paragraphs", "requirements": ["Gaya santai", "Menarik"] }, "main_content": { "heading_structure": { "H2": "Topik utama", "H3": "Penjelasan detail" }, "mandatory_elements": ["Penjelasan mendalam murni dari sumber", "Gunakan heading H2/H3", "Gunakan bullet point", "Gunakan bold/blockquote bila relevan", "Bahas sesuai fakta referensi semata"] }, "faq_section": { "minimum_questions": 5, "format": "Tanya jawab", "requirements": ["Pertanyaan relevan dengan konten", "Jawaban akurat"] }, "conclusion": { "requirements": ["Ringkas isi artikel"] } } }`;

        const promptMap = { "default": promptDefault, "straight_news": promptStraightNews, "jurnalis_heading": promptJurnalisHeading, "seo_artikel": promptSeoArtikel };
        if (window.HEAJ && HEAJ.promptOverrides) {
            Object.keys(HEAJ.promptOverrides).forEach(key => {
                if (promptMap[key] && String(HEAJ.promptOverrides[key] || "").trim()) {
                    promptMap[key] = String(HEAJ.promptOverrides[key]);
                }
            });
        }
        if (window.HEAJ && HEAJ.customSettings && Array.isArray(HEAJ.customSettings.prompts)) {
            HEAJ.customSettings.prompts.forEach(row => {
                if (row && row.key && String(row.prompt || '').trim()) {
                    promptMap[row.key] = String(row.prompt);
                }
            });
        }

        // ---------- Skema JSON ----------
        const responseSchema = {
            type: "OBJECT",
            properties: {
                titleOptions: { type: "ARRAY", items: { type: "STRING" } },
                slugOptions: { type: "ARRAY", items: { type: "STRING" } },
                metaDescriptions: { type: "ARRAY", items: { type: "STRING" } },
                category: { type: "STRING" },
                tags: { type: "ARRAY", items: { type: "STRING" } },
                imageKeywords: { type: "STRING" },
                articleBody: { type: "STRING" },
                references: { type: "ARRAY", items: { type: "STRING" } }
            },
            required: ["titleOptions", "slugOptions", "metaDescriptions", "category", "tags", "articleBody", "references"]
        };

        const continueArticleSchema = {
            type: "OBJECT",
            properties: {
                articleBody: { type: "STRING", description: "Lanjutan articleBody dalam HTML markup. Jangan ulangi bagian sebelumnya." },
                isComplete: { type: "BOOLEAN", description: "true jika artikel sudah terasa selesai dan penutupnya lengkap." }
            },
            required: ["articleBody", "isComplete"]
        };

        const sosmedSchema = {
            type: "OBJECT",
            properties: {
                twitterThread: { type: "ARRAY", items: { type: "STRING" } },
                igFbCaption: { type: "STRING", description: "Caption gabungan untuk IG/FB dengan emoji dan CTA." }
            },
            required: ["twitterThread", "igFbCaption"]
        };

        const ringkasanSchema = {
            type: "OBJECT",
            properties: {
                takeaways: { type: "ARRAY", items: { type: "STRING" }, description: "3-5 poin ringkasan utama dan paling penting dari artikel" }
            },
            required: ["takeaways"]
        };

        const videoScriptSchema = {
            type: "OBJECT",
            properties: {
                visualCues: { type: "STRING", description: "Ide visual B-Roll untuk editor video" },
                hook: { type: "STRING", description: "Kalimat pembuka yang memancing perhatian (2-3 detik)" },
                body: { type: "ARRAY", items: { type: "STRING" }, description: "Isi skrip video narasi yang padat dan menarik" },
                cta: { type: "STRING", description: "Call to action di akhir video (misal: Follow media ini)" }
            },
            required: ["visualCues", "hook", "body", "cta"]
        };

        // ---------- UI State Management ----------
        function setUIState(state) {
            const empty = document.getElementById('emptyState');
            const load = document.getElementById('loadingState');
            const result = document.getElementById('outputContainer');
            
            empty.classList.add('hidden'); empty.classList.remove('flex');
            load.classList.add('hidden'); load.classList.remove('flex');
            result.classList.add('hidden'); result.classList.remove('flex');

            if (state === 'empty') { empty.classList.remove('hidden'); empty.classList.add('flex'); }
            else if (state === 'loading') { load.classList.remove('hidden'); load.classList.add('flex'); }
            else if (state === 'result') { result.classList.remove('hidden'); result.classList.add('flex'); }
        }

        // ---------- Toast & Copy Utility ----------
        async function copyToClipboard(text) {
            try { await navigator.clipboard.writeText(text); return true; } 
            catch {
                const textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                try { document.execCommand('copy'); document.body.removeChild(textarea); return true; } 
                catch { document.body.removeChild(textarea); return false; }
            }
        }

        function showToast(message, isError = false) {
            const toast = document.getElementById('toast');
            const icon = document.getElementById('toastIcon');
            document.getElementById('toastMessage').textContent = heajTrText(message);

            if (isError) {
                toast.classList.replace('bg-slate-800', 'bg-red-600');
                icon.setAttribute('data-lucide', 'alert-circle');
            } else {
                toast.classList.replace('bg-red-600', 'bg-slate-800');
                icon.setAttribute('data-lucide', 'check-circle-2');
            }
            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
            toast.classList.remove('translate-y-24', 'opacity-0');
            setTimeout(() => toast.classList.add('translate-y-24', 'opacity-0'), 3000);
        }

        function copyTextToClipboard(text, btnElement = null) {
            copyToClipboard(text).then(success => {
                if (success) {
                    showToast("Disalin ke clipboard!");
                    if (btnElement) {
                        const originalHTML = btnElement.innerHTML;
                        btnElement.innerHTML = '<i data-lucide="check" class="w-3 h-3 text-emerald-500"></i>';
                        if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
                        setTimeout(() => { btnElement.innerHTML = originalHTML; if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); } }, 1500);
                    }
                } else showToast("Gagal menyalin.", true);
            });
        }


        function heajLicenseUnlocked() {
            return !!(window.HEAJ && (HEAJ.licenseUnlocked === true || (HEAJ.license && HEAJ.license.valid)));
        }

        function heajLicenseMessage() {
            const msg = window.HEAJ?.license?.message || 'Fitur ini membutuhkan lisensi aktif.';
            return msg;
        }

        function heajRequireLicense(featureName = 'Fitur ini') {
            if (heajLicenseUnlocked()) return true;
            showToast(`${featureName} membutuhkan lisensi aktif. Generator artikel dasar tetap bisa digunakan.`, true);
            return false;
        }

        function heajSetLocked(el, locked, title = '') {
            if (!el) return;
            el.classList.toggle('heaj-license-locked', !!locked);
            if ('disabled' in el) el.disabled = !!locked;
            if (locked && title) el.title = title;
        }

        function heajApplyLicenseFeatureLocks() {
            const locked = !heajLicenseUnlocked();
            const title = 'Fitur ini membutuhkan lisensi aktif. Aktivasi lisensi di menu Lisensi.';
            const controlSelectors = [
                '#aiProviderSelect', '#promptSelect', '#wordCountSelect', '#languageSelect',
                '#authorSelect', '#editorSelect',
                'input[name="showSource"]'
            ];
            controlSelectors.forEach(sel => document.querySelectorAll(sel).forEach(el => heajSetLocked(el, locked, title)));

            ['btnCopyArticleHtml','btnAddDraft','btnRingkasan','btnSosmed','btnSosmedImage','btnVideoScript','btnParaphraseAgain'].forEach(id => {
                heajSetLocked(document.getElementById(id), locked, title);
            });

            ['sourceImagesSection','sourceCompareSection','editorialScoreSection','referencesSection'].forEach(id => {
                const el = document.getElementById(id);
                if (el && locked) el.classList.add('hidden');
            });

            const panel = document.querySelector('.he-control-panel');
            if (panel) {
                panel.classList.toggle('heaj-license-locked-panel', locked);
                let note = panel.querySelector('.heaj-license-lock-note');
                if (locked && !note) {
                    note = document.createElement('div');
                    note.className = 'heaj-license-lock-note';
                    note.innerHTML = `Fitur pengaturan konten, penulis/editor, audit, image source, draft, dan fitur ekstra terkunci sampai lisensi aktif. <a href="${escapeHTML(window.HEAJ?.licenseUrl || '#')}">Aktifkan lisensi</a>`;
                    panel.prepend(note);
                } else if (!locked && note) {
                    note.remove();
                }
            }
        }

        function createSelectableItem(text, container, groupName, index, isCode = false) {
            const label = document.createElement('label');
            label.className = "flex items-start gap-3 bg-white p-3 border border-slate-200 rounded-lg cursor-pointer hover:border-indigo-300 transition-colors";
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.name = groupName;
            radio.value = String(index);
            radio.className = "mt-0.5 w-4 h-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 shrink-0";
            radio.checked = index === 0;
            radio.addEventListener('change', syncSelectedSeoFields);

            const span = document.createElement(isCode ? 'code' : 'span');
            span.className = isCode ? "text-red-600 text-xs font-mono flex-1 break-all mt-0.5 bg-red-50 px-1.5 rounded" : "text-slate-700 text-xs flex-1 leading-relaxed";
            span.textContent = text;

            label.appendChild(radio);
            label.appendChild(span);
            container.appendChild(label);
        }

        function getSelectedSEOIndex(type) {
            const map = { title: 'heaj_title_option', slug: 'heaj_slug_option', meta: 'heaj_meta_option' };
            const checked = document.querySelector(`input[name="${map[type]}"]:checked`);
            return checked ? parseInt(checked.value, 10) || 0 : 0;
        }

        function getSelectedSEOValue(type) {
            if (!lastArticleData) return '';
            const map = {
                title: ['heaj_title_option', 'titleOptions'],
                slug: ['heaj_slug_option', 'slugOptions'],
                meta: ['heaj_meta_option', 'metaDescriptions']
            };
            const config = map[type];
            if (!config) return '';
            const checked = document.querySelector(`input[name="${config[0]}"]:checked`);
            const index = checked ? parseInt(checked.value, 10) : 0;
            const values = Array.isArray(lastArticleData[config[1]]) ? lastArticleData[config[1]] : [];
            return values[index] || values[0] || '';
        }

        function syncSelectedSeoFields() {
            const selectedTitle = getSelectedSEOValue('title');
            if (selectedTitle) {
                document.getElementById('articleH1').textContent = selectedTitle;
            }
        }

        // ---------- API Caller Helper ----------
        async function fetchGeminiJSON(systemPrompt, userText, schema, useSearch = false) {
            const formData = new FormData();
            formData.append('action', 'heaj_generate_content');
            formData.append('nonce', HEAJ.nonce);
            formData.append('systemPrompt', systemPrompt);
            formData.append('userText', userText);
            formData.append('schema', JSON.stringify(schema));
            formData.append('useSearch', useSearch ? '1' : '0');
            formData.append('aiProvider', document.getElementById('aiProviderSelect')?.value || 'gemini');
            formData.append('promptStyle', document.getElementById('promptSelect')?.value || '');
            formData.append('promptLabel', document.getElementById('promptSelect')?.options[document.getElementById('promptSelect')?.selectedIndex || 0]?.text || '');
            formData.append('language', document.getElementById('languageSelect')?.value || 'id');
            formData.append('sourceInput', document.getElementById('sourceInput')?.value || '');

            const res = await fetch(HEAJ.ajax_url, {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            });

            const payload = await res.json().catch(() => null);
            if (!res.ok || !payload || !payload.success) {
                if (payload?.data?.redirect_url) { window.location.href = payload.data.redirect_url; return; }
                const msg = payload?.data?.message || `HTTP ${res.status}`;
                throw new Error(msg);
            }
            if (payload?.data?.fallback_from && typeof showToast === 'function') {
                showToast(`Provider ${payload.data.fallback_from.toUpperCase()} gagal, otomatis fallback ke Gemini.`, false);
            }
            lastProviderUsed = payload.data?.provider_used || payload.data?.provider_label || (document.getElementById('aiProviderSelect')?.value || 'gemini');
            lastSourceText = payload.data?.source_context || lastSourceText || '';
            lastSourceUrl = payload.data?.source_url || lastSourceUrl || '';
            lastSourceUrls = Array.isArray(payload.data?.source_urls) ? payload.data.source_urls : (lastSourceUrl ? [lastSourceUrl] : []);
            lastHistoryId = payload.data?.history_id || '';
            const resultData = payload.data.result || {};
            resultData.sourceUrls = lastSourceUrls;
            resultData.historyId = lastHistoryId;
            return resultData;
        }

        
        function setGenerateProgress(stepIndex, message) {
            const label = document.getElementById('heajLoadingStepText');
            const steps = document.querySelectorAll('.heaj-loading-step');
            if (label) label.textContent = message || 'Memproses...';
            steps.forEach((el, idx) => {
                el.classList.toggle('is-active', idx === stepIndex);
                el.classList.toggle('is-done', idx < stepIndex);
            });
        }

        function extractSourceUrlFromInput(input) {
            const match = String(input || '').match(/https?:\/\/[^\s<>"']+/i);
            return match ? match[0] : '';
        }


        function heajArticleWordCount(html) {
            const tmp = document.createElement('div');
            tmp.innerHTML = String(html || '');
            const text = (tmp.innerText || tmp.textContent || '').replace(/\s+/g, ' ').trim();
            return text ? text.split(/\s+/).length : 0;
        }

        function heajTargetWordCountFromInstruction(value) {
            const raw = String(value || '').toLowerCase();
            if (!raw) return 0;
            const nums = raw.match(/\d{3,5}/g);
            if (!nums || !nums.length) return 0;
            return Math.max(...nums.map(n => parseInt(n, 10)).filter(Boolean));
        }

        function heajArticleLooksCutOff(html) {
            const tmp = document.createElement('div');
            tmp.innerHTML = String(html || '');
            const text = (tmp.innerText || tmp.textContent || '').replace(/\s+/g, ' ').trim();
            if (!text) return true;
            const tail = text.slice(-180).trim();
            if (/[.!?”")\]]$/.test(tail)) return false;
            if (/(,| dan| yang| untuk| dengan| dari| ke| di| pada| sebagai| karena| setelah| dalam)$/i.test(tail)) return true;
            return tail.length > 0 && !/[.!?]$/.test(tail);
        }

        function heajExtractContentBlocks(html) {
            const tmp = document.createElement('div');
            tmp.innerHTML = String(html || '');
            const nodes = tmp.querySelectorAll('h2,h3,p,li,blockquote');
            return Array.from(nodes).map(node => (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim()).filter(Boolean);
        }

        function heajMergeArticleContinuation(currentHtml, additionHtml) {
            const current = String(currentHtml || '').trim();
            let addition = String(additionHtml || '').trim();
            if (!addition) return current;
            if (addition.includes(current) && addition.length > current.length) {
                addition = addition.replace(current, '').trim();
            }

            const currentBlocks = heajExtractContentBlocks(current).slice(-8).map(t => t.toLowerCase());
            const tmp = document.createElement('div');
            tmp.innerHTML = addition;
            let changed = true;
            while (changed) {
                changed = false;
                const first = tmp.querySelector('h2,h3,p,li,blockquote');
                if (!first) break;
                const firstText = (first.innerText || first.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
                if (firstText && currentBlocks.includes(firstText)) {
                    first.remove();
                    changed = true;
                }
            }
            addition = tmp.innerHTML.trim();
            if (!addition) return current;
            return current + "\n" + addition;
        }

        async function heajContinueLongArticleIfNeeded(articleData, options) {
            const targetWords = Number(options?.targetWords || 0);
            if (!articleData || !articleData.articleBody || targetWords < 1000) return articleData;

            const maxBatches = 4;
            const minAcceptable = Math.floor(targetWords * 0.94);
            let currentBody = String(articleData.articleBody || '');
            let currentWords = heajArticleWordCount(currentBody);
            const sourceContext = String(lastSourceText || options.sourceInput || '').slice(0, 14000);
            const languageRule = options.languageHardRule || '';
            const baseSystemPrompt = options.finalSystemPrompt || '';

            for (let batch = 1; batch <= maxBatches; batch++) {
                const cutOff = heajArticleLooksCutOff(currentBody);
                currentWords = heajArticleWordCount(currentBody);
                if (currentWords >= minAcceptable && !cutOff) break;

                setGenerateProgress(2, `Artikel panjang belum selesai (${currentWords}/${targetWords} kata). Melanjutkan batch ${batch}...`);

                const tail = currentBody.replace(/\s+/g, ' ').slice(-2200);
                const remaining = Math.max(250, targetWords - currentWords);
                const continueSystemPrompt = `${baseSystemPrompt}

MODE BATCH CONTINUE ARTIKEL PANJANG:
- Anda hanya melanjutkan field articleBody, bukan membuat metadata baru.
- Jangan ulangi paragraf, heading, lead, byline, atau bagian yang sudah ada.
- Mulai langsung dari lanjutan natural setelah akhir artikel saat ini.
- Gunakan markup HTML yang sama: <h2>, <h3>, <p>, <blockquote>, <ul><li> bila relevan.
- Target tambahan sekitar ${remaining} kata, tetapi tetap natural dan tidak memanjang kosong.
- Jika artikel sudah lengkap, buat penutup yang rapi lalu set isComplete true.
- Tetap hanya memakai fakta dari sumber. Jangan menambah data baru di luar sumber.
- Output wajib JSON sesuai schema.`;

                const continueUserPrompt = `${languageRule}

SUMBER / KONTEKS FAKTA:
${sourceContext}

ARTIKEL SAAT INI SUDAH BERISI ${currentWords} KATA.
LANJUTKAN DARI BAGIAN AKHIR INI, JANGAN ULANGI:

${tail}

TUGAS:
Lanjutkan articleBody agar artikel mencapai minimal sekitar ${targetWords} kata bila sumber memang cukup. Jangan menulis judul utama, slug, meta description, tags, atau byline.`;

                const part = await fetchGeminiJSON(continueSystemPrompt, continueUserPrompt, continueArticleSchema, false);
                const addition = part?.articleBody || '';
                if (!addition || heajArticleWordCount(addition) < 40) break;

                const merged = heajMergeArticleContinuation(currentBody, addition);
                if (heajArticleWordCount(merged) <= currentWords + 20) break;

                currentBody = merged;
                articleData.articleBody = currentBody;

                if (part?.isComplete && heajArticleWordCount(currentBody) >= minAcceptable) break;
            }

            return articleData;
        }

        // ---------- Fitur Utama: Proses Artikel ----------
        async function processArticle() {
            const sourceInput = document.getElementById('sourceInput').value.trim();
            lastInputHasUrl = /https?:\/\//i.test(sourceInput || '');
            const draftStatusEl = document.getElementById('draftStatus');
            if (draftStatusEl) { draftStatusEl.classList.add('hidden'); draftStatusEl.innerHTML = ''; }
            if (!sourceInput) return showToast("Mohon masukkan tautan atau teks sumber.", true);

            lastSourceText = '';
            lastSourceUrl = '';
            lastSourceUrls = [];
            lastHistoryId = '';
            lastProviderUsed = '';

            const btn = document.getElementById('generateBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="loader" style="width:16px;height:16px;border-width:2px;border-top-color:white;"></div> <span class="ml-2">Memproses...</span>';
            btn.classList.replace('bg-red-600','bg-red-400');

            setGenerateProgress(0, 'Membaca sumber dan menyiapkan konteks...');
            setUIState('loading');
            closeFeature('sosmedContainer');
            closeFeature('ringkasanContainer');
            closeFeature('videoScriptContainer');
            closeFeature('sosmedImageContainer');

            try {
                const selectedPromptKey = document.getElementById('promptSelect').value;
                const selectedWordCount = document.getElementById('wordCountSelect').value;
                const selectedLanguage = document.getElementById('languageSelect')?.value || 'id';
                let finalSystemPrompt = promptMap[selectedPromptKey] || promptDefault;
                const languageHardRule = selectedLanguage === 'en'
                    ? 'ABSOLUTE LANGUAGE RULE: Ignore any Bahasa Indonesia language instruction inside the selected prompt. Return every generated field in English: titleOptions, slugOptions, metaDescriptions, category, tags, articleBody, imageKeywords, summaries, captions, and scripts. Only keep proper nouns and direct quotes in their original form.'
                    : 'ATURAN BAHASA MUTLAK: Gunakan Bahasa Indonesia untuk semua field output kecuali nama diri dan kutipan langsung dari sumber.';
                finalSystemPrompt = languageHardRule + `\n\n` + finalSystemPrompt;
                if (window.HEAJ && HEAJ.brandInstruction) {
                    finalSystemPrompt += `\n\nBRAND PROFILE / WHITE LABEL:\n${String(HEAJ.brandInstruction)}`;
                }
                if (window.HEAJ && HEAJ.promptOverrides && String(HEAJ.promptOverrides.global || '').trim()) {
                    finalSystemPrompt += `\n\nINSTRUKSI GLOBAL CUSTOM DARI ADMIN:\n${String(HEAJ.promptOverrides.global)}`;
                }
                
                if (selectedWordCount) finalSystemPrompt += `\n\nINSTRUKSI TAMBAHAN: Panjang artikel wajib ${selectedWordCount}.`;
                if (selectedLanguage === 'en') {
                    finalSystemPrompt += `\n\nLANGUAGE OVERRIDE: Write ALL generated output in English, including titleOptions, slugOptions, metaDescriptions, category, tags, articleBody, takeaways, captions, and video scripts. Keep proper nouns and original quotes accurate. Use English journalistic style.`;
                } else {
                    finalSystemPrompt += `\n\nBAHASA OUTPUT: Gunakan Bahasa Indonesia untuk seluruh output.`;
                }
                if (['straight_news', 'jurnalis_heading', 'seo_artikel'].includes(selectedPromptKey)) {
                    finalSystemPrompt += `\n\nFORMAT MARKUP ARTIKEL: Untuk articleBody, gunakan markup artikel yang kaya dan rapi: <h2>, <h3>, <p>, <strong>, <blockquote>, dan <ul><li> bila relevan. Jangan mengembalikan teks polos.`;
                }
                finalSystemPrompt += `\n\nATURAN KETAT AKURASI, PARAGRAF & TANGGAL:
                1. SANGAT PENTING: DILARANG KERAS berhalusinasi. Anda HANYA BOLEH memparafrase fakta, tokoh, lokasi, dan kejadian yang BENAR-BENAR TERCANTUM di dalam sumber. Jangan mengambil info eksternal.
                2. Hasil harus format JSON dengan schema yang ditentukan.
                3. Untuk 'articleBody', WAJIB menggunakan tag <p> untuk setiap paragraf.
                4. Setiap paragraf (kecuali leads/pengantar dan blockquote/kutipan) HARUS maksimal 2 kalimat saja.
                5. Jangan gunakan <br> sebagai pemisah paragraf.
                6. PENTING UNTUK TANGGAL: Analisis dan ekstrak TANGGAL KEJADIAN secara akurat murni dari sumber teks/link. DILARANG KERAS menggunakan tanggal acak, tanggal default, atau tanggal hari ini jika tidak tercantum dalam sumber.
                7. TANGGAL, JAM, ANGKA, LOKASI, NAMA NARASUMBER, JABATAN, DAN KUTIPAN LANGSUNG WAJIB SAMA PERSIS DENGAN SUMBER.
                8. Kutipan di dalam tanda petik TIDAK BOLEH diparafrase. Salin verbatim dan gunakan <blockquote> bila relevan.
                9. Narasi di luar kutipan WAJIB diparafrase secara unik: ubah struktur kalimat, urutan penjelasan, dan pilihan kata tanpa mengubah fakta. Jangan menyalin paragraf sumber secara sama persis.
                10. Jangan melakukan spinning dangkal. Tulis ulang seperti redaktur manusia: tetap faktual, natural, dan berbeda susunan dari sumber.
                11. Jika ada 2-3 kalimat sumber yang berurutan, jangan menyalinnya dengan urutan dan bentuk yang sama; rangkum atau pecah ulang menjadi paragraf baru.
                12. Jika data pasti tidak ditemukan dalam sumber, JANGAN mengarang pengganti. Lebih baik hilangkan bagian tersebut daripada menulis fakta palsu.
                13. MODE MULTI-SUMBER: Jika input berisi beberapa URL, jangan menjadikan URL pertama sebagai sumber utama otomatis. Korelasikan semua sumber, cari irisan fakta, perbedaan fokus, dan nilai berita paling kuat. Tentukan angle artikel berdasarkan dampak publik, kebaruan, bukti terkuat, dan relevansi antar sumber.`;
                if (forceParaphraseMode) {
                    finalSystemPrompt += `\n\nMODE PARAFRASE ULANG: Fokus utama adalah menurunkan kemiripan narasi dengan sumber. Pertahankan semua data pasti dan kutipan langsung secara akurat, tetapi ubah total struktur paragraf, alur kalimat, dan cara penyampaian narasi non-kutipan. Jangan menyalin susunan kalimat sumber.`;
                }

                setGenerateProgress(1, 'Mengunci data fakta, kutipan, tanggal, angka, dan narasumber...');

                const userPrompt = `${languageHardRule}\n\nTUGAS: Tulis ulang referensi berita di bawah ini dengan akurasi fakta 100%. SANGAT DILARANG menambahkan narasi, tokoh, tanggal, jam, lokasi, angka, kutipan, atau nama narasumber fiktif yang tidak ada di sumber. Jika sumber berupa URL, server akan menambahkan teks sumber hasil ekstraksi; gunakan teks itu sebagai rujukan utama.\n\nSumber Referensi:\n\n${sourceInput}`;

                setGenerateProgress(2, 'Menulis ulang artikel dan metadata SEO...');
                lastSourceUrl = extractSourceUrlFromInput(sourceInput);
                lastArticleData = await fetchGeminiJSON(finalSystemPrompt, userPrompt, responseSchema, true);

                const targetWordCount = heajTargetWordCountFromInstruction(selectedWordCount);
                if (targetWordCount >= 1000) {
                    lastArticleData = await heajContinueLongArticleIfNeeded(lastArticleData, {
                        targetWords: targetWordCount,
                        sourceInput,
                        finalSystemPrompt,
                        languageHardRule
                    });
                }

                setGenerateProgress(3, 'Mengambil gambar sumber dan menyiapkan preview...');
                lastSourceImages = await fetchSourceImages(sourceInput);
                if (!lastSourceImages.length) {
                    const pexelsQuery = buildPexelsQueryFromArticle(lastArticleData, sourceInput);
                    lastSourceImages = await fetchPexelsImages(pexelsQuery);
                }
                lastArticleData.sourceImages = lastSourceImages;
                lastArticleData.imageSourceType = lastSourceImages.some(img => (img.source_type || img.scope) === 'pexels') ? 'pexels' : (lastSourceImages.length ? 'source' : 'none');
                updateHistoryImageMeta(lastArticleData.imageSourceType, lastSourceImages.length);
                
                // Injeksi Byline Penulis & Editor
                const author = document.getElementById('authorSelect').value;
                const editor = document.getElementById('editorSelect').value;
                if (author || editor) {
                    let authorPart = author ? `<b>${author}</b> <span style="font-size: x-small;">Penulis</span>` : '';
                    let editorPart = editor ? `<b>${editor}</b> <span style="font-size: x-small;">Editor</span>` : '';
                    let separator = (author && editor) ? ' | ' : '';
                    let bylineHTML = `<p class="lh-normal">${authorPart}${separator}${editorPart}</p>\n`;
                    lastArticleData.articleBody = bylineHTML + lastArticleData.articleBody;
                }
                
                setGenerateProgress(4, 'Finalisasi draft dan audit redaksi...');
                renderResults(lastArticleData);
                setUIState('result');
                showToast("Artikel berhasil dibuat!");
                forceParaphraseMode = false;
            } catch (e) {
                console.error(e);
                setUIState('empty');
                showToast(e?.message || "Gagal memproses artikel. Coba lagi.", true);
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i data-lucide="sparkles" class="w-4 h-4"></i> ' + heajTrText('Buat Artikel');
                btn.classList.replace('bg-red-400','bg-red-600');
                if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
            }
        }

        // ---------- Fitur Tambahan (Ringkasan, Sosmed, Video) ----------
        function getLanguageInstruction() {
            const code = document.getElementById('languageSelect')?.value || 'id';
            const langs = (window.HEAJ && HEAJ.customSettings && Array.isArray(HEAJ.customSettings.languages)) ? HEAJ.customSettings.languages : [];
            const found = langs.find(l => l && l.code === code);
            if (found && String(found.instruction || '').trim()) return String(found.instruction).trim();
            return code === 'en' ? 'Write the output in English.' : 'Tulis output dalam Bahasa Indonesia.';
        }

        function getCleanArticleText() {
            if (!lastArticleData || !lastArticleData.articleBody) return "";
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = lastArticleData.articleBody;
            return tempDiv.textContent || tempDiv.innerText || "";
        }

        async function generateRingkasan() {
            if (!heajRequireLicense('Ringkasan Cepat')) return;
            const cleanText = getCleanArticleText();
            if (!cleanText) return showToast("Silakan buat artikel terlebih dahulu.", true);

            const btn = document.getElementById('btnRingkasan');
            const container = document.getElementById('ringkasanContainer');
            const loader = document.getElementById('ringkasanLoading');
            const content = document.getElementById('outRingkasan');

            btn.disabled = true; btn.classList.add('opacity-70');
            container.classList.remove('hidden');
            loader.classList.remove('hidden'); loader.classList.add('flex');
            content.classList.add('hidden');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });

            const sysPrompt = "Buat 3-5 poin ringkasan utama (Key Takeaways) dari artikel berita berikut. Tulis singkat, padat, dan representatif. " + getLanguageInstruction();
            
            try {
                const result = await fetchGeminiJSON(sysPrompt, `Artikel:\n${cleanText}`, ringkasanSchema);
                const ul = document.getElementById('ringkasanList');
                ul.innerHTML = '';
                result.takeaways.forEach(poin => {
                    const li = document.createElement('li');
                    li.textContent = poin;
                    ul.appendChild(li);
                });
                loader.classList.add('hidden'); loader.classList.remove('flex');
                content.classList.remove('hidden');
                showToast("Ringkasan berhasil dibuat!");
            } catch (e) {
                container.classList.add('hidden');
                showToast("Gagal menyusun ringkasan.", true);
            } finally {
                btn.disabled = false; btn.classList.remove('opacity-70');
            }
        }

        async function generateSosmed() {
            if (!heajRequireLicense('Draft Sosmed')) return;
            const cleanText = getCleanArticleText();
            if (!cleanText) return showToast("Silakan buat artikel terlebih dahulu.", true);

            const btn = document.getElementById('btnSosmed');
            const container = document.getElementById('sosmedContainer');
            const loader = document.getElementById('sosmedLoading');
            const content = document.getElementById('sosmedContent');

            btn.disabled = true; btn.classList.add('opacity-70');
            container.classList.remove('hidden');
            loader.classList.remove('hidden'); loader.classList.add('flex');
            content.classList.add('hidden'); content.classList.remove('grid');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });

            const sysPrompt = `Berdasarkan isi artikel berita yang diberikan, buatkan draft postingan sosial media yang menarik, interaktif, dan sesuai dengan gaya bahasa jurnalistik santai khas media ini.
            1. twitterThread: Buat utas (thread) Twitter/X singkat yang terdiri dari 3-4 tweet bersambung.
            2. igFbCaption: Buat caption gabungan yang dioptimalkan untuk Instagram dan Facebook sekaligus. Sertakan emoji, berikan pertanyaan untuk diskusi audiens, dan hashtags relevan.
            ${getLanguageInstruction()}`;

            try {
                const sosmedData = await fetchGeminiJSON(sysPrompt, `Artikel:\n${cleanText}`, sosmedSchema);

                const twContainer = document.getElementById('outTwitter');
                twContainer.innerHTML = '';
                sosmedData.twitterThread.forEach((tweet, index) => {
                    const p = document.createElement('p');
                    p.className = "pb-2 mb-2 border-b border-indigo-50 last:border-0 last:mb-0 last:pb-0";
                    p.innerHTML = `<strong>${index + 1}/</strong> ${tweet}`;
                    twContainer.appendChild(p);
                });

                document.getElementById('outIgFb').innerText = sosmedData.igFbCaption;

                loader.classList.add('hidden'); loader.classList.remove('flex');
                content.classList.remove('hidden'); content.classList.add('grid');
                showToast("Draft sosial media berhasil dibuat!");
            } catch (error) {
                container.classList.add('hidden');
                showToast("Gagal membuat draft sosmed.", true);
            } finally {
                btn.disabled = false; btn.classList.remove('opacity-70');
            }
        }

        function getCurrentWebsiteText() {
            try {
                if (window.HEAJ && HEAJ.siteHost) return String(HEAJ.siteHost).replace(/^www\./, '');
            } catch (e) {}
            try {
                return window.location.hostname.replace(/^www\./, '');
            } catch (e) { return ''; }
        }

        function getSelectedSocialImageSource() {
            const picked = (selectedSourceImages && selectedSourceImages[0]) ? selectedSourceImages[0] : null;
            const fallback = (lastSourceImages && lastSourceImages[0]) ? lastSourceImages[0] : null;
            const img = picked || fallback || {};
            return {
                url: img.url || '',
                preview_url: img.preview_url || img.url || '',
                caption: img.caption || '',
                source_type: img.source_type || img.scope || 'source',
                is_manual: !!img.is_manual,
                manual_id: img.manual_id || '',
                file: img.file || null,
                file_name: img.file?.name || ''
            };
        }

        function buildSocialImagePrompt(platform, config) {
            const title = getSelectedSEOValue('title') || document.getElementById('articleH1')?.textContent || 'Judul artikel';
            const description = getSelectedSEOValue('meta') || (lastArticleData?.metaDescriptions?.[0] || 'Deskripsi singkat artikel.');
            const category = lastArticleData?.category || document.getElementById('badgeCategory')?.textContent || 'Berita';
            const website = getCurrentWebsiteText();
            const sourceImage = getSelectedSocialImageSource();
            const brand = (window.HEAJ && HEAJ.brand) ? HEAJ.brand : {};
            const mediaName = (window.HEAJ && HEAJ.mediaName) ? HEAJ.mediaName : (brand.media_name || brand.brand_name || 'HarianExpress');
            const logoUrl = brand.logo_url || '';
            const primaryColor = brand.primary_color || '#e30613';

            return {
                platform: platform,
                aspect_ratio: config.aspect_ratio,
                output_size: config.output_size,
                category: String(category).trim(),
                image: (sourceImage.is_manual ? (sourceImage.preview_url || sourceImage.url) : sourceImage.url) || '{{IMAGE_ARTIKEL}}',
                image_caption: sourceImage.caption || '',
                title: String(title).trim(),
                description: String(description).trim(),
                website: website || '{{WEBSITE}}',
                logo: logoUrl || '{{LOGO_HARIANEXPRESS_ASLI}}',
                brand_rules: {
                    media_name: mediaName,
                    primary_color: primaryColor,
                    logo_position: config.logo_position,
                    do_not_modify_logo: true,
                    instruction: 'Gunakan logo asli yang diberikan. Jangan ubah bentuk, warna, proporsi, teks, ikon, atau komposisi logo.'
                },
                design_template: {
                    visual_style: config.visual_style,
                    mood: 'dramatis, editorial, modern, high contrast, cocok untuk konten berita sosial media',
                    color_palette: ['black', 'white', primaryColor, 'dark gray'],
                    texture: ['subtle grain', 'dark vignette', 'grunge overlay ringan', 'halftone accent merah secukupnya'],
                    typography: {
                        headline: 'extra bold condensed sans-serif, uppercase, readable, strong editorial impact',
                        description: 'clean sans-serif, small-medium, readable',
                        website: 'small clean sans-serif'
                    },
                    layout: config.layout
                },
                prompt: `Buat visual konten sosial media ${platform} rasio ${config.aspect_ratio} ukuran ${config.output_size} untuk berita ${mediaName}. Gunakan image utama sebagai visual dominan. Tema desain editorial berita yang dramatis, modern, high contrast, warna hitam-putih dengan aksen merah/primary brand. Tambahkan tekstur grunge halus, grain, vignette gelap, dan elemen garis merah khas media. Tampilkan kategori "${String(category).trim()}" sebagai label kecil. Tampilkan judul besar uppercase "${String(title).trim()}" dengan font condensed bold yang sangat readable. Tambahkan deskripsi singkat "${String(description).trim()}". Letakkan website "${website || '{{WEBSITE}}'}" sesuai layout. Letakkan logo asli di ${config.logo_position}; jangan mengubah logo dalam bentuk, warna, proporsi, teks, ikon, atau komposisinya. Pastikan wajah/subjek utama pada image tidak tertutup headline, teks berada di safe area, dan komposisi profesional seperti poster berita premium.`,
                negative_prompt: [
                    'jangan ubah logo',
                    'jangan redesign logo',
                    'jangan stretch logo',
                    'jangan ubah warna logo',
                    'jangan tambah logo palsu',
                    'jangan style kartun',
                    'jangan teks keluar canvas',
                    'jangan headline menutupi wajah/subjek utama',
                    'jangan typo',
                    'jangan low contrast text',
                    'jangan elemen tidak relevan'
                ]
            };
        }


        function triggerDownload(url, filename = '') {
            if (!url) return;
            const a = document.createElement('a');
            a.href = url;
            if (filename) a.download = filename;
            a.rel = 'noopener';
            document.body.appendChild(a);
            a.click();
            a.remove();
        }

        function getSelectedGeneratedSocialImage() {
            if (!Array.isArray(lastGeneratedSocialImages) || !lastGeneratedSocialImages.length) return null;
            const selected = lastGeneratedSocialImages.find(item => item.platform === selectedSocialImagePlatform);
            return selected || lastGeneratedSocialImages[0] || null;
        }

        function syncSelectedSocialImageCard() {
            document.querySelectorAll('.heaj-sosmed-image-result-card[data-platform]').forEach(card => {
                const active = card.getAttribute('data-platform') === selectedSocialImagePlatform;
                card.classList.toggle('is-selected', active);
            });
        }

        function setSelectedSocialImagePlatform(platform) {
            selectedSocialImagePlatform = platform || '';
            syncSelectedSocialImageCard();
        }

        function buildSocialImagePromptBundle() {
            return {
                generated_at: new Date().toISOString(),
                source_url: lastSourceUrl || (lastSourceUrls && lastSourceUrls[0]) || '',
                fixed_rules: {
                    keep_logo_unchanged: true,
                    use_same_brand_scheme: true,
                    prioritize_readable_typography: true,
                    keep_all_text_inside_safe_area: true
                },
                prompts: {
                    instagram: buildSocialImagePrompt('Instagram Feed', {
                        aspect_ratio: '4:5',
                        output_size: '1080x1350',
                        logo_position: 'bottom-left footer area',
                        visual_style: 'vertical dramatic editorial news poster',
                        layout: 'main image on upper 55%, dark gradient lower area, category label top-left, huge headline lower-middle, description below headline, footer with logo left and website right'
                    }),
                    pinterest: buildSocialImagePrompt('Pinterest Pin', {
                        aspect_ratio: '2:3',
                        output_size: '1000x1500',
                        logo_position: 'bottom-left',
                        visual_style: 'tall premium editorial pin with strong headline stack',
                        layout: 'main image top, headline stacked vertically in lower-middle, description compact, footer with logo and website, more vertical breathing room'
                    }),
                    linkedin: buildSocialImagePrompt('LinkedIn Post', {
                        aspect_ratio: '1.91:1',
                        output_size: '1200x627',
                        logo_position: 'bottom-left',
                        visual_style: 'wide professional editorial news banner',
                        layout: 'image subject on right or center, dark text panel on left, category label top-left, headline large but max 3 lines, description short, website bottom-right'
                    })
                }
            };
        }

        function renderSocialImagePromptCard(key, item) {
            const labelMap = { instagram: 'Instagram 4:5', pinterest: 'Pinterest 2:3', linkedin: 'LinkedIn 1.91:1' };
            const jsonText = JSON.stringify(item, null, 2);
            return `
                <div class="heaj-sosmed-image-card">
                    <div class="heaj-sosmed-image-card-head">
                        <div>
                            <strong>${escapeHTML(labelMap[key] || key)}</strong>
                            <small>${escapeHTML(item.output_size || '')}</small>
                        </div>
                        <button type="button" class="heaj-sosmed-image-copy" data-social-image-key="${escapeHTML(key)}">
                            <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy
                        </button>
                    </div>
                    <pre id="heajSocialImagePrompt_${escapeHTML(key)}">${escapeHTML(jsonText)}</pre>
                </div>`;
        }

        function generateSocialImagePrompts() {
            if (!lastArticleData || !lastArticleData.articleBody) return showToast('Silakan buat artikel terlebih dahulu.', true);
            lastSocialImagePromptBundle = buildSocialImagePromptBundle();
            const container = document.getElementById('sosmedImageContainer');
            const grid = document.getElementById('sosmedImagePromptGrid');
            if (!container || !grid) return;
            grid.innerHTML = Object.keys(lastSocialImagePromptBundle.prompts).map(key => renderSocialImagePromptCard(key, lastSocialImagePromptBundle.prompts[key])).join('');
            grid.querySelectorAll('[data-social-image-key]').forEach(btn => {
                btn.addEventListener('click', () => {
                    const key = btn.getAttribute('data-social-image-key');
                    const item = lastSocialImagePromptBundle?.prompts?.[key];
                    if (item) copyTextToClipboard(JSON.stringify(item, null, 2), btn);
                });
            });
            container.classList.remove('hidden');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });
            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
            showToast('Prompt image sosial media berhasil dibuat!');
        }

        function copySocialImagePromptBundle(btnElement = null) {
            if (!lastSocialImagePromptBundle) {
                if (!lastArticleData) return showToast('Silakan buat artikel terlebih dahulu.', true);
                lastSocialImagePromptBundle = buildSocialImagePromptBundle();
            }
            const selectedItem = getSelectedGeneratedSocialImage();
            const selectedPrompt = selectedItem?.platform ? lastSocialImagePromptBundle?.prompts?.[selectedItem.platform] : null;
            const payload = selectedPrompt ? selectedPrompt : lastSocialImagePromptBundle;
            copyTextToClipboard(JSON.stringify(payload, null, 2), btnElement);
            if (selectedItem?.url) {
                triggerDownload(selectedItem.url, selectedItem.filename || 'social-image.png');
                showToast('Prompt berhasil dicopy dan image terpilih diunduh.');
            }
        }


        function buildSocialImageRequestPayload() {
            const sourceImage = getSelectedSocialImageSource();
            const brand = (window.HEAJ && HEAJ.brand) ? HEAJ.brand : {};
            return {
                title: getSelectedSEOValue('title') || document.getElementById('articleH1')?.textContent || 'Judul artikel',
                slug: getSelectedSEOValue('slug') || (lastArticleData?.slug || ''),
                description: getSelectedSEOValue('meta') || (lastArticleData?.metaDescriptions?.[0] || ''),
                category: lastArticleData?.category || document.getElementById('badgeCategory')?.textContent || 'BERITA',
                sub_category: (document.getElementById('contentStyle')?.selectedOptions?.[0]?.textContent || '').replace(/\s+/g, ' ').trim(),
                website: '',
                image_url: sourceImage.is_manual ? '' : (sourceImage.url || ''),
                image_is_manual: sourceImage.is_manual ? '1' : '0',
                manual_image_id: sourceImage.manual_id || '',
                image_caption: sourceImage.caption || '',
                logo_url: brand.logo_url || '',
                ai_provider: document.getElementById('aiProviderSelect')?.value || 'gemini',
                _sourceImage: sourceImage
            };
        }

        function renderGeneratedSocialImageCard(item) {
            const label = item.label || item.platform || 'Social Image';
            const size = `${item.width || ''}x${item.height || ''}`;
            const url = item.url || '#';
            const platform = item.platform || '';
            const kb = item.compressed_bytes ? Math.ceil(Number(item.compressed_bytes) / 1024) : 0;
            const compressText = kb ? ` · ${kb}KB` : '';
            const selectedClass = platform && platform === selectedSocialImagePlatform ? ' is-selected' : '';
            return `
                <div class="heaj-sosmed-image-card heaj-sosmed-image-result-card${selectedClass}" data-platform="${escapeHTML(platform)}">
                    <div class="heaj-sosmed-image-card-head">
                        <div>
                            <strong>${escapeHTML(label)}</strong>
                            <small>${escapeHTML(size)} ${escapeHTML((item.engine || 'AI').toUpperCase())}${item.filename ? ' · ' + escapeHTML(item.filename) : ''}${escapeHTML(compressText)}</small>
                        </div>
                        <div class="heaj-sosmed-image-actions">
                            <a class="heaj-sosmed-image-copy" href="${escapeHTML(url)}" target="_blank" rel="noopener">
                                <i data-lucide="external-link" class="w-3.5 h-3.5"></i> Buka
                            </a>
                            <a class="heaj-sosmed-image-copy" href="${escapeHTML(url)}" download>
                                <i data-lucide="download" class="w-3.5 h-3.5"></i> PNG
                            </a>
                        </div>
                    </div>
                    <a class="heaj-sosmed-image-preview-link" href="${escapeHTML(url)}" target="_blank" rel="noopener" aria-label="Buka ${escapeHTML(label)}">
                        <img src="${escapeHTML(url)}" alt="${escapeHTML(label)}" loading="lazy" />
                    </a>
                </div>`;
        }

        async function generateSocialImages() {
            if (!heajRequireLicense('Image Sosmed')) return;
            if (!lastArticleData || !lastArticleData.articleBody) return showToast('Silakan buat artikel terlebih dahulu.', true);
            const payload = buildSocialImageRequestPayload();
            lastSocialImagePromptBundle = buildSocialImagePromptBundle();
            if (!payload.image_url && !(payload._sourceImage && payload._sourceImage.is_manual && payload._sourceImage.file)) {
                return showToast('Pilih minimal 1 gambar sumber/featured image terlebih dahulu.', true);
            }

            const btn = document.getElementById('btnSosmedImage');
            const container = document.getElementById('sosmedImageContainer');
            const grid = document.getElementById('sosmedImagePromptGrid');
            const loader = document.getElementById('sosmedImageLoading');
            if (!container || !grid) return;

            const oldHTML = btn ? btn.innerHTML : '';
            if (btn) {
                btn.disabled = true;
                btn.classList.add('opacity-70');
                btn.innerHTML = '<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i> Generate...';
            }
            container.classList.remove('hidden');
            grid.innerHTML = '';
            if (loader) { loader.classList.remove('hidden'); loader.classList.add('flex'); }
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });
            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }

            const formData = new FormData();
            formData.append('action', 'heaj_generate_social_images');
            formData.append('nonce', HEAJ.nonce);
            Object.keys(payload).forEach(key => {
                if (key === '_sourceImage') return;
                formData.append(key, payload[key] || '');
            });
            if (payload._sourceImage && payload._sourceImage.is_manual && payload._sourceImage.file) {
                formData.append('manual_social_image', payload._sourceImage.file, payload._sourceImage.file.name || 'manual-social-image.jpg');
            }

            try {
                const res = await fetch(HEAJ.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                const json = await res.json();
                if (!res.ok || !json.success) throw new Error(json?.data?.message || 'Gagal membuat image sosial media.');
                const items = Array.isArray(json.data?.items) ? json.data.items : [];
                lastGeneratedSocialImages = items;
                selectedSocialImagePlatform = items[0]?.platform || '';
                grid.innerHTML = items.map(renderGeneratedSocialImageCard).join('');
                syncSelectedSocialImageCard();
                showToast(json.data?.message || 'Image sosial media berhasil dibuat.');
            } catch (error) {
                grid.innerHTML = `<div class="heaj-sosmed-image-error">${escapeHTML(error.message || 'Gagal membuat image sosial media.')}</div>`;
                showToast(error.message || 'Gagal membuat image sosial media.', true);
            } finally {
                if (loader) { loader.classList.add('hidden'); loader.classList.remove('flex'); }
                if (btn) {
                    btn.disabled = false;
                    btn.classList.remove('opacity-70');
                    btn.innerHTML = oldHTML;
                }
                if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
            }
        }

        async function generateVideoScript() {
            if (!heajRequireLicense('Skrip TikTok/Reels')) return;
            const cleanText = getCleanArticleText();
            if (!cleanText) return showToast("Silakan buat artikel terlebih dahulu.", true);

            const btn = document.getElementById('btnVideoScript');
            const container = document.getElementById('videoScriptContainer');
            const loader = document.getElementById('videoScriptLoading');
            const content = document.getElementById('outVideoScript');

            btn.disabled = true; btn.classList.add('opacity-70');
            container.classList.remove('hidden');
            loader.classList.remove('hidden'); loader.classList.add('flex');
            content.classList.add('hidden');
            container.scrollIntoView({ behavior: 'smooth', block: 'end' });

            const sysPrompt = `Konversi artikel berita ini menjadi skrip video vertikal singkat (TikTok/Instagram Reels/Shorts) berdurasi 30-60 detik. 
            Gunakan gaya bahasa yang LUGAS, TEGAS, dan KHAS JURNALISTIK PROFESIONAL (Straight News). Sampaikan fakta secara langsung, to the point, namun tetap ringkas untuk format video pendek. Pisahkan ke dalam JSON: 
            - visualCues: Arahan visual/B-roll untuk editor.
            - hook: Kalimat pembuka yang tegas dan langsung membidik inti berita (0-3 detik).
            - body: Array isi cerita (voiceover) yang padat fakta (5W+1H) tanpa basa-basi.
            - cta: Ajak penonton memberikan tanggapan atau follow media ini.
            ${getLanguageInstruction()}`;

            try {
                const scriptData = await fetchGeminiJSON(sysPrompt, `Artikel:\n${cleanText}`, videoScriptSchema);

                document.getElementById('outVideoVisuals').innerText = scriptData.visualCues;
                document.getElementById('outVideoHook').innerText = `"${scriptData.hook}"`;
                
                const bodyContainer = document.getElementById('outVideoBody');
                bodyContainer.innerHTML = '';
                scriptData.body.forEach(paragraf => {
                    const p = document.createElement('p');
                    p.className = "mb-1";
                    p.textContent = paragraf;
                    bodyContainer.appendChild(p);
                });
                
                document.getElementById('outVideoCta').innerText = scriptData.cta;

                loader.classList.add('hidden'); loader.classList.remove('flex');
                content.classList.remove('hidden');
                showToast("Skrip video berhasil dibuat!");
            } catch (e) {
                container.classList.add('hidden');
                showToast("Gagal menyusun skrip video.", true);
            } finally {
                btn.disabled = false; btn.classList.remove('opacity-70');
            }
        }

        function closeFeature(containerId) {
            document.getElementById(containerId).classList.add('hidden');
        }



        async function fetchSourceImages(sourceInput) {
            const hasUrl = /https?:\/\//i.test(sourceInput || '');
            if (!hasUrl) return [];
            const formData = new FormData();
            formData.append('action', 'heaj_fetch_source_images');
            formData.append('nonce', HEAJ.nonce);
            formData.append('source', sourceInput);
            try {
                const res = await fetch(HEAJ.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                const payload = await res.json().catch(() => null);
                if (!res.ok || !payload || !payload.success) return [];
                return Array.isArray(payload.data?.images) ? payload.data.images : [];
            } catch (e) {
                console.warn('Gagal mengambil gambar sumber', e);
                return [];
            }
        }


        function stripHtmlText(html) {
            const tmp = document.createElement('div');
            tmp.innerHTML = String(html || '');
            return (tmp.textContent || tmp.innerText || '').replace(/\s+/g, ' ').trim();
        }

        function normalizePexelsQueryText(value) {
            let raw = String(value || '').toLowerCase();
            raw = raw.replace(/https?:\/\/\S+/gi, ' ');
            raw = raw.replace(/\b(ilustrasi\s*foto|foto\s*ilustrasi|ilustrasi|foto|gambar|berita|artikel|news|image|photo|picture|pexels|caption|sumber|source|redaksi|reporter|editor|wartawan|jurnalis|kamera|camera|media|breaking|viral)\b/gi, ' ');
            raw = raw.replace(/[^\p{L}\p{N}\s-]+/gu, ' ').replace(/\s+/g, ' ').trim();
            return raw;
        }

        function translateVisualTopic(raw) {
            const text = normalizePexelsQueryText(raw);
            const rules = [
                { rx: /\b(banjir|katulampa|ciliwung|tma|bendungan|bendung|sungai|meluap|debit|siaga|hujan|puncak|bogor)\b/iu, q: 'flood river rain dam' },
                { rx: /\b(kebakaran|api|terbakar|pemadam)\b/iu, q: 'fire emergency smoke' },
                { rx: /\b(gempa|magnitudo|bencana|tsunami)\b/iu, q: 'earthquake disaster damage' },
                { rx: /\b(longsor|tanah longsor|tebing)\b/iu, q: 'landslide disaster mountain' },
                { rx: /\b(kecelakaan|tabrakan|jalan raya|kendaraan|lalu lintas)\b/iu, q: 'traffic accident road cars' },
                { rx: /\b(haji|umrah|jamaah|mekah|madinah|arab saudi|ka bah|kakbah)\b/iu, q: 'hajj pilgrimage mecca kaaba' },
                { rx: /\b(sekolah|siswa|guru|kelas|kampus|mahasiswa|pendidikan|universitas)\b/iu, q: 'education students classroom school' },
                { rx: /\b(teknologi|kecerdasan buatan|ai|aplikasi|digital|gadget|komputer|internet|startup)\b/iu, q: 'technology artificial intelligence computer' },
                { rx: /\b(ekonomi|keuangan|bisnis|umkm|pasar|investasi|saham|bank|rupiah|uang)\b/iu, q: 'business economy finance money' },
                { rx: /\b(kesehatan|rumah sakit|dokter|pasien|vaksin|penyakit|medis)\b/iu, q: 'healthcare hospital doctor patient' },
                { rx: /\b(wisata|travel|pantai|gunung|hotel|kuliner|liburan|destinasi|pariwisata)\b/iu, q: 'travel destination landscape' },
                { rx: /\b(bola|sepak bola|sepakbola|liga|pemain|pelatih|olahraga|stadion)\b/iu, q: 'football stadium sports' },
                { rx: /\b(properti|rumah|perumahan|apartemen|real estate|hunian)\b/iu, q: 'real estate housing property' },
                { rx: /\b(otomotif|mobil|motor|kendaraan|mesin)\b/iu, q: 'automotive car road' },
                { rx: /\b(politik|pemerintah|menteri|presiden|dpr|pemilu|pilkada|rapat)\b/iu, q: 'government meeting politics' },
                { rx: /\b(pertanian|petani|sawah|padi|panen|perkebunan)\b/iu, q: 'farm agriculture rice field' },
                { rx: /\b(laut|nelayan|ikan|kapal|pelabuhan)\b/iu, q: 'fishermen boat sea harbor' }
            ];
            const matched = [];
            rules.forEach(rule => { if (rule.rx.test(text)) matched.push(rule.q); });
            return matched;
        }

        function buildPexelsQueryFromArticle(data, fallbackInput) {
            // JDH-style: gunakan keyword visual yang pendek dan spesifik, bukan caption/label UI.
            const explicit = normalizePexelsQueryText(data && data.imageKeywords ? data.imageKeywords : '');
            if (explicit && explicit.length >= 4) return explicit.slice(0, 100);

            const title = data && Array.isArray(data.titleOptions) ? (data.titleOptions[0] || '') : '';
            const category = data && data.category ? String(data.category) : '';
            const tags = data && Array.isArray(data.tags) ? data.tags.slice(0, 8).join(' ') : '';
            const raw = [title, category, tags].join(' ');
            const mapped = translateVisualTopic(raw);
            if (mapped.length) return mapped.join(' ').slice(0, 100);

            const clean = normalizePexelsQueryText(raw || fallbackInput || '');
            const stop = new Set(['yang','dan','atau','dari','untuk','dengan','pada','dalam','ini','itu','akan','telah','adalah','sebagai','oleh','ke','di','the','and','for','with','from','into','about','update','hari','tahun','bulan','minggu','jadi','kata','ujar','menurut','mengatakan','menyebut','wib']);
            const words = clean.split(/\s+/).filter(w => w && w.length >= 4 && !stop.has(w) && !/^\d+$/.test(w));
            const query = [...new Set(words)].slice(0, 5).join(' ').trim();
            return query.length >= 4 ? query.slice(0, 100) : '';
        }

        async function fetchPexelsImages(query) {
            const formData = new FormData();
            formData.append('action', 'heaj_fetch_pexels_images');
            formData.append('nonce', HEAJ.nonce);
            if (!String(query || '').trim()) return [];
            formData.append('query', query);
            try {
                const res = await fetch(HEAJ.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                const payload = await res.json().catch(() => null);
                if (!res.ok || !payload || !payload.success) return [];
                return Array.isArray(payload.data?.images) ? payload.data.images : [];
            } catch(e) {
                console.warn('Gagal mengambil gambar Pexels', e);
                return [];
            }
        }

        async function updateHistoryImageMeta(imageSourceType, imageCount) {
            if (!lastHistoryId) return;
            const formData = new FormData();
            formData.append('action', 'heaj_update_history_meta');
            formData.append('nonce', HEAJ.nonce);
            formData.append('history_id', lastHistoryId);
            formData.append('image_source_type', imageSourceType || 'none');
            formData.append('image_count', String(imageCount || 0));
            formData.append('has_source_image', imageSourceType === 'source' ? '1' : '0');
            formData.append('has_pexels_image', imageSourceType === 'pexels' ? '1' : '0');
            try { await fetch(HEAJ.ajax_url, { method:'POST', credentials:'same-origin', body: formData }); } catch(e) { console.warn('Gagal update meta riwayat gambar', e); }
        }

        function normalizeImageNameKey(url) {
            try {
                const clean = new URL(String(url), window.location.href).pathname.split('/').pop() || String(url);
                return clean.toLowerCase()
                    .replace(/\.(jpe?g|png|webp|gif)$/i, '')
                    .replace(/[-_](?:\d{2,5}x\d{2,5}|scaled|cropped|thumbnail|thumb|small|medium|large|full)$/i, '')
                    .replace(/(?:[-_]\d{2,5}){1,2}$/i, '')
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '') || String(url);
            } catch(e) { return String(url || ''); }
        }

        function buildImageCaption(item = {}) {
            const parts = [];
            const cap = String(item.caption || '').trim();
            const credit = String(item.credit || item.sourceCredit || item.creditSource || '').trim();
            if (cap) parts.push(cap);
            if (credit && !cap.toLowerCase().includes(credit.toLowerCase())) parts.push(credit);
            return parts.join(' | ');
        }

        function createManualImageId() {
            return 'manual_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
        }

        function manualImageCaptionFromFile(file) {
            const name = String(file?.name || 'gambar manual').replace(/\.[a-z0-9]+$/i, '').replace(/[-_]+/g, ' ').trim();
            return name ? `Gambar tambahan: ${name}` : 'Gambar tambahan manual';
        }

        function removeManualSourceImage(manualId) {
            const idx = manualSourceImages.findIndex(item => item.manual_id === manualId);
            if (idx >= 0) {
                const item = manualSourceImages[idx];
                try { if (item.preview_url) URL.revokeObjectURL(item.preview_url); } catch(e) {}
                manualSourceImages.splice(idx, 1);
                selectedSourceImages = selectedSourceImages.filter(img => img.manual_id !== manualId);
                renderManualSourceImageCards();
                syncSelectedImageOrder();
            }
        }


        function editManualSourceImageCaption(manualId) {
            const item = manualSourceImages.find(img => img.manual_id === manualId);
            if (!item) return;
            const current = item.caption || manualImageCaptionFromFile(item.file) || 'Gambar tambahan manual';
            const next = window.prompt('Ubah alt + caption gambar manual:', current);
            if (next === null) return;
            const clean = String(next || '').replace(/\s+/g, ' ').trim();
            if (!clean) return showToast('Alt/caption gambar manual tidak boleh kosong.', true);
            item.caption = clean;
            selectedSourceImages = selectedSourceImages.map(img => {
                if (img && img.manual_id === manualId) {
                    return { ...img, caption: clean, rawCaption: clean };
                }
                return img;
            });
            renderManualSourceImageCards();
            syncSelectedImageOrder();
            showToast('Alt/caption gambar manual diperbarui.');
        }

        function renderManualSourceImageCards() {
            const section = document.getElementById('sourceImagesSection');
            const grid = document.getElementById('sourceImagesGrid');
            const count = document.getElementById('sourceImagesCount');
            if (!section || !grid) return;
            grid.querySelectorAll('.he-source-image-card.is-manual-upload').forEach(card => card.remove());
            manualSourceImages.forEach((item, index) => {
                const card = document.createElement('div');
                card.className = 'border border-slate-200 rounded-xl overflow-hidden bg-slate-50 shadow-sm he-source-image-card is-manual-upload';
                card.setAttribute('data-image-url', item.url);
                card.setAttribute('data-manual-id', item.manual_id);

                const imageWrap = document.createElement('div');
                imageWrap.className = 'relative';
                const orderBadge = document.createElement('span');
                orderBadge.className = 'he-source-image-order hidden absolute top-2 left-2 z-10 inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-900 text-white text-[11px] font-bold shadow';
                const image = document.createElement('img');
                image.src = item.url;
                image.alt = item.caption || `Upload manual ${index + 1}`;
                image.loading = 'lazy';
                image.className = 'w-full h-36 object-cover bg-slate-100';
                imageWrap.appendChild(image);
                imageWrap.appendChild(orderBadge);

                const body = document.createElement('div');
                body.className = 'p-3 space-y-2';
                const label = document.createElement('span');
                label.className = 'he-image-source-label';
                label.textContent = 'upload manual';
                const source = document.createElement('p');
                source.className = 'text-[10px] text-slate-500 truncate';
                source.textContent = item.file?.name || 'Gambar manual';
                const caption = document.createElement('p');
                caption.className = 'he-source-image-caption text-[11px] text-slate-600 leading-snug';
                caption.textContent = item.caption || 'Gambar tambahan manual';

                const actions = document.createElement('div');
                actions.className = 'he-source-image-actions inline-flex items-center rounded-lg overflow-hidden border border-slate-300 bg-white';

                const checkBtn = document.createElement('button');
                checkBtn.type = 'button';
                checkBtn.className = 'he-source-image-action he-source-image-check inline-flex items-center justify-center text-slate-700 hover:bg-slate-100 w-9 h-9 transition';
                checkBtn.title = 'Pilih gambar manual';
                checkBtn.setAttribute('aria-label', 'Pilih gambar manual sebagai featured/sisipan');
                checkBtn.setAttribute('aria-pressed', 'false');
                checkBtn.innerHTML = '<i data-lucide="check" class="w-3.5 h-3.5"></i>';
                checkBtn.onclick = () => toggleSourceImageSelection(item, card);

                const editBtn = document.createElement('button');
                editBtn.type = 'button';
                editBtn.className = 'he-source-image-action inline-flex items-center justify-center text-slate-700 hover:bg-slate-100 w-9 h-9 transition';
                editBtn.title = 'Edit alt + caption gambar manual';
                editBtn.setAttribute('aria-label', 'Edit alt dan caption gambar manual');
                editBtn.innerHTML = '<i data-lucide="pencil" class="w-3.5 h-3.5"></i>';
                editBtn.onclick = () => editManualSourceImageCaption(item.manual_id);

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'he-source-image-action inline-flex items-center justify-center text-slate-700 hover:bg-red-50 hover:text-red-600 w-9 h-9 transition';
                removeBtn.title = 'Hapus gambar manual';
                removeBtn.setAttribute('aria-label', 'Hapus gambar manual');
                removeBtn.innerHTML = '<i data-lucide="trash-2" class="w-3.5 h-3.5"></i>';
                removeBtn.onclick = () => removeManualSourceImage(item.manual_id);

                actions.appendChild(checkBtn);
                actions.appendChild(editBtn);
                actions.appendChild(removeBtn);
                body.appendChild(label);
                body.appendChild(source);
                body.appendChild(caption);
                body.appendChild(actions);
                card.appendChild(imageWrap);
                card.appendChild(body);
                grid.appendChild(card);
            });
            if (count) {
                const remoteCount = grid.querySelectorAll('.he-source-image-card:not(.is-manual-upload)').length;
                count.textContent = `${remoteCount + manualSourceImages.length}`;
            }
            if (manualSourceImages.length || grid.querySelector('.he-source-image-card')) {
                section.classList.remove('hidden');
            }
            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
        }

        function initManualImageUpload() {
            const input = document.getElementById('manualImageUpload');
            const section = document.getElementById('sourceImagesSection');
            if (!input || input.dataset.heajManualBound === '1') return;
            input.dataset.heajManualBound = '1';
            input.addEventListener('change', function(){
                const files = Array.from(input.files || []).filter(file => /^image\/(jpeg|png|webp)$/i.test(file.type));
                if (!files.length) {
                    input.value = '';
                    return showToast('Pilih file JPG, PNG, atau WebP.', true);
                }
                files.forEach(file => {
                    const item = {
                        manual_id: createManualImageId(),
                        is_manual: true,
                        file,
                        url: URL.createObjectURL(file),
                        preview_url: '',
                        caption: manualImageCaptionFromFile(file),
                        rawCaption: '',
                        credit: '',
                        source: 'manual-upload',
                        source_type: 'manual'
                    };
                    item.preview_url = item.url;
                    manualSourceImages.push(item);
                    selectedSourceImages.push(item);
                });
                if (section) section.classList.remove('hidden');
                renderManualSourceImageCards();
                syncSelectedImageOrder();
                input.value = '';
                showToast('Gambar manual ditambahkan dan otomatis dipilih.');
            });
        }

        function serializeSelectedSourceImages() {
            return selectedSourceImages.map(img => {
                if (img && img.is_manual) {
                    return {
                        is_manual: true,
                        manual_id: img.manual_id || '',
                        caption: img.caption || '',
                        source_type: 'manual'
                    };
                }
                return {
                    url: img?.url || '',
                    caption: img?.caption || '',
                    rawCaption: img?.rawCaption || '',
                    credit: img?.credit || '',
                    source: img?.source || '',
                    source_type: img?.source_type || img?.scope || ''
                };
            }).filter(item => item.is_manual ? item.manual_id : item.url);
        }

        function isSourceImageSelected(url) {
            return selectedSourceImages.some(img => img && img.url === url);
        }

        function syncSelectedImageOrder() {
            document.querySelectorAll('.he-source-image-card').forEach(card => {
                const url = card.getAttribute('data-image-url') || '';
                const pos = selectedSourceImages.findIndex(img => img && img.url === url);
                const btn = card.querySelector('.he-source-image-check');
                const badge = card.querySelector('.he-source-image-order');
                card.classList.toggle('is-featured-selected', pos === 0);
                card.classList.toggle('is-source-image-selected', pos >= 0);
                if (btn) {
                    btn.classList.toggle('is-active', pos >= 0);
                    btn.setAttribute('aria-pressed', pos >= 0 ? 'true' : 'false');
                    btn.title = pos === 0 ? 'Featured image utama' : (pos > 0 ? 'Gambar sisipan artikel' : 'Pilih gambar');
                }
                if (badge) {
                    badge.textContent = pos >= 0 ? String(pos + 1) : '';
                    badge.classList.toggle('hidden', pos < 0);
                }
            });
            runFactAudit();
        }

        function toggleSourceImageSelection(item, card) {
            const existing = selectedSourceImages.findIndex(img => img && ((item.is_manual && img.manual_id === item.manual_id) || (!item.is_manual && img.url === item.url)));
            if (existing >= 0) {
                selectedSourceImages.splice(existing, 1);
            } else {
                selectedSourceImages.push({
                    url: item.url,
                    caption: buildImageCaption(item),
                    rawCaption: item.caption || '',
                    credit: item.credit || item.sourceCredit || item.creditSource || '',
                    source: item.source || '',
                    source_type: item.source_type || item.scope || '',
                    is_manual: !!item.is_manual,
                    manual_id: item.manual_id || '',
                    file: item.file || null
                });
            }
            syncSelectedImageOrder();
        }

        function renderSourceImages(images = []) {
            const section = document.getElementById('sourceImagesSection');
            const grid = document.getElementById('sourceImagesGrid');
            const count = document.getElementById('sourceImagesCount');
            if (!section || !grid) return;
            grid.innerHTML = '';
            selectedSourceImages = [];
            const seenImageNames = new Set();
            const cleanImages = (Array.isArray(images) ? images.filter(item => item && item.url) : []).filter(item => {
                const key = normalizeImageNameKey(item.url);
                if (seenImageNames.has(key)) return false;
                seenImageNames.add(key);
                return true;
            });
            if (count) count.textContent = `${cleanImages.length}`;
            if (!cleanImages.length) {
                section.classList.remove('hidden');
                renderManualSourceImageCards();
                return;
            }
            cleanImages.forEach((item, index) => {
                const card = document.createElement('div');
                card.className = 'border border-slate-200 rounded-xl overflow-hidden bg-slate-50 shadow-sm he-source-image-card';
                card.setAttribute('data-image-url', item.url);
                const imageWrap = document.createElement('div');
                imageWrap.className = 'relative';
                const orderBadge = document.createElement('span');
                orderBadge.className = 'he-source-image-order hidden absolute top-2 left-2 z-10 inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-900 text-white text-[11px] font-bold shadow';
                const image = document.createElement('img');
                image.src = item.url;
                image.alt = buildImageCaption(item) || `Gambar sumber ${index + 1}`;
                image.loading = 'lazy';
                image.className = 'w-full h-36 object-cover bg-slate-100';
                imageWrap.appendChild(image);
                imageWrap.appendChild(orderBadge);
                const body = document.createElement('div');
                body.className = 'p-3 space-y-2';
                const source = document.createElement('p');
                source.className = 'text-[10px] text-slate-500 truncate';
                source.textContent = item.source || item.url;
                const caption = document.createElement('p');
                caption.className = 'he-source-image-caption text-[11px] text-slate-600 leading-snug';
                caption.textContent = buildImageCaption(item) || 'Caption tidak terdeteksi';
                if (item.source_type === 'pexels' || item.scope === 'pexels') {
                    const label = document.createElement('span');
                    label.className = 'he-image-source-label';
                    label.textContent = 'ilustrasi foto';
                    body.appendChild(label);
                }

                const actions = document.createElement('div');
                actions.className = 'he-source-image-actions inline-flex items-center rounded-lg overflow-hidden border border-slate-300 bg-white';

                const viewBtn = document.createElement('a');
                viewBtn.href = item.url;
                viewBtn.target = '_blank';
                viewBtn.rel = 'noopener noreferrer';
                viewBtn.className = 'he-source-image-action inline-flex items-center justify-center text-slate-700 hover:bg-slate-100 w-9 h-9 transition';
                viewBtn.title = 'Lihat full image';
                viewBtn.setAttribute('aria-label', 'Lihat full image');
                viewBtn.innerHTML = '<i data-lucide="eye" class="w-3.5 h-3.5"></i>';

                const copyBtn = document.createElement('button');
                copyBtn.type = 'button';
                copyBtn.className = 'he-source-image-action inline-flex items-center justify-center text-slate-700 hover:bg-slate-100 w-9 h-9 transition';
                copyBtn.title = 'Copy link';
                copyBtn.setAttribute('aria-label', 'Copy link gambar');
                copyBtn.innerHTML = '<i data-lucide="copy" class="w-3.5 h-3.5"></i>';
                copyBtn.onclick = () => copyTextToClipboard(item.url, copyBtn);

                const checkBtn = document.createElement('button');
                checkBtn.type = 'button';
                checkBtn.className = 'he-source-image-action he-source-image-check inline-flex items-center justify-center text-slate-700 hover:bg-slate-100 w-9 h-9 transition';
                checkBtn.title = 'Pilih gambar';
                checkBtn.setAttribute('aria-label', 'Pilih gambar sebagai featured/sisipan');
                checkBtn.setAttribute('aria-pressed', 'false');
                checkBtn.innerHTML = '<i data-lucide="check" class="w-3.5 h-3.5"></i>';
                checkBtn.onclick = () => toggleSourceImageSelection(item, card);

                actions.appendChild(viewBtn);
                actions.appendChild(copyBtn);
                actions.appendChild(checkBtn);
                body.appendChild(source);
                body.appendChild(caption);
                body.appendChild(actions);
                card.appendChild(imageWrap);
                card.appendChild(body);
                grid.appendChild(card);
            });
            section.classList.remove('hidden');
            renderManualSourceImageCards();
            syncSelectedImageOrder();
            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
        }

                function normalizeFactText(str) {
            return String(str || '').replace(/\s+/g, ' ').replace(/[“”]/g, '"').replace(/[‘’]/g, "'").trim().toLowerCase();
        }

        function collectFactTokens(text) {
            const value = String(text || '');
            const quotes = [];
            const quoteRegex = /["“]([^"”]{8,400})["”]/g;
            let m;
            while ((m = quoteRegex.exec(value))) quotes.push(m[1].trim());
            const dates = value.match(/\b(?:\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{1,2}\s+(?:Januari|Februari|Maret|April|Mei|Juni|Juli|Agustus|September|Oktober|November|Desember|January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4}|(?:Januari|Februari|Maret|April|Mei|Juni|Juli|Agustus|September|Oktober|November|Desember|January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s*,?\s*\d{4}|(?:Senin|Selasa|Rabu|Kamis|Jumat|Sabtu|Minggu|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday))\b/gi) || [];
            const times = value.match(/\b\d{1,2}[.:]\d{2}\s*(?:WIB|WITA|WIT|AM|PM)?\b/gi) || [];
            const numbers = value.match(/\b\d{1,3}(?:[.,]\d{3})*(?:[.,]\d+)?(?:\s*(?:cm|m|km|kg|liter\/detik|persen|%|orang|unit|jam|hari|bulan|tahun|anggota|anak|rumah|kendaraan|korban|orang\s+anak|orang\s+warga))?(?:\s+[A-Za-zÀ-ž]{3,}){0,2}/gi) || [];
            return { quotes:[...new Set(quotes)], dates:uniqueByCanonical(dates, normalizeDateTokenKey), times:[...new Set(times)], numbers:[...new Set(numbers)] };
        }



        function normalizeDateTokenKey(token) {
            let v = normalizeFactText(token).replace(/[,]/g, ' ').replace(/\s+/g, ' ').trim();
            const months = {
                januari:1, january:1, jan:1,
                februari:2, february:2, feb:2,
                maret:3, march:3, mar:3,
                april:4, apr:4,
                mei:5, may:5,
                juni:6, june:6, jun:6,
                juli:7, july:7, jul:7,
                agustus:8, august:8, aug:8,
                september:9, sep:9,
                oktober:10, october:10, oct:10,
                november:11, nov:11,
                desember:12, december:12, dec:12
            };
            let m = v.match(/\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\b/);
            if (m) {
                let y = m[3].length === 2 ? ('20' + m[3]) : m[3];
                return `${y}-${String(parseInt(m[2],10)).padStart(2,'0')}-${String(parseInt(m[1],10)).padStart(2,'0')}`;
            }
            m = v.match(/\b(\d{1,2})\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember|january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\s+(\d{4})\b/);
            if (m && months[m[2]]) return `${m[3]}-${String(months[m[2]]).padStart(2,'0')}-${String(parseInt(m[1],10)).padStart(2,'0')}`;
            m = v.match(/\b(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember|january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\s+(\d{1,2})\s+(\d{4})\b/);
            if (m && months[m[1]]) return `${m[3]}-${String(months[m[1]]).padStart(2,'0')}-${String(parseInt(m[2],10)).padStart(2,'0')}`;
            return v;
        }

        function uniqueByCanonical(values, canonicalFn) {
            const seen = new Set();
            const out = [];
            (values || []).forEach(v => {
                const key = canonicalFn ? canonicalFn(v) : normalizeFactText(v);
                if (!seen.has(key)) { seen.add(key); out.push(v); }
            });
            return out;
        }

        function runFactAudit() {
            const section = document.getElementById('factAuditSection');
            const list = document.getElementById('factAuditList');
            const missingBox = document.getElementById('factAuditMissing');
            if (!section || !list || !lastArticleData) return;
            if (!lastInputHasUrl) { section.classList.add('hidden'); return; }
            const articleText = getCleanArticleText();
            const sourceText = lastSourceText || (lastArticleData.sourceText || '');
            const hasSource = normalizeFactText(sourceText).length > 80;
            const normSource = normalizeFactText(sourceText);
            const tokens = collectFactTokens(articleText);
            const checks = [];
            const missing = [];
            const sourceTokens = collectFactTokens(sourceText);
            const sourceDateKeys = new Set((sourceTokens.dates || []).map(normalizeDateTokenKey));
            function tokenExistsInSource(label, token) {
                if (!hasSource) return false;
                if (label === 'Tanggal / hari') {
                    const key = normalizeDateTokenKey(token);
                    return sourceDateKeys.has(key) || normSource.includes(normalizeFactText(token));
                }
                return normSource.includes(normalizeFactText(token));
            }
            function checkGroup(label, arr, exact) {
                arr = label === 'Tanggal / hari' ? uniqueByCanonical(arr, normalizeDateTokenKey) : uniqueByCanonical(arr);
                if (!arr.length) { checks.push({label, status:'neutral', message:'Tidak terdeteksi di artikel.'}); return; }
                let found = 0;
                arr.forEach(token => {
                    const ok = tokenExistsInSource(label, token);
                    if (ok) found++; else if (exact) missing.push(token);
                });
                checks.push({label, status: found === arr.length ? 'ok' : (found ? 'warn' : 'bad'), message: `${found}/${arr.length} cocok dengan sumber`});
            }
            checkGroup('Kutipan langsung', tokens.quotes, true);
            checkGroup('Tanggal / hari', tokens.dates, true);
            checkGroup('Jam kejadian', tokens.times, true);
            checkGroup('Angka / data', tokens.numbers.slice(0, 30), true);
            checks.push({label:'Sumber URL', status: lastSourceUrl ? 'ok' : 'neutral', message: lastSourceUrl ? 'Tersimpan untuk audit draft.' : 'Tidak ada URL sumber.'});
            checks.push({label:'Mode parafrase aman', status:'ok', message:'Narasi boleh unik, kutipan dan data pasti tetap dikunci.'});
            if (selectedSourceImages.length && selectedSourceImages[0] && selectedSourceImages[0].url) {
                const cap = String(selectedSourceImages[0].caption || '');
                const hasIst = /\b(?:ist|istimewa)\b/i.test(cap);
                checks.push({label:'Caption foto istimewa/ist', status: hasIst ? 'ok' : 'warn', message: hasIst ? 'Caption gambar pilihan memuat ist/istimewa.' : 'Bukan foto ist/istimewa.'});
            }
            const visibleChecks = checks.filter(item => item.message !== 'Tidak terdeteksi di artikel.');
            list.innerHTML = visibleChecks.map(item => `<div class="heaj-audit-item is-${item.status}"><strong>${item.label}</strong><span>${item.message}</span></div>`).join('');
            if (missingBox) {
                const limited = missing.slice(0, 10);
                missingBox.innerHTML = limited.length ? `<strong>Perlu dicek manual:</strong><ul>${limited.map(x=>`<li>${escapeHTML(x)}</li>`).join('')}</ul>` : '<strong>Aman awal:</strong> tidak ada data pasti yang jelas hilang dari sumber hasil ekstraksi.';
            }
            section.classList.remove('hidden');
        }


        function stripQuotedText(value) {
            return String(value || '').replace(/["“][^"”]{8,800}["”]/g, ' ');
        }

        function tokenizeWords(value) {
            return normalizeFactText(value)
                .replace(/[^a-z0-9\u00c0-\u024f\u1e00-\u1eff\s]/gi, ' ')
                .split(/\s+/)
                .filter(w => w && w.length > 2);
        }

        function buildNgrams(words, size = 5) {
            const grams = [];
            if (!Array.isArray(words) || words.length < size) return grams;
            for (let i = 0; i <= words.length - size; i++) grams.push(words.slice(i, i + size).join(' '));
            return grams;
        }

        function calculateNarrativeSimilarity(sourceText, articleText) {
            const sourceWords = tokenizeWords(stripQuotedText(sourceText));
            const articleWords = tokenizeWords(stripQuotedText(articleText));
            const sourceGrams = new Set(buildNgrams(sourceWords, 5));
            const articleGrams = buildNgrams(articleWords, 5);
            if (!sourceGrams.size || !articleGrams.length) return { score: 0, matched: 0, total: articleGrams.length, level: 'low' };
            let matched = 0;
            articleGrams.forEach(g => { if (sourceGrams.has(g)) matched++; });
            const score = Math.round((matched / articleGrams.length) * 100);
            const level = score > 50 ? 'high' : 'low';
            return { score, matched, total: articleGrams.length, level };
        }

        function getSEOCompleteness() {
            return {
                title: !!getSelectedSEOValue('title'),
                slug: !!getSelectedSEOValue('slug'),
                meta: !!getSelectedSEOValue('meta'),
                tags: Array.isArray(lastArticleData?.tags) && lastArticleData.tags.filter(Boolean).length >= 5
            };
        }

        function calculateEditorialQualityScore() {
            const articleText = getCleanArticleText();
            const sourceText = lastSourceText || lastArticleData?.sourceText || '';
            const html = String(lastArticleData?.articleBody || '');
            const wordCount = articleText.trim() ? articleText.trim().split(/\s+/).length : 0;
            const seo = getSEOCompleteness();
            const tokens = collectFactTokens(articleText);
            const normSource = normalizeFactText(sourceText);
            const hasSource = normSource.length > 80;
            const importantTokens = [...tokens.quotes, ...tokens.dates, ...tokens.times, ...tokens.numbers.slice(0, 20)];
            const factTotal = importantTokens.length;
            const factMatch = importantTokens.filter(t => hasSource && normSource.includes(normalizeFactText(t))).length;
            const factRatio = factTotal ? (factMatch / factTotal) : (hasSource ? 0.85 : 0.55);
            const sim = calculateNarrativeSimilarity(sourceText, articleText);

            let checks = [
                { key:'source', label:'Sumber terbaca', ok: hasSource, points: hasSource ? 15 : 5 },
                { key:'facts', label:'Data pasti cocok', ok: factRatio >= 0.9, points: Math.round(25 * factRatio) },
                { key:'seo', label:'SEO lengkap', ok: seo.title && seo.slug && seo.meta && seo.tags, points: [seo.title, seo.slug, seo.meta, seo.tags].filter(Boolean).length * 5 },
                { key:'length', label:'Panjang memadai', ok: wordCount >= 300, points: wordCount >= 800 ? 15 : (wordCount >= 300 ? 11 : Math.max(0, Math.round(wordCount / 30))) },
                { key:'structure', label:'Struktur artikel', ok: /<h2|<h3|<blockquote|<ul/i.test(html), points: /<h2|<h3/i.test(html) ? 10 : (/<(blockquote|ul)/i.test(html) ? 7 : 4) },
                { key:'dup', label:'Kemiripan narasi rendah', ok: sim.level !== 'high', points: sim.level === 'low' ? 15 : (sim.level === 'medium' ? 9 : 3) }
            ];
            if (!lastInputHasUrl) {
                checks = checks.filter(c => c.key !== 'source' && c.key !== 'facts');
            }
            const rawScore = checks.reduce((sum, c) => sum + c.points, 0);
            const maxPoints = checks.reduce((sum, c) => {
                if (c.key === 'seo') return sum + 20;
                if (c.key === 'length') return sum + 15;
                if (c.key === 'structure') return sum + 10;
                if (c.key === 'dup') return sum + 15;
                if (c.key === 'source') return sum + 15;
                if (c.key === 'facts') return sum + 25;
                return sum + (c.points || 0);
            }, 0) || 100;
            const score = Math.max(0, Math.min(100, Math.round((rawScore / maxPoints) * 100)));
            return { score, checks, similarity: sim, wordCount, factMatch, factTotal };
        }

        function renderEditorialQuality() {
            const section = document.getElementById('editorialScoreSection');
            if (!section || !lastArticleData) return;
            const badge = document.getElementById('qualityScoreBadge');
            const bar = document.getElementById('qualityScoreBar');
            const details = document.getElementById('qualityScoreDetails');
            const dupLabel = document.getElementById('duplicationLabel');
            const dupInfo = document.getElementById('duplicationInfo');
            const btn = document.getElementById('btnParaphraseAgain');
            const data = calculateEditorialQualityScore();
            const tone = data.score >= 80 ? 'good' : (data.score >= 60 ? 'warn' : 'bad');
            if (badge) {
                badge.textContent = `${data.score}/100`;
                badge.className = `heaj-score-badge is-${tone}`;
            }
            if (bar) {
                bar.style.width = `${data.score}%`;
                bar.className = `is-${tone}`;
            }
            if (details) {
                details.innerHTML = data.checks.map(c => `<div class="heaj-score-item ${c.ok ? 'is-ok' : 'is-warn'}"><i data-lucide="${c.ok ? 'check-circle-2' : 'alert-triangle'}" class="w-3.5 h-3.5"></i><span>${escapeHTML(c.label)}</span><b>${c.points}</b></div>`).join('');
            }
            const sim = data.similarity;
            const simText = sim.level === 'high' ? 'Tinggi' : 'Tidak perlu parafrase ulang';
            if (dupLabel) dupLabel.textContent = `Kemiripan narasi: ${simText} (${sim.score}%)`;
            if (dupInfo) dupInfo.textContent = sim.level === 'high'
                ? 'Kemiripan di atas 50%. Pertimbangkan parafrase ulang sebelum dibuat draft.'
                : 'Kemiripan di bawah 50%. Tidak perlu parafrase ulang.';
            if (btn) btn.classList.toggle('hidden', sim.level !== 'high');
            section.classList.remove('hidden');
            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
        }

        function regenerateParaphraseNarrative() {
            if (!lastArticleData) return showToast('Silakan buat artikel terlebih dahulu.', true);
            forceParaphraseMode = true;
            processArticle();
        }

        function renderCompareSource() {
            const section = document.getElementById('sourceCompareSection');
            const source = document.getElementById('sourceCompareOriginal');
            const article = document.getElementById('sourceCompareArticle');
            if (!section || !source || !article) return;
            if (!lastSourceText) { section.classList.add('hidden'); return; }
            source.textContent = lastSourceText;
            article.textContent = getCleanArticleText();
            section.classList.remove('hidden');
        }

        function toggleSourceCompare() {
            const section = document.getElementById('sourceCompareSection');
            if (!section) return;
            if (section.classList.contains('hidden')) renderCompareSource();
            else section.classList.add('hidden');
        }

        // ---------- Render UI ----------
        function getFaviconUrl(url) {
            try {
                const parsed = new URL(String(url));
                return 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(parsed.hostname) + '&sz=32';
            } catch (e) {
                return '';
            }
        }

        function getDirectFaviconUrl(url) {
            try {
                const parsed = new URL(String(url));
                return parsed.origin.replace(/\/$/, '') + '/favicon.ico';
            } catch (e) {
                return '';
            }
        }

        function renderResults(data) {
            document.getElementById('badgeCategory').textContent = data.category;
            const catSelect = document.getElementById('existingCategorySelect');
            if (catSelect && data.category) {
                const exact = Array.from(catSelect.options).find(o => String(o.value).toLowerCase() === String(data.category).toLowerCase());
                catSelect.value = exact ? exact.value : '';
            }
            const pName = document.getElementById('promptSelect').options[document.getElementById('promptSelect').selectedIndex].text;
            const wCount = document.getElementById('wordCountSelect').value;
            const lang = document.getElementById('languageSelect')?.value === 'en' ? 'English' : 'Indonesia';
            document.getElementById('promptLabel').textContent = `Format: ${pName}${wCount ? ' (' + wCount + ')' : ''} • ${lang}`;

            const containers = {
                title: document.getElementById('outTitleOptions'),
                slug: document.getElementById('outSlugs'),
                meta: document.getElementById('outMeta')
            };
            
            containers.title.innerHTML = '';
            data.titleOptions.forEach((t, index) => createSelectableItem(t, containers.title, 'heaj_title_option', index, false));
            document.getElementById('articleH1').textContent = data.titleOptions[0] || "Judul Artikel";

            containers.slug.innerHTML = '';
            data.slugOptions.forEach((slug, index) => createSelectableItem(slug, containers.slug, 'heaj_slug_option', index, true));

            containers.meta.innerHTML = '';
            data.metaDescriptions.forEach((meta, index) => createSelectableItem(meta, containers.meta, 'heaj_meta_option', index, false));

            const tagsContainer = document.getElementById('outTags');
            tagsContainer.innerHTML = '';
            const cleanedTags = data.tags.map(t => t.replace(/^#+/, '').trim());
            cleanedTags.forEach(tag => {
                const chip = document.createElement('span');
                chip.className = "bg-indigo-50 text-indigo-700 border border-indigo-100 px-3 py-1 rounded-full text-xs shadow-sm";
                chip.textContent = tag;
                tagsContainer.appendChild(chip);
            });

            document.getElementById('articleContent').innerHTML = data.articleBody || "<p>Data isi artikel kosong.</p>";
            const wordCount = heajArticleWordCount(data.articleBody || document.getElementById('articleContent').innerHTML);
            document.getElementById('wordCountDisplay').innerHTML = `<i data-lucide="bar-chart-2" class="w-3 h-3 inline mr-1"></i> ${wordCount}`;

            const refList = document.getElementById('outReferences');
            if (refList) {
                refList.innerHTML = '';
                if (Array.isArray(data.references)) {
                    data.references.forEach(ref => {
                        const li = document.createElement('li');
                        li.className = "truncate flex items-center gap-2";
                        const refText = String(ref || '').trim();
                        if (/^https?:\/\//i.test(refText)) {
                            const a = document.createElement('a');
                            a.href = refText;
                            a.target = '_blank';
                            a.rel = 'noopener noreferrer';
                            a.className = 'hover:underline hover:text-blue-800 transition-colors';
                            a.textContent = refText;
                            const icon = document.createElement('img');
                            icon.src = getFaviconUrl(refText);
                            icon.dataset.fallback = getDirectFaviconUrl(refText);
                            icon.alt = '';
                            icon.loading = 'lazy';
                            icon.className = 'w-4 h-4 rounded-sm shrink-0 bg-white border border-slate-200';
                            icon.onerror = function(){
                                if (this.dataset.fallback && this.src !== this.dataset.fallback) {
                                    this.src = this.dataset.fallback;
                                    this.dataset.fallback = '';
                                } else {
                                    this.style.display = 'none';
                                }
                            };
                            li.appendChild(icon);
                            li.appendChild(a);
                        } else if (refText) {
                            li.textContent = refText;
                        }
                        if (refText) refList.appendChild(li);
                    });
                }
            }
            toggleReferencesVisibility();
            data.sourceText = lastSourceText || data.sourceText || '';
            data.sourceUrl = lastSourceUrl || data.sourceUrl || '';
            if (heajLicenseUnlocked()) {
                renderSourceImages(data.sourceImages || lastSourceImages || []);
                runFactAudit();
                renderEditorialQuality();
            } else {
                renderSourceImages([]);
                ['sourceImagesSection','sourceCompareSection','editorialScoreSection','referencesSection'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.classList.add('hidden');
                });
            }
            const warningCard = document.getElementById('heajWarningCard');
            if (warningCard) warningCard.classList.toggle('hidden', !lastInputHasUrl || !heajLicenseUnlocked());
            heajApplyLicenseFeatureLocks();

            if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
            localStorage.setItem('heaj_last_article', JSON.stringify(data));
        }

        function toggleReferencesVisibility() {
            const refSection = document.getElementById('referencesSection');
            if (!refSection) return;
            const checked = document.querySelector('input[name="showSource"]:checked');
            const showRef = !checked || checked.value === 'yes';
            const hasRefs = lastArticleData && Array.isArray(lastArticleData.references) && lastArticleData.references.length > 0;
            if (showRef && hasRefs) refSection.classList.remove('hidden');
            else refSection.classList.add('hidden');
        }

        function copyArticleHTML(btnElement = null) {
            if (!heajRequireLicense('Copy HTML')) return;
            if (!lastArticleData || !lastArticleData.articleBody) {
                showToast('Silakan buat artikel terlebih dahulu.', true);
                return;
            }
            const title = getSelectedSEOValue('title') || (document.getElementById('articleH1')?.textContent || 'Artikel');
            const content = document.getElementById('articleContent')?.innerHTML || lastArticleData.articleBody || '';
            const html = `<h1>${escapeHTML(title)}</h1>
${content}`;
            copyTextToClipboard(html, btnElement);
        }

        function escapeHTML(value) {
            return String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function copyAllSEOData() {
            if (!lastArticleData) return showToast("Tidak ada data untuk disalin.", true);
            const bundle = `Judul:\n${getSelectedSEOValue('title')}\n\nSlug:\n${getSelectedSEOValue('slug')}\n\nMeta Deskripsi:\n${getSelectedSEOValue('meta')}\n\nTags:\n${lastArticleData.tags.map(t=>t.replace(/^#+/,'').trim()).join(', ')}`;
            copyTextToClipboard(bundle, document.getElementById('btnCopyAllSEO'));
        }

        function copyElementText(elementId, btnElement) {
            const el = document.getElementById(elementId);
            const range = document.createRange();
            range.selectNodeContents(el);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            try {
                document.execCommand('copy');
                sel.removeAllRanges();
                showToast("Berhasil disalin!");
                if(btnElement) {
                    const orig = btnElement.innerHTML;
                    btnElement.innerHTML = '<i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i> Disalin!';
                    if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
                    setTimeout(()=> { btnElement.innerHTML = orig; if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); } }, 2000);
                }
            } catch { showToast("Gagal menyalin.", true); }
        }



        // ---------- Kirim ke Draft WordPress ----------
        function setDraftStatus(message, isError = false, editUrl = '') {
            const status = document.getElementById('draftStatus');
            if (!status) return;
            status.classList.remove('hidden', 'bg-emerald-50', 'border-emerald-200', 'text-emerald-700', 'bg-red-50', 'border-red-200', 'text-red-700');
            status.classList.add(isError ? 'bg-red-50' : 'bg-emerald-50', isError ? 'border-red-200' : 'border-emerald-200', isError ? 'text-red-700' : 'text-emerald-700');
            status.innerHTML = editUrl ? `${message} <a class="underline font-bold" href="${editUrl}" target="_blank" rel="noopener">Edit draft</a>` : message;
        }

        async function sendToWordPressDraft() {
            if (!heajRequireLicense('Kirim Draft')) return;
            if (!lastArticleData || !lastArticleData.articleBody) {
                showToast('Silakan buat artikel terlebih dahulu.', true);
                return;
            }
            const btn = document.getElementById('btnAddDraft');
            if (!btn) return;
            const original = btn.innerHTML;
            btn.disabled = true;
            btn.classList.add('opacity-70');
            btn.innerHTML = '<div class="loader" style="width:16px;height:16px;border-width:2px;border-top-color:white;"></div> <span class="ml-2">Mengirim ke Draft...</span>';

            const title = getSelectedSEOValue('title') || (document.getElementById('articleH1')?.textContent || 'Artikel');
            const slug = getSelectedSEOValue('slug');
            const meta = getSelectedSEOValue('meta');
            const tags = (lastArticleData.tags || []).map(t => String(t).replace(/^#+/, '').trim()).filter(Boolean).join(', ');

            const formData = new FormData();
            formData.append('action', 'he_create_draft');
            formData.append('nonce', HEAJ.nonce);
            formData.append('title', title);
            formData.append('slug', slug);
            formData.append('meta', meta);
            formData.append('content', lastArticleData.articleBody);
            formData.append('category', lastArticleData.category || '');
            formData.append('tags', tags);
            const draftSourceUrls = lastSourceUrls.length ? lastSourceUrls : (Array.isArray(lastArticleData.sourceUrls) ? lastArticleData.sourceUrls : (lastSourceUrl ? [lastSourceUrl] : []));
            formData.append('source_url', lastSourceUrl || lastArticleData.sourceUrl || (draftSourceUrls[0] || ''));
            formData.append('source_urls', JSON.stringify(draftSourceUrls));
            formData.append('history_id', lastHistoryId || lastArticleData.historyId || '');
            formData.append('title_index', String(getSelectedSEOIndex('title')));
            formData.append('slug_index', String(getSelectedSEOIndex('slug')));
            formData.append('meta_index', String(getSelectedSEOIndex('meta')));
            formData.append('ai_provider', lastProviderUsed || document.getElementById('aiProviderSelect')?.value || '');
            const excerpt = (meta || getCleanArticleText().slice(0, 180));
            formData.append('excerpt', excerpt);
            if (selectedSourceImages.length) {
                const serialImages = serializeSelectedSourceImages();
                const firstRemote = selectedSourceImages.find(img => img && !img.is_manual && img.url);
                formData.append('image_source', selectedSourceImages[0]?.is_manual ? 'manual' : (selectedSourceImages[0]?.source_type || selectedSourceImages[0]?.scope || 'source'));
                if (firstRemote) {
                    formData.append('featured_image_url', firstRemote.url);
                    formData.append('featured_image_caption', firstRemote.caption || '');
                }
                formData.append('source_images', JSON.stringify(serialImages));
                selectedSourceImages.filter(img => img && img.is_manual && img.file).forEach(img => {
                    formData.append('manual_source_images[]', img.file, img.file.name || 'manual-image.jpg');
                    formData.append('manual_image_ids[]', img.manual_id || '');
                    formData.append('manual_image_captions[]', img.caption || '');
                });
            }

            try {
                const res = await fetch(HEAJ.ajax_url, { method: 'POST', credentials: 'same-origin', body: formData });
                const payload = await res.json().catch(() => null);
                if (!res.ok || !payload || !payload.success) {
                    if (payload?.data?.redirect_url) { window.location.href = payload.data.redirect_url; return; }
                    throw new Error(payload?.data?.message || `HTTP ${res.status}`);
                }
                showToast('Draft WordPress berhasil dibuat!');
                setDraftStatus('Draft berhasil dibuat.', false, payload.data?.edit_url || '');
            } catch (e) {
                showToast(e?.message || 'Gagal membuat draft.', true);
                setDraftStatus(e?.message || 'Gagal membuat draft.', true);
            } finally {
                btn.disabled = false;
                btn.classList.remove('opacity-70');
                btn.innerHTML = original;
                if (window.HEAJRenderIcons) { window.HEAJRenderIcons(); } else if (window.lucide) { lucide.createIcons(); }
            }
        }

        function resetAll() {
            document.getElementById('sourceInput').value = '';
            setUIState('empty');
            closeFeature('sosmedContainer');
            closeFeature('ringkasanContainer');
            closeFeature('videoScriptContainer');
            closeFeature('sosmedImageContainer');
            lastSocialImagePromptBundle = null;
            lastGeneratedSocialImages = [];
            selectedSocialImagePlatform = '';
            renderSourceImages([]);
            const sourceImagesSection = document.getElementById('sourceImagesSection');
            if (sourceImagesSection) sourceImagesSection.classList.add('hidden');
            localStorage.removeItem('heaj_last_article');
            lastArticleData = null;
            lastSourceText = '';
            lastSourceUrl = '';
            lastSourceUrls = [];
            lastHistoryId = '';
            lastProviderUsed = '';
            selectedSourceImages = [];
            manualSourceImages.forEach(item => { try { if (item.preview_url) URL.revokeObjectURL(item.preview_url); } catch(e) {} });
            manualSourceImages = [];
            lastInputHasUrl = false;
            const draftStatus = document.getElementById('draftStatus');
            if (draftStatus) { draftStatus.classList.add('hidden'); draftStatus.innerHTML = ''; }
            const warningCard = document.getElementById('heajWarningCard');
            if (warningCard) warningCard.classList.remove('hidden');
            showToast("Ruang kerja dibersihkan.");
        }

        function initAiProviderSelect() {
            const select = document.getElementById('aiProviderSelect');
            const help = document.getElementById('aiProviderHelp');
            if (!select) return;
            const providers = (window.HEAJ && HEAJ.providers) ? HEAJ.providers : { gemini: 1, grok: 0, zai: 0, openrouter: 0 };
            Array.from(select.options).forEach(option => {
                const key = option.value;
                const count = parseInt(providers[key] || 0, 10);
                option.disabled = count <= 0;
                if (count <= 0) option.textContent = option.textContent.replace(/ \(belum ada API\)$/,'') + ' (belum ada API)';
            });
            if (select.selectedOptions[0]?.disabled) {
                const firstEnabled = Array.from(select.options).find(o => !o.disabled);
                if (firstEnabled) select.value = firstEnabled.value;
            }
            const updateHelp = () => {
                const label = select.options[select.selectedIndex]?.textContent || 'AI';
                const count = parseInt(providers[select.value] || 0, 10);
                if (help) help.textContent = `${label.replace(' (belum ada API)','')} aktif dengan ${count} API key.`;
            };
            select.addEventListener('change', updateHelp);
            updateHelp();
        }

        // Restore state on load
        window.addEventListener('load', () => {
            initAiProviderSelect();
            initManualImageUpload();
            heajApplyLicenseFeatureLocks();
            const saved = localStorage.getItem('heaj_last_article');
            if (saved) {
                try {
                    lastArticleData = JSON.parse(saved);
                    lastSourceText = lastArticleData.sourceText || '';
                    lastSourceUrl = lastArticleData.sourceUrl || '';
                    lastSourceUrls = Array.isArray(lastArticleData.sourceUrls) ? lastArticleData.sourceUrls : (lastSourceUrl ? [lastSourceUrl] : []);
                    lastInputHasUrl = !!(lastSourceUrl || lastSourceUrls.length);
                    lastHistoryId = lastArticleData.historyId || '';
                    setGenerateProgress(4, 'Finalisasi draft dan audit redaksi...');
                renderResults(lastArticleData);
                    setUIState('result');
                } catch { localStorage.removeItem('heaj_last_article'); }
            }
        });
        

        const draftBtn = document.getElementById('btnAddDraft');
        if (draftBtn) draftBtn.addEventListener('click', sendToWordPressDraft);

        document.querySelectorAll('input[name="showSource"]').forEach(radio => radio.addEventListener('change', toggleReferencesVisibility));

        const btnCopyCategory = document.getElementById('btnCopyCategory');
        if (btnCopyCategory) btnCopyCategory.onclick = function() {
            const categoryValue = lastArticleData?.category || document.getElementById('badgeCategory')?.textContent || '';
            if (categoryValue) copyTextToClipboard(categoryValue, this.querySelector('i'));
        };
        const existingCategorySelect = document.getElementById('existingCategorySelect');
        if (existingCategorySelect) {
            existingCategorySelect.addEventListener('change', function(){
                const value = this.value || '';
                if (!value) return;
                if (!lastArticleData) lastArticleData = {};
                lastArticleData.category = value;
                const badge = document.getElementById('badgeCategory');
                if (badge) badge.textContent = value;
                showToast('Kategori draft diganti ke: ' + value);
            });
        }
function updateSelectedAIName(){
    const select = document.getElementById('aiProviderSelect');
    const target = document.getElementById('heSelectedAIName');
    if (!select || !target) return;
    const opt = select.options[select.selectedIndex];
    target.textContent = opt ? opt.text.replace(' / ', ' / ') : 'AI';
}
document.addEventListener('DOMContentLoaded', function(){
    const select = document.getElementById('aiProviderSelect');
    if (select) {
        updateSelectedAIName();
        select.addEventListener('change', updateSelectedAIName);
    }
    initManualImageUpload();
    heajApplyLicenseFeatureLocks();
});

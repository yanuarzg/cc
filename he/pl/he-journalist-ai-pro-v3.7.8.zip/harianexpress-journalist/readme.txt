=== YZG AI Journalist ===
Contributors: yanuarzg
Tags: ai, journalist, gemini, grok, zai, seo, harianexpress
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 3.7.8
License: GPLv2 or later

White-label AI editorial assistant dengan rotasi API, output SEO, audit fakta, gambar sumber/Pexels, draft sosial media, skrip video, dan kirim ke Draft WordPress.

== Changelog ==

= 3.3.12 =
* Revisi header generator, settings, filter gambar mirip, threshold kemiripan narasi, dan visibilitas halaman subdomain.

= 3.3.3 =
* Hapus indikator API aktif dari halaman Generator Artikel.
* Perbaiki error JavaScript Cannot access lastSourceText before initialization.
* Perbaiki heading Riwayat Generate agar terlihat jelas.
* Prompt Custom di Pengaturan API disederhanakan hanya menjadi Instruksi Global Tambahan.

= 3.2.5 =
* Halaman Semua Subdomain: tombol di dalam card dihapus, icon buka website dipindahkan setelah nama domain, dan icon login ditempatkan di pojok kanan atas card.
* Sortir baru berdasarkan jumlah total artikel terbanyak/tersedikit.
* CSS dibuat lebih netral tanpa gradient dan tanpa warna terlalu colorfull.

= 3.1.7 =
* Perbaikan error Grok/xAI HTTP 403.
* API key Grok/Z.AI yang ditolak 401/403 otomatis diblokir dan dilewati.
* Fallback otomatis ke Gemini jika Grok/Z.AI gagal.

= 3.1.6 =
* Tambah dukungan provider AI Grok/xAI dan Z.AI pada Generator Artikel.
* Tambah input API Grok/xAI dan Z.AI di Pengaturan API.
* Hapus block info Lisensi Domain via GitHub dari halaman Pengaturan API.
* Tambah tautan Ambil API Key Gemini sebelum input API Key Tambahan.

= 3.1.5 =
* Auto-block API key bocor/invalid/expired/disabled dari respons Gemini.
* Status API key aktif/terblokir di Pengaturan API.
* Perbaikan update checker agar notifikasi update tidak muncul saat versi remote sama.

= 3.1.4 =
* Lisensi domain dibaca dari GitHub licenses.json.
* Tambah contoh licenses.json untuk menambah domain pembeli lisensi tanpa rilis ulang plugin.

= 3.1.3 =
* Filter gambar sumber: hanya dari area artikel atau image minimal 320px agar ikon/gambar kecil tidak tampil.
* Tambah pembatasan lisensi domain untuk harianexpress.com, subdomain harianexpress.com, harianexpress.id, subdomain harianexpress.id, dan geky.page.gd.
* Redirect domain tidak terdaftar ke https://yanuarzg.github.io/.
* Tambah tombol Beli Lisensi di footer sebelum Dibangun oleh YZG.

= 3.1 =
* Mobile responsive.

= 3.3.12 =
* Revisi header generator, settings, filter gambar mirip, threshold kemiripan narasi, dan visibilitas halaman subdomain.

= 3.3.3 =
* Tambah Quality Score artikel dan deteksi kemiripan narasi.
* Revisi label tombol HTML dan Draft.

= 3.4.7 =
* Fixed Custom Settings persistence by using native WordPress option array fields.
* Branding, prompt, language, author, and editor settings now apply reliably after save.

= 3.5.5 =
* Tambah fitur Social Media Image: generate PNG otomatis untuk Instagram, Pinterest, dan LinkedIn dari gambar sumber/featured image, judul, deskripsi, kategori, website, dan logo brand.

= 3.5.2 =
* Plugin UI now follows WordPress admin/user locale: Indonesian for id_ID, English for other locales.

= 3.5.4 =
* Tambah fitur Social Media Image: generate PNG otomatis untuk Instagram, Pinterest, dan LinkedIn dari gambar sumber/featured image, judul, deskripsi, kategori, website, dan logo brand.

= 3.5.2 =
* Performance & Architecture Update: API Key Manager, Gemini fallback model chain, and richer history tracking.

= 3.5.6 =
* Fix Social Media Image agar selalu memakai hostname situs tempat plugin dipasang, bukan hostname sumber artikel.
* Bundle font DejaVu Sans Condensed ke dalam plugin agar headline Social Media Image lebih konsisten lintas server.
* Tambah validasi imagettftext/FreeType. Jika server tidak mendukung TTF GD, plugin akan menolak generate agar hasil tidak rusak.

= 3.5.7 =
* Social Image sekarang default memakai Gemini AI agar hasil jauh lebih mirip template referensi, bukan hanya renderer GD lokal.
* Footer website social image kini selalu memakai domain WordPress tempat plugin dipasang, bukan domain sumber artikel.
* Tambah pengaturan template referensi Instagram/Pinterest/LinkedIn, model Gemini, ukuran image, dan prompt tambahan khusus social image.
* GD tetap tersedia sebagai fallback manual jika dibutuhkan.

= 3.5.8 =
* Fix payload Gemini Social Image: endpoint dipindah ke v1beta dan konfigurasi image memakai imageConfig, bukan responseFormat.image, agar tidak muncul error Unknown name responseModalities/responseFormat pada generation_config.

= 3.5.9 =
* Perbaiki handling quota Gemini Image: error quota kini ditampilkan lebih jelas.
* Jika Gemini Image quota habis/tidak tersedia, Social Image otomatis fallback ke GD lokal agar workflow tidak berhenti total.
* Output fallback diberi indikator engine gd_fallback dan warning quota.

= 3.6.0 =
* Nama file Social Image sekarang mengikuti slug artikel: slug-instagram.png, slug-pinterest.png, slug-linkedin.png.
* Payload Social Image sekarang mengirim slug terpilih dari SEO metadata.
* Preview Social Image menampilkan nama file hasil generate.

= 3.6.1 =
* Perbaiki fallback GD Social Image: baseline teks kini lurus horizontal, ukuran headline/deskripsi otomatis diperkecil agar tidak mudah terpotong.
* Gradient/shadow area foto dibuat lebih halus dengan transisi 1px dan tanpa kontras berlebihan.
* Tambah tombol Copy Prompt di panel Social Media Image untuk menyalin prompt bundle dan memakainya di tool AI lain.

= 3.6.2 =
* Rapikan spacing Social Image fallback GD: jarak kategori ke headline, headline ke deskripsi, dan deskripsi ke footer dibuat lebih lega dan lebih konsisten.
* Layout LinkedIn diperbaiki agar teks tidak terlalu mepet kiri/atas dan area teks-foto terasa lebih seimbang.

= 3.6.3 =
* Jarak headline ke deskripsi dipersempit pada Social Image fallback GD.
* Line-height headline dan deskripsi dinaikkan agar blok teks lebih lega dan enak dibaca.

= 3.6.4 =
* Jarak headline ke deskripsi disetel 1rem pada Social Image fallback GD.
* Line-height headline dan deskripsi disetel 1.25rem/1.25 pada blok teks agar lebih lapang dan konsisten.

= 3.6.5 =
* Fine-tune fallback GD Social Image: headline diperkecil ke sekitar 80%, gap headline-deskripsi dihilangkan, dan padding kiri blok teks diperbesar 2x.
* Gradient/shadow diperingan agar tidak menutupi foto utama, khususnya layout LinkedIn dan poster vertikal.
* UX mobile panel Social Media Image dibuat lebih responsif dengan toolbar/card/action yang lebih mudah dipakai di layar kecil.
* Tombol Copy Prompt kini menyalin prompt untuk image terpilih dan otomatis mengunduh image yang dipilih.
* CSS Social Media Image dirapikan agar tidak redundant dan mengurangi risiko konflik selector.

= 3.6.6 =
* Perbaiki layout LinkedIn 1.91:1 agar headline dan deskripsi tidak mudah terpotong: area teks diperlebar, ukuran headline/deskripsi diperkecil otomatis, batas minimum size diturunkan, dan jumlah baris maksimum ditambah.

= 3.6.7 =
* Perbaiki posisi garis merah miring/slash pada label kategori Social Image agar tidak terlalu jauh ke kanan saat sub-kategori kosong.
* Slash kini mengikuti lebar kategori dan sub-kategori secara dinamis.

= 3.6.9 =
* Hotfix fatal error dari kompresi PNG: menghapus penggunaan konstanta GD opsional dan membuat kompresi lebih aman di berbagai server.
* Download Social Image PNG tetap dikompres otomatis dengan target maksimal 200KB.
* Preview Social Image menampilkan ukuran file hasil kompresi dalam KB.

= 3.7.0 =
* Tambah Batch Continue untuk artikel panjang minimal 1000 kata agar hasil tidak berhenti di tengah.
* Jika output awal belum mencapai target kata atau terlihat terpotong, plugin otomatis meminta AI melanjutkan articleBody dalam beberapa batch.
* Batch continuation menjaga metadata tetap sama dan hanya menambahkan isi artikel tanpa mengulang paragraf sebelumnya.

= 3.7.1 =
* Ubah default pilihan Panjang Artikel menjadi: Sesuai prompt, Pendek (300-500), Sedang (500-1000), dan Panjang (1000+).
* Tambah migrasi ringan untuk mengganti set panjang artikel bawaan lama jika belum dikustom manual.

= 3.7.2 =
* Tambah sistem lisensi YZTheme untuk product ID yzg-ai-journalist dengan mode encrypted_json_annual.
* Tambah menu Lisensi di dashboard plugin.
* Tambah verifikasi remote ke Apps Script License API via action verify_license_public.
* Generator dan AJAX penting dikunci jika lisensi belum aktif.

= 3.7.3 =
* Lisensi: sembunyikan pengaturan API lisensi dari halaman Lisensi dan hapus catatan warning.
* Generator artikel dasar tetap bisa dipakai walau lisensi belum aktif; fitur premium seperti content settings, author/editor, image source, fact audit, quality score, extra features, copy HTML, dan kirim draft dikunci.
* Tambah tombol WA Support dan link Member Area YZTheme di halaman Lisensi.
* Pesan invalid_response License API dibuat lebih jelas jika Apps Script belum mengembalikan JSON.

= 3.7.4 =
* License verifier dibuat lebih robust untuk Google Apps Script: manual follow redirect script.googleusercontent.com, redirection 10, User-Agent eksplisit, dan fallback form POST.
* Tambah Debug API di halaman Lisensi agar respons HTML/non-JSON bisa dilacak tanpa menebak.
* Tidak menambah decrypt lokal dan tidak mengubah secret flow productSecrets.

= 3.7.5 =
* License verifier ditambah fallback lokal CryptoJS AES untuk encrypted_json_annual ketika Google Apps Script/Web App mengembalikan HTML/400.
* Validasi lokal mencocokkan product, license_mode, annual type, domain, dan expired date.
* Remote API tetap dicoba lebih dulu; fallback lokal hanya dipakai saat response remote bukan JSON/error transport.

= 3.7.6 =
* License fallback diselaraskan dengan pola NewsPress: secret lokal memakai fragment obfuscated, bukan plain string.
* Menghapus konstanta password plain dari plugin ZIP.
* Menambahkan integrity token ringan untuk validasi lokal.

= 3.7.8 =
* Fix local license integrity token untuk fallback NewsPress-style encrypted_json_annual.
* Hapus komentar fragment secret agar tidak terlalu terbaca di source.
* Validasi lokal tetap mengecek product, mode, annual type, domain, dan expired date.

<?php
/**
 * Plugin Name: HE Visitor Count REST Field
 * Plugin URI: https://yztheme.my.id
 * Description: Menambahkan field "views" dan "views_source" ke WordPress REST API, mendeteksi visitor counter Bopea/JellyWP, dan mendukung pembaruan otomatis dari GitHub.
 * Version: 2.1.0
 * Author: Harian Express
 * Author URI: https://yztheme.my.id
 * Update URI: https://raw.githubusercontent.com/yanuarzg/cc/main/he/vc/update.json
 * Requires at least: 4.7
 * Requires PHP: 7.0
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'HE_VC_VERSION', '2.1.0' );
define( 'HE_VC_FILE', __FILE__ );
define( 'HE_VC_SLUG', 'he-visitor-count-rest' );
define( 'HE_VC_UPDATE_URL', 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/vc/update.json' );
define( 'HE_VC_UPDATE_CACHE_KEY', 'he_vc_update_manifest_v21' );
define( 'HE_VC_HOMEPAGE', 'https://yztheme.my.id' );

/**
 * Mengubah nilai counter menjadi bilangan bulat non-negatif.
 * Mendukung angka mentah dan teks sederhana seperti "1.2K views".
 *
 * @param mixed $value Nilai counter.
 * @return int
 */
function he_vc_normalize_count( $value ) {
    if ( is_array( $value ) || is_object( $value ) ) {
        return 0;
    }

    if ( is_int( $value ) || is_float( $value ) ) {
        return max( 0, (int) round( $value ) );
    }

    $text = trim( wp_strip_all_tags( (string) $value ) );
    if ( '' === $text ) {
        return 0;
    }

    // Nilai database biasa, misalnya 1548, 1.548, atau 1,548.
    if ( preg_match( '/^\s*([0-9][0-9.,]*)\s*$/', $text, $matches ) ) {
        $digits = preg_replace( '/[^0-9]/', '', $matches[1] );
        return '' === $digits ? 0 : max( 0, (int) $digits );
    }

    // Nilai tampilan singkat, misalnya 1.2K, 2,5M, atau 326 views.
    if ( preg_match( '/([0-9]+(?:[.,][0-9]+)?)\s*([kKmMbB])?/', $text, $matches ) ) {
        $number = (float) str_replace( ',', '.', $matches[1] );
        $suffix = isset( $matches[2] ) ? strtolower( $matches[2] ) : '';
        $factor = 1;

        if ( 'k' === $suffix ) {
            $factor = 1000;
        } elseif ( 'm' === $suffix ) {
            $factor = 1000000;
        } elseif ( 'b' === $suffix ) {
            $factor = 1000000000;
        }

        return max( 0, (int) round( $number * $factor ) );
    }

    return 0;
}

/**
 * Mencari jumlah tayangan dan sumber datanya.
 * Hasil disimpan selama satu request agar field views dan views_source
 * tidak mengulang pembacaan metadata yang sama.
 *
 * @param int $post_id ID artikel.
 * @return array{count:int,source:string}
 */
function he_vc_resolve_views( $post_id ) {
    static $request_cache = array();

    $post_id = absint( $post_id );
    if ( ! $post_id ) {
        return array( 'count' => 0, 'source' => 'invalid_post_id' );
    }

    if ( isset( $request_cache[ $post_id ] ) ) {
        return $request_cache[ $post_id ];
    }

    // Bopea/JellyWP paling sering memakai post_views_count.
    $meta_keys = array(
        'post_views_count',
        'views',
        'post_views',
        'views_count',
        'view_count',
        'page_views',
        'pageviews',
        'entry_views',
        '_post_views',
        '_views',
        'jl_views',
        'jl_post_views',
        'bopea_views',
        'hits',
        'post_hits',
    );

    /**
     * Memungkinkan penambahan meta key khusus tanpa mengubah plugin.
     *
     * @param string[] $meta_keys Daftar meta key kandidat.
     * @param int      $post_id   ID artikel.
     */
    $meta_keys = apply_filters( 'he_visitor_count_meta_keys', $meta_keys, $post_id );
    $first_existing_source = '';

    foreach ( array_unique( array_filter( (array) $meta_keys, 'is_string' ) ) as $meta_key ) {
        if ( ! metadata_exists( 'post', $post_id, $meta_key ) ) {
            continue;
        }

        if ( '' === $first_existing_source ) {
            $first_existing_source = 'postmeta:' . $meta_key;
        }

        $count = he_vc_normalize_count( get_post_meta( $post_id, $meta_key, true ) );
        if ( $count > 0 ) {
            $request_cache[ $post_id ] = array(
                'count'  => $count,
                'source' => 'postmeta:' . $meta_key,
            );
            return $request_cache[ $post_id ];
        }
    }

    // Fallback: cari meta numerik yang nama key-nya mengandung view/hit/visit/read.
    $all_meta   = get_post_meta( $post_id );
    $candidates = array();

    foreach ( $all_meta as $meta_key => $values ) {
        if ( ! preg_match( '/(?:view|hit|visit|read)/i', (string) $meta_key ) ) {
            continue;
        }

        if ( '' === $first_existing_source ) {
            $first_existing_source = 'postmeta:' . $meta_key;
        }

        foreach ( (array) $values as $value ) {
            $count = he_vc_normalize_count( maybe_unserialize( $value ) );
            if ( $count > 0 ) {
                $candidates[] = array(
                    'count'  => $count,
                    'source' => 'postmeta:' . $meta_key,
                );
            }
        }
    }

    if ( ! empty( $candidates ) ) {
        usort( $candidates, function ( $a, $b ) {
            return $b['count'] - $a['count'];
        } );
        $request_cache[ $post_id ] = $candidates[0];
        return $request_cache[ $post_id ];
    }

    // Jika key ada tetapi nilainya memang nol, tetap tampilkan sumbernya.
    $request_cache[ $post_id ] = array(
        'count'  => 0,
        'source' => $first_existing_source ? $first_existing_source : 'not_found',
    );

    return $request_cache[ $post_id ];
}

/**
 * Mendaftarkan field visitor counter pada REST API.
 */
function he_vc_register_rest_fields() {
    $object_types = apply_filters( 'he_visitor_count_rest_types', array( 'post' ) );
    $object_types = array_values( array_unique( array_filter( (array) $object_types, 'is_string' ) ) );

    if ( empty( $object_types ) ) {
        $object_types = array( 'post' );
    }

    register_rest_field( $object_types, 'views', array(
        'get_callback' => function ( $object ) {
            $post_id = isset( $object['id'] ) ? absint( $object['id'] ) : 0;
            $result  = he_vc_resolve_views( $post_id );
            return (int) $result['count'];
        },
        'schema' => array(
            'description' => 'Jumlah tayangan artikel.',
            'type'        => 'integer',
            'context'     => array( 'view', 'edit' ),
            'readonly'    => true,
        ),
    ) );

    register_rest_field( $object_types, 'views_source', array(
        'get_callback' => function ( $object ) {
            $post_id = isset( $object['id'] ) ? absint( $object['id'] ) : 0;
            $result  = he_vc_resolve_views( $post_id );
            return sanitize_text_field( $result['source'] );
        },
        'schema' => array(
            'description' => 'Sumber data visitor counter yang terdeteksi.',
            'type'        => 'string',
            'context'     => array( 'view', 'edit' ),
            'readonly'    => true,
        ),
    ) );
}
add_action( 'rest_api_init', 'he_vc_register_rest_fields' );

/**
 * Mengambil dan memvalidasi manifest pembaruan.
 *
 * @param bool $force Paksa mengambil ulang manifest.
 * @return array|false
 */
function he_vc_get_update_manifest( $force = false ) {
    if ( ! $force ) {
        $cached = get_site_transient( HE_VC_UPDATE_CACHE_KEY );
        if ( is_array( $cached ) ) {
            return ! empty( $cached['manifest'] ) && is_array( $cached['manifest'] )
                ? $cached['manifest']
                : false;
        }
    }

    $manifest_url = apply_filters( 'he_vc_update_manifest_url', HE_VC_UPDATE_URL );
    $response     = wp_remote_get( esc_url_raw( $manifest_url ), array(
        'timeout'     => 12,
        'redirection' => 3,
        'sslverify'   => true,
        'headers'     => array(
            'Accept'     => 'application/json',
            'User-Agent' => 'HE-Visitor-Count-REST/' . HE_VC_VERSION . '; ' . home_url( '/' ),
        ),
    ) );

    if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
        set_site_transient( HE_VC_UPDATE_CACHE_KEY, array( 'manifest' => array() ), 30 * MINUTE_IN_SECONDS );
        return false;
    }

    $manifest = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( ! is_array( $manifest ) ) {
        set_site_transient( HE_VC_UPDATE_CACHE_KEY, array( 'manifest' => array() ), 30 * MINUTE_IN_SECONDS );
        return false;
    }

    $new_version = isset( $manifest['new_version'] ) ? $manifest['new_version'] : ( isset( $manifest['version'] ) ? $manifest['version'] : '' );
    $package     = isset( $manifest['package'] ) ? $manifest['package'] : ( isset( $manifest['download_url'] ) ? $manifest['download_url'] : '' );

    if ( ! preg_match( '/^[0-9]+(?:\.[0-9A-Za-z-]+)+$/', (string) $new_version ) || ! wp_http_validate_url( $package ) ) {
        set_site_transient( HE_VC_UPDATE_CACHE_KEY, array( 'manifest' => array() ), 30 * MINUTE_IN_SECONDS );
        return false;
    }

    $manifest['new_version'] = sanitize_text_field( $new_version );
    $manifest['package']     = esc_url_raw( $package );

    set_site_transient( HE_VC_UPDATE_CACHE_KEY, array( 'manifest' => $manifest ), 6 * HOUR_IN_SECONDS );
    return $manifest;
}

/**
 * Membentuk objek update WordPress dari manifest JSON.
 *
 * @param array $manifest Manifest pembaruan.
 * @return stdClass
 */
function he_vc_build_update_object( $manifest ) {
    $update              = new stdClass();
    $update->slug        = HE_VC_SLUG;
    $update->plugin      = plugin_basename( HE_VC_FILE );
    $update->new_version = $manifest['new_version'];
    $update->package     = $manifest['package'];
    $update->url         = isset( $manifest['homepage'] ) ? esc_url_raw( $manifest['homepage'] ) : '';

    if ( isset( $manifest['requires'] ) ) {
        $update->requires = sanitize_text_field( $manifest['requires'] );
    }
    if ( isset( $manifest['requires_php'] ) ) {
        $update->requires_php = sanitize_text_field( $manifest['requires_php'] );
    }
    if ( isset( $manifest['tested'] ) ) {
        $update->tested = sanitize_text_field( $manifest['tested'] );
    }
    if ( isset( $manifest['icons'] ) && is_array( $manifest['icons'] ) ) {
        $update->icons = array_map( 'esc_url_raw', $manifest['icons'] );
    }
    if ( isset( $manifest['banners'] ) && is_array( $manifest['banners'] ) ) {
        $update->banners = array_map( 'esc_url_raw', $manifest['banners'] );
    }

    return $update;
}

/**
 * Menambahkan update plugin ke transient WordPress.
 *
 * @param object $transient Transient update_plugins.
 * @return object
 */
function he_vc_check_for_update( $transient ) {
    if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
        return $transient;
    }

    $plugin_file = plugin_basename( HE_VC_FILE );
    $manifest    = he_vc_get_update_manifest();

    if ( ! $manifest ) {
        return $transient;
    }

    $update = he_vc_build_update_object( $manifest );

    if ( version_compare( HE_VC_VERSION, $manifest['new_version'], '<' ) ) {
        $transient->response[ $plugin_file ] = $update;
    } elseif ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
        $transient->no_update[ $plugin_file ] = $update;
    }

    return $transient;
}
add_filter( 'pre_set_site_transient_update_plugins', 'he_vc_check_for_update' );

/**
 * Menampilkan informasi plugin pada modal "Lihat rincian" WordPress.
 *
 * @param mixed  $result Hasil sebelumnya.
 * @param string $action Aksi plugins_api.
 * @param object $args   Argumen permintaan.
 * @return mixed
 */
function he_vc_plugin_information( $result, $action, $args ) {
    if ( 'plugin_information' !== $action || empty( $args->slug ) || HE_VC_SLUG !== $args->slug ) {
        return $result;
    }

    $manifest = he_vc_get_update_manifest();
    if ( ! $manifest ) {
        return $result;
    }

    $info                  = new stdClass();
    $info->name            = isset( $manifest['name'] ) ? sanitize_text_field( $manifest['name'] ) : 'HE Visitor Count REST Field';
    $info->slug            = HE_VC_SLUG;
    $info->version         = $manifest['new_version'];
    $info->author          = isset( $manifest['author'] ) ? wp_kses_post( $manifest['author'] ) : 'Harian Express';
    $info->author_profile  = isset( $manifest['author_profile'] ) ? esc_url_raw( $manifest['author_profile'] ) : HE_VC_HOMEPAGE;
    $info->homepage        = isset( $manifest['homepage'] ) ? esc_url_raw( $manifest['homepage'] ) : HE_VC_HOMEPAGE;
    $info->download_link   = $manifest['package'];
    $info->external        = true;

    if ( isset( $manifest['short_description'] ) ) {
        $info->short_description = sanitize_text_field( $manifest['short_description'] );
    }
    if ( isset( $manifest['contributors'] ) && is_array( $manifest['contributors'] ) ) {
        $info->contributors = array_map( 'sanitize_text_field', $manifest['contributors'] );
    }
    if ( isset( $manifest['donate_link'] ) ) {
        $info->donate_link = esc_url_raw( $manifest['donate_link'] );
    }

    if ( isset( $manifest['requires'] ) ) {
        $info->requires = sanitize_text_field( $manifest['requires'] );
    }
    if ( isset( $manifest['requires_php'] ) ) {
        $info->requires_php = sanitize_text_field( $manifest['requires_php'] );
    }
    if ( isset( $manifest['tested'] ) ) {
        $info->tested = sanitize_text_field( $manifest['tested'] );
    }
    if ( isset( $manifest['last_updated'] ) ) {
        $info->last_updated = sanitize_text_field( $manifest['last_updated'] );
    }
    if ( isset( $manifest['sections'] ) && is_array( $manifest['sections'] ) ) {
        $info->sections = array_map( 'wp_kses_post', $manifest['sections'] );
    }
    if ( isset( $manifest['banners'] ) && is_array( $manifest['banners'] ) ) {
        $info->banners = array_map( 'esc_url_raw', $manifest['banners'] );
    }
    if ( isset( $manifest['icons'] ) && is_array( $manifest['icons'] ) ) {
        $info->icons = array_map( 'esc_url_raw', $manifest['icons'] );
    }

    return $info;
}
add_filter( 'plugins_api', 'he_vc_plugin_information', 20, 3 );

/**
 * Memuat dukungan Thickbox untuk modal informasi plugin.
 *
 * @param string $hook_suffix Nama halaman admin.
 */
function he_vc_enqueue_plugin_details_assets( $hook_suffix ) {
    if ( 'plugins.php' !== $hook_suffix && 'update-core.php' !== $hook_suffix ) {
        return;
    }

    add_thickbox();
}
add_action( 'admin_enqueue_scripts', 'he_vc_enqueue_plugin_details_assets' );

/**
 * Menambahkan tautan View details dan Plugin homepage pada baris plugin.
 * Tautan View details membuka data dari update.json melalui filter plugins_api.
 *
 * @param string[] $links       Daftar tautan metadata plugin.
 * @param string   $plugin_file Path relatif file plugin.
 * @param array    $plugin_data Data header plugin.
 * @param string   $status      Status plugin.
 * @return string[]
 */
function he_vc_plugin_row_meta( $links, $plugin_file, $plugin_data, $status ) {
    unset( $plugin_data, $status );

    if ( plugin_basename( HE_VC_FILE ) !== $plugin_file ) {
        return $links;
    }

    $details_url = add_query_arg(
        array(
            'tab'       => 'plugin-information',
            'plugin'    => HE_VC_SLUG,
            'TB_iframe' => 'true',
            'width'     => 772,
            'height'    => 700,
        ),
        self_admin_url( 'plugin-install.php' )
    );

    $links[] = sprintf(
        '<a href="%1$s" class="thickbox open-plugin-details-modal" aria-label="%2$s">%3$s</a>',
        esc_url( $details_url ),
        esc_attr__( 'View details for HE Visitor Count REST Field', 'he-visitor-count-rest' ),
        esc_html__( 'View details', 'he-visitor-count-rest' )
    );

    $links[] = sprintf(
        '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
        esc_url( HE_VC_HOMEPAGE ),
        esc_html__( 'Plugin homepage', 'he-visitor-count-rest' )
    );

    return $links;
}
add_filter( 'plugin_row_meta', 'he_vc_plugin_row_meta', 10, 4 );

/**
 * Menghapus cache manifest setelah proses pembaruan plugin selesai.
 *
 * @param WP_Upgrader $upgrader Objek upgrader.
 * @param array       $options  Opsi proses upgrader.
 */
function he_vc_clear_update_cache_after_upgrade( $upgrader, $options ) {
    if ( empty( $options['action'] ) || 'update' !== $options['action'] || empty( $options['type'] ) || 'plugin' !== $options['type'] ) {
        return;
    }

    delete_site_transient( HE_VC_UPDATE_CACHE_KEY );
}
add_action( 'upgrader_process_complete', 'he_vc_clear_update_cache_after_upgrade', 10, 2 );

/**
 * Hapus cache pembaruan saat plugin diaktifkan.
 */
function he_vc_on_activation() {
    delete_site_transient( HE_VC_UPDATE_CACHE_KEY );
    delete_site_transient( 'update_plugins' );
}
register_activation_hook( HE_VC_FILE, 'he_vc_on_activation' );

=== HE Visitor Count REST Field ===
Contributors: harianexpress
Tags: rest-api, views, visitor-counter, bopea, jellywp
Requires at least: 4.7
Requires PHP: 7.0
Stable tag: 2.0.0
License: GPLv2 or later

Menambahkan field views dan views_source ke WordPress REST API serta mendukung pembaruan otomatis dari GitHub.

== Description ==

Plugin ini membaca visitor counter dari post meta yang umum digunakan Bopea/JellyWP dan plugin penghitung tayangan lainnya.

Contoh endpoint:
/wp-json/wp/v2/posts/123?_fields=id,title,views,views_source

== Changelog ==

= 2.0.0 =
* Menambahkan pembaruan otomatis melalui update.json di GitHub Raw.
* Menambahkan cache manifest pembaruan selama enam jam.
* Menambahkan informasi detail pembaruan pada halaman plugin WordPress.
* Mengoptimalkan pembacaan views dan views_source dengan cache per request.
* Menampilkan sumber meta key walaupun nilai counter masih nol.
* Menambahkan filter he_visitor_count_rest_types untuk post type tambahan.

= 1.1.0 =
* Menambahkan dukungan post_views_count dan beberapa meta key umum.
* Menambahkan field views_source.

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_DB {
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'hech_' . $name;
    }

    public static function install() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();

        $articles = self::table( 'articles' );
        $terms    = self::table( 'terms' );
        $sources  = self::table( 'sources' );
        $outbox   = self::table( 'outbox' );

        $sql_articles = "CREATE TABLE {$articles} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_hash char(32) NOT NULL,
            source_domain varchar(190) NOT NULL,
            source_name varchar(190) NOT NULL DEFAULT '',
            source_post_id bigint(20) unsigned NOT NULL,
            title text NOT NULL,
            url text NOT NULL,
            image_url text NOT NULL,
            excerpt longtext NULL,
            author_id bigint(20) unsigned NOT NULL DEFAULT 0,
            author_name varchar(190) NOT NULL DEFAULT '',
            author_url text NULL,
            author_avatar_url text NULL,
            views bigint(20) unsigned NOT NULL DEFAULT 0,
            views_source varchar(190) NOT NULL DEFAULT '',
            metrics_updated_at datetime NULL,
            published_at datetime NULL,
            modified_at datetime NULL,
            status varchar(20) NOT NULL DEFAULT 'publish',
            payload_hash char(64) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY source_post (source_hash,source_post_id),
            KEY status_date (status,published_at),
            KEY source_hash (source_hash),
            KEY author_date (author_name(100),published_at),
            KEY views (views),
            KEY modified_at (modified_at)
        ) {$charset_collate};";

        $sql_terms = "CREATE TABLE {$terms} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            article_id bigint(20) unsigned NOT NULL,
            taxonomy varchar(32) NOT NULL DEFAULT 'category',
            term_slug varchar(190) NOT NULL,
            term_name varchar(190) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY article_term (article_id,taxonomy,term_slug(100)),
            KEY taxonomy_slug (taxonomy,term_slug(100)),
            KEY article_id (article_id)
        ) {$charset_collate};";

        $sql_sources = "CREATE TABLE {$sources} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_hash char(32) NOT NULL,
            domain varchar(190) NOT NULL,
            name varchar(190) NOT NULL DEFAULT '',
            active tinyint(1) NOT NULL DEFAULT 1,
            last_seen_at datetime NULL,
            last_error text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY source_hash (source_hash),
            KEY active (active)
        ) {$charset_collate};";

        $sql_outbox = "CREATE TABLE {$outbox} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_key varchar(190) NOT NULL,
            source_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            payload longtext NOT NULL,
            attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            next_attempt datetime NOT NULL,
            last_error text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY event_key (event_key(150)),
            KEY due_queue (next_attempt,attempts)
        ) {$charset_collate};";

        dbDelta( $sql_articles );
        dbDelta( $sql_terms );
        dbDelta( $sql_sources );
        dbDelta( $sql_outbox );

        update_option( 'hech_db_version', HECH_VERSION, false );
    }
}

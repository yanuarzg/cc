<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_Plugin {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_filter( 'cron_schedules', array( $this, 'cron_schedules' ) );
        add_action( 'plugins_loaded', array( $this, 'maybe_upgrade' ), 5 );
        add_action( 'init', array( $this, 'ensure_cron' ) );

        new HECH_Visitor();
        new HECH_Hub();
        new HECH_Source();
        new HECH_Compat();
        new HECH_Settings();
        new HECH_Updater();
    }

    public static function defaults() {
        return array(
            'mode'                  => 'source',
            'hub_url'               => 'https://harianexpress.com',
            'network_secret'        => wp_generate_password( 64, true, true ),
            'auto_register_sources' => 1,
            'api_cache_ttl'         => 45,
            'proxy_cache_ttl'       => 45,
            'dashboard_cache_ttl'   => 90,
            'dashboard_history_months' => 18,
            'dashboard_max_posts'  => 30000,
            'visitor_primary_meta_key' => 'post_views_count',
            'visitor_fallback_scan' => 0,
            'visitor_expose_source' => 0,
            'visitor_sync_delay'   => 60,
            'groups'                => self::default_groups(),
            'legacy_patterns'       => array(
                'https://script.google.com/macros/s/AKfycby-wjHrISkxkjEaHOpoU2risaNErxoJYEhV9qswp873AF8p3jmNhjE8GSw84K3jZhTD/exec',
            ),
        );
    }

    public static function default_groups() {
        return array(
            'daerah' => array(
                'bali.harianexpress.com',
                'banten.harianexpress.com',
                'blitar.harianexpress.com',
                'bogor.harianexpress.com',
                'depok.harianexpress.com',
                'jabar.harianexpress.com',
                'jakarta.harianexpress.com',
                'jateng.harianexpress.com',
                'jatim.harianexpress.com',
                'kalimantan.harianexpress.com',
                'kaltim.harianexpress.com',
                'klaten.harianexpress.com',
                'lampung.harianexpress.com',
                'tangsel.harianexpress.com',
            ),
        );
    }

    public static function get_settings() {
        $settings = get_option( 'hech_settings', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }
        return wp_parse_args( $settings, self::defaults() );
    }

    public static function setting( $key, $default = null ) {
        $settings = self::get_settings();
        return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
    }

    public static function mode_allows_hub() {
        return in_array( self::setting( 'mode', 'source' ), array( 'hub', 'both' ), true );
    }

    public static function mode_allows_source() {
        return in_array( self::setting( 'mode', 'source' ), array( 'source', 'both' ), true );
    }

    public static function activate() {
        HECH_DB::install();

        if ( false === get_option( 'hech_settings', false ) ) {
            add_option( 'hech_settings', self::defaults(), '', false );
        }
        if ( false === get_option( 'hech_cache_generation', false ) ) {
            add_option( 'hech_cache_generation', 1, '', false );
        }

        self::migrate_legacy_visitor_settings();
        delete_site_transient( 'hech_update_manifest_v110' );
        delete_site_transient( 'hech_update_manifest_v111' );
        delete_site_transient( 'update_plugins' );

        self::schedule_cron();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( 'hech_process_outbox_event' );
        wp_clear_scheduled_hook( 'hech_process_outbox_event', array( 'single' ) );
        wp_clear_scheduled_hook( 'hech_deferred_visitor_sync' );
        delete_option( 'hech_outbox_process_lock' );
        flush_rewrite_rules();
    }

    public function maybe_upgrade() {
        if ( get_option( 'hech_db_version' ) !== HECH_VERSION ) {
            HECH_DB::install();
            self::migrate_legacy_visitor_settings();
            delete_site_transient( 'hech_update_manifest_v110' );
        delete_site_transient( 'hech_update_manifest_v111' );
        }
    }

    public function cron_schedules( $schedules ) {
        if ( ! isset( $schedules['hech_minute'] ) ) {
            $schedules['hech_minute'] = array(
                'interval' => 60,
                'display'  => __( 'Setiap menit (HE Content Hub)', 'harianexpress-content-hub' ),
            );
        }
        return $schedules;
    }

    public function ensure_cron() {
        self::schedule_cron();
    }

    public static function schedule_cron() {
        if ( ! wp_next_scheduled( 'hech_process_outbox_event' ) ) {
            wp_schedule_event( time() + 60, 'hech_minute', 'hech_process_outbox_event' );
        }
    }

    public static function migrate_legacy_visitor_settings() {
        $legacy = get_option( 'he_vc_settings', array() );
        if ( ! is_array( $legacy ) || ! $legacy ) {
            return;
        }
        $settings = self::get_settings();
        if ( ! empty( $legacy['primary_meta_key'] ) && ( empty( $settings['visitor_primary_meta_key'] ) || 'post_views_count' === $settings['visitor_primary_meta_key'] ) ) {
            $settings['visitor_primary_meta_key'] = sanitize_key( $legacy['primary_meta_key'] );
        }
        if ( ! empty( $legacy['fallback_scan'] ) ) {
            $settings['visitor_fallback_scan'] = 1;
        }
        if ( ! empty( $legacy['expose_source'] ) ) {
            $settings['visitor_expose_source'] = 1;
        }
        update_option( 'hech_settings', $settings, false );
    }

    public static function normalize_domain( $value ) {
        $value = trim( strtolower( (string) $value ) );
        if ( '' === $value ) {
            return '';
        }
        if ( false !== strpos( $value, '://' ) ) {
            $host = wp_parse_url( $value, PHP_URL_HOST );
            $value = $host ? $host : $value;
        }
        $value = preg_replace( '#^www\.#', 'www.', $value );
        $value = preg_replace( '#/.*$#', '', $value );
        $value = preg_replace( '/:\d+$/', '', $value );
        return sanitize_text_field( $value );
    }

    public static function current_domain() {
        return self::normalize_domain( home_url() );
    }

    public static function normalize_base_url( $url ) {
        $url = trim( (string) $url );
        if ( '' === $url ) {
            return '';
        }
        if ( ! preg_match( '#^https?://#i', $url ) ) {
            $url = 'https://' . $url;
        }
        return untrailingslashit( esc_url_raw( $url ) );
    }

    public static function bump_cache_generation() {
        $generation = (int) get_option( 'hech_cache_generation', 1 );
        update_option( 'hech_cache_generation', $generation + 1, false );
    }
}

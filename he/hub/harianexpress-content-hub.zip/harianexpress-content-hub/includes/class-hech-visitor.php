<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Visitor counter resolver, REST adapter, and Hub metric event bridge.
 */
class HECH_Visitor {
    private static $request_cache = array();

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_rest_fields' ) );
        add_action( 'added_post_meta', array( $this, 'on_meta_changed' ), 10, 4 );
        add_action( 'updated_post_meta', array( $this, 'on_meta_changed' ), 10, 4 );
        add_action( 'deleted_post_meta', array( $this, 'on_meta_deleted' ), 10, 4 );
        add_action( 'hech_deferred_visitor_sync', array( $this, 'run_deferred_sync' ), 10, 1 );
        add_filter( 'he_np_source_post_metrics', array( $this, 'add_network_metrics' ), 10, 2 );
        add_action( 'admin_notices', array( $this, 'maybe_show_legacy_notice' ) );
    }

    public static function normalize_count( $value ) {
        if ( is_array( $value ) || is_object( $value ) ) {
            return 0;
        }
        if ( is_int( $value ) || is_float( $value ) ) {
            return max( 0, (int) round( $value ) );
        }

        $text = trim( wp_strip_all_tags( (string) $value ) );
        if ( '' === $text ) {
            return 0;
        }
        if ( preg_match( '/^\s*([0-9][0-9.,]*)\s*$/', $text, $matches ) ) {
            $digits = preg_replace( '/[^0-9]/', '', $matches[1] );
            return '' === $digits ? 0 : max( 0, (int) $digits );
        }
        if ( preg_match( '/([0-9]+(?:[.,][0-9]+)?)\s*([kKmMbB])?/', $text, $matches ) ) {
            $number = (float) str_replace( ',', '.', $matches[1] );
            $suffix = isset( $matches[2] ) ? strtolower( $matches[2] ) : '';
            $factor = array( 'k' => 1000, 'm' => 1000000, 'b' => 1000000000 );
            return max( 0, (int) round( $number * ( isset( $factor[ $suffix ] ) ? $factor[ $suffix ] : 1 ) ) );
        }
        return 0;
    }

    public static function candidate_meta_keys( $post_id = 0 ) {
        $keys = array(
            HECH_Plugin::setting( 'visitor_primary_meta_key', 'post_views_count' ),
            'post_views_count', 'views', 'post_views', 'views_count', 'view_count',
            'page_views', 'pageviews', 'entry_views', '_post_views', '_views',
            'jl_views', 'jl_post_views', 'bopea_views', 'hits', 'post_hits',
        );
        $keys = apply_filters( 'hech_visitor_meta_keys', $keys, absint( $post_id ) );
        return array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $keys ) ) ) );
    }

    public static function resolve_views( $post_id ) {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return array( 'count' => 0, 'source' => 'invalid_post_id' );
        }
        if ( isset( self::$request_cache[ $post_id ] ) ) {
            return self::$request_cache[ $post_id ];
        }

        // Reuse the standalone plugin resolver during a gradual migration.
        if ( function_exists( 'he_vc_resolve_views' ) ) {
            $legacy = he_vc_resolve_views( $post_id );
            if ( is_array( $legacy ) && isset( $legacy['count'] ) ) {
                return self::$request_cache[ $post_id ] = array(
                    'count'  => max( 0, (int) $legacy['count'] ),
                    'source' => isset( $legacy['source'] ) ? sanitize_text_field( $legacy['source'] ) : 'legacy-resolver',
                );
            }
        }

        $first_existing_source = '';
        foreach ( self::candidate_meta_keys( $post_id ) as $meta_key ) {
            if ( ! metadata_exists( 'post', $post_id, $meta_key ) ) {
                continue;
            }
            if ( '' === $first_existing_source ) {
                $first_existing_source = 'postmeta:' . $meta_key;
            }
            $count = self::normalize_count( get_post_meta( $post_id, $meta_key, true ) );
            if ( $count > 0 ) {
                return self::$request_cache[ $post_id ] = array( 'count' => $count, 'source' => 'postmeta:' . $meta_key );
            }
        }

        if ( HECH_Plugin::setting( 'visitor_fallback_scan', 0 ) ) {
            $candidates = array();
            foreach ( get_post_meta( $post_id ) as $meta_key => $values ) {
                if ( ! preg_match( '/(?:view|hit|visit|read)/i', (string) $meta_key ) ) {
                    continue;
                }
                if ( '' === $first_existing_source ) {
                    $first_existing_source = 'postmeta:' . $meta_key;
                }
                foreach ( (array) $values as $value ) {
                    $count = self::normalize_count( maybe_unserialize( $value ) );
                    if ( $count > 0 ) {
                        $candidates[] = array( 'count' => $count, 'source' => 'postmeta:' . $meta_key );
                    }
                }
            }
            if ( $candidates ) {
                usort( $candidates, static function ( $a, $b ) { return $b['count'] - $a['count']; } );
                return self::$request_cache[ $post_id ] = $candidates[0];
            }
        }

        return self::$request_cache[ $post_id ] = array(
            'count'  => 0,
            'source' => $first_existing_source ? $first_existing_source : 'not_found',
        );
    }

    public static function post_metrics( $post_id ) {
        $result = self::resolve_views( $post_id );
        return array(
            'views'            => (int) $result['count'],
            'views_source'     => sanitize_text_field( $result['source'] ),
            'views_updated_at' => gmdate( DATE_W3C ),
        );
    }

    public static function clear_request_cache( $post_id ) {
        unset( self::$request_cache[ absint( $post_id ) ] );
    }

    public function register_rest_fields() {
        $types = apply_filters( 'hech_visitor_rest_types', array( 'post' ) );
        $types = array_values( array_unique( array_filter( (array) $types, 'is_string' ) ) );
        if ( ! $types ) {
            $types = array( 'post' );
        }

        register_rest_field( $types, 'views', array(
            'get_callback' => static function ( $object ) {
                $result = self::resolve_views( isset( $object['id'] ) ? absint( $object['id'] ) : 0 );
                return (int) $result['count'];
            },
            'schema' => array(
                'description' => 'Jumlah tayangan artikel.',
                'type' => 'integer',
                'context' => array( 'view', 'edit' ),
                'readonly' => true,
            ),
        ) );

        register_rest_field( $types, 'views_source', array(
            'get_callback' => static function ( $object ) {
                $post_id = isset( $object['id'] ) ? absint( $object['id'] ) : 0;
                if ( ! HECH_Plugin::setting( 'visitor_expose_source', 0 ) && ! current_user_can( 'edit_post', $post_id ) ) {
                    return '';
                }
                $result = self::resolve_views( $post_id );
                return sanitize_text_field( $result['source'] );
            },
            'schema' => array(
                'description' => 'Sumber data visitor counter.',
                'type' => 'string',
                'context' => array( 'view', 'edit' ),
                'readonly' => true,
            ),
        ) );
    }

    public function add_network_metrics( $metrics, $post_id ) {
        return array_merge( is_array( $metrics ) ? $metrics : array(), self::post_metrics( $post_id ) );
    }

    public function on_meta_changed( $meta_id, $post_id, $meta_key, $meta_value ) {
        unset( $meta_id );
        $post_id  = absint( $post_id );
        $meta_key = sanitize_key( $meta_key );
        if ( ! $post_id || ! in_array( $meta_key, self::candidate_meta_keys( $post_id ), true ) ) {
            return;
        }

        self::clear_request_cache( $post_id );

        $delay    = max( 15, min( 600, absint( apply_filters( 'hech_visitor_sync_delay', HECH_Plugin::setting( 'visitor_sync_delay', 60 ), $post_id, $meta_key ) ) ) );
        $lock_key = 'hech_visitor_sync_' . $post_id;

        // Kirim perubahan pertama segera agar dashboard cepat berubah.
        // Perubahan berikutnya selama interval digabung oleh outbox dan dikirim ulang
        // pada akhir interval dengan nilai terbaru.
        if ( false === get_transient( $lock_key ) ) {
            set_transient( $lock_key, 1, $delay );
            do_action( 'hech_visitor_count_changed', $post_id, self::normalize_count( $meta_value ), $meta_key );
        }

        $args = array( $post_id );
        if ( ! wp_next_scheduled( 'hech_deferred_visitor_sync', $args ) ) {
            wp_schedule_single_event( time() + $delay, 'hech_deferred_visitor_sync', $args );
        }
    }

    public function run_deferred_sync( $post_id ) {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return;
        }

        delete_transient( 'hech_visitor_sync_' . $post_id );
        self::clear_request_cache( $post_id );
        $result = self::resolve_views( $post_id );
        $source = isset( $result['source'] ) ? sanitize_text_field( $result['source'] ) : '';
        $meta_key = 0 === strpos( $source, 'postmeta:' ) ? sanitize_key( substr( $source, 9 ) ) : sanitize_key( HECH_Plugin::setting( 'visitor_primary_meta_key', 'post_views_count' ) );
        do_action( 'hech_visitor_count_changed', $post_id, isset( $result['count'] ) ? (int) $result['count'] : 0, $meta_key );
    }

    public function on_meta_deleted( $meta_ids, $post_id, $meta_key, $meta_value ) {
        unset( $meta_ids, $meta_value );
        $post_id = absint( $post_id );
        if ( $post_id && in_array( sanitize_key( $meta_key ), self::candidate_meta_keys( $post_id ), true ) ) {
            self::clear_request_cache( $post_id );
            delete_transient( 'hech_visitor_sync_' . $post_id );
            do_action( 'hech_visitor_count_changed', $post_id, 0, sanitize_key( $meta_key ) );
        }
    }

    public function maybe_show_legacy_notice() {
        if ( ! current_user_can( 'activate_plugins' ) || ! function_exists( 'he_vc_resolve_views' ) ) {
            return;
        }
        echo '<div class="notice notice-warning"><p><strong>HE Content Hub:</strong> Fitur HE Visitor Count sudah terintegrasi. Setelah verifikasi data visitor, plugin HE Visitor Count REST Field lama dapat dinonaktifkan agar hook tidak berjalan ganda.</p></div>';
    }
}

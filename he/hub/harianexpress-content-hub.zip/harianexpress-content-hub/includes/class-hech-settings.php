<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_Settings {
    private $source;

    public function __construct() {
        $this->source = new HECH_Source( false );

        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );

        add_action( 'wp_ajax_hech_backfill_batch', array( $this, 'ajax_backfill_batch' ) );
        add_action( 'wp_ajax_hech_process_queue', array( $this, 'ajax_process_queue' ) );
        add_action( 'wp_ajax_hech_test_connection', array( $this, 'ajax_test_connection' ) );
        add_action( 'wp_ajax_hech_generate_secret', array( $this, 'ajax_generate_secret' ) );
        add_action( 'admin_post_hech_toggle_source', array( $this, 'toggle_source' ) );
    }

    public function admin_menu() {
        add_options_page(
            __( 'HE Content Hub', 'harianexpress-content-hub' ),
            __( 'HE Content Hub', 'harianexpress-content-hub' ),
            'manage_options',
            'hech-settings',
            array( $this, 'render_page' )
        );
    }

    public function register_settings() {
        register_setting(
            'hech_settings_group',
            'hech_settings',
            array( $this, 'sanitize_settings' )
        );
    }

    public function sanitize_settings( $input ) {
        $input = is_array( $input ) ? $input : array();
        $current = HECH_Plugin::get_settings();
        $output  = $current;

        $mode = isset( $input['mode'] ) ? sanitize_key( $input['mode'] ) : 'source';
        $output['mode'] = in_array( $mode, array( 'source', 'hub', 'both', 'disabled' ), true ) ? $mode : 'source';
        $output['hub_url'] = HECH_Plugin::normalize_base_url( isset( $input['hub_url'] ) ? $input['hub_url'] : '' );
        $output['network_secret'] = isset( $input['network_secret'] ) ? sanitize_text_field( $input['network_secret'] ) : '';
        if ( '' === $output['network_secret'] ) {
            $output['network_secret'] = wp_generate_password( 64, true, true );
        }
        $output['auto_register_sources'] = ! empty( $input['auto_register_sources'] ) ? 1 : 0;
        $output['api_cache_ttl'] = max( 5, min( 300, absint( isset( $input['api_cache_ttl'] ) ? $input['api_cache_ttl'] : 45 ) ) );
        $output['proxy_cache_ttl'] = max( 5, min( 300, absint( isset( $input['proxy_cache_ttl'] ) ? $input['proxy_cache_ttl'] : 45 ) ) );
        $output['dashboard_cache_ttl'] = max( 15, min( 600, absint( isset( $input['dashboard_cache_ttl'] ) ? $input['dashboard_cache_ttl'] : 90 ) ) );
        $output['dashboard_history_months'] = max( 1, min( 60, absint( isset( $input['dashboard_history_months'] ) ? $input['dashboard_history_months'] : 18 ) ) );
        $output['dashboard_max_posts'] = max( 1000, min( 50000, absint( isset( $input['dashboard_max_posts'] ) ? $input['dashboard_max_posts'] : 30000 ) ) );
        $output['visitor_primary_meta_key'] = sanitize_key( isset( $input['visitor_primary_meta_key'] ) ? $input['visitor_primary_meta_key'] : 'post_views_count' );
        if ( '' === $output['visitor_primary_meta_key'] ) {
            $output['visitor_primary_meta_key'] = 'post_views_count';
        }
        $output['visitor_fallback_scan'] = ! empty( $input['visitor_fallback_scan'] ) ? 1 : 0;
        $output['visitor_expose_source'] = ! empty( $input['visitor_expose_source'] ) ? 1 : 0;
        $output['visitor_sync_delay'] = max( 15, min( 600, absint( isset( $input['visitor_sync_delay'] ) ? $input['visitor_sync_delay'] : 60 ) ) );
        $output['groups'] = $this->parse_groups_text( isset( $input['groups_text'] ) ? $input['groups_text'] : '' );
        $output['legacy_patterns'] = $this->parse_lines( isset( $input['legacy_patterns_text'] ) ? $input['legacy_patterns_text'] : '' );

        HECH_Plugin::bump_cache_generation();
        return $output;
    }

    private function parse_groups_text( $text ) {
        $groups = array();
        $lines  = preg_split( '/\r\n|\r|\n/', (string) $text );

        foreach ( $lines as $line ) {
            $line = trim( $line );
            if ( '' === $line || 0 === strpos( $line, '#' ) || false === strpos( $line, '=' ) ) {
                continue;
            }

            list( $name, $domains_text ) = array_map( 'trim', explode( '=', $line, 2 ) );
            $name = sanitize_key( $name );
            if ( ! $name || 'all' === $name ) {
                continue;
            }

            $domains = array();
            foreach ( explode( ',', $domains_text ) as $domain ) {
                $domain = HECH_Plugin::normalize_domain( $domain );
                if ( $domain ) {
                    $domains[] = $domain;
                }
            }
            if ( $domains ) {
                $groups[ $name ] = array_values( array_unique( $domains ) );
            }
        }

        return $groups;
    }

    private function parse_lines( $text ) {
        $lines = preg_split( '/\r\n|\r|\n/', (string) $text );
        $clean = array();
        foreach ( $lines as $line ) {
            $line = trim( $line );
            if ( $line ) {
                $clean[] = esc_url_raw( $line );
            }
        }
        return array_values( array_unique( array_filter( $clean ) ) );
    }

    private function groups_to_text( $groups ) {
        $lines = array();
        foreach ( (array) $groups as $name => $domains ) {
            if ( is_array( $domains ) && $domains ) {
                $lines[] = sanitize_key( $name ) . '=' . implode( ',', $domains );
            }
        }
        return implode( "\n", $lines );
    }

    public function enqueue_admin( $hook ) {
        if ( 'settings_page_hech-settings' !== $hook ) {
            return;
        }

        wp_enqueue_script(
            'hech-admin',
            HECH_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            HECH_VERSION,
            true
        );

        wp_localize_script(
            'hech-admin',
            'HECH_ADMIN',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'hech_admin_actions' ),
                'labels'  => array(
                    'working'       => __( 'Memproses…', 'harianexpress-content-hub' ),
                    'backfillDone'  => __( 'Semua artikel lama telah dimasukkan ke antrean.', 'harianexpress-content-hub' ),
                    'requestFailed' => __( 'Permintaan gagal. Periksa console dan log WordPress.', 'harianexpress-content-hub' ),
                ),
            )
        );
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $wpdb;
        $settings = HECH_Plugin::get_settings();
        $articles = HECH_DB::table( 'articles' );
        $sources  = HECH_DB::table( 'sources' );
        $outbox   = HECH_DB::table( 'outbox' );

        $article_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$articles} WHERE status = 'publish'" );
        $source_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$sources} WHERE active = 1" );
        $queue_count   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$outbox}" );
        $source_rows   = $wpdb->get_results( "SELECT domain, name, active, last_seen_at, last_error FROM {$sources} ORDER BY domain ASC LIMIT 200" );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'HarianExpress Content Hub', 'harianexpress-content-hub' ); ?></h1>
            <p><?php esc_html_e( 'Plugin yang sama dapat dipasang pada seluruh domain. Pilih mode Hub/Both pada situs pusat dan mode Source pada subdomain.', 'harianexpress-content-hub' ); ?></p>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;max-width:900px;margin:18px 0;">
                <?php $this->stat_box( __( 'Artikel aktif di Hub', 'harianexpress-content-hub' ), $article_count ); ?>
                <?php $this->stat_box( __( 'Sumber aktif', 'harianexpress-content-hub' ), $source_count ); ?>
                <?php $this->stat_box( __( 'Antrean lokal', 'harianexpress-content-hub' ), $queue_count ); ?>
                <?php $this->stat_box( __( 'Domain lokal', 'harianexpress-content-hub' ), HECH_Plugin::current_domain() ); ?>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields( 'hech_settings_group' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="hech-mode"><?php esc_html_e( 'Mode situs', 'harianexpress-content-hub' ); ?></label></th>
                        <td>
                            <select id="hech-mode" name="hech_settings[mode]">
                                <option value="source" <?php selected( $settings['mode'], 'source' ); ?>>Source</option>
                                <option value="hub" <?php selected( $settings['mode'], 'hub' ); ?>>Hub</option>
                                <option value="both" <?php selected( $settings['mode'], 'both' ); ?>>Source + Hub</option>
                                <option value="disabled" <?php selected( $settings['mode'], 'disabled' ); ?>>Disabled</option>
                            </select>
                            <p class="description"><?php esc_html_e( 'Situs pusat yang juga menerbitkan artikel sebaiknya menggunakan Source + Hub.', 'harianexpress-content-hub' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-hub-url"><?php esc_html_e( 'URL Hub pusat', 'harianexpress-content-hub' ); ?></label></th>
                        <td>
                            <input class="regular-text" type="url" id="hech-hub-url" name="hech_settings[hub_url]" value="<?php echo esc_attr( $settings['hub_url'] ); ?>" placeholder="https://harianexpress.com">
                            <p class="description"><?php esc_html_e( 'Isi URL yang sama pada seluruh Source.', 'harianexpress-content-hub' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-secret"><?php esc_html_e( 'Network Secret', 'harianexpress-content-hub' ); ?></label></th>
                        <td>
                            <input class="large-text code" type="text" id="hech-secret" name="hech_settings[network_secret]" value="<?php echo esc_attr( $settings['network_secret'] ); ?>" autocomplete="off">
                            <button type="button" class="button" id="hech-generate-secret"><?php esc_html_e( 'Buat secret baru', 'harianexpress-content-hub' ); ?></button>
                            <p class="description"><strong><?php esc_html_e( 'Harus identik pada Hub dan semua Source.', 'harianexpress-content-hub' ); ?></strong> <?php esc_html_e( 'Mengganti secret akan menghentikan sinkronisasi sampai seluruh situs diperbarui.', 'harianexpress-content-hub' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Registrasi sumber', 'harianexpress-content-hub' ); ?></th>
                        <td>
                            <label><input type="checkbox" name="hech_settings[auto_register_sources]" value="1" <?php checked( ! empty( $settings['auto_register_sources'] ) ); ?>> <?php esc_html_e( 'Izinkan domain dengan Network Secret yang benar mendaftar otomatis', 'harianexpress-content-hub' ); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-api-cache"><?php esc_html_e( 'Cache API Hub', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input type="number" min="5" max="300" id="hech-api-cache" name="hech_settings[api_cache_ttl]" value="<?php echo esc_attr( $settings['api_cache_ttl'] ); ?>"> detik</td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-proxy-cache"><?php esc_html_e( 'Cache proxy Source', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input type="number" min="5" max="300" id="hech-proxy-cache" name="hech_settings[proxy_cache_ttl]" value="<?php echo esc_attr( $settings['proxy_cache_ttl'] ); ?>"> detik</td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-dashboard-cache"><?php esc_html_e( 'Cache Dashboard Redaksi', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input type="number" min="15" max="600" id="hech-dashboard-cache" name="hech_settings[dashboard_cache_ttl]" value="<?php echo esc_attr( $settings['dashboard_cache_ttl'] ); ?>"> detik</td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-dashboard-months"><?php esc_html_e( 'Riwayat dashboard', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input type="number" min="1" max="60" id="hech-dashboard-months" name="hech_settings[dashboard_history_months]" value="<?php echo esc_attr( $settings['dashboard_history_months'] ); ?>"> bulan <p class="description">Endpoint dashboard mengambil data dari indeks Hub, bukan REST setiap domain.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-dashboard-limit"><?php esc_html_e( 'Batas artikel dashboard', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input type="number" min="1000" max="50000" step="1000" id="hech-dashboard-limit" name="hech_settings[dashboard_max_posts]" value="<?php echo esc_attr( $settings['dashboard_max_posts'] ); ?>"> artikel</td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-visitor-key"><?php esc_html_e( 'Visitor primary meta key', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input class="regular-text code" id="hech-visitor-key" name="hech_settings[visitor_primary_meta_key]" value="<?php echo esc_attr( $settings['visitor_primary_meta_key'] ); ?>"><p class="description">Biasanya <code>post_views_count</code>. Fitur HE Visitor Count REST sudah tergabung dalam plugin ini.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Visitor compatibility', 'harianexpress-content-hub' ); ?></th>
                        <td>
                            <label><input type="checkbox" name="hech_settings[visitor_fallback_scan]" value="1" <?php checked( ! empty( $settings['visitor_fallback_scan'] ) ); ?>> Pindai meta lain jika key utama tidak ditemukan</label><br>
                            <label><input type="checkbox" name="hech_settings[visitor_expose_source]" value="1" <?php checked( ! empty( $settings['visitor_expose_source'] ) ); ?>> Tampilkan <code>views_source</code> pada REST publik</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-visitor-sync-delay"><?php esc_html_e( 'Jeda sinkronisasi trafik', 'harianexpress-content-hub' ); ?></label></th>
                        <td><input type="number" min="15" max="600" id="hech-visitor-sync-delay" name="hech_settings[visitor_sync_delay]" value="<?php echo esc_attr( $settings['visitor_sync_delay'] ); ?>"> detik <p class="description">Perubahan pertama dikirim segera; perubahan berikutnya digabung dan dikirim ulang setelah jeda ini.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-groups"><?php esc_html_e( 'Kelompok domain', 'harianexpress-content-hub' ); ?></label></th>
                        <td>
                            <textarea class="large-text code" rows="8" id="hech-groups" name="hech_settings[groups_text]"><?php echo esc_textarea( $this->groups_to_text( $settings['groups'] ) ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Format satu baris: daerah=bali.harianexpress.com,jateng.harianexpress.com. Group all otomatis memakai semua sumber aktif.', 'harianexpress-content-hub' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hech-patterns"><?php esc_html_e( 'URL Google Apps Script lama', 'harianexpress-content-hub' ); ?></label></th>
                        <td>
                            <textarea class="large-text code" rows="4" id="hech-patterns" name="hech_settings[legacy_patterns_text]"><?php echo esc_textarea( implode( "\n", (array) $settings['legacy_patterns'] ) ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Satu URL per baris. Plugin juga mendeteksi endpoint script.google.com yang memiliki parameter aggregator.', 'harianexpress-content-hub' ); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <hr>
            <h2><?php esc_html_e( 'Sinkronisasi dan pemeriksaan', 'harianexpress-content-hub' ); ?></h2>
            <p>
                <button type="button" class="button button-primary" id="hech-test-connection"><?php esc_html_e( 'Tes koneksi ke Hub', 'harianexpress-content-hub' ); ?></button>
                <button type="button" class="button" id="hech-backfill"><?php esc_html_e( 'Masukkan semua artikel lama ke antrean', 'harianexpress-content-hub' ); ?></button>
                <button type="button" class="button" id="hech-process-queue"><?php esc_html_e( 'Proses antrean sekarang', 'harianexpress-content-hub' ); ?></button>
            </p>
            <div id="hech-action-status" style="max-width:900px;"></div>

            <p><strong><?php esc_html_e( 'Endpoint widget lokal:', 'harianexpress-content-hub' ); ?></strong><br><code><?php echo esc_html( HECH_Plugin::mode_allows_hub() ? rest_url( 'he-hub/v1/posts' ) : rest_url( 'he-hub/v1/proxy' ) ); ?></code></p>
            <p><strong><?php esc_html_e( 'Endpoint Dashboard Redaksi:', 'harianexpress-content-hub' ); ?></strong><br><code><?php echo esc_html( HECH_Plugin::mode_allows_hub() ? rest_url( 'he-hub/v1/dashboard' ) : rest_url( 'he-hub/v1/dashboard-proxy' ) ); ?></code></p>

            <?php if ( $source_rows ) : ?>
                <h2><?php esc_html_e( 'Sumber yang terdaftar pada Hub', 'harianexpress-content-hub' ); ?></h2>
                <table class="widefat striped" style="max-width:1100px;">
                    <thead><tr><th>Domain</th><th>Nama</th><th>Aktif</th><th>Terakhir terlihat (UTC)</th><th>Error terakhir</th></tr></thead>
                    <tbody>
                    <?php foreach ( $source_rows as $row ) : ?>
                        <tr>
                            <td><code><?php echo esc_html( $row->domain ); ?></code></td>
                            <td><?php echo esc_html( $row->name ); ?></td>
                            <td>
                                <?php echo (int) $row->active ? 'Ya' : 'Tidak'; ?>
                                <?php
                                $toggle_url = wp_nonce_url(
                                    add_query_arg(
                                        array(
                                            'action' => 'hech_toggle_source',
                                            'domain' => rawurlencode( $row->domain ),
                                            'active' => (int) $row->active ? 0 : 1,
                                        ),
                                        admin_url( 'admin-post.php' )
                                    ),
                                    'hech_toggle_source_' . $row->domain
                                );
                                ?>
                                <br><a href="<?php echo esc_url( $toggle_url ); ?>"><?php echo (int) $row->active ? esc_html__( 'Nonaktifkan', 'harianexpress-content-hub' ) : esc_html__( 'Aktifkan', 'harianexpress-content-hub' ); ?></a>
                            </td>
                            <td><?php echo esc_html( $row->last_seen_at ); ?></td>
                            <td><?php echo esc_html( $row->last_error ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    private function stat_box( $label, $value ) {
        ?>
        <div style="background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:14px 16px;">
            <div style="font-size:12px;color:#646970;margin-bottom:5px;"><?php echo esc_html( $label ); ?></div>
            <div style="font-size:20px;font-weight:600;overflow-wrap:anywhere;"><?php echo esc_html( $value ); ?></div>
        </div>
        <?php
    }


    public function toggle_source() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Akses ditolak.', 'harianexpress-content-hub' ) );
        }

        $domain = isset( $_GET['domain'] ) ? HECH_Plugin::normalize_domain( rawurldecode( wp_unslash( $_GET['domain'] ) ) ) : '';
        $active = isset( $_GET['active'] ) ? (int) (bool) absint( $_GET['active'] ) : 0;
        check_admin_referer( 'hech_toggle_source_' . $domain );

        if ( $domain ) {
            global $wpdb;
            $wpdb->update(
                HECH_DB::table( 'sources' ),
                array(
                    'active'     => $active,
                    'updated_at' => current_time( 'mysql', true ),
                ),
                array( 'source_hash' => md5( $domain ) ),
                array( '%d', '%s' ),
                array( '%s' )
            );
            HECH_Plugin::bump_cache_generation();
        }

        wp_safe_redirect( admin_url( 'options-general.php?page=hech-settings' ) );
        exit;
    }

    private function verify_ajax() {
        check_ajax_referer( 'hech_admin_actions', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Akses ditolak.', 'harianexpress-content-hub' ) ), 403 );
        }
    }

    public function ajax_backfill_batch() {
        $this->verify_ajax();
        if ( ! HECH_Plugin::mode_allows_source() ) {
            wp_send_json_error( array( 'message' => __( 'Mode Source tidak aktif.', 'harianexpress-content-hub' ) ), 400 );
        }
        $offset = isset( $_POST['offset'] ) ? absint( wp_unslash( $_POST['offset'] ) ) : 0;
        wp_send_json_success( $this->source->queue_all_published_batch( $offset, 50 ) );
    }

    public function ajax_process_queue() {
        $this->verify_ajax();
        global $wpdb;
        $stats   = $this->source->process_outbox( 'manual', 50 );
        $pending = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . HECH_DB::table( 'outbox' ) );
        $stats['pending'] = $pending;
        wp_send_json_success( $stats );
    }

    public function ajax_test_connection() {
        $this->verify_ajax();
        $result = $this->source->ping_hub();
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
        }
        wp_send_json_success( $result );
    }

    public function ajax_generate_secret() {
        $this->verify_ajax();
        wp_send_json_success( array( 'secret' => wp_generate_password( 64, true, true ) ) );
    }
}

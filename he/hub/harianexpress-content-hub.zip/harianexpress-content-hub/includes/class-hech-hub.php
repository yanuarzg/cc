<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_Hub {
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        register_rest_route(
            'he-hub/v1',
            '/posts',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_posts' ),
                'permission_callback' => '__return_true',
                'args'                => $this->public_query_args(),
            )
        );

        register_rest_route(
            'he-hub/v1',
            '/proxy',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_proxy' ),
                'permission_callback' => '__return_true',
                'args'                => $this->public_query_args(),
            )
        );

        register_rest_route(
            'he-hub/v1',
            '/dashboard',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_dashboard' ),
                'permission_callback' => '__return_true',
                'args'                => $this->dashboard_query_args(),
            )
        );

        register_rest_route(
            'he-hub/v1',
            '/dashboard-proxy',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_dashboard_proxy' ),
                'permission_callback' => '__return_true',
                'args'                => $this->dashboard_query_args(),
            )
        );

        register_rest_route(
            'he-hub/v1',
            '/ingest',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_ingest' ),
                'permission_callback' => array( $this, 'verify_signed_request' ),
            )
        );

        register_rest_route(
            'he-hub/v1',
            '/ping',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'rest_ping' ),
                'permission_callback' => array( $this, 'verify_signed_request' ),
            )
        );
    }

    private function public_query_args() {
        return array(
            'group' => array(
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => 'all',
            ),
            'sources' => array(
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => '',
            ),
            'category' => array(
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => '',
            ),
            'category_match' => array(
                'sanitize_callback' => 'sanitize_key',
                'default'           => 'or',
            ),
            'items' => array(
                'sanitize_callback' => 'absint',
                'default'           => 10,
            ),
            'start' => array(
                'sanitize_callback' => 'absint',
                'default'           => 1,
            ),
            'sort' => array(
                'sanitize_callback' => 'sanitize_key',
                'default'           => 'date',
            ),
            'refresh' => array(
                'sanitize_callback' => 'absint',
                'default'           => 0,
            ),
            'nocache' => array(
                'sanitize_callback' => 'absint',
                'default'           => 0,
            ),
        );
    }

    private function dashboard_query_args() {
        return array(
            'group' => array( 'sanitize_callback' => 'sanitize_text_field', 'default' => 'all' ),
            'sources' => array( 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
            'months' => array( 'sanitize_callback' => 'absint', 'default' => 18 ),
            'limit' => array( 'sanitize_callback' => 'absint', 'default' => 30000 ),
            'author' => array( 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
            'refresh' => array( 'sanitize_callback' => 'absint', 'default' => 0 ),
            'nocache' => array( 'sanitize_callback' => 'absint', 'default' => 0 ),
        );
    }

    public function verify_signed_request( WP_REST_Request $request ) {
        if ( ! HECH_Plugin::mode_allows_hub() ) {
            return new WP_Error(
                'hech_hub_disabled',
                __( 'Mode Hub tidak aktif pada situs ini.', 'harianexpress-content-hub' ),
                array( 'status' => 403 )
            );
        }

        $timestamp = (string) $request->get_header( 'x-heh-timestamp' );
        $domain    = HECH_Plugin::normalize_domain( $request->get_header( 'x-heh-domain' ) );
        $signature = (string) $request->get_header( 'x-heh-signature' );

        if ( '' === $timestamp || '' === $domain || '' === $signature ) {
            return new WP_Error(
                'hech_signature_missing',
                __( 'Header autentikasi tidak lengkap.', 'harianexpress-content-hub' ),
                array( 'status' => 401 )
            );
        }

        if ( abs( time() - (int) $timestamp ) > 300 ) {
            return new WP_Error(
                'hech_signature_expired',
                __( 'Tanda tangan permintaan sudah kedaluwarsa.', 'harianexpress-content-hub' ),
                array( 'status' => 401 )
            );
        }

        $secret = (string) HECH_Plugin::setting( 'network_secret', '' );
        if ( '' === $secret ) {
            return new WP_Error(
                'hech_secret_missing',
                __( 'Network Secret belum dikonfigurasi pada Hub.', 'harianexpress-content-hub' ),
                array( 'status' => 500 )
            );
        }

        $expected = hash_hmac(
            'sha256',
            $timestamp . '.' . $domain . '.' . $request->get_body(),
            $secret
        );

        if ( ! hash_equals( $expected, $signature ) ) {
            return new WP_Error(
                'hech_signature_invalid',
                __( 'Tanda tangan permintaan tidak valid.', 'harianexpress-content-hub' ),
                array( 'status' => 403 )
            );
        }

        if ( ! $this->source_is_allowed( $domain ) ) {
            return new WP_Error(
                'hech_source_not_allowed',
                __( 'Domain sumber belum diizinkan oleh Hub.', 'harianexpress-content-hub' ),
                array( 'status' => 403 )
            );
        }

        $request->set_param( '_hech_verified_domain', $domain );
        return true;
    }

    private function source_is_allowed( $domain ) {
        global $wpdb;

        $table = HECH_DB::table( 'sources' );
        $hash  = md5( $domain );
        $row   = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT active FROM {$table} WHERE source_hash = %s LIMIT 1",
                $hash
            )
        );

        if ( $row ) {
            return 1 === (int) $row->active;
        }

        return (bool) HECH_Plugin::setting( 'auto_register_sources', 1 );
    }

    public function rest_ping( WP_REST_Request $request ) {
        $domain = HECH_Plugin::normalize_domain( $request->get_param( '_hech_verified_domain' ) );
        $this->touch_source( $domain, $domain, '' );

        return rest_ensure_response(
            array(
                'ok'      => true,
                'hub'     => HECH_Plugin::current_domain(),
                'source'  => $domain,
                'version' => HECH_VERSION,
                'time'    => gmdate( 'c' ),
            )
        );
    }

    public function rest_ingest( WP_REST_Request $request ) {
        $payload = $request->get_json_params();
        if ( ! is_array( $payload ) ) {
            return new WP_Error(
                'hech_payload_invalid',
                __( 'Payload JSON tidak valid.', 'harianexpress-content-hub' ),
                array( 'status' => 400 )
            );
        }

        $verified_domain = HECH_Plugin::normalize_domain( $request->get_param( '_hech_verified_domain' ) );
        $payload_domain  = HECH_Plugin::normalize_domain( isset( $payload['source_domain'] ) ? $payload['source_domain'] : '' );

        if ( ! $payload_domain || $payload_domain !== $verified_domain ) {
            return new WP_Error(
                'hech_domain_mismatch',
                __( 'Domain pada payload tidak sesuai dengan tanda tangan.', 'harianexpress-content-hub' ),
                array( 'status' => 400 )
            );
        }

        $result = self::ingest_payload( $payload, false );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function ingest_payload( $payload, $trusted_local = false ) {
        global $wpdb;

        if ( ! is_array( $payload ) ) {
            return new WP_Error( 'hech_payload_invalid', __( 'Payload tidak valid.', 'harianexpress-content-hub' ), array( 'status' => 400 ) );
        }

        $source_domain  = HECH_Plugin::normalize_domain( isset( $payload['source_domain'] ) ? $payload['source_domain'] : '' );
        $source_post_id = isset( $payload['source_post_id'] ) ? absint( $payload['source_post_id'] ) : 0;
        $status         = isset( $payload['status'] ) ? sanitize_key( $payload['status'] ) : 'publish';

        if ( ! $source_domain || ! $source_post_id ) {
            return new WP_Error(
                'hech_payload_required',
                __( 'source_domain dan source_post_id wajib tersedia.', 'harianexpress-content-hub' ),
                array( 'status' => 400 )
            );
        }

        if ( ! $trusted_local && ! HECH_Plugin::mode_allows_hub() ) {
            return new WP_Error( 'hech_hub_disabled', __( 'Mode Hub tidak aktif.', 'harianexpress-content-hub' ), array( 'status' => 403 ) );
        }

        $articles = HECH_DB::table( 'articles' );
        $terms    = HECH_DB::table( 'terms' );
        $hash     = md5( $source_domain );
        $now      = current_time( 'mysql', true );

        $existing_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$articles} WHERE source_hash = %s AND source_post_id = %d LIMIT 1",
                $hash,
                $source_post_id
            )
        );

        if ( in_array( $status, array( 'delete', 'deleted' ), true ) ) {
            if ( $existing_id ) {
                $wpdb->delete( $terms, array( 'article_id' => (int) $existing_id ), array( '%d' ) );
                $wpdb->delete( $articles, array( 'id' => (int) $existing_id ), array( '%d' ) );
            }
            self::touch_source_static(
                $source_domain,
                isset( $payload['source_name'] ) ? sanitize_text_field( $payload['source_name'] ) : $source_domain,
                ''
            );
            HECH_Plugin::bump_cache_generation();

            return array(
                'ok'      => true,
                'action'  => 'deleted',
                'source'  => $source_domain,
                'post_id' => $source_post_id,
            );
        }

        $published_at = self::sanitize_datetime( isset( $payload['published_at'] ) ? $payload['published_at'] : '' );
        $modified_at  = self::sanitize_datetime( isset( $payload['modified_at'] ) ? $payload['modified_at'] : '' );
        $author       = isset( $payload['author'] ) && is_array( $payload['author'] ) ? $payload['author'] : array();
        $metrics      = isset( $payload['metrics'] ) && is_array( $payload['metrics'] ) ? $payload['metrics'] : array();
        $views        = isset( $metrics['views'] ) ? HECH_Visitor::normalize_count( $metrics['views'] ) : 0;

        $clean = array(
            'source_hash'   => $hash,
            'source_domain' => $source_domain,
            'source_name'   => isset( $payload['source_name'] ) ? sanitize_text_field( $payload['source_name'] ) : '',
            'source_post_id'=> $source_post_id,
            'title'         => isset( $payload['title'] ) ? wp_strip_all_tags( $payload['title'] ) : '',
            'url'           => isset( $payload['url'] ) ? esc_url_raw( $payload['url'] ) : '',
            'image_url'     => isset( $payload['image_url'] ) ? esc_url_raw( $payload['image_url'] ) : '',
            'excerpt'       => isset( $payload['excerpt'] ) ? wp_kses_post( $payload['excerpt'] ) : '',
            'author_id'     => isset( $author['id'] ) ? absint( $author['id'] ) : 0,
            'author_name'   => isset( $author['name'] ) ? sanitize_text_field( $author['name'] ) : '',
            'author_url'    => isset( $author['url'] ) ? esc_url_raw( $author['url'] ) : '',
            'author_avatar_url' => isset( $author['avatar_url'] ) ? esc_url_raw( $author['avatar_url'] ) : '',
            'views'         => $views,
            'views_source'  => isset( $metrics['views_source'] ) ? sanitize_text_field( $metrics['views_source'] ) : '',
            'metrics_updated_at' => self::sanitize_datetime( isset( $metrics['views_updated_at'] ) ? $metrics['views_updated_at'] : $modified_at ),
            'published_at'  => $published_at,
            'modified_at'   => $modified_at,
            'status'        => in_array( $status, array( 'publish', 'draft', 'pending', 'future', 'private', 'trash' ), true ) ? $status : 'draft',
            'payload_hash'  => hash( 'sha256', wp_json_encode( $payload ) ),
            'updated_at'    => $now,
        );

        if ( $existing_id ) {
            $wpdb->update(
                $articles,
                $clean,
                array( 'id' => (int) $existing_id )
            );
            $article_id = (int) $existing_id;
            $action     = 'updated';
        } else {
            $clean['created_at'] = $now;
            $wpdb->insert( $articles, $clean );
            $article_id = (int) $wpdb->insert_id;
            $action     = 'inserted';
        }

        if ( ! $article_id ) {
            return new WP_Error(
                'hech_database_error',
                $wpdb->last_error ? $wpdb->last_error : __( 'Artikel gagal disimpan.', 'harianexpress-content-hub' ),
                array( 'status' => 500 )
            );
        }

        $wpdb->delete( $terms, array( 'article_id' => $article_id ), array( '%d' ) );
        self::insert_terms( $article_id, 'category', isset( $payload['categories'] ) ? $payload['categories'] : array() );
        self::insert_terms( $article_id, 'post_tag', isset( $payload['tags'] ) ? $payload['tags'] : array() );

        self::touch_source_static( $source_domain, $clean['source_name'], '' );
        HECH_Plugin::bump_cache_generation();

        return array(
            'ok'         => true,
            'action'     => $action,
            'article_id' => $article_id,
            'source'     => $source_domain,
            'post_id'    => $source_post_id,
        );
    }

    private static function insert_terms( $article_id, $taxonomy, $items ) {
        global $wpdb;
        $table = HECH_DB::table( 'terms' );

        if ( ! is_array( $items ) ) {
            return;
        }

        foreach ( $items as $item ) {
            if ( is_string( $item ) ) {
                $name = sanitize_text_field( $item );
                $slug = sanitize_title( $item );
            } elseif ( is_array( $item ) ) {
                $name = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
                $slug = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : sanitize_title( $name );
            } else {
                continue;
            }

            if ( '' === $slug ) {
                continue;
            }

            $wpdb->insert(
                $table,
                array(
                    'article_id' => (int) $article_id,
                    'taxonomy'   => sanitize_key( $taxonomy ),
                    'term_slug'  => $slug,
                    'term_name'  => $name,
                ),
                array( '%d', '%s', '%s', '%s' )
            );
        }
    }

    private static function sanitize_datetime( $value ) {
        if ( ! $value ) {
            return current_time( 'mysql', true );
        }
        $timestamp = strtotime( (string) $value );
        if ( ! $timestamp ) {
            return current_time( 'mysql', true );
        }
        return gmdate( 'Y-m-d H:i:s', $timestamp );
    }

    private function touch_source( $domain, $name, $error ) {
        self::touch_source_static( $domain, $name, $error );
    }

    public static function touch_source_static( $domain, $name, $error ) {
        global $wpdb;
        $table = HECH_DB::table( 'sources' );
        $domain = HECH_Plugin::normalize_domain( $domain );
        if ( ! $domain ) {
            return;
        }

        $hash = md5( $domain );
        $now  = current_time( 'mysql', true );
        $id   = $wpdb->get_var(
            $wpdb->prepare( "SELECT id FROM {$table} WHERE source_hash = %s LIMIT 1", $hash )
        );

        $data = array(
            'domain'       => $domain,
            'name'         => $name ? sanitize_text_field( $name ) : $domain,
            'last_seen_at' => $now,
            'last_error'   => sanitize_textarea_field( $error ),
            'updated_at'   => $now,
        );

        if ( $id ) {
            $wpdb->update( $table, $data, array( 'id' => (int) $id ) );
        } else {
            $data['source_hash'] = $hash;
            $data['active']      = 1;
            $data['created_at']  = $now;
            $wpdb->insert( $table, $data );
        }
    }

    public function rest_posts( WP_REST_Request $request ) {
        if ( ! HECH_Plugin::mode_allows_hub() ) {
            return new WP_Error(
                'hech_hub_disabled',
                __( 'Mode Hub tidak aktif pada situs ini.', 'harianexpress-content-hub' ),
                array( 'status' => 503 )
            );
        }

        $params = $this->normalize_query_params( $request );
        $result = $this->query_posts( $params );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $response = rest_ensure_response( $result );
        $ttl = max( 5, min( 300, absint( HECH_Plugin::setting( 'api_cache_ttl', 45 ) ) ) );
        $response->header( 'Cache-Control', 'public, max-age=' . $ttl . ', stale-while-revalidate=' . ( $ttl * 4 ) );
        $response->header( 'X-HECH-Source', 'local-hub' );
        return $response;
    }

    public function rest_proxy( WP_REST_Request $request ) {
        if ( HECH_Plugin::mode_allows_hub() ) {
            return $this->rest_posts( $request );
        }

        $hub_url = HECH_Plugin::normalize_base_url( HECH_Plugin::setting( 'hub_url', '' ) );
        if ( ! $hub_url ) {
            return new WP_Error(
                'hech_hub_url_missing',
                __( 'URL Hub belum dikonfigurasi.', 'harianexpress-content-hub' ),
                array( 'status' => 503 )
            );
        }

        $params = $this->normalize_query_params( $request );
        $params_for_url = $params;

        $remote_url = add_query_arg( $params_for_url, $hub_url . '/wp-json/he-hub/v1/posts' );
        $cache_ttl  = max( 5, min( 300, absint( HECH_Plugin::setting( 'proxy_cache_ttl', 45 ) ) ) );
        $cache_key  = 'hech_proxy_' . md5( $remote_url );
        $stale_key  = $cache_key . '_stale';
        $refresh    = ! empty( $params['refresh'] );

        if ( ! $refresh ) {
            $cached = get_transient( $cache_key );
            if ( false !== $cached && is_array( $cached ) ) {
                $response = rest_ensure_response( $cached );
                $response->header( 'X-HECH-Source', 'proxy-cache' );
                return $response;
            }
        }

        $remote = wp_safe_remote_get(
            $remote_url,
            array(
                'timeout'     => 10,
                'redirection' => 3,
                'headers'     => array( 'Accept' => 'application/json' ),
            )
        );

        if ( is_wp_error( $remote ) ) {
            $stale = get_transient( $stale_key );
            if ( false !== $stale && is_array( $stale ) ) {
                $response = rest_ensure_response( $stale );
                $response->header( 'X-HECH-Source', 'proxy-stale' );
                return $response;
            }
            return new WP_Error( 'hech_proxy_failed', $remote->get_error_message(), array( 'status' => 502 ) );
        }

        $code = wp_remote_retrieve_response_code( $remote );
        $body = wp_remote_retrieve_body( $remote );
        $data = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
            $stale = get_transient( $stale_key );
            if ( false !== $stale && is_array( $stale ) ) {
                $response = rest_ensure_response( $stale );
                $response->header( 'X-HECH-Source', 'proxy-stale' );
                return $response;
            }
            return new WP_Error(
                'hech_proxy_invalid_response',
                sprintf( __( 'Hub mengembalikan respons HTTP %d.', 'harianexpress-content-hub' ), (int) $code ),
                array( 'status' => 502 )
            );
        }

        set_transient( $cache_key, $data, $cache_ttl );
        set_transient( $stale_key, $data, 15 * MINUTE_IN_SECONDS );

        $response = rest_ensure_response( $data );
        $response->header( 'Cache-Control', 'public, max-age=' . $cache_ttl );
        $response->header( 'X-HECH-Source', 'remote-hub' );
        return $response;
    }

    public function rest_dashboard( WP_REST_Request $request ) {
        if ( ! HECH_Plugin::mode_allows_hub() ) {
            return new WP_Error( 'hech_hub_disabled', __( 'Mode Hub tidak aktif pada situs ini.', 'harianexpress-content-hub' ), array( 'status' => 503 ) );
        }

        $params = $this->normalize_dashboard_params( $request );
        $result = $this->query_dashboard( $params );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $ttl = max( 15, min( 600, absint( HECH_Plugin::setting( 'dashboard_cache_ttl', 90 ) ) ) );
        $response = rest_ensure_response( $result );
        if ( ! empty( $params['refresh'] ) ) {
            $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
            $response->header( 'Pragma', 'no-cache' );
            $response->header( 'Expires', '0' );
        } else {
            $response->header( 'Cache-Control', 'public, max-age=' . $ttl . ', stale-while-revalidate=' . ( $ttl * 5 ) );
        }
        $response->header( 'ETag', '"' . md5( wp_json_encode( $result['meta'] ) . '|' . ( isset( $result['coverage']['updatedAt'] ) ? $result['coverage']['updatedAt'] : '' ) ) . '"' );
        $response->header( 'X-HECH-Source', 'dashboard-local-hub' );
        return $response;
    }

    public function rest_dashboard_proxy( WP_REST_Request $request ) {
        if ( HECH_Plugin::mode_allows_hub() ) {
            return $this->rest_dashboard( $request );
        }

        $hub_url = HECH_Plugin::normalize_base_url( HECH_Plugin::setting( 'hub_url', '' ) );
        if ( ! $hub_url ) {
            return new WP_Error( 'hech_hub_url_missing', __( 'URL Hub belum dikonfigurasi.', 'harianexpress-content-hub' ), array( 'status' => 503 ) );
        }

        $params = $this->normalize_dashboard_params( $request );
        $remote_url = add_query_arg( $params, $hub_url . '/wp-json/he-hub/v1/dashboard' );
        $ttl = max( 15, min( 600, absint( HECH_Plugin::setting( 'dashboard_cache_ttl', 90 ) ) ) );
        $cache_key = 'hech_dashboard_proxy_' . md5( $remote_url );
        $stale_key = $cache_key . '_stale';

        if ( empty( $params['refresh'] ) ) {
            $cached = get_transient( $cache_key );
            if ( false !== $cached && is_array( $cached ) ) {
                $response = rest_ensure_response( $cached );
                $response->header( 'Cache-Control', 'public, max-age=' . $ttl );
                $response->header( 'X-HECH-Source', 'dashboard-proxy-cache' );
                return $response;
            }
        }

        $remote = wp_safe_remote_get( $remote_url, array(
            'timeout' => 30,
            'redirection' => 3,
            'headers' => array( 'Accept' => 'application/json', 'Accept-Encoding' => 'gzip, deflate' ),
        ) );
        if ( is_wp_error( $remote ) ) {
            $stale = get_transient( $stale_key );
            if ( false !== $stale && is_array( $stale ) ) {
                return rest_ensure_response( $stale );
            }
            return new WP_Error( 'hech_dashboard_proxy_failed', $remote->get_error_message(), array( 'status' => 502 ) );
        }

        $code = (int) wp_remote_retrieve_response_code( $remote );
        $data = json_decode( wp_remote_retrieve_body( $remote ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
            $stale = get_transient( $stale_key );
            if ( false !== $stale && is_array( $stale ) ) {
                return rest_ensure_response( $stale );
            }
            return new WP_Error( 'hech_dashboard_proxy_invalid', sprintf( __( 'Hub mengembalikan HTTP %d.', 'harianexpress-content-hub' ), $code ), array( 'status' => 502 ) );
        }

        set_transient( $cache_key, $data, $ttl );
        set_transient( $stale_key, $data, 6 * HOUR_IN_SECONDS );
        $response = rest_ensure_response( $data );
        $response->header( 'Cache-Control', 'public, max-age=' . $ttl );
        $response->header( 'X-HECH-Source', 'dashboard-remote-hub' );
        return $response;
    }

    private function normalize_dashboard_params( WP_REST_Request $request ) {
        $sources = trim( (string) $request->get_param( 'sources' ) );
        $group = $sources ? $sources : trim( (string) $request->get_param( 'group' ) );
        if ( '' === $group ) {
            $group = 'all';
        }
        $default_months = max( 1, min( 60, absint( HECH_Plugin::setting( 'dashboard_history_months', 18 ) ) ) );
        $max_posts = max( 1000, min( 50000, absint( HECH_Plugin::setting( 'dashboard_max_posts', 30000 ) ) ) );
        return array(
            'group' => $group,
            'months' => max( 1, min( 60, absint( $request->get_param( 'months' ) ) ?: $default_months ) ),
            'limit' => max( 100, min( $max_posts, absint( $request->get_param( 'limit' ) ) ?: $max_posts ) ),
            'author' => sanitize_text_field( $request->get_param( 'author' ) ?: '' ),
            'refresh' => (bool) ( absint( $request->get_param( 'refresh' ) ) || absint( $request->get_param( 'nocache' ) ) ),
        );
    }

    private function query_dashboard( $params ) {
        global $wpdb;

        $generation = (int) get_option( 'hech_cache_generation', 1 );
        $ttl = max( 15, min( 600, absint( HECH_Plugin::setting( 'dashboard_cache_ttl', 90 ) ) ) );
        $cache_key = 'hech_dashboard_' . md5( $generation . '|' . wp_json_encode( $params ) );
        if ( empty( $params['refresh'] ) ) {
            $cached = get_transient( $cache_key );
            if ( false !== $cached && is_array( $cached ) ) {
                return $cached;
            }
        }

        $articles = HECH_DB::table( 'articles' );
        $terms = HECH_DB::table( 'terms' );
        $sources_table = HECH_DB::table( 'sources' );
        $domains = $this->resolve_domains( $params['group'] );
        if ( ! $domains ) {
            return array(
                'schemaVersion' => 1,
                'generatedAt' => gmdate( 'c' ),
                'hub' => HECH_Plugin::current_domain(),
                'posts' => array(),
                'sourceHealth' => array(),
                'coverage' => array( 'oldest' => '', 'newest' => '', 'updatedAt' => gmdate( 'c' ), 'complete' => true, 'cappedSources' => 0, 'trafficMetrics' => array() ),
                'meta' => array( 'count' => 0, 'limit' => (int) $params['limit'], 'truncated' => false, 'months' => (int) $params['months'] ),
            );
        }

        $month_start = new DateTimeImmutable( 'first day of this month 00:00:00', new DateTimeZone( 'UTC' ) );
        $cutoff = $month_start->modify( '-' . max( 0, (int) $params['months'] - 1 ) . ' months' )->format( 'Y-m-d H:i:s' );

        $where = array( "a.status = 'publish'", 'a.published_at >= %s' );
        $values = array( $cutoff );
        $domain_placeholders = implode( ',', array_fill( 0, count( $domains ), '%s' ) );
        $where[] = "a.source_domain IN ({$domain_placeholders})";
        foreach ( $domains as $domain ) {
            $values[] = $domain;
        }
        if ( '' !== $params['author'] ) {
            $where[] = 'a.author_name = %s';
            $values[] = $params['author'];
        }

        $query_limit = (int) $params['limit'] + 1;
        $values[] = $query_limit;
        $sql = "SELECT a.id, a.source_post_id, a.source_domain, a.title, a.url, a.image_url,
                       a.author_id, a.author_name, a.author_url, a.author_avatar_url,
                       a.views, a.views_source, a.metrics_updated_at, a.published_at, a.modified_at
                FROM {$articles} a
                WHERE " . implode( ' AND ', $where ) . "
                ORDER BY a.published_at DESC, a.id DESC
                LIMIT %d";
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) );
        if ( null === $rows ) {
            return new WP_Error( 'hech_dashboard_query_failed', $wpdb->last_error ?: __( 'Query dashboard gagal.', 'harianexpress-content-hub' ), array( 'status' => 500 ) );
        }

        $truncated = count( $rows ) > (int) $params['limit'];
        if ( $truncated ) {
            $rows = array_slice( $rows, 0, (int) $params['limit'] );
        }

        $labels = array();
        $ids = array_map( static function ( $row ) { return (int) $row->id; }, $rows );
        foreach ( array_chunk( $ids, 800 ) as $chunk ) {
            if ( ! $chunk ) {
                continue;
            }
            $placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
            $term_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT article_id, term_name FROM {$terms} WHERE taxonomy = 'category' AND article_id IN ({$placeholders}) ORDER BY id ASC",
                $chunk
            ) );
            foreach ( (array) $term_rows as $term_row ) {
                $article_id = (int) $term_row->article_id;
                if ( ! isset( $labels[ $article_id ] ) ) {
                    $labels[ $article_id ] = array();
                }
                $labels[ $article_id ][] = sanitize_text_field( $term_row->term_name );
            }
        }

        $placeholder = 'https://harianexpress.com/wp-content/uploads/2024/12/HE-Logo-Besar.png';
        $posts = array();
        $traffic_metrics = array();
        foreach ( $rows as $row ) {
            $published = $row->published_at ? strtotime( $row->published_at . ' UTC' ) : time();
            $modified = $row->modified_at ? strtotime( $row->modified_at . ' UTC' ) : $published;
            $traffic_available = '' !== (string) $row->views_source && 'not_found' !== (string) $row->views_source;
            if ( $traffic_available ) {
                $traffic_metrics['views'] = true;
            }
            $posts[] = array(
                'id' => (string) $row->source_post_id,
                'title' => html_entity_decode( (string) $row->title, ENT_QUOTES, get_bloginfo( 'charset' ) ),
                'link' => esc_url_raw( $row->url ),
                'thumb' => $row->image_url ? esc_url_raw( $row->image_url ) : $placeholder,
                'date' => gmdate( 'c', $published ),
                'modified' => gmdate( 'c', $modified ),
                'author' => $row->author_name ? sanitize_text_field( $row->author_name ) : 'Unknown',
                'rawAuthor' => $row->author_name ? sanitize_text_field( $row->author_name ) : 'Unknown',
                'sourceAuthorId' => (string) $row->author_id,
                'authorUrl' => esc_url_raw( $row->author_url ),
                'authorAvatar' => esc_url_raw( $row->author_avatar_url ),
                'labels' => isset( $labels[ (int) $row->id ] ) ? array_values( array_unique( $labels[ (int) $row->id ] ) ) : array(),
                'source' => sanitize_text_field( $row->source_domain ),
                'traffic' => (int) $row->views,
                'trafficAvailable' => $traffic_available,
                'trafficSourceField' => sanitize_text_field( $row->views_source ),
                'trafficMetric' => $traffic_available ? 'views' : '',
            );
        }

        $health_rows = $wpdb->get_results( "SELECT domain, active, last_seen_at, last_error FROM {$sources_table} ORDER BY domain ASC" );
        $source_health = array();
        foreach ( (array) $health_rows as $row ) {
            if ( ! in_array( HECH_Plugin::normalize_domain( $row->domain ), $domains, true ) ) {
                continue;
            }
            $error = sanitize_text_field( $row->last_error );
            $source_health[] = array(
                'source' => sanitize_text_field( $row->domain ),
                'status' => $error ? 'partial' : 'success',
                'fetchedPages' => 1,
                'targetPages' => 1,
                'reportedPages' => 1,
                'capped' => false,
                'error' => $error,
                'lastSeenAt' => $row->last_seen_at ? mysql_to_rfc3339( $row->last_seen_at ) : '',
            );
        }

        $newest = $posts ? $posts[0]['date'] : '';
        $oldest = $posts ? $posts[ count( $posts ) - 1 ]['date'] : '';
        $complete = ! $truncated;
        foreach ( $source_health as $health ) {
            if ( 'success' !== $health['status'] ) {
                $complete = false;
                break;
            }
        }

        $result = array(
            'schemaVersion' => 1,
            'generatedAt' => gmdate( 'c' ),
            'hub' => HECH_Plugin::current_domain(),
            'posts' => $posts,
            'sourceHealth' => $source_health,
            'coverage' => array(
                'oldest' => $oldest,
                'newest' => $newest,
                'updatedAt' => gmdate( 'c' ),
                'complete' => $complete,
                'cappedSources' => $truncated ? 1 : 0,
                'trafficMetrics' => array_keys( $traffic_metrics ),
            ),
            'meta' => array(
                'count' => count( $posts ),
                'limit' => (int) $params['limit'],
                'truncated' => $truncated,
                'months' => (int) $params['months'],
                'cutoff' => gmdate( 'c', strtotime( $cutoff . ' UTC' ) ),
            ),
        );

        set_transient( $cache_key, $result, $ttl );
        return $result;
    }

    private function normalize_query_params( WP_REST_Request $request ) {
        $group    = trim( (string) $request->get_param( 'group' ) );
        $sources  = trim( (string) $request->get_param( 'sources' ) );
        $category = trim( (string) $request->get_param( 'category' ) );
        $items    = max( 1, min( 100, absint( $request->get_param( 'items' ) ) ?: 10 ) );
        $start    = max( 1, min( 10000, absint( $request->get_param( 'start' ) ) ?: 1 ) );
        $sort     = sanitize_key( $request->get_param( 'sort' ) ?: 'date' );
        $match    = sanitize_key( $request->get_param( 'category_match' ) ?: 'or' );
        $refresh  = absint( $request->get_param( 'refresh' ) ) || absint( $request->get_param( 'nocache' ) );

        if ( $sources ) {
            $group = $sources;
        }
        if ( '' === $group ) {
            $group = 'all';
        }
        if ( ! in_array( $sort, array( 'date', 'source' ), true ) ) {
            $sort = 'date';
        }
        if ( ! in_array( $match, array( 'or', 'and' ), true ) ) {
            $match = 'or';
        }

        return array(
            'group'          => $group,
            'category'       => $category,
            'items'          => $items,
            'start'          => $start,
            'sort'           => $sort,
            'category_match' => $match,
            'refresh'        => (bool) $refresh,
        );
    }

    private function query_posts( $params ) {
        global $wpdb;

        $generation = (int) get_option( 'hech_cache_generation', 1 );
        $cache_ttl  = max( 5, min( 300, absint( HECH_Plugin::setting( 'api_cache_ttl', 45 ) ) ) );
        $cache_key  = 'hech_query_' . md5( $generation . '|' . wp_json_encode( $params ) );

        if ( empty( $params['refresh'] ) ) {
            $cached = get_transient( $cache_key );
            if ( false !== $cached && is_array( $cached ) ) {
                return $cached;
            }
        }

        $articles = HECH_DB::table( 'articles' );
        $terms    = HECH_DB::table( 'terms' );
        $domains  = $this->resolve_domains( $params['group'] );
        $cats     = $this->parse_categories( $params['category'] );
        $offset   = max( 0, (int) $params['start'] - 1 );

        $where  = array( "a.status = 'publish'" );
        $values = array();

        if ( is_array( $domains ) && count( $domains ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $domains ), '%s' ) );
            $where[]      = "a.source_domain IN ({$placeholders})";
            foreach ( $domains as $domain ) {
                $values[] = $domain;
            }
        }

        if ( count( $cats ) ) {
            $cat_placeholders = implode( ',', array_fill( 0, count( $cats ), '%s' ) );
            if ( 'and' === $params['category_match'] && count( $cats ) > 1 ) {
                $where[] = "a.id IN (
                    SELECT t.article_id
                    FROM {$terms} t
                    WHERE t.taxonomy = 'category'
                      AND t.term_slug IN ({$cat_placeholders})
                    GROUP BY t.article_id
                    HAVING COUNT(DISTINCT t.term_slug) = %d
                )";
                foreach ( $cats as $cat ) {
                    $values[] = $cat;
                }
                $values[] = count( $cats );
            } else {
                $where[] = "EXISTS (
                    SELECT 1 FROM {$terms} t
                    WHERE t.article_id = a.id
                      AND t.taxonomy = 'category'
                      AND t.term_slug IN ({$cat_placeholders})
                )";
                foreach ( $cats as $cat ) {
                    $values[] = $cat;
                }
            }
        }

        $order = 'source' === $params['sort']
            ? 'a.source_domain ASC, a.published_at DESC, a.id DESC'
            : 'a.published_at DESC, a.id DESC';

        $sql = "SELECT a.id, a.title, a.url, a.image_url, a.published_at, a.source_domain
                FROM {$articles} a
                WHERE " . implode( ' AND ', $where ) . "
                ORDER BY {$order}
                LIMIT %d OFFSET %d";

        $values[] = (int) $params['items'];
        $values[] = (int) $offset;
        $prepared = $wpdb->prepare( $sql, $values );
        $rows     = $wpdb->get_results( $prepared );

        if ( null === $rows ) {
            return new WP_Error(
                'hech_query_failed',
                $wpdb->last_error ? $wpdb->last_error : __( 'Query artikel gagal.', 'harianexpress-content-hub' ),
                array( 'status' => 500 )
            );
        }

        $placeholder = 'https://harianexpress.com/wp-content/uploads/2024/12/HE-Logo-Besar.png';
        $result = array();

        foreach ( $rows as $row ) {
            $timestamp = $row->published_at ? strtotime( $row->published_at . ' UTC' ) : time();
            $result[] = array(
                'title'   => html_entity_decode( (string) $row->title, ENT_QUOTES, get_bloginfo( 'charset' ) ),
                'link'    => esc_url_raw( $row->url ),
                'rawDate' => gmdate( 'c', $timestamp ),
                'date'    => wp_date( 'j F Y', $timestamp ),
                'source'  => $row->source_domain,
                'img'     => $row->image_url ? esc_url_raw( $row->image_url ) : $placeholder,
            );
        }

        set_transient( $cache_key, $result, $cache_ttl );
        return $result;
    }

    private function parse_categories( $value ) {
        if ( ! $value ) {
            return array();
        }

        $parts = preg_split( '/\s*,\s*/', (string) $value );
        $parts = array_map( 'sanitize_title', $parts );
        $parts = array_filter( array_unique( $parts ) );
        return array_values( $parts );
    }

    private function resolve_domains( $group_or_sources ) {
        global $wpdb;

        $raw = trim( (string) $group_or_sources );
        if ( '' === $raw || 'all' === strtolower( $raw ) ) {
            $table = HECH_DB::table( 'sources' );
            $domains = $wpdb->get_col( "SELECT domain FROM {$table} WHERE active = 1 ORDER BY domain ASC" );
            return array_values( array_filter( array_map( array( 'HECH_Plugin', 'normalize_domain' ), $domains ) ) );
        }

        if ( false !== strpos( $raw, ',' ) ) {
            return $this->clean_domain_list( explode( ',', $raw ) );
        }

        $groups = HECH_Plugin::setting( 'groups', array() );
        $key    = sanitize_key( $raw );
        if ( is_array( $groups ) && isset( $groups[ $key ] ) && is_array( $groups[ $key ] ) ) {
            return $this->clean_domain_list( $groups[ $key ] );
        }

        if ( false !== strpos( $raw, '.' ) ) {
            $domain = HECH_Plugin::normalize_domain( $raw );
            return $domain ? array( $domain ) : array();
        }

        // Kompatibilitas perilaku GAS lama: group tidak dikenal kembali ke semua sumber aktif.
        $table = HECH_DB::table( 'sources' );
        $domains = $wpdb->get_col( "SELECT domain FROM {$table} WHERE active = 1 ORDER BY domain ASC" );
        return array_values( array_filter( array_map( array( 'HECH_Plugin', 'normalize_domain' ), $domains ) ) );
    }

    private function clean_domain_list( $domains ) {
        $clean = array();
        foreach ( (array) $domains as $domain ) {
            $domain = HECH_Plugin::normalize_domain( $domain );
            if ( $domain ) {
                $clean[] = $domain;
            }
        }
        return array_values( array_unique( $clean ) );
    }
}

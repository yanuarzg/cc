<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_Source {
    public function __construct( $register_hooks = true ) {
        if ( ! $register_hooks ) {
            return;
        }
        add_action( 'transition_post_status', array( $this, 'on_transition_post_status' ), 10, 3 );
        add_action( 'before_delete_post', array( $this, 'on_before_delete_post' ), 10, 1 );
        add_action( 'hech_process_outbox_event', array( $this, 'process_outbox' ) );
        add_action( 'hech_visitor_count_changed', array( $this, 'on_visitor_count_changed' ), 10, 3 );
    }

    public function on_visitor_count_changed( $post_id, $count, $meta_key ) {
        unset( $count, $meta_key );
        if ( ! HECH_Plugin::mode_allows_source() ) {
            return;
        }
        $post = get_post( $post_id );
        if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
            return;
        }
        $payload = $this->build_payload( $post_id, 'publish' );
        if ( ! is_wp_error( $payload ) ) {
            $this->queue_payload( 'post:' . $post_id, $post_id, $payload );
        }
    }

    public function on_transition_post_status( $new_status, $old_status, $post ) {
        if ( ! HECH_Plugin::mode_allows_source() ) {
            return;
        }
        if ( ! $post instanceof WP_Post || 'post' !== $post->post_type ) {
            return;
        }
        if ( wp_is_post_revision( $post->ID ) || wp_is_post_autosave( $post->ID ) ) {
            return;
        }

        $allowed_statuses = array( 'publish', 'draft', 'pending', 'future', 'private', 'trash' );
        if ( ! in_array( $new_status, $allowed_statuses, true ) ) {
            return;
        }

        $payload = $this->build_payload( $post->ID, $new_status );
        if ( is_wp_error( $payload ) ) {
            return;
        }
        $this->queue_payload( 'post:' . $post->ID, $post->ID, $payload );
    }

    public function on_before_delete_post( $post_id ) {
        if ( ! HECH_Plugin::mode_allows_source() ) {
            return;
        }
        $post = get_post( $post_id );
        if ( ! $post || 'post' !== $post->post_type || wp_is_post_revision( $post_id ) ) {
            return;
        }

        $payload = array(
            'source_post_id' => (int) $post_id,
            'source_domain'  => HECH_Plugin::current_domain(),
            'source_name'    => get_bloginfo( 'name' ),
            'title'          => get_the_title( $post_id ),
            'url'            => get_permalink( $post_id ),
            'image_url'      => '',
            'excerpt'        => '',
            'published_at'   => gmdate( 'c' ),
            'modified_at'    => gmdate( 'c' ),
            'author'          => $this->get_author_payload( $post ),
            'metrics'         => HECH_Visitor::post_metrics( $post_id ),
            'categories'     => array(),
            'tags'           => array(),
            'status'         => 'delete',
        );

        $this->queue_payload( 'post:' . $post_id, $post_id, $payload );
    }

    public function build_payload( $post_id, $status = null ) {
        $post = get_post( $post_id );
        if ( ! $post || 'post' !== $post->post_type ) {
            return new WP_Error( 'hech_post_not_found', __( 'Post tidak ditemukan.', 'harianexpress-content-hub' ) );
        }

        $status = $status ? sanitize_key( $status ) : sanitize_key( $post->post_status );

        return array(
            'source_post_id' => (int) $post_id,
            'source_domain'  => HECH_Plugin::current_domain(),
            'source_name'    => get_bloginfo( 'name' ),
            'title'          => get_the_title( $post_id ),
            'url'            => get_permalink( $post_id ),
            'image_url'      => get_the_post_thumbnail_url( $post_id, 'medium_large' ) ?: '',
            'excerpt'        => wp_strip_all_tags( get_the_excerpt( $post_id ) ),
            'published_at'   => $this->post_date_iso( $post, 'post_date_gmt' ),
            'modified_at'    => $this->post_date_iso( $post, 'post_modified_gmt' ),
            'author'          => $this->get_author_payload( $post ),
            'metrics'         => HECH_Visitor::post_metrics( $post_id ),
            'categories'     => $this->get_terms_payload( $post_id, 'category' ),
            'tags'           => $this->get_terms_payload( $post_id, 'post_tag' ),
            'status'         => $status,
        );
    }

    private function get_author_payload( WP_Post $post ) {
        $author_id = absint( $post->post_author );
        return array(
            'id'         => $author_id,
            'name'       => $author_id ? get_the_author_meta( 'display_name', $author_id ) : '',
            'url'        => $author_id ? get_author_posts_url( $author_id ) : '',
            'avatar_url' => $author_id ? get_avatar_url( $author_id, array( 'size' => 192 ) ) : '',
        );
    }

    private function post_date_iso( WP_Post $post, $field ) {
        $value = isset( $post->{$field} ) ? $post->{$field} : '';
        if ( ! $value || '0000-00-00 00:00:00' === $value ) {
            return gmdate( 'c' );
        }
        return gmdate( 'c', strtotime( $value . ' UTC' ) );
    }

    private function get_terms_payload( $post_id, $taxonomy ) {
        $terms = wp_get_post_terms( $post_id, $taxonomy );
        if ( is_wp_error( $terms ) ) {
            return array();
        }

        $result = array();
        foreach ( $terms as $term ) {
            $result[] = array(
                'id'   => (int) $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
            );
        }
        return $result;
    }

    public function queue_payload( $event_key, $post_id, $payload ) {
        global $wpdb;
        $table = HECH_DB::table( 'outbox' );
        $now   = current_time( 'mysql', true );

        $wpdb->replace(
            $table,
            array(
                'event_key'      => sanitize_text_field( $event_key ),
                'source_post_id' => (int) $post_id,
                'payload'        => wp_json_encode( $payload ),
                'attempts'       => 0,
                'next_attempt'   => $now,
                'last_error'     => '',
                'created_at'     => $now,
                'updated_at'     => $now,
            ),
            array( '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s' )
        );

        HECH_Plugin::schedule_cron();
        if ( ! wp_next_scheduled( 'hech_process_outbox_event', array( 'single' ) ) ) {
            wp_schedule_single_event( time() + 5, 'hech_process_outbox_event', array( 'single' ) );
        }
    }

    public function process_outbox( $single = null, $limit = 20 ) {
        $empty_stats = array( 'processed' => 0, 'success' => 0, 'failed' => 0 );

        if ( ! HECH_Plugin::mode_allows_source() ) {
            return $empty_stats;
        }

        if ( ! $this->acquire_outbox_lock() ) {
            $empty_stats['locked'] = true;
            return $empty_stats;
        }

        try {
            global $wpdb;
            $table = HECH_DB::table( 'outbox' );
            $limit = max( 1, min( 100, absint( $limit ) ) );
            $now   = current_time( 'mysql', true );

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$table}
                     WHERE next_attempt <= %s AND attempts < 10
                     ORDER BY id ASC LIMIT %d",
                    $now,
                    $limit
                )
            );

            $stats = $empty_stats;
            foreach ( (array) $rows as $row ) {
                $stats['processed']++;
                $payload = json_decode( $row->payload, true );
                if ( ! is_array( $payload ) ) {
                    $this->mark_failed( $row, 'Payload queue bukan JSON yang valid.' );
                    $stats['failed']++;
                    continue;
                }

                $result = $this->send_payload( $payload );
                if ( is_wp_error( $result ) ) {
                    $this->mark_failed( $row, $result->get_error_message() );
                    $stats['failed']++;
                } else {
                    $wpdb->delete( $table, array( 'id' => (int) $row->id ), array( '%d' ) );
                    $stats['success']++;
                }
            }

            return $stats;
        } finally {
            delete_option( 'hech_outbox_process_lock' );
        }
    }

    private function acquire_outbox_lock() {
        $option = 'hech_outbox_process_lock';
        $now    = time();
        $locked = (int) get_option( $option, 0 );

        if ( $locked && ( $now - $locked ) < 300 ) {
            return false;
        }

        if ( $locked ) {
            delete_option( $option );
        }

        return add_option( $option, $now, '', false );
    }

    private function mark_failed( $row, $message ) {
        global $wpdb;
        $table    = HECH_DB::table( 'outbox' );
        $attempts = (int) $row->attempts + 1;
        $delay    = min( HOUR_IN_SECONDS, 30 * ( 2 ** min( 7, $attempts ) ) );

        $wpdb->update(
            $table,
            array(
                'attempts'     => $attempts,
                'next_attempt' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
                'last_error'   => sanitize_textarea_field( $message ),
                'updated_at'   => current_time( 'mysql', true ),
            ),
            array( 'id' => (int) $row->id ),
            array( '%d', '%s', '%s', '%s' ),
            array( '%d' )
        );
    }

    public function send_payload( $payload ) {
        $hub_url = HECH_Plugin::normalize_base_url( HECH_Plugin::setting( 'hub_url', '' ) );
        $secret  = (string) HECH_Plugin::setting( 'network_secret', '' );
        $domain  = HECH_Plugin::current_domain();

        if ( ! $hub_url ) {
            return new WP_Error( 'hech_hub_url_missing', __( 'URL Hub belum diisi.', 'harianexpress-content-hub' ) );
        }
        if ( '' === $secret ) {
            return new WP_Error( 'hech_secret_missing', __( 'Network Secret belum diisi.', 'harianexpress-content-hub' ) );
        }

        $hub_domain = HECH_Plugin::normalize_domain( $hub_url );
        if ( $hub_domain === $domain && HECH_Plugin::mode_allows_hub() ) {
            return HECH_Hub::ingest_payload( $payload, true );
        }

        $body      = wp_json_encode( $payload );
        $timestamp = (string) time();
        $signature = hash_hmac( 'sha256', $timestamp . '.' . $domain . '.' . $body, $secret );
        $endpoint  = $hub_url . '/wp-json/he-hub/v1/ingest';

        $response = wp_safe_remote_post(
            $endpoint,
            array(
                'timeout'     => 15,
                'redirection' => 3,
                'headers'     => array(
                    'Accept'             => 'application/json',
                    'Content-Type'       => 'application/json; charset=utf-8',
                    'X-HEH-Domain'       => $domain,
                    'X-HEH-Timestamp'    => $timestamp,
                    'X-HEH-Signature'    => $signature,
                ),
                'body'        => $body,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 ) {
            $message = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : 'HTTP ' . $code;
            return new WP_Error( 'hech_hub_rejected', sanitize_text_field( $message ) );
        }

        return is_array( $data ) ? $data : array( 'ok' => true );
    }

    public function ping_hub() {
        $hub_url = HECH_Plugin::normalize_base_url( HECH_Plugin::setting( 'hub_url', '' ) );
        $secret  = (string) HECH_Plugin::setting( 'network_secret', '' );
        $domain  = HECH_Plugin::current_domain();

        if ( ! $hub_url || '' === $secret ) {
            return new WP_Error( 'hech_settings_incomplete', __( 'URL Hub atau Network Secret belum diisi.', 'harianexpress-content-hub' ) );
        }

        if ( HECH_Plugin::normalize_domain( $hub_url ) === $domain && HECH_Plugin::mode_allows_hub() ) {
            return array( 'ok' => true, 'hub' => $domain, 'local' => true );
        }

        $body      = wp_json_encode( array( 'action' => 'ping' ) );
        $timestamp = (string) time();
        $signature = hash_hmac( 'sha256', $timestamp . '.' . $domain . '.' . $body, $secret );

        $response = wp_safe_remote_post(
            $hub_url . '/wp-json/he-hub/v1/ping',
            array(
                'timeout' => 12,
                'headers' => array(
                    'Accept'          => 'application/json',
                    'Content-Type'    => 'application/json; charset=utf-8',
                    'X-HEH-Domain'    => $domain,
                    'X-HEH-Timestamp' => $timestamp,
                    'X-HEH-Signature' => $signature,
                ),
                'body' => $body,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'hech_ping_failed', isset( $data['message'] ) ? $data['message'] : 'HTTP ' . $code );
        }
        return $data;
    }

    public function queue_all_published_batch( $offset = 0, $batch = 50 ) {
        $offset = max( 0, absint( $offset ) );
        $batch  = max( 1, min( 200, absint( $batch ) ) );

        $query = new WP_Query(
            array(
                'post_type'              => 'post',
                'post_status'            => 'publish',
                'posts_per_page'         => $batch,
                'offset'                 => $offset,
                'orderby'                => 'ID',
                'order'                  => 'ASC',
                'fields'                 => 'ids',
                'no_found_rows'          => false,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            )
        );

        foreach ( $query->posts as $post_id ) {
            $payload = $this->build_payload( $post_id, 'publish' );
            if ( ! is_wp_error( $payload ) ) {
                $this->queue_payload( 'post:' . $post_id, $post_id, $payload );
            }
        }

        return array(
            'queued'      => count( $query->posts ),
            'next_offset' => $offset + count( $query->posts ),
            'total'       => (int) $query->found_posts,
            'done'        => ( $offset + count( $query->posts ) ) >= (int) $query->found_posts,
        );
    }
}

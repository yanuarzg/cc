<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_Compat {
    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 0 );
        add_filter( 'script_loader_tag', array( $this, 'script_tag' ), 10, 3 );
    }


    public function script_tag( $tag, $handle, $src ) {
        if ( 'hech-legacy-compat' !== $handle ) {
            return $tag;
        }
        if ( false === strpos( $tag, 'data-cfasync=' ) ) {
            $tag = str_replace( '<script ', '<script data-cfasync="false" data-no-optimize="1" ', $tag );
        }
        return $tag;
    }

    public function enqueue() {
        if ( is_admin() || 'disabled' === HECH_Plugin::setting( 'mode', 'source' ) ) {
            return;
        }

        $endpoint = HECH_Plugin::mode_allows_hub()
            ? rest_url( 'he-hub/v1/posts' )
            : rest_url( 'he-hub/v1/proxy' );

        wp_enqueue_script(
            'hech-legacy-compat',
            HECH_URL . 'assets/js/compat.js',
            array(),
            HECH_VERSION,
            false
        );

        wp_localize_script(
            'hech-legacy-compat',
            'HECH_COMPAT',
            array(
                'endpoint'       => esc_url_raw( $endpoint ),
                'legacyPatterns' => array_values( array_filter( (array) HECH_Plugin::setting( 'legacy_patterns', array() ) ) ),
                'debug'          => defined( 'WP_DEBUG' ) && WP_DEBUG,
            )
        );
    }
}

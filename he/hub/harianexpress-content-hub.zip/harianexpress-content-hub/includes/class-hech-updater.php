<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HECH_Updater {
    const MANIFEST_URL = 'https://raw.githubusercontent.com/yanuarzg/cc/main/he/hub/update.json';
    const CACHE_KEY = 'hech_update_manifest_v110';
    const SLUG = 'harianexpress-content-hub';

    public function __construct() {
        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_update' ) );
        add_filter( 'plugins_api', array( $this, 'plugin_information' ), 20, 3 );
        add_filter( 'upgrader_pre_download', array( $this, 'verify_package' ), 10, 4 );
        add_action( 'upgrader_process_complete', array( $this, 'clear_cache_after_upgrade' ), 10, 2 );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_details_assets' ) );
        add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 4 );
    }

    private function allowed_hosts( $type ) {
        $hosts = 'manifest' === $type
            ? array( 'raw.githubusercontent.com' )
            : array( 'github.com', 'codeload.github.com', 'objects.githubusercontent.com', 'raw.githubusercontent.com' );
        return apply_filters( 'hech_allowed_update_hosts', $hosts, $type );
    }

    private function valid_url( $url, $type ) {
        $url = esc_url_raw( $url );
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        $scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
        return 'https' === $scheme && wp_http_validate_url( $url ) && in_array( $host, $this->allowed_hosts( $type ), true );
    }

    public function get_manifest( $force = false ) {
        if ( ! $force ) {
            $cached = get_site_transient( self::CACHE_KEY );
            if ( is_array( $cached ) ) {
                return ! empty( $cached['manifest'] ) && is_array( $cached['manifest'] ) ? $cached['manifest'] : false;
            }
        }

        $url = apply_filters( 'hech_update_manifest_url', self::MANIFEST_URL );
        if ( ! $this->valid_url( $url, 'manifest' ) ) {
            return false;
        }

        $response = wp_safe_remote_get( $url, array(
            'timeout' => 12,
            'redirection' => 3,
            'sslverify' => true,
            'headers' => array(
                'Accept' => 'application/json',
                'User-Agent' => 'HE-Content-Hub/' . HECH_VERSION . '; ' . home_url( '/' ),
            ),
        ) );

        if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
            set_site_transient( self::CACHE_KEY, array( 'manifest' => array() ), 30 * MINUTE_IN_SECONDS );
            return false;
        }

        $manifest = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $manifest ) ) {
            set_site_transient( self::CACHE_KEY, array( 'manifest' => array() ), 30 * MINUTE_IN_SECONDS );
            return false;
        }

        $version = isset( $manifest['new_version'] ) ? $manifest['new_version'] : ( isset( $manifest['version'] ) ? $manifest['version'] : '' );
        $package = isset( $manifest['package'] ) ? $manifest['package'] : ( isset( $manifest['download_url'] ) ? $manifest['download_url'] : '' );
        if ( ! preg_match( '/^[0-9]+(?:\.[0-9A-Za-z-]+)+$/', (string) $version ) || ! $this->valid_url( $package, 'package' ) ) {
            set_site_transient( self::CACHE_KEY, array( 'manifest' => array() ), 30 * MINUTE_IN_SECONDS );
            return false;
        }

        $manifest['new_version'] = sanitize_text_field( $version );
        $manifest['package'] = esc_url_raw( $package );
        if ( ! empty( $manifest['sha256'] ) && preg_match( '/^[a-f0-9]{64}$/i', (string) $manifest['sha256'] ) ) {
            $manifest['sha256'] = strtolower( (string) $manifest['sha256'] );
        } else {
            unset( $manifest['sha256'] );
        }

        set_site_transient( self::CACHE_KEY, array( 'manifest' => $manifest ), 6 * HOUR_IN_SECONDS );
        return $manifest;
    }

    private function update_object( $manifest ) {
        $update = new stdClass();
        $update->slug = self::SLUG;
        $update->plugin = plugin_basename( HECH_FILE );
        $update->new_version = $manifest['new_version'];
        $update->package = $manifest['package'];
        $update->url = isset( $manifest['homepage'] ) ? esc_url_raw( $manifest['homepage'] ) : '';
        foreach ( array( 'requires', 'requires_php', 'tested' ) as $field ) {
            if ( isset( $manifest[ $field ] ) ) {
                $update->{$field} = sanitize_text_field( $manifest[ $field ] );
            }
        }
        if ( isset( $manifest['icons'] ) && is_array( $manifest['icons'] ) ) {
            $update->icons = array_map( 'esc_url_raw', $manifest['icons'] );
        }
        if ( isset( $manifest['banners'] ) && is_array( $manifest['banners'] ) ) {
            $update->banners = array_map( 'esc_url_raw', $manifest['banners'] );
        }
        return $update;
    }

    public function check_for_update( $transient ) {
        if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
            return $transient;
        }
        $manifest = $this->get_manifest();
        if ( ! $manifest ) {
            return $transient;
        }
        $plugin_file = plugin_basename( HECH_FILE );
        $update = $this->update_object( $manifest );
        if ( version_compare( HECH_VERSION, $manifest['new_version'], '<' ) ) {
            $transient->response[ $plugin_file ] = $update;
        } elseif ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
            $transient->no_update[ $plugin_file ] = $update;
        }
        return $transient;
    }

    public function plugin_information( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
            return $result;
        }
        $manifest = $this->get_manifest();
        if ( ! $manifest ) {
            return $result;
        }
        $info = new stdClass();
        $info->name = isset( $manifest['name'] ) ? sanitize_text_field( $manifest['name'] ) : 'HarianExpress Content Hub';
        $info->slug = self::SLUG;
        $info->version = $manifest['new_version'];
        $info->author = isset( $manifest['author'] ) ? wp_kses_post( $manifest['author'] ) : 'HarianExpress';
        $info->homepage = isset( $manifest['homepage'] ) ? esc_url_raw( $manifest['homepage'] ) : '';
        $info->download_link = $manifest['package'];
        $info->external = true;
        foreach ( array( 'short_description', 'requires', 'requires_php', 'tested', 'last_updated' ) as $field ) {
            if ( isset( $manifest[ $field ] ) ) {
                $info->{$field} = sanitize_text_field( $manifest[ $field ] );
            }
        }
        if ( isset( $manifest['sections'] ) && is_array( $manifest['sections'] ) ) {
            $info->sections = array_map( 'wp_kses_post', $manifest['sections'] );
        }
        return $info;
    }

    public function verify_package( $reply, $package, $upgrader, $hook_extra ) {
        unset( $upgrader );
        if ( false !== $reply ) {
            return $reply;
        }
        $plugins = array();
        if ( ! empty( $hook_extra['plugin'] ) ) {
            $plugins[] = $hook_extra['plugin'];
        }
        if ( ! empty( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ) {
            $plugins = array_merge( $plugins, $hook_extra['plugins'] );
        }
        if ( ! in_array( plugin_basename( HECH_FILE ), $plugins, true ) ) {
            return $reply;
        }
        $manifest = $this->get_manifest();
        if ( ! $manifest || empty( $manifest['sha256'] ) ) {
            return $reply;
        }
        if ( untrailingslashit( $package ) !== untrailingslashit( $manifest['package'] ) ) {
            return new WP_Error( 'hech_package_mismatch', 'URL paket pembaruan tidak cocok dengan manifest.' );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url( $package, 300 );
        if ( is_wp_error( $file ) ) {
            return $file;
        }
        $actual = hash_file( 'sha256', $file );
        if ( ! hash_equals( $manifest['sha256'], strtolower( (string) $actual ) ) ) {
            @unlink( $file );
            return new WP_Error( 'hech_checksum_mismatch', 'Checksum SHA-256 paket pembaruan tidak cocok.' );
        }
        return $file;
    }

    public function clear_cache_after_upgrade( $upgrader, $options ) {
        unset( $upgrader );
        if ( ! empty( $options['action'] ) && 'update' === $options['action'] && ! empty( $options['type'] ) && 'plugin' === $options['type'] ) {
            delete_site_transient( self::CACHE_KEY );
        }
    }

    public function enqueue_details_assets( $hook ) {
        if ( 'plugins.php' === $hook || 'update-core.php' === $hook ) {
            add_thickbox();
        }
    }

    public function plugin_row_meta( $links, $plugin_file, $plugin_data, $status ) {
        unset( $plugin_data, $status );
        if ( plugin_basename( HECH_FILE ) !== $plugin_file ) {
            return $links;
        }
        $details_url = add_query_arg( array(
            'tab' => 'plugin-information',
            'plugin' => self::SLUG,
            'TB_iframe' => 'true',
            'width' => 772,
            'height' => 700,
        ), self_admin_url( 'plugin-install.php' ) );
        $links[] = '<a href="' . esc_url( $details_url ) . '" class="thickbox open-plugin-details-modal">' . esc_html__( 'View details', 'harianexpress-content-hub' ) . '</a>';
        $links[] = '<a href="https://github.com/yanuarzg/cc/tree/main/he/hub" target="_blank" rel="noopener noreferrer">GitHub</a>';
        return $links;
    }
}

<?php
/**
 * Data sengaja tidak dihapus saat plugin dicopot untuk mencegah kehilangan indeks.
 * Hapus tabel hech_* secara manual hanya apabila data benar-benar tidak diperlukan.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

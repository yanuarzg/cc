=== HarianExpress Content Hub ===
Contributors: harianexpress
Tags: content-hub, rest-api, visitor-count, multisource, dashboard
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.1.1
License: GPLv2 or later

Hub artikel dan visitor analytics berbasis push untuk widget multi-source serta Dashboard Redaksi.

== Description ==

Plugin yang sama dipasang pada situs pusat dan semua situs sumber.

* Mode Hub menyimpan indeks artikel dari seluruh jaringan.
* Mode Source mengirim artikel, author, kategori, gambar, dan visitor metric ke Hub.
* Widget multi-source lama tetap kompatibel melalui endpoint posts/proxy dan interceptor Google Apps Script.
* Dashboard Redaksi memakai satu endpoint Hub, bukan REST API puluhan domain.
* Field REST `views` dan `views_source` dari HE Visitor Count REST Field sudah terintegrasi.
* Pembaruan otomatis memakai manifest GitHub `he/hub/update.json` dengan validasi SHA-256 opsional.

Endpoint utama:

* `/wp-json/he-hub/v1/posts`
* `/wp-json/he-hub/v1/proxy`
* `/wp-json/he-hub/v1/dashboard`
* `/wp-json/he-hub/v1/dashboard-proxy`

== Upgrade Notice ==

Setelah memperbarui dari 1.0.0, jalankan backfill artikel pada seluruh Source agar kolom author dan visitor metric lama ikut masuk ke Hub. Setelah verifikasi, plugin HE Visitor Count REST Field lama dapat dinonaktifkan.

== Changelog ==

= 1.1.1 =
* Trafik dikirim segera lalu didebounce, menggantikan milestone kelipatan 25.
* Refresh dashboard melewati cache browser/CDN.
* Dashboard selalu memeriksa data Hub terbaru di belakang layar.

= 1.1.0 =
* Menggabungkan resolver visitor count dan REST field `views`.
* Menambahkan visitor metric ke payload Source dan indeks Hub.
* Menambahkan author ID, nama, URL, avatar, views, dan sumber views pada database Hub.
* Menambahkan endpoint Dashboard Redaksi satu-request dengan cache dan metadata cakupan.
* Menambahkan endpoint dashboard proxy untuk situs Source.
* Menambahkan updater GitHub berbasis update.json dan SHA-256.
* Menambahkan pengaturan visitor serta cache/riwayat/batas dashboard.
* Mempertahankan kompatibilitas widget multi-source lama.

= 1.0.0 =
* Rilis awal Content Hub berbasis push.

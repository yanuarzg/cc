<?php
/**
 * Plugin Name: HarianExpress Content Hub
 * Description: Hub artikel dan visitor analytics berbasis push untuk widget multi-source serta Dashboard Redaksi berkecepatan tinggi.
 * Version: 1.1.1
 * Author: HarianExpress
 * Plugin URI: https://github.com/yanuarzg/cc/tree/main/he/hub
 * Update URI: https://raw.githubusercontent.com/yanuarzg/cc/main/he/hub/update.json
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: harianexpress-content-hub
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'HECH_VERSION', '1.1.1' );
define( 'HECH_FILE', __FILE__ );
define( 'HECH_DIR', plugin_dir_path( __FILE__ ) );
define( 'HECH_URL', plugin_dir_url( __FILE__ ) );

require_once HECH_DIR . 'includes/class-hech-db.php';
require_once HECH_DIR . 'includes/class-hech-visitor.php';
require_once HECH_DIR . 'includes/class-hech-updater.php';
require_once HECH_DIR . 'includes/class-hech-plugin.php';
require_once HECH_DIR . 'includes/class-hech-hub.php';
require_once HECH_DIR . 'includes/class-hech-source.php';
require_once HECH_DIR . 'includes/class-hech-compat.php';
require_once HECH_DIR . 'includes/class-hech-settings.php';

register_activation_hook( __FILE__, array( 'HECH_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'HECH_Plugin', 'deactivate' ) );

HECH_Plugin::instance();

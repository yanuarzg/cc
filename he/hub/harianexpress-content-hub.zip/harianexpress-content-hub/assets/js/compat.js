(function (window, document) {
  'use strict';

  var config = window.HECH_COMPAT || {};
  if (!config.endpoint || typeof window.fetch !== 'function') {
    return;
  }

  var originalFetch = window.fetch.bind(window);
  var originalXHROpen = window.XMLHttpRequest && window.XMLHttpRequest.prototype.open;
  var activeContext = null;
  var preexistingLegacyLoader = window.loadMultiWPFromAggregator;
  var assignedLegacyLoader;
  var wrapperCache = null;

  function log() {
    if (config.debug && window.console && console.debug) {
      console.debug.apply(console, ['[HE Content Hub]'].concat([].slice.call(arguments)));
    }
  }

  function parseUrl(value) {
    try {
      return new URL(value, window.location.href);
    } catch (error) {
      return null;
    }
  }

  function isLegacyAggregator(url) {
    if (!url) return false;

    var patterns = Array.isArray(config.legacyPatterns) ? config.legacyPatterns : [];
    for (var i = 0; i < patterns.length; i++) {
      if (patterns[i] && url.href.indexOf(patterns[i]) === 0) {
        return true;
      }
    }

    return url.hostname === 'script.google.com' &&
      url.pathname.indexOf('/macros/s/') === 0 &&
      (url.searchParams.has('group') ||
       url.searchParams.has('sources') ||
       url.searchParams.has('category') ||
       url.searchParams.has('items'));
  }

  function attr(container, name) {
    if (!container || !container.getAttribute) return '';
    return container.getAttribute(name) || '';
  }

  function firstValue() {
    for (var i = 0; i < arguments.length; i++) {
      if (arguments[i] !== null && arguments[i] !== undefined && String(arguments[i]).trim() !== '') {
        return String(arguments[i]);
      }
    }
    return '';
  }

  function rewriteUrl(rawUrl) {
    var legacyUrl = parseUrl(rawUrl);
    if (!isLegacyAggregator(legacyUrl)) {
      return null;
    }

    var target = parseUrl(config.endpoint);
    if (!target) return null;

    var group = firstValue(
      activeContext && activeContext.group,
      activeContext && activeContext.sources,
      legacyUrl.searchParams.get('group'),
      legacyUrl.searchParams.get('sources'),
      'all'
    );

    var category = firstValue(
      activeContext && activeContext.category,
      legacyUrl.searchParams.get('category')
    );

    var items = firstValue(
      activeContext && activeContext.items,
      legacyUrl.searchParams.get('items'),
      '10'
    );

    var start = firstValue(
      activeContext && activeContext.start,
      legacyUrl.searchParams.get('start'),
      '1'
    );

    var sort = firstValue(
      activeContext && activeContext.sort,
      legacyUrl.searchParams.get('sort'),
      'date'
    );

    var categoryMatch = firstValue(
      activeContext && activeContext.categoryMatch,
      legacyUrl.searchParams.get('category_match'),
      legacyUrl.searchParams.get('match'),
      'or'
    );

    target.searchParams.set('group', group);
    target.searchParams.set('category', category);
    target.searchParams.set('items', items);
    target.searchParams.set('start', start);
    target.searchParams.set('sort', sort);
    target.searchParams.set('category_match', categoryMatch);

    if (legacyUrl.searchParams.get('refresh') === '1' || legacyUrl.searchParams.get('nocache') === '1') {
      target.searchParams.set('refresh', '1');
    }

    log('Mengalihkan aggregator:', legacyUrl.href, '→', target.href);
    return target.href;
  }

  window.fetch = function (input, init) {
    var isRequest = typeof window.Request !== 'undefined' && input instanceof window.Request;
    var rawUrl = isRequest ? input.url : String(input);
    var rewritten = rewriteUrl(rawUrl);

    if (!rewritten) {
      return originalFetch(input, init);
    }

    if (isRequest) {
      try {
        return originalFetch(new window.Request(rewritten, input), init);
      } catch (error) {
        return originalFetch(rewritten, init);
      }
    }

    return originalFetch(rewritten, init);
  };

  if (originalXHROpen) {
    window.XMLHttpRequest.prototype.open = function (method, url) {
      var rewritten = rewriteUrl(String(url));
      var args = [].slice.call(arguments);
      if (rewritten) {
        args[1] = rewritten;
      }
      return originalXHROpen.apply(this, args);
    };
  }

  // Menangkap fungsi global lama tanpa mengubah file tema. Wrapper hanya memberi
  // konteks elemen agar data-sort, data-start, data-category-match, data-group,
  // dan data-sources ikut diteruskan ketika fungsi lama melakukan fetch.
  try {
    Object.defineProperty(window, 'loadMultiWPFromAggregator', {
      configurable: true,
      enumerable: true,
      get: function () {
        if (typeof assignedLegacyLoader !== 'function') {
          return assignedLegacyLoader;
        }
        if (!wrapperCache) {
          wrapperCache = function (container) {
            var previous = activeContext;
            var groupAttr = attr(container, 'data-group');
            var sourcesAttr = attr(container, 'data-sources');
            var selectedAttr = groupAttr ? 'data-group' : (sourcesAttr ? 'data-sources' : 'data-group');
            var originalAttr = attr(container, selectedAttr);
            var sortValue = attr(container, 'data-sort') || 'date';
            var matchValue = attr(container, 'data-category-match') || 'or';
            var salt = '|hech:' + sortValue + ':' + matchValue;

            activeContext = {
              group: groupAttr,
              sources: sourcesAttr,
              category: attr(container, 'data-category'),
              items: attr(container, 'data-items'),
              start: attr(container, 'data-start'),
              sort: sortValue,
              categoryMatch: matchValue
            };

            // Membuat key deduplikasi fungsi lama tetap berbeda untuk sort/match
            // yang berbeda, tanpa mengubah nilai yang dikirim ke endpoint Hub.
            if (container && container.setAttribute) {
              container.setAttribute(selectedAttr, (originalAttr || 'all') + salt);
            }

            try {
              return assignedLegacyLoader.apply(this, arguments);
            } finally {
              if (container && container.setAttribute) {
                if (originalAttr) {
                  container.setAttribute(selectedAttr, originalAttr);
                } else {
                  container.removeAttribute(selectedAttr);
                }
              }
              activeContext = previous;
            }
          };
        }
        return wrapperCache;
      },
      set: function (fn) {
        assignedLegacyLoader = fn;
        wrapperCache = null;
      }
    });
    if (typeof preexistingLegacyLoader === 'function') {
      assignedLegacyLoader = preexistingLegacyLoader;
    }
  } catch (error) {
    log('Property hook tidak dapat dipasang:', error);
  }
})(window, document);

(function ($) {
  'use strict';

  var cfg = window.HECH_ADMIN || {};
  var $status = $('#hech-action-status');

  function show(message, type) {
    type = type || 'info';
    var $notice = $('<div>').addClass('notice notice-' + type + ' inline');
    $('<p>').text(String(message)).appendTo($notice);
    $status.empty().append($notice);
  }

  function request(action, data) {
    return $.post(cfg.ajaxUrl, $.extend({ action: action, nonce: cfg.nonce }, data || {}));
  }

  $('#hech-generate-secret').on('click', function () {
    request('hech_generate_secret').done(function (response) {
      if (response.success) {
        $('#hech-secret').val(response.data.secret);
        show('Secret baru dibuat. Simpan pengaturan lalu salin secret yang sama ke seluruh Source.', 'warning');
      }
    }).fail(function () { show(cfg.labels.requestFailed, 'error'); });
  });

  $('#hech-test-connection').on('click', function () {
    show(cfg.labels.working, 'info');
    request('hech_test_connection').done(function (response) {
      if (response.success) {
        show('Koneksi berhasil. Hub: ' + (response.data.hub || '-') + '.', 'success');
      } else {
        show(response.data && response.data.message ? response.data.message : cfg.labels.requestFailed, 'error');
      }
    }).fail(function (xhr) {
      var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
      show(message || cfg.labels.requestFailed, 'error');
    });
  });

  $('#hech-process-queue').on('click', function () {
    show(cfg.labels.working, 'info');
    request('hech_process_queue').done(function (response) {
      if (response.success) {
        var d = response.data;
        show('Diproses: ' + d.processed + ', berhasil: ' + d.success + ', gagal: ' + d.failed + ', tersisa: ' + d.pending + '.', d.failed ? 'warning' : 'success');
      } else {
        show(cfg.labels.requestFailed, 'error');
      }
    }).fail(function () { show(cfg.labels.requestFailed, 'error'); });
  });

  $('#hech-backfill').on('click', function () {
    var offset = 0;
    var $button = $(this).prop('disabled', true);

    function next() {
      request('hech_backfill_batch', { offset: offset }).done(function (response) {
        if (!response.success) {
          show(response.data && response.data.message ? response.data.message : cfg.labels.requestFailed, 'error');
          $button.prop('disabled', false);
          return;
        }

        var d = response.data;
        offset = d.next_offset;
        show('Artikel dimasukkan ke antrean: ' + offset + ' dari ' + d.total + '.', 'info');

        if (d.done) {
          show(cfg.labels.backfillDone + ' Total: ' + d.total + '.', 'success');
          $button.prop('disabled', false);
          return;
        }
        window.setTimeout(next, 250);
      }).fail(function () {
        show(cfg.labels.requestFailed, 'error');
        $button.prop('disabled', false);
      });
    }

    next();
  });
})(jQuery);
